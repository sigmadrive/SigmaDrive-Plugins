//! Optional browser-host fallback when desktop duplication is unavailable.
//! No picker, permission change, border suppression, cross-session cache or worker process.
use std::{convert::TryFrom, io, thread, time::{Duration, Instant}};
use windows::{
    core::{factory, Interface},
    Graphics::{Capture::{Direct3D11CaptureFrame, Direct3D11CaptureFramePool, GraphicsCaptureItem, GraphicsCaptureSession, IGraphicsCaptureSessionStatics, IDirect3D11CaptureFramePoolStatics2}, DirectX::{Direct3D11::IDirect3DDevice, DirectXPixelFormat}},
    Win32::{Foundation::HMODULE, Graphics::{Direct3D::{D3D_DRIVER_TYPE_HARDWARE,D3D_DRIVER_TYPE_WARP}, Direct3D11::*, Dxgi::{Common::*, IDXGIAdapter, IDXGIDevice}, Gdi::HMONITOR}, System::WinRT::{Direct3D11::{CreateDirect3D11DeviceFromDXGIDevice, IDirect3DDxgiInterfaceAccess}, Graphics::Capture::IGraphicsCaptureItemInterop, RoInitialize, RoUninitialize, RO_INIT_MULTITHREADED}},
};

const MAX_BYTES:usize=64*1024*1024;
fn failure(error:windows::core::Error)->io::Error {io::Error::new(io::ErrorKind::Other,format!("WGC operation failed: {:08x}",error.code().0 as u32))}
fn frame_pending(error:&windows::core::Error)->bool {
    // windows-core maps a successful null WinRT frame to Error::empty() (code zero).
    matches!(error.code().0 as u32,0|0x80004003)
}
fn geometry(width:i32,height:i32)->io::Result<(usize,usize)> {
    let row=usize::try_from(width).ok().and_then(|n|n.checked_mul(4));
    let bytes=row.and_then(|n|usize::try_from(height).ok().and_then(|h|n.checked_mul(h)));
    match (row,bytes) { (Some(row),Some(bytes)) if width>0&&height>0&&bytes<=MAX_BYTES=>Ok((row,bytes)),_=>Err(io::Error::new(io::ErrorKind::InvalidInput,"WGC geometry denied")) }
}
fn copy_rows(source:&[u8],pitch:usize,width:i32,height:i32,data:&mut Vec<u8>)->io::Result<()> {
    let (row,bytes)=geometry(width,height)?;
    let extent=pitch.checked_mul(height as usize).filter(|n|*n<=MAX_BYTES&&*n<=source.len());
    if pitch<row||extent.is_none(){return Err(io::Error::new(io::ErrorKind::InvalidData,"WGC row layout denied"));}
    data.resize(bytes,0);
    for y in 0..height as usize{data[y*row..(y+1)*row].copy_from_slice(&source[y*pitch..y*pitch+row]);}
    Ok(())
}
pub fn allowed(option:&str,namespace:&str)->bool {
    option=="Y"&&namespace.len()==64&&namespace.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))
}
struct Apartment(bool);
impl Drop for Apartment {fn drop(&mut self){if self.0{unsafe{RoUninitialize();}}}}
// Generated static methods cache factory pointers beyond this capture's apartment.
// A refresh can tear down that apartment, invalidating the next cached call.
fn session_supported()->windows::core::Result<bool>{
    let statics=factory::<GraphicsCaptureSession,IGraphicsCaptureSessionStatics>()?;
    let mut supported=false;
    unsafe{(statics.vtable().IsSupported)(statics.as_raw(),&mut supported).ok()?;}
    Ok(supported)
}
fn create_pool(device:&IDirect3DDevice,size:windows::Graphics::SizeInt32)->windows::core::Result<Direct3D11CaptureFramePool>{
    let statics=factory::<Direct3D11CaptureFramePool,IDirect3D11CaptureFramePoolStatics2>()?;
    let mut pool=std::ptr::null_mut();
    unsafe{
        (statics.vtable().CreateFreeThreaded)(statics.as_raw(),device.as_raw(),DirectXPixelFormat::B8G8R8A8UIntNormalized,2,size,&mut pool).ok()?;
        windows::core::Type::from_abi(pool)
    }
}
pub struct CapturerWgc {
    session:GraphicsCaptureSession,
    pool:Direct3D11CaptureFramePool,
    item:GraphicsCaptureItem,
    context:ID3D11DeviceContext,
    staging:ID3D11Texture2D,
    width:i32,
    height:i32,
    started:Instant,
    last:Option<i64>,
    _apartment:Apartment,
}
impl CapturerWgc {
    pub fn new(monitor:*mut core::ffi::c_void,width:i32,height:i32)->io::Result<Self>{
        geometry(width,height)?;
        if monitor.is_null(){return Err(io::Error::new(io::ErrorKind::InvalidInput,"WGC monitor unavailable"));}
        // An existing STA is valid with CreateFreeThreaded and is owned by its caller.
        let initialized=match unsafe{RoInitialize(RO_INIT_MULTITHREADED)}{Ok(())=>true,Err(e) if e.code().0 as u32==0x80010106=>false,Err(e)=>return Err(failure(e))};
        let apartment=Apartment(initialized);
        if !session_supported().map_err(failure)?{return Err(io::Error::new(io::ErrorKind::Unsupported,"WGC unavailable"));}
        let interop:IGraphicsCaptureItemInterop=factory::<GraphicsCaptureItem,IGraphicsCaptureItemInterop>().map_err(failure)?;
        let item:GraphicsCaptureItem=unsafe{interop.CreateForMonitor(HMONITOR(monitor))}.map_err(failure)?;
        let size=item.Size().map_err(failure)?;
        if size.Width!=width||size.Height!=height{return Err(io::Error::new(io::ErrorKind::InvalidData,"WGC display size changed"));}
        let mut device=None;let mut context=None;
        let create=|driver,device:&mut Option<ID3D11Device>,context:&mut Option<ID3D11DeviceContext>|unsafe {
            D3D11CreateDevice(None::<&IDXGIAdapter>,driver,HMODULE::default(),D3D11_CREATE_DEVICE_BGRA_SUPPORT,None,D3D11_SDK_VERSION,Some(device),None,Some(context))
        };
        if create(D3D_DRIVER_TYPE_HARDWARE,&mut device,&mut context).is_err(){
            create(D3D_DRIVER_TYPE_WARP,&mut device,&mut context).map_err(failure)?;
            super::wgc_metrics::device(super::wgc_metrics::Device::Warp);
        }else{super::wgc_metrics::device(super::wgc_metrics::Device::Hardware);}
        let device=device.ok_or_else(||io::Error::new(io::ErrorKind::Other,"WGC device unavailable"))?;
        let context=context.ok_or_else(||io::Error::new(io::ErrorKind::Other,"WGC context unavailable"))?;
        let dxgi:IDXGIDevice=device.cast().map_err(failure)?;
        let winrt:IDirect3DDevice=unsafe{CreateDirect3D11DeviceFromDXGIDevice(&dxgi)}.map_err(failure)?.cast().map_err(failure)?;
        let desc=D3D11_TEXTURE2D_DESC {Width:width as u32,Height:height as u32,MipLevels:1,ArraySize:1,Format:DXGI_FORMAT_B8G8R8A8_UNORM,SampleDesc:DXGI_SAMPLE_DESC {Count:1,Quality:0},Usage:D3D11_USAGE_STAGING,CPUAccessFlags:D3D11_CPU_ACCESS_READ.0 as u32,..Default::default()};
        let mut staging=None;
        unsafe{device.CreateTexture2D(&desc,None,Some(&mut staging))}.map_err(failure)?;
        let staging=staging.ok_or_else(||io::Error::new(io::ErrorKind::Other,"WGC staging unavailable"))?;
        let pool=create_pool(&winrt,size).map_err(failure)?;
        let session=match pool.CreateCaptureSession(&item){Ok(v)=>v,Err(e)=>{let _=pool.Close();return Err(failure(e));}};
        // Cursor is already handled by the existing cursor protocol; keep the OS capture border.
        if let Err(e)=session.SetIsCursorCaptureEnabled(false){let _=session.Close();let _=pool.Close();return Err(failure(e));}
        if let Err(e)=session.StartCapture(){let _=session.Close();let _=pool.Close();return Err(failure(e));}
        Ok(Self{session,pool,item,context,staging,width,height,started:Instant::now(),last:None,_apartment:apartment})
    }
    pub fn frame(&mut self,data:&mut Vec<u8>,timeout:Duration)->io::Result<()> {
        let wait_observation=super::wgc_metrics::begin(super::wgc_metrics::Stage::Wait);
        let until=Instant::now()+timeout.min(Duration::from_millis(50));
        let frame=loop {
            match self.pool.TryGetNextFrame(){
                Ok(frame)=>break frame,
                Err(e) if frame_pending(&e)=>{}, // null frame: no new content yet
                Err(e)=>return Err(failure(e)),
            }
            if self.last.is_none()&&self.started.elapsed()>Duration::from_millis(750){return Err(io::Error::new(io::ErrorKind::Other,"WGC initial frame unavailable"));}
            if Instant::now()>=until{return Err(io::ErrorKind::WouldBlock.into());}
            thread::sleep(Duration::from_millis(2));
        };
        drop(wait_observation);
        let acquire_observation=super::wgc_metrics::begin(super::wgc_metrics::Stage::Acquire);
        struct Frame(Direct3D11CaptureFrame);
        impl Drop for Frame {fn drop(&mut self){let _=self.0.Close();}}
        let mut frame=Frame(frame);
        // Fixed two-frame pool: discard at most one older frame, never an unbounded drain.
        if let Ok(newer)=self.pool.TryGetNextFrame(){frame=Frame(newer);}
        let time=frame.0.SystemRelativeTime().map_err(failure)?.Duration;
        if self.last==Some(time){return Err(io::ErrorKind::WouldBlock.into());}
        let size=frame.0.ContentSize().map_err(failure)?;
        let current=self.item.Size().map_err(failure)?;
        if size.Width!=self.width||size.Height!=self.height||current!=size{return Err(io::Error::new(io::ErrorKind::Other,"WGC display changed"));}
        let surface=frame.0.Surface().map_err(failure)?;
        let access:IDirect3DDxgiInterfaceAccess=surface.cast().map_err(failure)?;
        let texture:ID3D11Texture2D=unsafe{access.GetInterface()}.map_err(failure)?;
        let mut desc=D3D11_TEXTURE2D_DESC::default();unsafe{texture.GetDesc(&mut desc);}
        if desc.Width!=self.width as u32||desc.Height!=self.height as u32||desc.Format!=DXGI_FORMAT_B8G8R8A8_UNORM{return Err(io::Error::new(io::ErrorKind::Other,"WGC texture changed"));}
        drop(acquire_observation);
        {
            let _copy_observation=super::wgc_metrics::begin(super::wgc_metrics::Stage::Copy);
            unsafe{self.context.CopyResource(&self.staging,&texture);}
        }
        let mut mapped=D3D11_MAPPED_SUBRESOURCE::default();
        {
            let _map_observation=super::wgc_metrics::begin(super::wgc_metrics::Stage::Map);
            unsafe{self.context.Map(&self.staging,0,D3D11_MAP_READ,0,Some(&mut mapped))}.map_err(failure)?;
        }
        struct Mapping<'a>(&'a ID3D11DeviceContext,&'a ID3D11Texture2D);
        impl Drop for Mapping<'_>{fn drop(&mut self){let _unmap_observation=super::wgc_metrics::begin(super::wgc_metrics::Stage::Unmap);unsafe{self.0.Unmap(self.1,0);}}}
        let _mapping=Mapping(&self.context,&self.staging);
        let (row,_)=geometry(self.width,self.height)?;
        let pitch=mapped.RowPitch as usize;
        if mapped.pData.is_null()||pitch<row{return Err(io::Error::new(io::ErrorKind::Other,"WGC mapping unavailable"));}
        let extent=pitch.checked_mul(self.height as usize).ok_or_else(||io::Error::new(io::ErrorKind::Other,"WGC stride overflow"))?;
        if extent>MAX_BYTES{return Err(io::Error::new(io::ErrorKind::Other,"WGC mapped size denied"));}
        {
            let _read_observation=super::wgc_metrics::begin(super::wgc_metrics::Stage::Read);
            copy_rows(unsafe{std::slice::from_raw_parts(mapped.pData as *const u8,extent)},pitch,self.width,self.height,data)?;
        }
        self.last=Some(time);Ok(())
    }
}
impl Drop for CapturerWgc {fn drop(&mut self){let _=self.session.Close();let _=self.pool.Close();}}

#[cfg(test)]mod tests {
    use super::*;
    #[test]fn support_probe_survives_repeated_apartment_teardown(){
        std::thread::spawn(||{
            for _ in 0..100{
                unsafe{RoInitialize(RO_INIT_MULTITHREADED)}.expect("initialize test apartment");
                let apartment=Apartment(true);
                session_supported().expect("query WGC support without a cached factory");
                drop(apartment);
            }
        }).join().expect("query worker must not crash");
    }
    #[test]fn successful_null_winrt_frame_is_pending_but_access_denied_is_fatal(){
        let empty=unsafe{<Direct3D11CaptureFrame as windows::core::Type<Direct3D11CaptureFrame>>::from_abi(core::ptr::null_mut())};
        assert!(frame_pending(&empty.err().expect("null ABI has no frame")));
        assert!(!frame_pending(&windows::core::Error::from_hresult(windows::core::HRESULT(0x80070005u32 as i32))));
    }
    #[test]fn geometry_rejects_empty_overflow_and_excessive_images(){for(w,h)in[(0,1),(1,0),(-1,2),(i32::MAX,2),(8192,8192)]{assert!(geometry(w,h).is_err());}assert_eq!(geometry(1600,1200).unwrap(),(6400,7680000));}
    #[test]fn opt_in_is_only_valid_for_an_exact_isolated_local_profile(){assert!(allowed("Y",&"a".repeat(64)));for(o,n)in[("N","a".repeat(64)),("Y","".into()),("Y","A".repeat(64)),("Y","g".repeat(64))]{assert!(!allowed(o,&n));}}
    #[test]fn padded_bgra_rows_remain_top_down_and_invalid_layout_does_not_replace_output(){let pixels=(0u8..32).collect::<Vec<_>>();let mut out=vec![];copy_rows(&pixels,16,3,2,&mut out).unwrap();assert_eq!(out,[&pixels[..12],&pixels[16..28]].concat());let before=out.clone();assert!(copy_rows(&pixels,8,3,2,&mut out).is_err());assert!(copy_rows(&pixels[..20],16,3,2,&mut out).is_err());assert_eq!(out,before);}
}
