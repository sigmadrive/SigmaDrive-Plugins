use std::{convert::TryFrom, mem::size_of};
use winapi::{
    shared::windef::{HBITMAP, HDC, HGDIOBJ},
    um::wingdi::{
        BitBlt,
        CreateCompatibleBitmap,
        CreateCompatibleDC,
        CreateDCW,
        CreateDIBSection,
        DeleteDC,
        DeleteObject,
        GetDIBits,
        GdiFlush,
        SelectObject,
        BITMAPINFO,
        BITMAPINFOHEADER,
        BI_RGB,
        CAPTUREBLT,
        DIB_RGB_COLORS, //CAPTUREBLT,
        HGDI_ERROR,
        RGBQUAD,
        SRCCOPY,
    },
};

const PIXEL_WIDTH: i32 = 4;

pub struct CapturerGDI {
    screen_dc: HDC,
    dc: HDC,
    bmp: HBITMAP,
    width: i32,
    height: i32,
    top_down: Option<(*mut u8, usize, HGDIOBJ)>,
}

fn top_down_bitmap(dc: HDC, width: i32, height: i32) -> Option<(HBITMAP, *mut u8, usize)> {
    if width <= 0 || height <= 0 {
        return None;
    }
    let bytes = u32::try_from(width).ok()?.checked_mul(height as u32)?.checked_mul(4)?;
    let mut info: BITMAPINFO = unsafe { std::mem::zeroed() };
    info.bmiHeader.biSize = size_of::<BITMAPINFOHEADER>() as _;
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    info.bmiHeader.biCompression = BI_RGB;
    info.bmiHeader.biSizeImage = bytes;
    let mut bits = std::ptr::null_mut();
    let bitmap = unsafe {
        CreateDIBSection(dc, &info, DIB_RGB_COLORS, &mut bits, std::ptr::null_mut(), 0)
    };
    if bitmap.is_null() || bits.is_null() {
        if !bitmap.is_null() {
            unsafe { DeleteObject(bitmap as _); }
        }
        None
    } else {
        Some((bitmap, bits.cast(), bytes as usize))
    }
}

impl CapturerGDI {
    pub fn new(name: &[u16], width: i32, height: i32) -> Result<Self, Box<dyn std::error::Error>> {
        /* or Enumerate monitors with EnumDisplayMonitors,
        https://stackoverflow.com/questions/34987695/how-can-i-get-an-hmonitor-handle-from-a-display-device-name
            #[no_mangle]
            pub extern "C" fn callback(m: HMONITOR, dc: HDC, rect: LPRECT, lp: LPARAM) -> BOOL {}
        */
        /*
        shared::windef::HMONITOR,
        winuser::{GetMonitorInfoW, GetSystemMetrics, MONITORINFOEXW},
        let mut mi: MONITORINFOEXW = std::mem::MaybeUninit::uninit().assume_init();
        mi.cbSize = size_of::<MONITORINFOEXW>() as _;
        if GetMonitorInfoW(m, &mut mi as *mut MONITORINFOEXW as _) == 0 {
            return Err(format!("Failed to get monitor information of: {:?}", m).into());
        }
        */
        unsafe {
            if name.is_empty() {
                return Err("Empty display name".into());
            }
            let screen_dc = CreateDCW(&name[0], 0 as _, 0 as _, 0 as _);
            if screen_dc.is_null() {
                return Err("Failed to create dc from monitor name".into());
            }

            // Create a Windows Bitmap, and copy the bits into it
            let dc = CreateCompatibleDC(screen_dc);
            if dc.is_null() {
                DeleteDC(screen_dc);
                return Err("Can't get a Windows display".into());
            }

            // Unsupported DIB creation retains the existing compatible-bitmap path.
            let dib = top_down_bitmap(screen_dc, width, height);
            let bmp = match dib {
                Some((bitmap, _, _)) => bitmap,
                None => CreateCompatibleBitmap(screen_dc, width, height),
            };
            if bmp.is_null() {
                DeleteDC(screen_dc);
                DeleteDC(dc);
                return Err("Can't create a Windows buffer".into());
            }

            let res = SelectObject(dc, bmp as _);
            if res.is_null() || res == HGDI_ERROR {
                DeleteDC(screen_dc);
                DeleteDC(dc);
                DeleteObject(bmp as _);
                return Err("Can't select Windows buffer".into());
            }
            Ok(Self {
                screen_dc,
                dc,
                bmp,
                width,
                height,
                top_down: dib.map(|(_, bits, bytes)| (bits, bytes, res)),
            })
        }
    }

    pub fn frame(&self, data: &mut Vec<u8>) -> Result<(), Box<dyn std::error::Error>> {
        unsafe {
            let res = BitBlt(
                self.dc,
                0,
                0,
                self.width,
                self.height,
                self.screen_dc,
                0,
                0,
                SRCCOPY | CAPTUREBLT, // CAPTUREBLT enable layered window but also make cursor blinking
            );
            if res == 0 {
                return Err("Failed to copy screen to Windows buffer".into());
            }

            if let Some((bits, bytes, _)) = self.top_down {
                // GDI may batch BitBlt. Complete writes before reading DIB memory.
                if GdiFlush() == 0 {
                    return Err("Failed to complete Windows buffer copy".into());
                }
                data.resize(bytes, 0);
                std::ptr::copy_nonoverlapping(bits, data.as_mut_ptr(), bytes);
                return Ok(());
            }

            let stride = self.width * PIXEL_WIDTH;
            let size: usize = (stride * self.height) as usize;
            let mut data1: Vec<u8> = Vec::with_capacity(size);
            data1.set_len(size);
            data.resize(size, 0);

            let mut bmi = BITMAPINFO {
                bmiHeader: BITMAPINFOHEADER {
                    biSize: size_of::<BITMAPINFOHEADER>() as _,
                    biWidth: self.width as _,
                    biHeight: self.height as _,
                    biPlanes: 1,
                    biBitCount: (8 * PIXEL_WIDTH) as _,
                    biCompression: BI_RGB,
                    biSizeImage: (self.width * self.height * PIXEL_WIDTH) as _,
                    biXPelsPerMeter: 0,
                    biYPelsPerMeter: 0,
                    biClrUsed: 0,
                    biClrImportant: 0,
                },
                bmiColors: [RGBQUAD {
                    rgbBlue: 0,
                    rgbGreen: 0,
                    rgbRed: 0,
                    rgbReserved: 0,
                }],
            };

            // copy bits into Vec
            let res = GetDIBits(
                self.dc,
                self.bmp,
                0,
                self.height as _,
                &mut data[0] as *mut u8 as _,
                &mut bmi as _,
                DIB_RGB_COLORS,
            );
            if res == 0 {
                return Err("GetDIBits failed".into());
            }
            crate::common::ARGBMirror(
                data.as_ptr(),
                stride,
                data1.as_mut_ptr(),
                stride,
                self.width,
                self.height,
            );
            crate::common::ARGBRotate(
                data1.as_ptr(),
                stride,
                data.as_mut_ptr(),
                stride,
                self.width,
                self.height,
                crate::RotationMode::kRotate180,
            );
            Ok(())
        }
    }
}

impl Drop for CapturerGDI {
    fn drop(&mut self) {
        unsafe {
            if let Some((_, _, previous)) = self.top_down {
                SelectObject(self.dc, previous);
            }
            DeleteDC(self.screen_dc);
            DeleteDC(self.dc);
            DeleteObject(self.bmp as _);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::*;
    use super::*;
    #[test]
    fn top_down_frames_preserve_pixel_positions_and_reuse_the_buffer() {
        unsafe {
            // A memory-only source: this test never captures a user's desktop.
            let source = CreateCompatibleDC(std::ptr::null_mut());
            assert!(!source.is_null());
            let (source_bitmap, source_bits, bytes) = top_down_bitmap(source, 3, 2).unwrap();
            let source_previous = SelectObject(source, source_bitmap as _);
            assert!(!source_previous.is_null() && source_previous != HGDI_ERROR);
            let target = CreateCompatibleDC(source);
            assert!(!target.is_null());
            let (bitmap, bits, _) = top_down_bitmap(source, 3, 2).unwrap();
            let previous = SelectObject(target, bitmap as _);
            assert!(!previous.is_null() && previous != HGDI_ERROR);
            let capture = CapturerGDI {screen_dc:source, dc:target, bmp:bitmap, width:3, height:2, top_down:Some((bits,bytes,previous))};
            let mut output = Vec::new();
            for base in [11u8, 91u8] {
                let mut expected = Vec::new();
                for pixel in 0..6 {expected.extend_from_slice(&[base+pixel,base+pixel+1,base+pixel+2,0]);}
                std::ptr::copy_nonoverlapping(expected.as_ptr(),source_bits,bytes);
                capture.frame(&mut output).unwrap();
                assert_eq!(output, expected);
                assert_eq!(output.len(),24);
            }
            // The source bitmap belongs to this test, not the capture target.
            SelectObject(source, source_previous);
            assert_ne!(DeleteObject(source_bitmap as _),0);
            drop(capture);
        }
    }

    #[test]
    fn top_down_bitmap_rejects_invalid_or_overflowing_geometry() {
        for (w,h) in [(0,2),(2,0),(-1,2),(2,-1),(i32::MAX,2)] {
            assert!(top_down_bitmap(std::ptr::null_mut(),w,h).is_none());
        }
    }

    #[test]
    fn top_down_target_bitmap_is_released_with_the_capture() {
        unsafe {
            let source=CreateCompatibleDC(std::ptr::null_mut());
            let dc=CreateCompatibleDC(source);
            assert!(!source.is_null() && !dc.is_null());
            let (bitmap,bits,bytes)=top_down_bitmap(source,2,2).unwrap();
            let previous=SelectObject(dc,bitmap as _);
            assert!(!previous.is_null() && previous != HGDI_ERROR);
            let capture=CapturerGDI {screen_dc:source,dc,bmp:bitmap,width:2,height:2,top_down:Some((bits,bytes,previous))};
            drop(capture);
            let mut object: winapi::um::wingdi::BITMAP=std::mem::zeroed();
            assert_eq!(winapi::um::wingdi::GetObjectW(bitmap as _,size_of::<winapi::um::wingdi::BITMAP>() as _, &mut object as *mut _ as _),0);
        }
    }
    #[test]
    fn test() {
        match Displays::new().unwrap().next() {
            Some(d) => {
                let w = d.width();
                let h = d.height();
                let c = CapturerGDI::new(d.name(), w, h).unwrap();
                let mut data = Vec::new();
                c.frame(&mut data).unwrap();
                let mut bitflipped = Vec::with_capacity((w * h * 4) as usize);
                for y in 0..h {
                    for x in 0..w {
                        let i = (w * 4 * y + 4 * x) as usize;
                        bitflipped.extend_from_slice(&[data[i + 2], data[i + 1], data[i], 255]);
                    }
                }
                repng::encode(
                    std::fs::File::create("gdi_screen.png").unwrap(),
                    d.width() as u32,
                    d.height() as u32,
                    &bitflipped,
                )
                .unwrap();
            }
            _ => {
                assert!(false);
            }
        }
    }
}
