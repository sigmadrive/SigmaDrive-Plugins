@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "CARGO_TARGET_DIR=S:\SigmaNode\_qa\wgc-capture-candidate-20261027\cargo-target"
set "LIBCLANG_PATH=S:\SigmaNode\client\.runtime\sigmadesk-multi\clang\clang\native"
set "VCPKG_ROOT=S:\SigmaNode\client\.runtime\sigmadesk-multi\vcpkg"
set "CARGO_BUILD_JOBS=2"
set "CARGO_NET_OFFLINE=true"
cd /d S:\SigmaNode\_qa\wgc-empty-frame-candidate-20261028\source
cargo test --release --locked --offline -p scrap --lib wgc::tests -- --test-threads=1 > ..\capture-tests.log 2>&1
if errorlevel 1 exit /b 1
cargo test --release --locked --offline --features flutter --lib sigma_engine_metrics::tests -- --test-threads=1 > ..\engine-metrics-tests.log 2>&1
if errorlevel 1 exit /b 1
cargo build --release --locked --offline --features flutter --lib > ..\engine-build.log 2>&1
if errorlevel 1 exit /b 1
copy /b "%CARGO_TARGET_DIR%\release\librustdesk.dll" "S:\SigmaNode\_qa\wgc-empty-frame-candidate-20261028\librustdesk.dll" >nul
if errorlevel 1 exit /b 1
dumpbin /exports "S:\SigmaNode\_qa\wgc-empty-frame-candidate-20261028\baseline-035.dll" > ..\baseline-exports.txt
if errorlevel 1 exit /b 1
dumpbin /exports "S:\SigmaNode\_qa\wgc-empty-frame-candidate-20261028\librustdesk.dll" > ..\candidate-exports.txt
exit /b %ERRORLEVEL%
