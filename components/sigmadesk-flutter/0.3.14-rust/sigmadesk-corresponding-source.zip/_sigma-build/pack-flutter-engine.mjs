// Packs only a fresh, source-built Flutter/Rust engine. Not an installer.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const [bundle,output]=process.argv.slice(2,4).map(p=>p&&path.resolve(p));
const version=process.argv[4]??'0.3.0-rust';if(!/^\d+\.\d+\.\d+-rust$/.test(version))throw Error('Exact engine version required');
if(!bundle||!output||!path.isAbsolute(process.argv[2])||!path.isAbsolute(process.argv[3])||fs.existsSync(output))throw Error('Fresh absolute engine package directory required');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){
 const p=path.join(dir,e.name),rel=path.relative(bundle,p).replaceAll('\\','/');
 if(e.isSymbolicLink())throw Error('Linked engine asset denied');
 if(e.isDirectory()){walk(p);continue;}
 if(!e.isFile()||rel.split('/').some(x=>!x||['.','..'].includes(x)||x.includes(':')||/[ .]$/.test(x)))throw Error('Invalid engine asset');
 if(/\.(pdb|lib|exp)$/i.test(rel))continue;
 if(/\.exe$/i.test(rel)&&rel!=='rustdesk.exe')throw Error('Unexpected helper executable');
 if(!rel.startsWith('data/')&&!/^(?:rustdesk\.exe|[a-zA-Z0-9_-]+\.dll)$/.test(rel))throw Error('Unexpected engine member');
 const b=fs.readFileSync(p);files.push({path:rel,bytes:b.length,sha256:sha(b)});
}}
walk(bundle);files.sort((a,b)=>a.path.localeCompare(b.path,'en'));
for(const p of ['rustdesk.exe','librustdesk.dll','flutter_windows.dll','data/app.so','data/icudtl.dat'])if(!files.some(f=>f.path===p))throw Error('Missing Flutter engine asset '+p);
if(files.length>8192||files.reduce((s,f)=>s+f.bytes,0)>256*1048576)throw Error('Engine budget exceeded');
fs.mkdirSync(output,{recursive:true});
const raw=Buffer.from(JSON.stringify({schema:1,entry:'rustdesk.exe',files},null,2)+'\n');
fs.writeFileSync(path.join(output,'sigmadesk-files.json'),raw,{flag:'wx'});
const archive=path.join(output,'sigmadesk.component'),fd=fs.openSync(archive,'wx');
try {const n=Buffer.alloc(4);n.writeUInt32LE(raw.length);fs.writeSync(fd,Buffer.from('SDDESK1\n'));fs.writeSync(fd,n);fs.writeSync(fd,raw);for(const f of files){const b=fs.readFileSync(path.join(bundle,f.path));if(sha(b)!==f.sha256)throw Error('Asset changed while packing');fs.writeSync(fd,b);}fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
const archiveBytes=fs.readFileSync(archive);
const report={schema:1,version,files:files.length,rawBytes:archiveBytes.length,sha256:sha(archiveBytes),manifest_sha256:sha(raw),architecture:'Flutter AOT runner + Rust native library',go:false,sciterUi:false,published:false,screenInputAcceptance:false};
fs.writeFileSync(path.join(output,'engine-build.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
