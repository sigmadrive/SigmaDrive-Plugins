@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "CARGO_TARGET_DIR=S:\SigmaNode\_qa\wgc-capture-candidate-20261027\cargo-target"
set "LIBCLANG_PATH=S:\SigmaNode\client\.runtime\sigmadesk-multi\clang\clang\native"
set "VCPKG_ROOT=S:\SigmaNode\client\.runtime\sigmadesk-multi\vcpkg"
set "CARGO_BUILD_JOBS=2"
set "CARGO_NET_OFFLINE=true"
cd /d S:\SigmaNode\_qa\wgc-capture-candidate-20261027\source
cargo build --release --locked --offline --features flutter --lib > ..\engine-build.log 2>&1
exit /b %ERRORLEVEL%
