param(
 [string]$SourceRoot,
 [string]$FlutterRoot='C:\SDK\flutter',
 [string]$ToolRoot=(Join-Path $env:LOCALAPPDATA 'SigmaDeskFlutterBuild'),
 [string]$NativeRoot
)
$ErrorActionPreference='Stop'
if(-not $SourceRoot){$SourceRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\.runtime\sigmadesk-multi\upstream'))}
if(-not $NativeRoot){$NativeRoot=[IO.Path]::GetFullPath((Join-Path $SourceRoot '..'))}
if(-not(Test-Path -LiteralPath (Join-Path $SourceRoot 'src\flutter_ffi.rs'))){throw 'Prepared isolated source is required'}
$env:PATH="$ToolRoot\bin;$FlutterRoot\bin;$env:PATH"
$env:RUST_LOG='info'
$env:LIBCLANG_PATH=Join-Path $NativeRoot 'clang\clang\native'
$env:VCPKG_ROOT=Join-Path $NativeRoot 'vcpkg'
$env:CARGO_BUILD_JOBS='2'
$env:CARGO_TARGET_DIR=Join-Path $ToolRoot 'engine-target'
$env:SIGMADESK_RUST_TARGET=$env:CARGO_TARGET_DIR
Push-Location -LiteralPath $SourceRoot
try {
 Push-Location -LiteralPath 'flutter'
 try {flutter pub get; if($LASTEXITCODE -ne 0){throw 'Flutter dependencies failed'}} finally {Pop-Location}
 flutter_rust_bridge_codegen --rust-input ./src/flutter_ffi.rs --dart-output ./flutter/lib/generated_bridge.dart --c-output ./flutter/macos/Runner/bridge_generated.h --llvm-path "$ToolRoot\llvm"
 if($LASTEXITCODE -ne 0){throw 'FRB generation failed'}
 cargo build --release --locked --features flutter --lib
 if($LASTEXITCODE -ne 0){throw 'Rust Flutter library failed'}
 Push-Location -LiteralPath 'flutter'
 try {
  flutter build windows --release --no-pub
  if($LASTEXITCODE -ne 0){throw 'Flutter Windows engine failed'}
 } finally {Pop-Location}
} finally {Pop-Location}
Write-Output 'Source-built isolated Flutter/Rust engine complete; video and permission acceptance remain separate.'
