//! Shared by the privileged presenter and its broker. A Windows logon session
//! is never selected merely because it is globally active. No credentials,
//! unlock, tscon, SwitchDesktop, or session-connect operation exists here.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Owner {
    Known(String),
    NoUser,
    Unknown,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Snapshot {
    pub system: bool,
    pub process_session: u32,
    pub console_session: u32,
    pub connected: bool,
    pub owner: Owner,
    pub input_desktop: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Scope {
    owner_sid: String,
    session: u32,
}

/// Not serializable: a stamp is an in-process observation, not evidence that
/// an untrusted caller can manufacture on a pipe.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Stamp(Snapshot);
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ConnectionState {
    Active,
    Connected,
    Disconnected,
    Unknown,
}

pub fn renderable_connection(state: ConnectionState, owner: &Owner, desktop: &str) -> bool {
    state == ConnectionState::Active
        || (state == ConnectionState::Connected && *owner == Owner::NoUser && desktop == "Winlogon")
}

/// A privileged worker without the broker's explicit private loopback profile
/// must not inherit an upstream default rendezvous server or feature set.
pub fn valid_profile(id: &str, option: impl Fn(&str) -> String, server_key: &str) -> bool {
    fn rdid(id: &str) -> bool {
        (6..=12).contains(&id.len()) && id.bytes().all(|c| c.is_ascii_digit())
    }
    if !rdid(id) {
        return false;
    }
    let peer = option("id-whitelist");
    if !rdid(&peer) || peer == id {
        return false;
    }
    if option("key") != server_key
        || server_key.is_empty()
        || option("api-server") != "http://127.0.0.1:9"
        || option("approve-mode") != "password"
        || option("access-mode") != "custom"
        || option("verification-method") != "use-permanent-password"
        || !matches!(option("enable-keyboard").as_str(), "Y" | "N")
    {
        return false;
    }
    let local = |name: &str, relay: bool| {
        option(name).parse::<std::net::SocketAddr>().is_ok_and(|v| {
            v.ip() == std::net::IpAddr::V4(std::net::Ipv4Addr::LOCALHOST)
                && v.port() >= 1024
                && if relay {
                    v.port() == 21117
                } else {
                    v.port() != 21117
                }
        })
    };
    if !local("custom-rendezvous-server", false) || !local("relay-server", true) {
        return false;
    }
    DISABLED_OPTIONS.iter().all(|key| option(key) == "N")
}
pub const DISABLED_OPTIONS: &[&str] = &[
    "enable-clipboard",
    "enable-file-transfer",
    "enable-camera",
    "enable-terminal",
    "enable-remote-printer",
    "enable-audio",
    "enable-tunnel",
    "enable-remote-restart",
    "enable-record-session",
    "enable-block-input",
    "enable-privacy-mode",
    "allow-auto-update",
    "allow-auto-record-incoming",
    "allow-auto-record-outgoing",
    "allow-remote-config-modification",
    "allow-remote-cm-modification",
    "allow-websocket",
    "allow-insecure-tls-fallback",
    "direct-server",
    "enable-lan-discovery",
    "allow-hide-cm",
    "allow-logon-screen-password",
    "sigma-engine-local-metrics-v1",
    "allow-only-conn-window-open",
];

pub fn valid_owner_sid(value: &str) -> bool {
    // Local/domain/Microsoft user SIDs. Service/builtin/group identities are
    // deliberately excluded from an interactive-owner enrollment.
    let parts: Vec<_> = value.split('-').collect();
    parts.len() == 8
        && parts[..4] == ["S", "1", "5", "21"]
        && parts[4..].iter().all(|v| {
            !v.is_empty() && (*v == "0" || !v.starts_with('0')) && v.parse::<u32>().is_ok()
        })
}

impl Scope {
    pub fn new(owner_sid: &str, session: u32) -> Option<Self> {
        (valid_owner_sid(owner_sid) && session != 0 && session != u32::MAX).then(|| Self {
            owner_sid: owner_sid.into(),
            session,
        })
    }

    pub fn inspect(&self, snapshot: Snapshot) -> Option<Stamp> {
        if !snapshot.system
            || !snapshot.connected
            || snapshot.process_session != self.session
            || snapshot.console_session != self.session
        {
            return None;
        }
        let permitted = match (&snapshot.owner, snapshot.input_desktop.as_str()) {
            (Owner::Known(sid), "Default" | "Winlogon") => sid == &self.owner_sid,
            // The no-user login surface is permitted, but no user's Default
            // desktop is ever inferred from a failed WTS/token lookup.
            (Owner::NoUser, "Winlogon") => true,
            _ => false,
        };
        permitted.then_some(Stamp(snapshot))
    }

    pub fn unchanged(&self, before: &Stamp, after: Snapshot) -> bool {
        self.inspect(after)
            .is_some_and(|current| current == *before)
    }
}

#[cfg(windows)]
pub mod windows {
    use super::*;
    use std::ptr::null_mut;
    use windows_sys::Win32::{
        Foundation::{CloseHandle, HANDLE, LocalFree},
        Security::{Authorization::ConvertSidToStringSidW, *},
        System::{RemoteDesktop::*, StationsAndDesktops::*, Threading::*},
    };

    struct Handle(HANDLE);
    impl Drop for Handle {
        fn drop(&mut self) {
            unsafe {
                CloseHandle(self.0);
            }
        }
    }

    fn token_sid(token: HANDLE) -> Option<String> {
        let mut size = 0;
        unsafe {
            GetTokenInformation(token, TokenUser, null_mut(), 0, &mut size);
        }
        if !(std::mem::size_of::<TOKEN_USER>() as u32..=65536).contains(&size) {
            return None;
        }
        // TOKEN_USER contains pointers and must be aligned, unlike Vec<u8>.
        let mut buffer = vec![0usize; (size as usize).div_ceil(std::mem::size_of::<usize>())];
        if unsafe {
            GetTokenInformation(
                token,
                TokenUser,
                buffer.as_mut_ptr().cast(),
                size,
                &mut size,
            )
        } == 0
        {
            return None;
        }
        let user = unsafe { &*(buffer.as_ptr().cast::<TOKEN_USER>()) };
        let mut text = null_mut();
        if unsafe { ConvertSidToStringSidW(user.User.Sid, &mut text) } == 0 {
            return None;
        }
        let n = (0..=512).find(|i| unsafe { *text.add(*i) } == 0);
        let result =
            n.and_then(|n| String::from_utf16(unsafe { std::slice::from_raw_parts(text, n) }).ok());
        unsafe {
            LocalFree(text.cast());
        }
        result
    }

    pub fn process_sid(process: HANDLE) -> Option<String> {
        let mut token = null_mut();
        if unsafe { OpenProcessToken(process, TOKEN_QUERY, &mut token) } == 0 {
            return None;
        }
        let token = Handle(token);
        token_sid(token.0)
    }

    pub fn session_owner(session: u32) -> Owner {
        // A failure to query a user token is not equivalent to no logged-on
        // user. Only an explicitly empty username constitutes the login UI.
        let mut text = null_mut();
        let mut size = 0;
        if unsafe {
            WTSQuerySessionInformationW(null_mut(), session, WTSUserName, &mut text, &mut size)
        } == 0
        {
            return Owner::Unknown;
        }
        let empty = if !text.is_null() && size >= 2 && size <= 65536 && size % 2 == 0 {
            Some(unsafe { *text == 0 })
        } else {
            None
        };
        unsafe {
            WTSFreeMemory(text.cast());
        }
        match empty {
            Some(true) => Owner::NoUser,
            Some(false) => {
                let mut token = null_mut();
                if unsafe { WTSQueryUserToken(session, &mut token) } == 0 {
                    return Owner::Unknown;
                }
                let token = Handle(token);
                token_sid(token.0)
                    .map(Owner::Known)
                    .unwrap_or(Owner::Unknown)
            }
            None => Owner::Unknown,
        }
    }

    fn input_desktop() -> Option<String> {
        let desktop = unsafe { OpenInputDesktop(0, 0, DESKTOP_READOBJECTS) };
        if desktop.is_null() {
            return None;
        }
        let mut name = [0u16; 256];
        let mut used = 0;
        let ok = unsafe {
            GetUserObjectInformationW(
                desktop,
                UOI_NAME as i32,
                name.as_mut_ptr().cast(),
                std::mem::size_of_val(&name) as u32,
                &mut used,
            )
        } != 0;
        unsafe {
            CloseDesktop(desktop);
        }
        if !ok || used < 2 || used as usize > std::mem::size_of_val(&name) || used % 2 != 0 {
            return None;
        }
        let chars = &name[..used as usize / 2];
        if chars.last() != Some(&0) {
            return None;
        }
        String::from_utf16(&chars[..chars.len() - 1]).ok()
    }

    pub fn current() -> Snapshot {
        let mut process_session = u32::MAX;
        unsafe {
            ProcessIdToSessionId(GetCurrentProcessId(), &mut process_session);
        }
        let console_session = unsafe { WTSGetActiveConsoleSessionId() };
        let mut data = null_mut();
        let mut size = 0;
        let connection = if unsafe {
            WTSQuerySessionInformationW(
                null_mut(),
                process_session,
                WTSConnectState,
                &mut data,
                &mut size,
            )
        } != 0
        {
            let state = if !data.is_null()
                && size as usize == std::mem::size_of::<WTS_CONNECTSTATE_CLASS>()
            {
                match unsafe { std::ptr::read_unaligned(data.cast::<WTS_CONNECTSTATE_CLASS>()) } {
                    v if v == WTSActive => ConnectionState::Active,
                    v if v == WTSConnected => ConnectionState::Connected,
                    v if v == WTSDisconnected => ConnectionState::Disconnected,
                    _ => ConnectionState::Unknown,
                }
            } else {
                ConnectionState::Unknown
            };
            unsafe {
                WTSFreeMemory(data.cast());
            }
            state
        } else {
            ConnectionState::Unknown
        };
        let owner = session_owner(process_session);
        let input_desktop = input_desktop().unwrap_or_default();
        let connected = renderable_connection(connection, &owner, &input_desktop);
        Snapshot {
            system: process_sid(unsafe { GetCurrentProcess() }).as_deref() == Some("S-1-5-18"),
            process_session,
            console_session,
            connected,
            owner,
            input_desktop,
        }
    }

    pub fn environment_scope() -> Option<Scope> {
        let owner = std::env::var("SIGMADESK_HOST_OWNER_SID").ok()?;
        let session: u32 = std::env::var("SIGMADESK_HOST_SESSION").ok()?.parse().ok()?;
        Scope::new(&owner, session)
    }

    pub fn requested() -> bool {
        std::env::var_os("SIGMADESK_HOST_OWNER_SID").is_some()
    }

    /// Legacy per-user engines retain their existing behavior. Privileged
    /// mode can never fall back to that behavior on a malformed environment.
    pub fn permitted() -> bool {
        !requested() || environment_scope().is_some_and(|scope| scope.inspect(current()).is_some())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const OWNER: &str = "S-1-5-21-100-200-300-1001";
    const OTHER: &str = "S-1-5-21-100-200-300-1002";
    fn sample() -> Snapshot {
        Snapshot {
            system: true,
            process_session: 3,
            console_session: 3,
            connected: true,
            owner: Owner::Known(OWNER.into()),
            input_desktop: "Default".into(),
        }
    }
    #[test]
    fn accepts_only_user_sids_and_interactive_sessions() {
        for sid in [
            "",
            "S-1-5-18",
            "S-1-5-32-544",
            "S-1-5-21-100-200-300",
            "S-1-5-21-01-2-3-4",
            "S-1-5-21-1-2-3-4294967296",
        ] {
            assert!(Scope::new(sid, 3).is_none(), "{sid}");
        }
        assert!(Scope::new(OWNER, 0).is_none());
        assert!(Scope::new(OWNER, u32::MAX).is_none());
        assert!(Scope::new(OWNER, 3).is_some());
    }
    #[test]
    fn secure_desktop_manual_login_preserves_owner_boundary() {
        let scope = Scope::new(OWNER, 3).unwrap();
        assert!(scope.inspect(sample()).is_some());
        let mut s = sample();
        s.input_desktop = "Winlogon".into();
        assert!(scope.inspect(s.clone()).is_some());
        s.owner = Owner::NoUser;
        assert!(scope.inspect(s.clone()).is_some());
        s.input_desktop = "Default".into();
        assert!(scope.inspect(s).is_none());
    }
    #[test]
    fn never_follows_foreign_or_unknown_windows_owner_even_when_locked() {
        let scope = Scope::new(OWNER, 3).unwrap();
        for owner in [Owner::Known(OTHER.into()), Owner::Unknown] {
            for desktop in ["Default", "Winlogon"] {
                let mut s = sample();
                s.owner = owner.clone();
                s.input_desktop = desktop.into();
                assert!(scope.inspect(s).is_none());
            }
        }
    }
    #[test]
    fn session_zero_disconnected_or_non_system_cannot_present() {
        let scope = Scope::new(OWNER, 3).unwrap();
        let mut s = sample();
        s.system = false;
        assert!(scope.inspect(s).is_none());
        let mut s = sample();
        s.connected = false;
        assert!(scope.inspect(s).is_none());
        for session in [0, 4, u32::MAX] {
            let mut s = sample();
            s.process_session = session;
            assert!(scope.inspect(s).is_none());
            let mut s = sample();
            s.console_session = session;
            assert!(scope.inspect(s).is_none());
        }
    }
    #[test]
    fn drops_pixels_if_identity_or_desktop_changes_during_capture_or_encode() {
        let scope = Scope::new(OWNER, 3).unwrap();
        let before = scope.inspect(sample()).unwrap();
        assert!(scope.unchanged(&before, sample()));
        let mut s = sample();
        s.owner = Owner::Known(OTHER.into());
        assert!(!scope.unchanged(&before, s));
        let mut s = sample();
        s.input_desktop = "Winlogon".into();
        assert!(!scope.unchanged(&before, s));
        let mut s = sample();
        s.console_session = 4;
        assert!(!scope.unchanged(&before, s));
    }
    #[test]
    fn rejects_unknown_desktop_and_lookup_failure() {
        let scope = Scope::new(OWNER, 3).unwrap();
        for name in ["", "Screen-saver", "default", "Other", "Default\0Winlogon"] {
            let mut s = sample();
            s.input_desktop = name.into();
            assert!(scope.inspect(s).is_none());
        }
    }
    #[test]
    fn connected_without_logon_is_not_confused_with_disconnected_rdp() {
        assert!(renderable_connection(
            ConnectionState::Connected,
            &Owner::NoUser,
            "Winlogon"
        ));
        for state in [ConnectionState::Disconnected, ConnectionState::Unknown] {
            assert!(!renderable_connection(state, &Owner::NoUser, "Winlogon"));
        }
        assert!(!renderable_connection(
            ConnectionState::Connected,
            &Owner::Known(OWNER.into()),
            "Default"
        ));
        assert!(!renderable_connection(
            ConnectionState::Connected,
            &Owner::Unknown,
            "Winlogon"
        ));
    }
    #[test]
    fn privileged_profile_cannot_fall_back_to_public_rendezvous_or_extra_features() {
        let mut map = std::collections::HashMap::from([
            ("key", "test-public-server-key".into()),
            ("api-server", "http://127.0.0.1:9".into()),
            ("approve-mode", "password".into()),
            ("access-mode", "custom".into()),
            ("verification-method", "use-permanent-password".into()),
            ("enable-keyboard", "N".into()),
            ("custom-rendezvous-server", "127.0.0.1:21116".into()),
            ("relay-server", "127.0.0.1:21117".into()),
            ("id-whitelist", "987654321".into()),
        ]);
        for name in DISABLED_OPTIONS {
            map.insert(*name, "N".to_owned());
        }
        let check = |m: &std::collections::HashMap<&str, String>| {
            valid_profile(
                "123456789",
                |key| m.get(key).cloned().unwrap_or_default(),
                "test-public-server-key",
            )
        };
        assert!(check(&map));
        for name in [
            "key",
            "id-whitelist",
            "custom-rendezvous-server",
            "enable-keyboard",
        ] {
            let mut bad = map.clone();
            bad.remove(name);
            assert!(!check(&bad), "{name}");
        }
        for name in DISABLED_OPTIONS {
            let mut bad = map.clone();
            bad.insert(name, "Y".into());
            assert!(!check(&bad), "{name}");
        }
        for address in [
            "rs-public.example:21116",
            "0.0.0.0:21116",
            "127.0.0.2:21116",
            "127.0.0.1:21117",
        ] {
            let mut bad = map.clone();
            bad.insert("custom-rendezvous-server", address.into());
            assert!(!check(&bad));
        }
    }
}
