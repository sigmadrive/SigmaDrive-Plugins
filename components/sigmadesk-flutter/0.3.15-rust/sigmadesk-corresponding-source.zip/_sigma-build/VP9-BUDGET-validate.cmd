@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "PATH=C:\Users\cmars\.cargo\bin;%PATH%"
set "CARGO_TARGET_DIR=S:\SigmaNode\_qa\wgc-capture-candidate-20261027\cargo-target"
set "LIBCLANG_PATH=S:\SigmaNode\client\.runtime\sigmadesk-multi\clang\clang\native"
set "VCPKG_ROOT=S:\SigmaNode\client\.runtime\sigmadesk-multi\vcpkg"
set "CARGO_BUILD_JOBS=2"
set "CARGO_NET_OFFLINE=true"
cd /d S:\SigmaNode\_qa\desk-vp9-budget-20261031\engine-source
cargo test --release --locked --offline -p scrap --lib sigma_startup_threads_tests -- --test-threads=1 > ..\thread-policy-tests.log 2>&1
if errorlevel 1 exit /b 1
cargo test --release --locked --offline -p scrap --lib sigma_thread_benchmark --no-run > ..\resource-bench-build.log 2>&1
if errorlevel 1 exit /b 1
exit /b 0