//! Validate the existing private install boundary, then repair only the pinned
//! SigmaDesk component. This is not a replacement for installer-wide repair.
//!
//! No ancestor ACL is written. A bad ancestor fails closed. Every whitelisted
//! descendant is inspected before ANY owner/ACL mutation, including protected
//! child ACLs; root ACL equality never exempts children. Only exact BUILTIN
//! Administrators ownership may be normalized to this user, within this scope,
//! using already granted WRITE_OWNER and without using/enabling a privilege.
use anyhow::{Result, ensure};
use std::{
    collections::{BTreeMap, HashSet},
    fs::{File, OpenOptions},
    os::windows::{fs::OpenOptionsExt, io::AsRawHandle},
    path::{Component, Path, PathBuf},
    ptr::null_mut,
};
use windows_sys::Win32::{
    Foundation::{CloseHandle, HANDLE, LocalFree},
    Security::{
        Authorization::{
            ConvertStringSecurityDescriptorToSecurityDescriptorW, ConvertStringSidToSidW,
            GetSecurityInfo, SE_FILE_OBJECT, SetSecurityInfo,
        },
        ACCESS_ALLOWED_ACE, ACE_HEADER, ACL, ACL_SIZE_INFORMATION, AccessCheck,
        AclSizeInformation, CONTAINER_INHERIT_ACE, DACL_SECURITY_INFORMATION,
        EqualSid, GetAce, GetAclInformation, GetLengthSid, GetSecurityDescriptorControl, IsValidSid,
        INHERITED_ACE, OBJECT_INHERIT_ACE, OWNER_SECURITY_INFORMATION, GROUP_SECURITY_INFORMATION,
        PROTECTED_DACL_SECURITY_INFORMATION, PSID, SE_DACL_PROTECTED,
        DuplicateToken, GENERIC_MAPPING, PRIVILEGE_SET, SecurityImpersonation,
        TOKEN_DUPLICATE, TOKEN_QUERY,
    },
    Storage::FileSystem::{
        BY_HANDLE_FILE_INFORMATION, FILE_ALL_ACCESS, FILE_ATTRIBUTE_DIRECTORY,
        FILE_ATTRIBUTE_REPARSE_POINT, FILE_FLAG_BACKUP_SEMANTICS,
        FILE_FLAG_OPEN_REPARSE_POINT, FILE_READ_ATTRIBUTES, FILE_READ_DATA,
        FILE_SHARE_READ, FILE_SHARE_WRITE, GetFileInformationByHandle,
        FILE_GENERIC_READ, FILE_GENERIC_WRITE, FILE_GENERIC_EXECUTE,
        READ_CONTROL, WRITE_DAC, WRITE_OWNER,
    },
    System::Threading::{GetCurrentProcess, OpenProcessToken},
};

pub struct ScopedComponent {
    pub root: PathBuf,
    /// Keep these until the isolated engine has stopped. They deny DELETE but
    /// are not a substitute for the caller's full SHA/inventory/read handles.
    pub guards: Vec<File>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Kind { Directory, File }

struct LocalMemory(*mut core::ffi::c_void);
impl Drop for LocalMemory {
    fn drop(&mut self) { if !self.0.is_null() { unsafe { LocalFree(self.0); } } }
}
struct Kernel(HANDLE);
impl Drop for Kernel {
    fn drop(&mut self) { if !self.0.is_null() { unsafe { CloseHandle(self.0); } } }
}
struct Sid(LocalMemory);
impl Sid {
    fn current() -> Result<Self> {
        let value = crate::identity::current_sid()?;
        Self::parse(&value)
    }
    fn parse(value: &str) -> Result<Self> {
        let text: Vec<u16> = value.encode_utf16().chain(Some(0)).collect();
        let mut sid = null_mut();
        ensure!(unsafe { ConvertStringSidToSidW(text.as_ptr(), &mut sid) } != 0,
            "component SID unavailable");
        Ok(Self(LocalMemory(sid)))
    }
    fn raw(&self) -> PSID { self.0.0 }
}
struct Security {
    _memory: LocalMemory,
    owner: PSID,
    acl: *mut ACL,
    control: u16,
}
impl Security {
    fn read(file: &File) -> Result<Self> {
        let mut owner = null_mut();
        let mut acl = null_mut();
        let mut group = null_mut();
        let mut sd = null_mut();
        let status = unsafe { GetSecurityInfo(file.as_raw_handle() as HANDLE,
            SE_FILE_OBJECT, OWNER_SECURITY_INFORMATION | GROUP_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION,
            &mut owner, &mut group, &mut acl, null_mut(), &mut sd) };
        let memory = LocalMemory(sd);
        ensure!(status == 0 && !sd.is_null(), "component security unavailable");
        let mut control = 0;
        let mut revision = 0;
        ensure!(unsafe { GetSecurityDescriptorControl(sd, &mut control, &mut revision) } != 0,
            "component security control unavailable");
        Ok(Self { _memory: memory, owner, acl, control })
    }
    fn mine(&self, sid: &Sid) -> bool {
        !self.owner.is_null() && unsafe { EqualSid(self.owner, sid.raw()) } != 0
    }
    fn write_owner_without_privilege(&self) -> Result<()> {
        // AccessCheck sees the same descriptor as the opened object. The copied
        // impersonation token is never installed on a thread or modified. An
        // enabled take-ownership privilege must not substitute for a DACL grant.
        let mut token = null_mut();
        ensure!(unsafe { OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_DUPLICATE,
            &mut token) } != 0, "component owner access token unavailable");
        let token = Kernel(token);
        let mut copy = null_mut();
        ensure!(unsafe { DuplicateToken(token.0, SecurityImpersonation, &mut copy) } != 0,
            "component owner access token unavailable");
        let copy = Kernel(copy);
        let mut mapping = GENERIC_MAPPING { GenericRead: FILE_GENERIC_READ,
            GenericWrite: FILE_GENERIC_WRITE, GenericExecute: FILE_GENERIC_EXECUTE,
            GenericAll: FILE_ALL_ACCESS };
        let mut privileges = [0u64; 128];
        let mut bytes = core::mem::size_of_val(&privileges) as u32;
        let mut granted = 0;
        let mut allowed = 0;
        ensure!(unsafe { AccessCheck(self._memory.0, copy.0, WRITE_OWNER, &mut mapping,
            privileges.as_mut_ptr().cast(), &mut bytes, &mut granted, &mut allowed) } != 0
            && allowed != 0 && granted & WRITE_OWNER != 0
            && unsafe { (*(privileges.as_ptr() as *const PRIVILEGE_SET)).PrivilegeCount } == 0,
            "component existing WRITE_OWNER access required");
        Ok(())
    }
    fn exact_acl(&self, sid: &Sid, kind: Kind, protected: bool, inherited: bool) -> bool {
        if self.acl.is_null() || (protected && self.control & SE_DACL_PROTECTED == 0) { return false; }
        let mut info: ACL_SIZE_INFORMATION = unsafe { core::mem::zeroed() };
        if unsafe { GetAclInformation(self.acl, (&mut info as *mut ACL_SIZE_INFORMATION).cast(),
            core::mem::size_of::<ACL_SIZE_INFORMATION>() as u32, AclSizeInformation) } == 0
            || info.AceCount != 1 { return false; }
        let mut raw = null_mut();
        if unsafe { GetAce(self.acl, 0, &mut raw) } == 0 || raw.is_null() { return false; }
        let header = unsafe { &*(raw as *const ACE_HEADER) };
        // Validate the header before accessing a type-specific ACE or its SID.
        let sid_offset = core::mem::offset_of!(ACCESS_ALLOWED_ACE, SidStart);
        if header.AceType != 0 || (header.AceSize as usize) < sid_offset + 8 { return false; }
        let ace_sid = unsafe { (raw as *mut u8).add(sid_offset) } as PSID;
        if unsafe { GetLengthSid(ace_sid) } as usize > header.AceSize as usize - sid_offset
            || unsafe { IsValidSid(ace_sid) } == 0 { return false; }
        let ace = unsafe { &*(raw as *const ACCESS_ALLOWED_ACE) };
        let wanted = if kind == Kind::Directory { OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE } else { 0 };
        let flags = ace.Header.AceFlags as u32;
        let allowed = wanted | if inherited { INHERITED_ACE } else { 0 };
        // ACCESS_ALLOWED_ACE_TYPE = 0 (Win32 ACE_HEADER ABI).
        ace.Header.AceType == 0
            && flags & !allowed == 0 && flags & wanted == wanted
            && ace.Mask == FILE_ALL_ACCESS
            && unsafe { EqualSid(ace_sid, sid.raw()) } != 0
    }
}

fn relative_files(files: &[String]) -> Result<BTreeMap<String, Kind>> {
    ensure!(!files.is_empty() && files.len() <= 8192, "component inventory bound");
    let mut result = BTreeMap::from([(String::new(), Kind::Directory)]);
    let mut names = HashSet::new();
    for name in files {
        ensure!(!name.is_empty() && name.len() <= 240 && !name.contains(['\\', ':', '\0']),
            "component member name denied");
        ensure!(!name.ends_with(".sigma-part"), "partial component member denied");
        let parts: Vec<_> = name.split('/').collect();
        ensure!(parts.len() <= 32, "component member depth denied");
        for p in &parts {
            ensure!(!p.is_empty() && *p != "." && *p != ".." && !p.ends_with([' ', '.'])
                && !p.chars().any(|c| c.is_control() || "<>\"|?*".contains(c)),
                "component member name denied");
            let stem = p.split('.').next().unwrap_or("").to_ascii_uppercase();
            ensure!(!matches!(stem.as_str(), "CON" | "PRN" | "AUX" | "NUL")
                && !(stem.len() == 4 && (stem.starts_with("COM") || stem.starts_with("LPT"))
                    && stem.as_bytes()[3].is_ascii_digit()), "component device member denied");
        }
        ensure!(names.insert(name.to_ascii_lowercase()), "duplicate component member");
        for i in 1..parts.len() {
            let parent = parts[..i].join("/");
            ensure!(result.get(&parent).is_none_or(|kind| *kind == Kind::Directory),
                "component member type collision");
            result.insert(parent, Kind::Directory);
        }
        ensure!(result.insert(name.clone(), Kind::File).is_none(), "component member collision");
        ensure!(result.len() <= 32768, "component object bound");
    }
    let mut folded = HashSet::new();
    ensure!(result.keys().all(|name| folded.insert(name.to_ascii_lowercase())),
        "component case collision");
    ensure!(["rustdesk.exe", "librustdesk.dll", "flutter_windows.dll"].iter()
        .all(|name| result.get(*name) == Some(&Kind::File)), "component entry inventory missing");
    Ok(result)
}

fn component_parts(relative: &Path) -> Result<[String; 3]> {
    let raw = relative.to_str().ok_or_else(|| anyhow::anyhow!("component scope encoding denied"))?;
    ensure!(raw.split(['/', '\\']).count() == 3
        && !raw.split(['/', '\\']).any(|part| part.is_empty() || part == "." || part == ".."),
        "component scope denied");
    let parts: Vec<_> = relative.components().map(|part| match part {
        Component::Normal(name) => name.to_str().map(str::to_owned), _ => None,
    }).collect();
    ensure!(parts.len() == 3 && parts.iter().all(Option::is_some), "component scope denied");
    let parts = [parts[0].clone().unwrap(), parts[1].clone().unwrap(), parts[2].clone().unwrap()];
    ensure!(parts[0] == "components" && parts[1] == "sigmadesk"
        && parts[2].len() == 64 && parts[2].bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c)),
        "component scope denied");
    Ok(parts)
}

fn inspect(file: &File, kind: Kind) -> Result<(u32, u64)> {
    let mut info: BY_HANDLE_FILE_INFORMATION = unsafe { core::mem::zeroed() };
    ensure!(unsafe { GetFileInformationByHandle(file.as_raw_handle() as HANDLE, &mut info) } != 0,
        "component file identity unavailable");
    inspect_information(&info, kind)
}
fn inspect_information(info: &BY_HANDLE_FILE_INFORMATION, kind: Kind) -> Result<(u32, u64)> {
    ensure!(info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT == 0,
        "linked component object denied");
    ensure!((info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY != 0) == (kind == Kind::Directory),
        "component object type mismatch");
    ensure!(kind == Kind::Directory || info.nNumberOfLinks == 1, "hardlinked component file denied");
    Ok((info.dwVolumeSerialNumber, ((info.nFileIndexHigh as u64) << 32) | info.nFileIndexLow as u64))
}
fn open(path: &Path, kind: Kind, repair: bool) -> Result<File> {
    crate::download::safe(path).map_err(anyhow::Error::msg)?;
    let file = OpenOptions::new().access_mode(READ_CONTROL | FILE_READ_ATTRIBUTES | FILE_READ_DATA
        | if repair { WRITE_DAC } else { 0 })
        .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
        .custom_flags(FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT)
        .open(path)?;
    inspect(&file, kind)?;
    crate::download::safe(path).map_err(anyhow::Error::msg)?;
    Ok(file)
}

struct OwnerNormalization { file: File, kind: Kind, identity: (u32, u64) }
fn owner_allowed(security: &Security, sid: &Sid, admins: &Sid) -> bool {
    security.mine(sid) || security.mine(admins)
}
fn prepare_owner(path: &Path, file: &File, kind: Kind, sid: &Sid, admins: &Sid)
    -> Result<Option<OwnerNormalization>> {
    let security = Security::read(file)?;
    if security.mine(sid) { return Ok(None); }
    ensure!(security.mine(admins), "foreign component owner denied");
    security.write_owner_without_privilege()?;
    let identity = inspect(file, kind)?;
    // No owner/DACL change occurs here. The original deny-delete guard pins the
    // object while a second handle requests ONLY the extra existing owner right.
    crate::download::safe(path).map_err(anyhow::Error::msg)?;
    let owner_file = OpenOptions::new().access_mode(READ_CONTROL | FILE_READ_ATTRIBUTES | WRITE_OWNER)
        .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
        .custom_flags(FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT).open(path)?;
    ensure!(inspect(&owner_file, kind)? == identity, "component ownership identity changed");
    let opened = Security::read(&owner_file)?;
    ensure!(opened.mine(admins), "component ownership changed before preparation");
    opened.write_owner_without_privilege()?;
    Ok(Some(OwnerNormalization { file: owner_file, kind, identity }))
}
fn normalize_owner(plan: &OwnerNormalization, sid: &Sid, admins: &Sid) -> Result<()> {
    ensure!(inspect(&plan.file, plan.kind)? == plan.identity,
        "component ownership identity changed");
    let security = Security::read(&plan.file)?;
    if security.mine(sid) { return Ok(()); }
    ensure!(security.mine(admins), "foreign component owner denied");
    security.write_owner_without_privilege()?;
    ensure!(unsafe { SetSecurityInfo(plan.file.as_raw_handle() as HANDLE, SE_FILE_OBJECT,
        OWNER_SECURITY_INFORMATION, sid.raw(), null_mut(), null_mut(), null_mut()) } == 0,
        "component owner normalization failed");
    ensure!(inspect(&plan.file, plan.kind)? == plan.identity
        && Security::read(&plan.file)?.mine(sid), "component owner normalization verification failed");
    Ok(())
}

fn repair(file: &File, sid: &Sid, sid_text: &str, kind: Kind) -> Result<()> {
    let before = Security::read(file)?;
    ensure!(before.mine(sid), "foreign component owner denied");
    if !before.exact_acl(sid, kind, true, false) {
        let flags = if kind == Kind::Directory { "OICI" } else { "" };
        let text: Vec<u16> = format!("D:P(A;{flags};FA;;;{sid_text})")
            .encode_utf16().chain(Some(0)).collect();
        let mut raw = null_mut();
        ensure!(unsafe { ConvertStringSecurityDescriptorToSecurityDescriptorW(text.as_ptr(),
            1, &mut raw, null_mut()) } != 0, "component private ACL unavailable");
        let _memory = LocalMemory(raw);
        let mut present = 0;
        let mut defaulted = 0;
        let mut acl = null_mut();
        ensure!(unsafe { windows_sys::Win32::Security::GetSecurityDescriptorDacl(raw,
            &mut present, &mut acl, &mut defaulted) } != 0 && present != 0 && !acl.is_null(),
            "component private ACL invalid");
        ensure!(unsafe { SetSecurityInfo(file.as_raw_handle() as HANDLE, SE_FILE_OBJECT,
            DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
            null_mut(), null_mut(), acl, null_mut()) } == 0, "component private ACL repair failed");
    }
    let after = Security::read(file)?;
    ensure!(after.mine(sid) && after.exact_acl(sid, kind, true, false),
        "component private ACL verification failed");
    Ok(())
}

fn inventory(root: &Path, expected: &BTreeMap<String, Kind>) -> Result<()> {
    fn visit(root: &Path, dir: &Path, expected: &BTreeMap<String, Kind>, seen: &mut HashSet<String>) -> Result<()> {
        for entry in std::fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();
            crate::download::safe(&path).map_err(anyhow::Error::msg)?;
            let name = path.strip_prefix(root)?.components().map(|part| {
                part.as_os_str().to_str().ok_or_else(|| anyhow::anyhow!("component name encoding denied"))
            }).collect::<Result<Vec<_>>>()?.join("/");
            let kind = expected.get(&name).ok_or_else(|| anyhow::anyhow!("unlisted component object"))?;
            let metadata = entry.metadata()?;
            ensure!(metadata.is_dir() == (*kind == Kind::Directory)
                && (metadata.is_dir() || metadata.is_file()), "component inventory type mismatch");
            ensure!(seen.insert(name), "duplicate component object");
            if *kind == Kind::Directory { visit(root, &path, expected, seen)?; }
        }
        Ok(())
    }
    let mut seen = HashSet::from([String::new()]);
    visit(root, root, expected, &mut seen)?;
    ensure!(seen.len() == expected.len(), "component inventory missing object");
    Ok(())
}

/// No creation, download, privilege change or install-wide ACL propagation.
/// The caller must pass the signed client's pinned manifest, then still perform
/// its full hash/inventory verification and retain its verified read handles.
pub fn existing_component(relative_component: &Path, expected_files: &[String]) -> Result<ScopedComponent> {
    let anchor = crate::install::local()?.join("Programs").join(crate::identity::PRIVATE_INSTALL_DIRECTORY);
    existing_at(&anchor, relative_component, expected_files)
}
fn existing_at(anchor: &Path, relative: &Path, files: &[String]) -> Result<ScopedComponent> {
    let parts = component_parts(relative)?;
    let expected = relative_files(files)?;
    let sid_text = crate::identity::current_sid()?;
    let sid = Sid::current()?;
    let admins = Sid::parse("S-1-5-32-544")?;
    let mut guards = vec![];
    let mut owner_plans = vec![];
    let mut path = anchor.to_owned();
    for index in 0..3 {
        let file = open(&path, Kind::Directory, false)?;
        let security = Security::read(&file)?;
        ensure!(owner_allowed(&security, &sid, &admins)
            && security.exact_acl(&sid, Kind::Directory, index == 0, index != 0),
            "private component ancestor boundary denied");
        if let Some(plan) = prepare_owner(&path, &file, Kind::Directory, &sid, &admins)? {
            owner_plans.push(plan);
        }
        guards.push(file);
        path.push(&parts[index]);
    }
    let root = path;
    // Lock every expected object against rename/delete and validate its owner
    // and identity BEFORE repairing even one ACL. Full traversal rejects extra
    // objects, links and hardlinks without following or mutating them.
    let mut selected = vec![];
    let mut ids = HashSet::new();
    for (name, kind) in &expected {
        let path = if name.is_empty() { root.clone() } else { root.join(name) };
        let file = open(&path, *kind, true)?;
        ensure!(ids.insert(inspect(&file, *kind)?), "aliased component object denied");
        ensure!(owner_allowed(&Security::read(&file)?, &sid, &admins), "foreign component owner denied");
        if let Some(plan) = prepare_owner(&path, &file, *kind, &sid, &admins)? {
            owner_plans.push(plan);
        }
        selected.push((file, *kind));
    }
    inventory(&root, &expected)?;
    // Revalidate the complete prepared scope before the FIRST mutation. Owner
    // plans exist only for the exact Administrators SID with pre-granted rights.
    for (index, file) in guards.iter().enumerate() {
        inspect(file, Kind::Directory)?;
        let security = Security::read(file)?;
        ensure!(owner_allowed(&security, &sid, &admins)
            && security.exact_acl(&sid, Kind::Directory, index == 0, index != 0),
            "private component ancestor boundary changed");
    }
    for (file, kind) in &selected {
        inspect(file, *kind)?;
        ensure!(owner_allowed(&Security::read(file)?, &sid, &admins), "foreign component owner denied");
    }
    for plan in &owner_plans {
        ensure!(inspect(&plan.file, plan.kind)? == plan.identity,
            "component ownership identity changed");
        let security = Security::read(&plan.file)?;
        ensure!(owner_allowed(&security, &sid, &admins), "foreign component owner denied");
        security.write_owner_without_privilege()?;
    }
    for plan in &owner_plans { normalize_owner(plan, &sid, &admins)?; }
    for (index, file) in guards.iter().enumerate() {
        let security = Security::read(file)?;
        ensure!(security.mine(&sid)
            && security.exact_acl(&sid, Kind::Directory, index == 0, index != 0),
            "private component normalized boundary denied");
    }
    for (file, kind) in &selected { repair(file, &sid, &sid_text, *kind)?; }
    // Setting an inheritable directory ACL can update children. Check ALL of
    // them again after the final mutation, rather than trusting root equality.
    for (file, kind) in &selected {
        let security = Security::read(file)?;
        ensure!(security.mine(&sid) && security.exact_acl(&sid, *kind, true, false),
            "component post-repair boundary denied");
    }
    inventory(&root, &expected)?;
    for (file, kind) in selected { inspect(&file, kind)?; guards.push(file); }
    crate::download::safe(&root).map_err(anyhow::Error::msg)?;
    Ok(ScopedComponent { root, guards })
}

#[cfg(test)]
mod tests {
    use super::*;
    use windows_sys::Win32::Security::{GetSecurityDescriptorDacl, GetSecurityDescriptorOwner};
    const HASH: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    struct Fixture { parent: PathBuf, anchor: PathBuf, relative: PathBuf, files: Vec<String> }
    impl Fixture {
        fn natural() -> Self {
            let parent = std::env::temp_dir().join(format!("sigma-component-scope-{}", uuid::Uuid::new_v4()));
            std::fs::create_dir(&parent).unwrap();
            let anchor = parent.join("install");
            let relative = PathBuf::from("components").join("sigmadesk").join(HASH);
            let root = anchor.join(&relative);
            std::fs::create_dir_all(root.join("data/sub")).unwrap();
            let files = ["rustdesk.exe", "librustdesk.dll", "flutter_windows.dll", "data/sub/fixture.bin"]
                .iter().map(|s| s.to_string()).collect::<Vec<_>>();
            for name in &files { std::fs::write(root.join(name), b"synthetic fixture only").unwrap(); }
            let sid = crate::identity::current_sid().unwrap();
            // Set only the fixture's intended DACL, never its default owner.
            // In particular elevated fixtures retain Administrators ownership.
            test_descriptor(&anchor, &format!("D:P(A;OICI;FA;;;{sid})"));
            Self { parent, anchor, relative, files }
        }
        fn objects(&self) -> Vec<PathBuf> {
            [self.anchor.clone(), self.anchor.join("components"), self.anchor.join("components/sigmadesk")]
                .into_iter().chain(relative_files(&self.files).unwrap().keys()
                    .map(|name| self.root().join(name))).collect()
        }
        fn new() -> Self {
            let fixture = Self::natural();
            let sid = crate::identity::current_sid().unwrap();
            // Explicit normal-user scenario, separate from natural/elevated cases.
            for path in fixture.objects() { test_owner(&path, &sid); }
            fixture
        }
        fn elevated() -> Option<Self> {
            let fixture = Self::natural();
            for path in fixture.objects() {
                if !try_test_owner(&path, "S-1-5-32-544") {
                    eprintln!("component_scope elevated-owner fixture unavailable; no privilege enabled");
                    return None;
                }
            }
            Some(fixture)
        }
        fn bytes(&self) -> Vec<Vec<u8>> {
            self.files.iter().map(|name| std::fs::read(self.root().join(name)).unwrap()).collect()
        }
        fn root(&self) -> PathBuf { self.anchor.join(&self.relative) }
        fn run(&self) -> Result<ScopedComponent> { existing_at(&self.anchor, &self.relative, &self.files) }
    }
    fn try_test_owner(path: &Path, sid: &str) -> bool {
        let Ok(file) = OpenOptions::new().access_mode(READ_CONTROL | WRITE_OWNER)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            .custom_flags(FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT).open(path)
            else { return false; };
        let owner = Sid::parse(sid).unwrap();
        (unsafe { SetSecurityInfo(file.as_raw_handle() as HANDLE, SE_FILE_OBJECT,
            OWNER_SECURITY_INFORMATION, owner.raw(), null_mut(), null_mut(), null_mut()) }) == 0
    }
    fn test_owner(path: &Path, sid: &str) {
        assert!(try_test_owner(path, sid), "synthetic fixture owner setup failed");
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            let Ok(temp) = std::env::temp_dir().canonicalize() else { return };
            let Ok(path) = self.parent.canonicalize() else { return };
            let Some(name) = path.file_name().and_then(|s| s.to_str()) else { return };
            let Some(id) = name.strip_prefix("sigma-component-scope-") else { return };
            if path.parent() == Some(temp.as_path()) && uuid::Uuid::parse_str(id).is_ok() {
                let _ = std::fs::remove_dir_all(path);
            }
        }
    }
    fn test_descriptor(path: &Path, sddl: &str) {
        use windows_sys::Win32::Storage::FileSystem::WRITE_OWNER;
        let file = OpenOptions::new().access_mode(READ_CONTROL | WRITE_DAC | WRITE_OWNER)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            .custom_flags(FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT).open(path).unwrap();
        let text: Vec<u16> = sddl.encode_utf16().chain(Some(0)).collect();
        let mut raw = null_mut();
        assert_ne!(unsafe { ConvertStringSecurityDescriptorToSecurityDescriptorW(text.as_ptr(), 1, &mut raw, null_mut()) }, 0);
        let _memory = LocalMemory(raw);
        let mut acl = null_mut(); let mut owner = null_mut(); let mut present = 0; let mut defaulted = 0;
        assert_ne!(unsafe { GetSecurityDescriptorDacl(raw, &mut present, &mut acl, &mut defaulted) }, 0);
        assert_ne!(unsafe { GetSecurityDescriptorOwner(raw, &mut owner, &mut defaulted) }, 0);
        let flags = DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION
            | if owner.is_null() { 0 } else { OWNER_SECURITY_INFORMATION };
        assert_eq!(unsafe { SetSecurityInfo(file.as_raw_handle() as HANDLE, SE_FILE_OBJECT,
            flags, owner, null_mut(), acl, null_mut()) }, 0);
    }
    fn policy(path: &Path, kind: Kind) -> (bool, bool, Vec<u8>) {
        // Security-only observation of a bounded synthetic fixture. Deliberately
        // do not call inspect(): the hardlink test must inspect its unchanged ACL.
        let file = OpenOptions::new().access_mode(READ_CONTROL | FILE_READ_ATTRIBUTES)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            .custom_flags(FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT)
            .open(path).unwrap();
        let security = Security::read(&file).unwrap();
        let sid = Sid::current().unwrap();
        let acl = if security.acl.is_null() { vec![] } else {
            unsafe { core::slice::from_raw_parts(security.acl.cast::<u8>(), (*security.acl).AclSize as usize).to_vec() }
        };
        (security.mine(&sid), security.exact_acl(&sid, kind, true, false), acl)
    }
    fn is_admin_owner(path: &Path, kind: Kind) -> bool {
        let file = open(path, kind, false).unwrap();
        Security::read(&file).unwrap().mine(&Sid::parse("S-1-5-32-544").unwrap())
    }
    fn memory_security(sddl: &str) -> Security {
        let text: Vec<u16> = sddl.encode_utf16().chain(Some(0)).collect();
        let mut raw = null_mut();
        assert_ne!(unsafe { ConvertStringSecurityDescriptorToSecurityDescriptorW(text.as_ptr(),
            1, &mut raw, null_mut()) }, 0);
        let memory = LocalMemory(raw);
        let mut owner = null_mut();
        let mut acl = null_mut();
        let mut present = 0;
        let mut defaulted = 0;
        let mut control = 0;
        let mut revision = 0;
        assert_ne!(unsafe { GetSecurityDescriptorOwner(raw, &mut owner, &mut defaulted) }, 0);
        assert_ne!(unsafe { GetSecurityDescriptorDacl(raw, &mut present, &mut acl, &mut defaulted) }, 0);
        assert_ne!(unsafe { GetSecurityDescriptorControl(raw, &mut control, &mut revision) }, 0);
        Security { _memory: memory, owner, acl, control }
    }
    fn assert_all_current(fixture: &Fixture) {
        let sid = Sid::current().unwrap();
        for path in fixture.objects() {
            let kind = if path.is_dir() { Kind::Directory } else { Kind::File };
            let file = open(&path, kind, false).unwrap();
            assert!(Security::read(&file).unwrap().mine(&sid));
        }
    }
    #[test]
    fn scope_and_inventory_policy_are_fixed() {
        for bad in ["components/other/x", "components/sigmadesk/x", "../components/sigmadesk/x", "C:/components/sigmadesk/x"] {
            assert!(component_parts(Path::new(bad)).is_err());
        }
        let mut names = vec!["rustdesk.exe".into(), "librustdesk.dll".into(), "flutter_windows.dll".into()];
        assert!(relative_files(&names).is_ok());
        for bad in ["../bad", "a\\b", "a:b", "CON.txt", "a/", "data/../bad", "data/name."] {
            names.push(bad.into()); assert!(relative_files(&names).is_err()); names.pop();
        }
        names.push("RUSTDESK.EXE".into()); assert!(relative_files(&names).is_err());
    }
    #[test]
    fn inherited_parent_policy_and_all_child_repairs_are_preserved() {
        let fixture = Fixture::new();
        let root = fixture.root();
        let sid = crate::identity::current_sid().unwrap();
        test_descriptor(&root.join("data"), &format!("D:P(A;OICI;FA;;;{sid})(A;OICI;FA;;;WD)"));
        test_descriptor(&root.join("rustdesk.exe"), "D:NO_ACCESS_CONTROL");
        assert!(!policy(&root.join("rustdesk.exe"), Kind::File).1);
        let guarded = fixture.run().unwrap();
        for (name, kind) in relative_files(&fixture.files).unwrap() {
            assert!(policy(&root.join(name), kind).1);
        }
        drop(guarded);
    }
    #[test]
    fn unlisted_member_is_rejected_before_any_child_acl_repair() {
        let fixture = Fixture::new(); let root = fixture.root();
        test_descriptor(&root.join("rustdesk.exe"), "D:NO_ACCESS_CONTROL");
        std::fs::write(root.join("unlisted.dll"), b"not a listed member").unwrap();
        assert!(fixture.run().is_err());
        assert!(policy(&root.join("rustdesk.exe"), Kind::File).2.is_empty());
        std::fs::remove_file(root.join("unlisted.dll")).unwrap();
        std::fs::create_dir(root.join("unlisted-empty-dir")).unwrap();
        assert!(fixture.run().is_err());
    }
    #[test]
    fn bad_ancestor_is_rejected_and_sibling_security_is_untouched() {
        let fixture = Fixture::new();
        let sibling = fixture.anchor.join("unrelated-old-cache");
        std::fs::create_dir(&sibling).unwrap();
        let marker = sibling.join("synthetic.bin"); std::fs::write(&marker, b"unchanged").unwrap();
        let sid = crate::identity::current_sid().unwrap();
        test_descriptor(&marker, &format!("D:P(A;;FA;;;{sid})(A;;FR;;;WD)"));
        let before = policy(&marker, Kind::File);
        drop(fixture.run().unwrap());
        assert_eq!(policy(&marker, Kind::File), before);
        assert_eq!(std::fs::read(&marker).unwrap(), b"unchanged");
        test_descriptor(&fixture.anchor, &format!("D:P(A;OICI;FA;;;{sid})(A;OICI;FR;;;WD)"));
        assert!(fixture.run().is_err());
        assert!(!policy(&fixture.anchor, Kind::Directory).1);
    }
    #[test]
    fn hardlinks_are_rejected_before_mutation() {
        let fixture = Fixture::new();
        let file = fixture.root().join("rustdesk.exe");
        let outside = fixture.parent.join("outside-synthetic.bin");
        std::fs::hard_link(&file, &outside).unwrap();
        let before = policy(&outside, Kind::File);
        assert!(fixture.run().is_err());
        assert_eq!(policy(&outside, Kind::File), before);
    }
    #[test]
    fn held_guards_block_delete_and_ancestor_replacement() {
        let fixture = Fixture::new(); let root = fixture.root();
        let guarded = fixture.run().unwrap();
        assert!(std::fs::remove_file(root.join("rustdesk.exe")).is_err());
        assert!(std::fs::rename(&root, root.with_file_name("moved")).is_err());
        assert!(std::fs::rename(&fixture.anchor, fixture.anchor.with_file_name("moved-install")).is_err());
        drop(guarded);
        assert!(std::fs::remove_file(root.join("rustdesk.exe")).is_ok());
    }
    #[test]
    fn another_sid_is_not_accepted_as_the_current_owner() {
        let fixture = Fixture::new();
        let handle = open(&fixture.anchor, Kind::Directory, false).unwrap();
        let security = Security::read(&handle).unwrap();
        let other = Sid::parse("S-1-1-0").unwrap();
        assert!(!security.mine(&other));
        assert!(!security.exact_acl(&other, Kind::Directory, true, false));
    }
    #[test]
    fn reparse_object_is_rejected_without_following_the_target_when_supported() {
        let fixture = Fixture::new();
        let original = fixture.root().join("data/sub/fixture.bin");
        let target = fixture.parent.join("outside-synthetic.bin");
        std::fs::write(&target, b"outside unchanged").unwrap();
        std::fs::remove_file(&original).unwrap();
        if std::os::windows::fs::symlink_file(&target, &original).is_err() {
            // Windows can require developer mode/privilege for test symlinks.
            // Do not enable it. This integration branch is not a passed link test.
            eprintln!("component_scope symlink integration unavailable; no security setting changed");
            return;
        }
        assert!(fixture.run().is_err());
        assert_eq!(std::fs::read(&target).unwrap(), b"outside unchanged");
    }
    #[test]
    fn reparse_attribute_rejection_is_unconditional() {
        let mut info: BY_HANDLE_FILE_INFORMATION = unsafe { core::mem::zeroed() };
        info.dwFileAttributes = FILE_ATTRIBUTE_REPARSE_POINT;
        assert!(inspect_information(&info, Kind::File).is_err());
        info.dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
        assert!(inspect_information(&info, Kind::Directory).is_err());
    }
    #[test]
    fn natural_default_owner_is_checked_without_fixture_normalization() {
        let fixture = Fixture::natural();
        let bytes = fixture.bytes();
        let admin = is_admin_owner(&fixture.anchor, Kind::Directory);
        eprintln!("component_scope natural default owner: {}", if admin { "builtin_admins" } else { "current_user" });
        let guarded = fixture.run().unwrap();
        assert_all_current(&fixture);
        assert_eq!(fixture.bytes(), bytes);
        drop(guarded);
    }
    #[test]
    fn current_owner_does_not_need_write_owner_to_repair_its_child_acl() {
        let fixture = Fixture::new();
        let sid = crate::identity::current_sid().unwrap();
        let target = fixture.root().join("rustdesk.exe");
        test_descriptor(&target, &format!("D:P(A;;0x001701ff;;;{sid})"));
        let bytes = fixture.bytes();
        drop(fixture.run().unwrap());
        assert!(policy(&target, Kind::File).1);
        assert_eq!(fixture.bytes(), bytes);
    }
    #[test]
    fn builtin_admin_owned_single_child_is_normalized_with_existing_rights() {
        let fixture = Fixture::new();
        let target = fixture.root().join("data/sub/fixture.bin");
        if !try_test_owner(&target, "S-1-5-32-544") {
            eprintln!("component_scope elevated-owner fixture unavailable; no privilege enabled");
            return;
        }
        assert!(is_admin_owner(&target, Kind::File));
        let bytes = fixture.bytes();
        drop(fixture.run().unwrap());
        assert_all_current(&fixture);
        assert_eq!(fixture.bytes(), bytes);
    }
    #[test]
    fn builtin_admin_owned_chain_and_all_children_normalize_without_sibling_changes() {
        let Some(fixture) = Fixture::elevated() else { return; };
        assert!(is_admin_owner(&fixture.anchor, Kind::Directory));
        assert!(is_admin_owner(&fixture.anchor.join("components"), Kind::Directory));
        assert!(is_admin_owner(&fixture.root().join("data/sub"), Kind::Directory));
        assert!(is_admin_owner(&fixture.root().join("rustdesk.exe"), Kind::File));
        let sibling = fixture.anchor.join("unrelated-old-cache");
        std::fs::create_dir(&sibling).unwrap();
        let sid = crate::identity::current_sid().unwrap();
        test_owner(&sibling, &sid);
        test_descriptor(&sibling, &format!("D:P(A;OICI;FA;;;{sid})(A;OICI;FR;;;WD)"));
        let marker = sibling.join("fixture.bin"); std::fs::write(&marker, b"unchanged sibling").unwrap();
        let before = policy(&sibling, Kind::Directory);
        let bytes = fixture.bytes();
        drop(fixture.run().unwrap());
        assert_all_current(&fixture);
        assert_eq!(fixture.bytes(), bytes);
        assert_eq!(policy(&sibling, Kind::Directory), before);
        assert_eq!(std::fs::read(&marker).unwrap(), b"unchanged sibling");
    }
    #[test]
    fn admin_owner_without_write_owner_fails_before_any_owner_or_acl_change() {
        let Some(fixture) = Fixture::elevated() else { return; };
        let target = fixture.root().join("rustdesk.exe");
        let sid = crate::identity::current_sid().unwrap();
        test_descriptor(&target, &format!("D:P(A;;0x001701ff;;;{sid})"));
        let before = policy(&target, Kind::File);
        assert!(is_admin_owner(&target, Kind::File));
        assert!(fixture.run().is_err());
        assert!(is_admin_owner(&fixture.anchor, Kind::Directory));
        assert!(is_admin_owner(&target, Kind::File));
        assert_eq!(policy(&target, Kind::File), before);
    }
    #[test]
    fn admin_owner_preflight_rejects_extra_objects_and_hardlinks_without_normalization() {
        let Some(fixture) = Fixture::elevated() else { return; };
        let root = fixture.root();
        let extra = root.join("unlisted.dll"); std::fs::write(&extra, b"unexpected").unwrap();
        assert!(fixture.run().is_err());
        assert!(is_admin_owner(&fixture.anchor, Kind::Directory));
        assert!(is_admin_owner(&root.join("rustdesk.exe"), Kind::File));
        std::fs::remove_file(&extra).unwrap();
        let outside = fixture.parent.join("outside-synthetic.bin");
        std::fs::hard_link(root.join("rustdesk.exe"), &outside).unwrap();
        assert!(fixture.run().is_err());
        assert!(is_admin_owner(&fixture.anchor, Kind::Directory));
        std::fs::remove_file(&outside).unwrap();
    }
    #[test]
    fn admin_owned_ancestor_with_nonprivate_acl_is_never_normalized() {
        let Some(fixture) = Fixture::elevated() else { return; };
        let sid = crate::identity::current_sid().unwrap();
        test_descriptor(&fixture.anchor, &format!("D:P(A;OICI;FA;;;{sid})(A;OICI;FR;;;WD)"));
        let before = policy(&fixture.anchor, Kind::Directory);
        assert!(fixture.run().is_err());
        assert!(is_admin_owner(&fixture.anchor, Kind::Directory));
        assert_eq!(policy(&fixture.anchor, Kind::Directory), before);
    }
    #[test]
    fn admin_exception_does_not_accept_an_arbitrary_other_sid() {
        let sid = Sid::current().unwrap();
        let admins = Sid::parse("S-1-5-32-544").unwrap();
        for value in ["S-1-1-0", "S-1-5-18", "S-1-5-21-1-2-3-9999"] {
            let other = Sid::parse(value).unwrap();
            let security = Security { _memory: LocalMemory(null_mut()), owner: other.raw(),
                acl: null_mut(), control: 0 };
            assert!(!owner_allowed(&security, &sid, &admins));
        }
    }
    #[test]
    fn admin_owner_descriptor_requires_real_access_check_with_existing_write_owner() {
        // Owner/group are actual BA SIDs in a valid Windows descriptor. This
        // exercises the real OS AccessCheck with this process's copied token,
        // not an owner-policy mock or a claim of filesystem owner normalization.
        let sid_text = crate::identity::current_sid().unwrap();
        let sid = Sid::current().unwrap();
        let admins = Sid::parse("S-1-5-32-544").unwrap();
        let security = memory_security(&format!("O:BAG:BAD:P(A;OICI;FA;;;{sid_text})"));
        assert!(security.mine(&admins));
        assert!(!security.mine(&sid));
        assert!(security.exact_acl(&sid, Kind::Directory, true, false));
        security.write_owner_without_privilege().unwrap();
        eprintln!("component_scope BA descriptor AccessCheck existing_WRITE_OWNER=granted privilege_used=0");
    }
    #[test]
    fn admin_owner_descriptor_without_write_owner_is_denied_by_real_access_check() {
        let sid_text = crate::identity::current_sid().unwrap();
        let admins = Sid::parse("S-1-5-32-544").unwrap();
        let security = memory_security(&format!("O:BAG:BAD:P(A;;0x001701ff;;;{sid_text})"));
        assert!(security.mine(&admins));
        assert!(security.write_owner_without_privilege().is_err());
        eprintln!("component_scope BA descriptor AccessCheck missing_WRITE_OWNER=denied");
    }
    #[test]
    fn synthetic_wide_cache_cost_is_separate_from_scoped_component_work() {
        // Timing evidence only: no threshold assertion, no real installation,
        // and no claim about remote-PC latency. Fixture::new is explicitly the
        // current-user-owned case; elevated cases above exercise real BA owners.
        let fixture = Fixture::new();
        let cache = fixture.anchor.join("unrelated-synthetic-cache");
        let per_directory = 250;
        let directories = 16;
        for directory in 0..directories {
            let dir = cache.join(format!("d{directory}"));
            std::fs::create_dir_all(&dir).unwrap();
            for file in 0..per_directory {
                std::fs::write(dir.join(format!("f{file}.bin")), b"synthetic cache only").unwrap();
            }
        }
        let bytes = fixture.bytes();
        for round in 1..=3 {
            let start = std::time::Instant::now();
            crate::identity::protect_directory(&fixture.anchor).unwrap();
            let full_ms = start.elapsed().as_millis();
            let start = std::time::Instant::now();
            let scoped = fixture.run().unwrap();
            let scoped_ms = start.elapsed().as_millis();
            drop(scoped);
            eprintln!("component_scope synthetic_acl_timing cache_files={} selected_files={} round={} full_root_ms={} scoped_ms={}",
                per_directory * directories, fixture.files.len(), round, full_ms, scoped_ms);
        }
        assert_eq!(fixture.bytes(), bytes);
        assert_eq!(std::fs::read(cache.join("d0/f0.bin")).unwrap(), b"synthetic cache only");
        assert_eq!(std::fs::read(cache.join("d15/f249.bin")).unwrap(), b"synthetic cache only");
    }
}
