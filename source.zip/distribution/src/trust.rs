//! A release-specific, offline trust chain. Remote input can supply payload bytes
//! only, never a new root, URL, command, version, or installer arguments.
use ed25519_dalek::{Signature, VerifyingKey};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::BTreeSet;
use time::{OffsetDateTime, format_description::well_known::Rfc3339};

pub const ROOT: &str = include_str!("../public/component-root.json");
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub type Result<T> = std::result::Result<T, String>;
#[derive(Clone, Debug)]
pub struct Chunk {
    pub hash: String,
    pub size: u64,
    pub wire: Option<(String, u64)>,
}
impl Chunk {
    pub fn transport(&self) -> Self {
        match &self.wire {
            Some((hash, size)) => Self {
                hash: hash.clone(),
                size: *size,
                wire: None,
            },
            None => self.clone(),
        }
    }
}
#[derive(Clone, Debug)]
pub struct Release {
    pub filename: String,
    pub version: String,
    pub sequence: u64,
    pub manifest_hash: String,
    pub verification: &'static str,
    pub hash: String,
    pub size: u64,
    pub commit: String,
    pub chunks: Vec<Chunk>,
}
pub fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|v| format!("{v:02x}"))
        .collect()
}
fn field<'a>(v: &'a Value, k: &str) -> Result<&'a str> {
    v[k].as_str().ok_or_else(|| format!("missing string: {k}"))
}
fn number(v: &Value, k: &str) -> Result<u64> {
    v[k].as_u64().ok_or_else(|| format!("missing integer: {k}"))
}
fn hex(s: &str, n: usize) -> Result<Vec<u8>> {
    if !is_hex(s, n * 2) {
        return Err("invalid digest/key/signature".into());
    }
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).map_err(|e| e.to_string()))
        .collect()
}
fn is_hex(s: &str, n: usize) -> bool {
    s.len() == n
        && s.bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}
fn json(raw: &str) -> Result<Value> {
    serde_json::from_str(raw).map_err(|e| e.to_string())
}
fn valid_until(signed: &Value, now: OffsetDateTime) -> Result<()> {
    let expires =
        OffsetDateTime::parse(field(signed, "expires")?, &Rfc3339).map_err(|e| e.to_string())?;
    if now >= expires {
        return Err("release metadata expired; obtain a new SigmaDrive setup".into());
    }
    Ok(())
}
fn role(root: &Value, envelope: &Value, name: &str, now: OffsetDateTime) -> Result<()> {
    let signed = &envelope["signed"];
    if field(signed, "_type")? != name {
        return Err("metadata role mismatch".into());
    }
    valid_until(signed, now)?;
    let rule = &root["roles"][name];
    let threshold = number(rule, "threshold")? as usize;
    let ids = rule["keyids"].as_array().ok_or("missing role keys")?;
    if threshold == 0 || threshold > ids.len() {
        return Err("invalid threshold".into());
    }
    // serde_json's default Map is a BTreeMap: recursively sorted keys, compact
    // integer JSON, matching the canonical encoding of this embedded catalog.
    let canonical = serde_json::to_vec(signed).map_err(|e| e.to_string())?;
    let mut seen = BTreeSet::new();
    for sig in envelope["signatures"]
        .as_array()
        .ok_or("missing signatures")?
    {
        let id = field(sig, "keyid")?;
        if !ids.iter().any(|v| v.as_str() == Some(id)) || seen.contains(id) {
            continue;
        }
        let key = &root["keys"][id];
        if field(key, "keytype")? != "ed25519" || field(key, "scheme")? != "ed25519" {
            continue;
        }
        let public: [u8; 32] = hex(field(&key["keyval"], "public")?, 32)?
            .try_into()
            .map_err(|_| "key length")?;
        let signature =
            Signature::from_slice(&hex(field(sig, "sig")?, 64)?).map_err(|e| e.to_string())?;
        let key = VerifyingKey::from_bytes(&public).map_err(|e| e.to_string())?;
        if key.verify_strict(&canonical, &signature).is_ok() {
            seen.insert(id);
        }
    }
    if seen.len() < threshold {
        return Err(format!("{name}: signature threshold not met"));
    }
    Ok(())
}
fn link(parent: &Value, name: &str, raw: &str, child: &Value) -> Result<()> {
    let desc = &parent["signed"]["meta"][name];
    if number(desc, "version")? != number(&child["signed"], "version")?
        || number(desc, "length")? != raw.len() as u64
        || field(&desc["hashes"], "sha256")? != digest(raw.as_bytes())
    {
        return Err("metadata hash/length/version mismatch".into());
    }
    Ok(())
}
pub fn verify(raw: &str, now: OffsetDateTime) -> Result<Release> {
    let trusted = json(ROOT)?;
    role(&trusted["signed"], &trusted, "root", now)?;
    let bundle = json(raw)?;
    if field(&bundle, "schema")? != "sigmadrive.catalog-bundle/v1" {
        return Err("catalog schema".into());
    }
    let meta = &bundle["metadata"];
    if field(meta, "1.root.json")? != ROOT {
        return Err("unexpected trust root".into());
    }
    let timestamp = json(field(meta, "timestamp.json")?)?;
    let snapshot_raw = field(meta, "snapshot.json")?;
    let snapshot = json(snapshot_raw)?;
    let targets_raw = field(meta, "targets.json")?;
    let targets = json(targets_raw)?;
    for (name, envelope) in [
        ("timestamp", &timestamp),
        ("snapshot", &snapshot),
        ("targets", &targets),
    ] {
        role(&trusted["signed"], envelope, name, now)?;
    }
    link(&timestamp, "snapshot.json", snapshot_raw, &snapshot)?;
    link(&snapshot, "targets.json", targets_raw, &targets)?;
    let entries = targets["signed"]["targets"]
        .as_object()
        .ok_or("missing targets")?;
    if entries.len() != 1 {
        return Err("one installer target required".into());
    }
    // The bootstrap bundle is client-only; optional components use the product
    // catalog after installation and are never part of the update transaction.
    let target = &targets["signed"]["targets"]["stable/windows-amd64/package.bin"];
    let c = &target["custom"];
    if field(c, "product_id")? != "sigmadrive.flutter.rust"
        || field(c, "ui_runtime")? != "flutter"
        || !valid_version(field(c, "version")?)
        || field(c, "core_engine")? != "rust"
        || field(c, "format")? != "sigmadrive.package/v1"
        || field(c, "os")? != "windows"
        || field(c, "arch")? != "amd64"
        || c["revoked"].as_bool() == Some(true)
        || number(c, "schema")? != 3
    {
        return Err("unsupported installer".into());
    }
    let commit = field(c, "artifact_commit")?.to_owned();
    let hash = field(&target["hashes"], "sha256")?.to_owned();
    let size = number(target, "length")?;
    let manifest_hash = field(c, "package_manifest_sha256")?.to_owned();
    if !is_hex(&manifest_hash, 64) {
        return Err("package manifest identity".into());
    }
    if !is_hex(&commit, 40) || !is_hex(&hash, 64) || size == 0 || size > 256 * 1024 * 1024 {
        return Err("installer budget/identity".into());
    }
    let schema = field(&c["chunks"], "schema")?;
    let delta = schema == "sigmadrive.chunks/v2";
    if schema != "sigmadrive.chunks/v1" && !delta {
        return Err("chunk schema".into());
    }
    let mut chunks = Vec::new();
    for ch in c["chunks"]["chunks"].as_array().ok_or("missing chunks")? {
        let hash = field(ch, "sha256")?.to_owned();
        let size = number(ch, "size")?;
        if !is_hex(&hash, 64) || size == 0 || size > 4 * 1024 * 1024 {
            return Err("invalid chunk".into());
        }
        let wire = if delta {
            let h = field(ch, "wire_sha256")?.to_owned();
            let n = number(ch, "wire_size")?;
            if !is_hex(&h, 64) || n == 0 || n > 4 * 1024 * 1024 || size > 1024 * 1024 {
                return Err("invalid compressed chunk".into());
            }
            Some((h, n))
        } else {
            if !ch["wire_sha256"].is_null() || !ch["wire_size"].is_null() {
                return Err("unexpected chunk encoding".into());
            }
            None
        };
        chunks.push(Chunk { hash, size, wire });
    }
    if chunks.is_empty()
        || chunks.len() > 4096
        || chunks.iter().map(|c| c.size).sum::<u64>() != size
        || !delta
            && chunks
                .iter()
                .take(chunks.len() - 1)
                .any(|c| c.size != 4 * 1024 * 1024)
    {
        return Err("invalid chunk layout".into());
    }
    Ok(Release {
        filename: format!("SigmaDriveRust_{}.package", field(c, "version")?),
        version: field(c, "version")?.into(),
        sequence: number(&timestamp["signed"], "version")?,
        manifest_hash,
        verification: "threshold-signed-catalog",
        hash,
        size,
        commit,
        chunks,
    })
}

pub fn valid_version(s: &str) -> bool {
    let a = s.split('.').collect::<Vec<_>>();
    a.len() == 3
        && a.iter().all(|p| {
            !p.is_empty()
                && p.len() <= 6
                && p.bytes().all(|b| b.is_ascii_digit())
                && (p.len() == 1 || !p.starts_with('0'))
        })
}
pub fn version_tuple(s: &str) -> Result<(u32, u32, u32)> {
    if !valid_version(s) {
        return Err("invalid version".into());
    }
    let a = s
        .split('.')
        .map(|p| p.parse::<u32>().map_err(|_| "invalid version".to_owned()))
        .collect::<Result<Vec<_>>>()?;
    Ok((a[0], a[1], a[2]))
}

/// Installed signed file identity remains verifiable offline after update metadata expires.
/// This is never used to select or install an update.
pub fn verify_installed(raw: &str) -> Result<Release> {
    let bundle = json(raw)?;
    let meta = &bundle["metadata"];
    let mut expiries = Vec::new();
    for name in [
        "1.root.json",
        "timestamp.json",
        "snapshot.json",
        "targets.json",
    ] {
        let e = json(field(meta, name)?)?;
        let expires = OffsetDateTime::parse(field(&e["signed"], "expires")?, &Rfc3339)
            .map_err(|e| e.to_string())?;
        expiries.push(expires);
    }
    let at = expiries
        .into_iter()
        .min()
        .ok_or("installed metadata missing")?
        - time::Duration::seconds(1);
    verify(raw, at)
}
