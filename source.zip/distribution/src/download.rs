use crate::trust::{self, Chunk, Release, Result};
use std::os::windows::fs::{MetadataExt, OpenOptionsExt};
use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
    ptr::{null, null_mut},
    sync::atomic::{AtomicBool, Ordering},
    time::{Duration, Instant},
};
use windows_sys::Win32::{Foundation::GetLastError, Networking::WinHttp::*};

pub fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}
struct Handle(*mut std::ffi::c_void);
impl Drop for Handle {
    fn drop(&mut self) {
        unsafe {
            WinHttpCloseHandle(self.0);
        }
    }
}
fn handle(h: *mut std::ffi::c_void) -> std::result::Result<Handle, FetchError> {
    if h.is_null() {
        Err(net_error())
    } else {
        Ok(Handle(h))
    }
}
#[derive(Debug)]
struct FetchError {
    message: String,
    retry: bool,
    public_cdn_denied: bool,
}
fn net_error() -> FetchError {
    let code = unsafe { GetLastError() };
    FetchError {
        message: format!("WinHTTP error {code}"),
        retry: matches!(code, 12002 | 12007 | 12029 | 12030 | 12031),
        public_cdn_denied: false,
    }
}
fn status_error(status: u32) -> FetchError {
    FetchError {
        message: format!("HTTP {status}"),
        retry: matches!(status, 404 | 408 | 429 | 500..=599),
        public_cdn_denied: status == 403,
    }
}
// Both routes are fixed unauthenticated public artifact sources, bound to the
// same immutable commit and signed content hash. A CDN availability rejection
// does not grant access to anything on the origin. Origin denials, TLS failures
// and integrity failures remain fatal. Never reuse this rule for peer/cloud auth.
fn may_use_public_origin(host: &str, error: &FetchError) -> bool {
    host == "cdn.jsdelivr.net" && (error.retry || error.public_cdn_denied)
}
fn cancelled(cancel: &AtomicBool) -> Result<()> {
    if cancel.load(Ordering::Relaxed) {
        Err("cancelled".into())
    } else {
        Ok(())
    }
}
pub fn safe(path: &Path) -> Result<()> {
    for p in path.ancestors() {
        match fs::symlink_metadata(p) {
            Ok(m) => {
                if m.file_attributes() & 0x400 != 0 {
                    return Err("linked cache path denied".into());
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.to_string()),
        }
    }
    Ok(())
}
pub fn verified(path: &Path, size: u64, hash: &str) -> Result<()> {
    safe(path)?;
    let mut file = OpenOptions::new()
        .read(true)
        .share_mode(1)
        .open(path)
        .map_err(|e| e.to_string())?;
    if !file.metadata().map_err(|e| e.to_string())?.is_file() {
        return Err("nonregular cache file".into());
    }
    if file.metadata().map_err(|e| e.to_string())?.len() != size {
        return Err("payload length mismatch".into());
    }
    let mut bytes = Vec::new();
    Read::by_ref(&mut file)
        .take(size + 1)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() as u64 != size || trust::digest(&bytes) != hash {
        return Err("payload hash mismatch".into());
    }
    Ok(())
}
fn session() -> std::result::Result<Handle, FetchError> {
    unsafe {
        let agent = wide("SigmaDrive-Setup/2");
        let s = handle(WinHttpOpen(
            agent.as_ptr(),
            WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
            null(),
            null(),
            0,
        ))?;
        if WinHttpSetTimeouts(s.0, 5000, 5000, 5000, 5000) == 0 {
            return Err(net_error());
        }
        Ok(s)
    }
}
fn fetch(
    session: &Handle,
    host: &str,
    path: &str,
    ch: &Chunk,
    cancel: &AtomicBool,
    progress: &mut dyn FnMut(u64),
) -> std::result::Result<Vec<u8>, FetchError> {
    unsafe {
        let server = wide(host);
        let conn = handle(WinHttpConnect(session.0, server.as_ptr(), 443, 0))?;
        let method = wide("GET");
        let target = wide(path);
        let request = handle(WinHttpOpenRequest(
            conn.0,
            method.as_ptr(),
            target.as_ptr(),
            null(),
            null(),
            null(),
            WINHTTP_FLAG_SECURE,
        ))?;
        let policy = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
        if WinHttpSetOption(
            request.0,
            WINHTTP_OPTION_REDIRECT_POLICY,
            &policy as *const _ as _,
            4,
        ) == 0
        {
            return Err(net_error());
        }
        let disabled = WINHTTP_DISABLE_COOKIES | WINHTTP_DISABLE_AUTHENTICATION;
        if WinHttpSetOption(
            request.0,
            WINHTTP_OPTION_DISABLE_FEATURE,
            &disabled as *const _ as _,
            4,
        ) == 0
        {
            return Err(net_error());
        }
        let headers = wide("Accept-Encoding: identity\r\n");
        if WinHttpSendRequest(request.0, headers.as_ptr(), u32::MAX, null(), 0, 0, 0) == 0 {
            return Err(net_error());
        }
        if WinHttpReceiveResponse(request.0, null_mut()) == 0 {
            return Err(net_error());
        }
        let mut status = 0u32;
        let mut len = 4;
        if WinHttpQueryHeaders(
            request.0,
            WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            null(),
            &mut status as *mut _ as _,
            &mut len,
            null_mut(),
        ) == 0
        {
            return Err(net_error());
        }
        if status != 200 {
            return Err(status_error(status));
        }
        let mut bytes = Vec::with_capacity(ch.size as usize);
        let start = Instant::now();
        let mut buf = [0u8; 65536];
        loop {
            if cancel.load(Ordering::Relaxed) {
                return Err(FetchError {
                    message: "cancelled".into(),
                    retry: false,
                    public_cdn_denied: false,
                });
            }
            if start.elapsed() > Duration::from_secs(90) {
                return Err(FetchError {
                    message: "chunk time budget".into(),
                    retry: true,
                    public_cdn_denied: false,
                });
            }
            let mut read = 0u32;
            if WinHttpReadData(
                request.0,
                buf.as_mut_ptr() as _,
                buf.len() as u32,
                &mut read,
            ) == 0
            {
                return Err(net_error());
            }
            if read == 0 {
                break;
            }
            bytes.extend_from_slice(&buf[..read as usize]);
            progress(read as u64);
            if bytes.len() as u64 > ch.size {
                return Err(FetchError {
                    message: "oversize chunk".into(),
                    retry: false,
                    public_cdn_denied: false,
                });
            }
        }
        if !ch.hash.is_empty()
            && (bytes.len() as u64 != ch.size || trust::digest(&bytes) != ch.hash)
        {
            return Err(FetchError {
                message: "chunk integrity mismatch".into(),
                retry: false,
                public_cdn_denied: false,
            });
        }
        Ok(bytes)
    }
}
pub struct Prepared {
    pub path: PathBuf,
    pub received: u64,
    pub reused: usize,
    pub downloaded: usize,
    pub _lock: File,
}
fn write_new(path: &Path, bytes: &[u8]) -> Result<()> {
    safe(path)?;
    let mut f = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|e| e.to_string())?;
    f.write_all(bytes)
        .and_then(|_| f.sync_all())
        .map_err(|e| e.to_string())
}
pub fn prepare(
    r: &Release,
    dir: &Path,
    cancel: &AtomicBool,
    stop_after: Option<usize>,
    notify: &mut dyn FnMut(u32, &str),
) -> Result<Prepared> {
    prepare_with_progress(r, dir, cancel, stop_after, &mut |p| notify(p.percent, p.message))
}

/// Counters describe this attempt: received includes bytes from failed retries;
/// chunk counts advance only after their content has been verified and stored.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Progress {
    pub percent: u32,
    pub stage: &'static str,
    pub message: &'static str,
    pub received_bytes: u64,
    pub reused_chunks: usize,
    pub downloaded_chunks: usize,
    pub total_chunks: usize,
}

pub fn prepare_with_progress(
    r: &Release,
    dir: &Path,
    cancel: &AtomicBool,
    stop_after: Option<usize>,
    notify: &mut dyn FnMut(&Progress),
) -> Result<Prepared> {
    if !dir.is_absolute() {
        return Err("absolute cache required".into());
    }
    safe(dir)?;
    fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    let lock_path = dir.join("setup.lock");
    safe(&lock_path)?;
    let lock = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .share_mode(0)
        .open(lock_path)
        .map_err(|_| "setup already running or cache inaccessible")?;
    let log_path = dir.join("download.jsonl");
    safe(&log_path)?;
    let mut log = OpenOptions::new()
        .create(true)
        .append(true)
        .open(log_path)
        .map_err(|e| e.to_string())?;
    let mut completed = 0;
    let mut received = 0;
    let mut reused = 0;
    let mut downloaded = 0;
    writeln!(
        log,
        "{}",
        serde_json::json!({"event":"start","version":trust::VERSION,"artifact":r.filename,"verification":r.verification})
    )
    .map_err(|e| e.to_string())?;
    // Only authenticated segments of the four installed product binaries are
    // imported. The cache is shared by releases and every use rechecks SHA-256.
    let mut cache_bytes = 0u64;
    for entry in fs::read_dir(dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        safe(&entry.path())?;
        let m = entry.metadata().map_err(|e| e.to_string())?;
        if m.is_file() {
            cache_bytes = cache_bytes.saturating_add(m.len());
        }
    }
    if cache_bytes.saturating_add(r.size * 2) > 2 * 1024 * 1024 * 1024 {
        return Err(
            "설치 캐시 공간 한도를 초과했습니다. 이전 설치 캐시를 정리한 뒤 다시 시도해 주세요."
                .into(),
        );
    }
    notify(&Progress { percent: 1, stage: "reuse_scan", message: "기존 설치 파일에서 재사용할 부분을 확인하고 있습니다.",
        received_bytes: received, reused_chunks: reused, downloaded_chunks: downloaded, total_chunks: r.chunks.len() });
    crate::delta::seed(r, dir, cancel, &mut log)?;
    let session = session().map_err(|e| e.message)?;
    for ch in &r.chunks {
        cancelled(cancel)?;
        let p = dir.join(format!("{}.bin", ch.hash));
        safe(&p)?;
        if verified(&p, ch.size, &ch.hash).is_ok() {
            reused += 1;
            writeln!(
                log,
                "{}",
                serde_json::json!({"event":"reuse","sha256":ch.hash})
            )
            .map_err(|e| e.to_string())?;
        } else {
            // Only this release's content-addressed cache object may be repaired.
            if p.exists() {
                if !p.is_file() {
                    return Err("nonregular cache object".into());
                }
                fs::remove_file(&p).map_err(|e| e.to_string())?;
            }
            let wire = ch.transport();
            let suffix = format!("chunks/sha256/{}/{}.bin", &wire.hash[..2], wire.hash);
            let mut bytes = None;
            for (host, base) in [
                (
                    "cdn.jsdelivr.net",
                    format!("/gh/sigmadrive/SigmaDrive-Plugins@{}/", r.commit),
                ),
                (
                    "raw.githubusercontent.com",
                    format!("/sigmadrive/SigmaDrive-Plugins/{}/", r.commit),
                ),
            ] {
                cancelled(cancel)?;
                let mut within = 0;
                let result = fetch(
                    &session,
                    host,
                    &format!("{base}{suffix}"),
                    &wire,
                    cancel,
                    &mut |n| {
                        received += n;
                        within += n;
                        notify(&Progress { percent: ((completed * 90 / r.size) as u32).max(1),
                            stage: "chunks", message: "설치에 필요한 조각을 수신·검증하고 있습니다.",
                            received_bytes: received, reused_chunks: reused, downloaded_chunks: downloaded, total_chunks: r.chunks.len() });
                    },
                );
                writeln!(log,"{}",serde_json::json!({"event":"fetch","source":host,"sha256":ch.hash,"received":within,"result":result.as_ref().map(|_|"verified").unwrap_or("failed"),"error":result.as_ref().err().map(|e|&e.message)})).map_err(|e|e.to_string())?;
                match result {
                    Ok(v) => {
                        bytes = Some(v);
                        break;
                    }
                    Err(e) => {
                        if !may_use_public_origin(host, &e) || cancel.load(Ordering::Relaxed) {
                            return Err(e.message);
                        }
                    }
                }
            }
            let bytes = crate::delta::decode(ch, bytes.ok_or("download failed")?)?;
            let temp = dir.join(format!("{}.part", ch.hash));
            safe(&temp)?;
            if temp.exists() {
                if !temp.is_file() {
                    return Err("nonregular temporary file".into());
                }
                fs::remove_file(&temp).map_err(|e| e.to_string())?;
            }
            write_new(&temp, &bytes)?;
            fs::rename(&temp, &p).map_err(|e| e.to_string())?;
            downloaded += 1;
        }
        completed += ch.size;
        notify(&Progress { percent: ((completed * 90 / r.size) as u32).max(1),
            stage: "chunks", message: "설치에 필요한 조각을 수신·검증하고 있습니다.",
            received_bytes: received, reused_chunks: reused, downloaded_chunks: downloaded, total_chunks: r.chunks.len() });
        if stop_after == Some(downloaded) {
            return Err("cancelled after verified chunk (test)".into());
        }
    }
    cancelled(cancel)?;
    notify(&Progress { percent: 92, stage: "package_verify", message: "확보한 조각으로 설치 파일을 구성하고 전체 무결성을 확인하고 있습니다.",
        received_bytes: received, reused_chunks: reused, downloaded_chunks: downloaded, total_chunks: r.chunks.len() });
    let output = dir.join(&r.filename);
    safe(&output)?;
    if output.exists() {
        verified(&output, r.size, &r.hash)?;
    } else {
        let temp = dir.join("installer.part");
        safe(&temp)?;
        if temp.exists() {
            if !temp.is_file() {
                return Err("nonregular temporary file".into());
            }
            fs::remove_file(&temp).map_err(|e| e.to_string())?;
        }
        let mut out = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temp)
            .map_err(|e| e.to_string())?;
        for ch in &r.chunks {
            cancelled(cancel)?;
            let p = dir.join(format!("{}.bin", ch.hash));
            verified(&p, ch.size, &ch.hash)?;
            let mut input = OpenOptions::new()
                .read(true)
                .share_mode(1)
                .open(p)
                .map_err(|e| e.to_string())?;
            std::io::copy(&mut Read::by_ref(&mut input).take(ch.size + 1), &mut out)
                .map_err(|e| e.to_string())?;
        }
        out.sync_all().map_err(|e| e.to_string())?;
        drop(out);
        verified(&temp, r.size, &r.hash)?;
        fs::rename(&temp, &output).map_err(|e| e.to_string())?;
    }
    cancelled(cancel)?;
    writeln!(log,"{}",serde_json::json!({"event":"verified","sha256":r.hash,"received":received,"reused":reused,"downloaded":downloaded})).map_err(|e|e.to_string())?;
    Ok(Prepared {
        path: output,
        received,
        reused,
        downloaded,
        _lock: lock,
    })
}
pub fn catalog(cancel: &AtomicBool) -> Result<String> {
    Ok(catalog_selection(cancel)?.raw)
}
pub fn catalog_selection(cancel: &AtomicBool) -> Result<crate::catalog::Candidate> {
    let session = session().map_err(|e| e.message)?;
    let bound = Chunk {
        hash: String::new(),
        size: 1024 * 1024,
        wire: None,
    };
    let mut candidates = Vec::new();
    for (host, path) in [
        (
            "cdn.jsdelivr.net",
            "/gh/sigmadrive/SigmaDrive-Plugins@main/channels/rust-windows-stable.json",
        ),
        (
            "raw.githubusercontent.com",
            "/sigmadrive/SigmaDrive-Plugins/main/channels/rust-windows-stable.json",
        ),
    ] {
        match fetch(&session, host, path, &bound, cancel, &mut |_| {}) {
            Ok(b) => candidates.push(
                String::from_utf8(b)
                    .map_err(|_| "catalog encoding".into())
                    .and_then(|raw| crate::catalog::verify(raw, host)),
            ),
            Err(e) => {
                if cancel.load(Ordering::Acquire) || (!e.retry && !e.public_cdn_denied) {
                    return Err(e.message);
                }
                candidates.push(Err(e.message));
            }
        }
    }
    let origin = candidates.pop().ok_or("GitHub catalog unavailable")?;
    let cdn = candidates.pop().ok_or("CDN catalog unavailable")?;
    crate::catalog::select(cdn, origin)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn retry_does_not_bypass_access_or_integrity() {
        for s in [401, 403, 301, 302, 400] {
            assert!(!status_error(s).retry);
        }
        for s in [404, 408, 429, 500, 503] {
            assert!(status_error(s).retry);
        }
    }
    #[test]
    fn public_cdn_denial_can_use_only_the_fixed_public_origin() {
        assert!(may_use_public_origin(
            "cdn.jsdelivr.net",
            &status_error(403)
        ));
        assert!(!may_use_public_origin(
            "raw.githubusercontent.com",
            &status_error(403)
        ));
        assert!(!may_use_public_origin(
            "cdn.jsdelivr.net",
            &status_error(401)
        ));
        assert!(!may_use_public_origin("other.example", &status_error(403)));
        assert!(!may_use_public_origin(
            "cdn.jsdelivr.net",
            &FetchError {
                message: "integrity mismatch".into(),
                retry: false,
                public_cdn_denied: false
            }
        ));
    }
    #[test]
    fn existing_corrupt_output_rejected() {
        let dir =
            std::env::temp_dir().join(format!("sigma-setup-hash-test-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let p = dir.join("payload");
        fs::write(&p, b"hello").unwrap();
        assert!(verified(&p, 5, &trust::digest(b"hello")).is_ok());
        assert!(verified(&p, 5, &trust::digest(b"other")).is_err());
        assert!(verified(&p, 4, &trust::digest(b"hello")).is_err());
        fs::remove_file(p).unwrap();
        fs::remove_dir(dir).unwrap();
    }

    struct ProgressFixture(PathBuf);
    impl ProgressFixture {
        fn new() -> Self {
            let dir = std::env::temp_dir().join(format!("sigmadrive-update-progress-test-{}", uuid::Uuid::new_v4().simple()));
            fs::create_dir(&dir).unwrap();
            Self(dir)
        }
        fn release(&self) -> Release {
            let parts = [b"synthetic first chunk".as_slice(), b"synthetic second chunk".as_slice()];
            let mut chunks = Vec::new();
            for part in parts {
                let hash = trust::digest(part);
                fs::write(self.0.join(format!("{hash}.bin")), part).unwrap();
                chunks.push(Chunk { hash, size: part.len() as u64, wire: None });
            }
            let payload = parts.concat();
            Release { filename: "synthetic.package".into(), version: "0.3.18".into(), sequence: 19,
                manifest_hash: trust::digest(b"synthetic manifest"), verification: "synthetic test fixture",
                hash: trust::digest(&payload), size: payload.len() as u64, commit: "a".repeat(40), chunks }
        }
    }
    impl Drop for ProgressFixture {
        fn drop(&mut self) {
            // Verify the resolved direct temp child and its fresh UUID before recursive cleanup.
            let target = self.0.canonicalize().unwrap();
            let temp = std::env::temp_dir().canonicalize().unwrap();
            assert_eq!(target.parent(), Some(temp.as_path()));
            let name = target.file_name().unwrap().to_str().unwrap();
            let suffix = name.strip_prefix("sigmadrive-update-progress-test-").unwrap();
            assert_eq!(suffix.len(), 32);
            assert!(uuid::Uuid::parse_str(suffix).is_ok());
            assert_eq!(target.file_name(), self.0.file_name());
            fs::remove_dir_all(&target).unwrap();
        }
    }
    #[test]
    fn progress_follows_real_verified_cache_work_and_legacy_callback_still_works() {
        let fixture = ProgressFixture::new();
        let release = fixture.release();
        let cancel = AtomicBool::new(false);
        let mut events = Vec::new();
        // Every signed-content object is present: no outbound HTTP request is performed.
        let result = prepare_with_progress(&release, &fixture.0, &cancel, None, &mut |p| events.push(p.clone())).unwrap();
        assert_eq!((result.received, result.reused, result.downloaded), (0, 2, 0));
        assert_eq!(events.iter().map(|p| p.stage).collect::<Vec<_>>(), vec!["reuse_scan", "chunks", "chunks", "package_verify"]);
        assert_eq!(events.iter().map(|p| p.reused_chunks).collect::<Vec<_>>(), vec![0, 1, 2, 2]);
        assert!(events.windows(2).all(|p| p[0].percent <= p[1].percent));
        assert!(events.iter().all(|p| p.received_bytes == 0 && p.downloaded_chunks == 0 && p.total_chunks == 2));
        verified(&result.path, release.size, &release.hash).unwrap();
        drop(result);
        let mut legacy = Vec::new();
        prepare(&release, &fixture.0, &cancel, None, &mut |percent, message| legacy.push((percent, message.to_owned()))).unwrap();
        assert_eq!(legacy.last().unwrap().0, 92);
        assert!(legacy.last().unwrap().1.contains("전체 무결성"));
    }
    #[test]
    fn progress_cannot_turn_corrupt_package_or_cancelled_work_into_success() {
        let fixture = ProgressFixture::new();
        let release = fixture.release();
        fs::write(fixture.0.join(&release.filename), vec![0; release.size as usize]).unwrap();
        let mut events = Vec::new();
        let cancel = AtomicBool::new(false);
        assert!(prepare_with_progress(&release, &fixture.0, &cancel, None, &mut |p| events.push(p.clone())).err().unwrap().contains("hash mismatch"));
        assert_eq!(events.last().unwrap().stage, "package_verify");
        assert_eq!(events.last().unwrap().reused_chunks, 2);
        assert!(!events.iter().any(|p| p.stage == "ready"));
        cancel.store(true, Ordering::Release);
        events.clear();
        assert!(prepare_with_progress(&release, &fixture.0, &cancel, None, &mut |p| events.push(p.clone())).is_err());
        assert!(events.iter().all(|p| p.reused_chunks == 0 && p.downloaded_chunks == 0));
    }
}
