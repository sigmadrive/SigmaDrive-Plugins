//! Non-executable package format: signed archive identity plus bounded file list.
//! It cannot carry installer commands, symlinks, registry actions or arbitrary paths.
use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    io::{Read, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
};

pub const MAGIC: &[u8; 8] = b"SDPKG1\r\n";
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Entry {
    pub path: String,
    pub bytes: u64,
    pub sha256: String,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub schema: u32,
    pub version: String,
    pub engine: String,
    pub files: Vec<Entry>,
}
pub fn relative(value: &str) -> Result<PathBuf> {
    ensure!(
        !value.is_empty()
            && value.len() <= 240
            && !value.contains(['\\', ':', '\0'])
            && !value.starts_with('/'),
        "invalid package path"
    );
    for p in value.split('/') {
        ensure!(
            !p.is_empty()
                && p != "."
                && p != ".."
                && !p.ends_with([' ', '.'])
                && !p.chars().any(|c| c.is_control() || "<>\"|?*".contains(c)),
            "unsafe package name"
        );
        let base = p.split('.').next().unwrap_or("").to_ascii_uppercase();
        ensure!(
            !matches!(base.as_str(), "CON" | "PRN" | "AUX" | "NUL")
                && !(base.len() == 4
                    && (base.starts_with("COM") || base.starts_with("LPT"))
                    && base.as_bytes()[3].is_ascii_digit()),
            "reserved package name"
        );
    }
    let filename = value.rsplit('/').next().unwrap().to_ascii_lowercase();
    ensure!(
        !matches!(
            filename.as_str(),
            "sigmad.exe" | "rclone.exe" | "sigma-bridge.exe" | "sigmadrive_bridge.dll"
        ) && (!filename.ends_with(".exe") || value == "sigmadrive_flutter.exe"),
        "legacy/helper executable denied"
    );
    ensure!(
        !matches!(
            filename.as_str(),
            "catalog.json" | "rust-core-manifest.json" | "current.json" | "staged.json"
        ),
        "reserved package metadata"
    );
    Ok(PathBuf::from(value))
}

pub fn extract(
    archive: &Path,
    destination: &Path,
    version: &str,
    cancel: &AtomicBool,
) -> Result<Manifest> {
    crate::download::safe(destination).map_err(anyhow::Error::msg)?;
    ensure!(!destination.exists(), "candidate directory already exists");
    let mut input = std::fs::OpenOptions::new().read(true).open(archive)?;
    let mut magic = [0u8; 8];
    input.read_exact(&mut magic)?;
    ensure!(&magic == MAGIC, "invalid package format");
    let mut n = [0u8; 4];
    input.read_exact(&mut n)?;
    let n = u32::from_le_bytes(n) as usize;
    ensure!(n > 0 && n <= 2 * 1024 * 1024, "package manifest bound");
    let mut bytes = vec![0u8; n];
    input.read_exact(&mut bytes)?;
    let manifest: Manifest = serde_json::from_slice(&bytes)?;
    ensure!(
        manifest.schema == 1
            && manifest.engine == "rust"
            && manifest.version == version
            && !manifest.files.is_empty()
            && manifest.files.len() <= 8192,
        "package identity mismatch"
    );
    let mut paths = std::collections::HashSet::new();
    let mut total = 0u64;
    for file in &manifest.files {
        relative(&file.path)?;
        ensure!(
            paths.insert(file.path.to_ascii_lowercase())
                && file.sha256.len() == 64
                && file.sha256.bytes().all(|b| b.is_ascii_hexdigit()),
            "duplicate package path/hash invalid"
        );
        total = total
            .checked_add(file.bytes)
            .ok_or_else(|| anyhow::anyhow!("package size overflow"))?;
        ensure!(total <= 256 * 1024 * 1024, "package file budget");
    }
    ensure!(
        paths.contains("sigmadrive_flutter.exe")
            && paths.contains("sigmadrive_core.dll")
            && paths.contains("flutter_windows.dll")
            && paths.contains("public-oauth.json")
            && paths.contains("dokan2.dll")
            && paths.contains("prerequisites/dokan_x64.msi"),
        "Rust Flutter runtime files missing"
    );
    std::fs::create_dir(destination)?;
    for file in &manifest.files {
        ensure!(!cancel.load(Ordering::Acquire), "cancelled");
        let path = destination.join(relative(&file.path)?);
        crate::download::safe(&path).map_err(anyhow::Error::msg)?;
        std::fs::create_dir_all(
            path.parent()
                .ok_or_else(|| anyhow::anyhow!("package parent missing"))?,
        )?;
        let mut out = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)?;
        let mut left = file.bytes;
        let mut hash = Sha256::new();
        let mut b = vec![0u8; 1024 * 1024];
        while left > 0 {
            ensure!(!cancel.load(Ordering::Acquire), "cancelled");
            let n = left.min(b.len() as u64) as usize;
            input.read_exact(&mut b[..n])?;
            hash.update(&b[..n]);
            out.write_all(&b[..n])?;
            left -= n as u64;
        }
        ensure!(
            hex::encode(hash.finalize()) == file.sha256,
            "package member checksum failed"
        );
        out.sync_all()?;
    }
    let mut extra = [0];
    ensure!(input.read(&mut extra)? == 0, "trailing package content");
    Ok(manifest)
}
pub fn verify(folder: &Path, manifest: &Manifest) -> Result<()> {
    for f in &manifest.files {
        let path = folder.join(relative(&f.path)?);
        crate::download::safe(&path).map_err(anyhow::Error::msg)?;
        crate::download::verified(&path, f.bytes, &f.sha256).map_err(anyhow::Error::msg)?;
    }
    Ok(())
}

#[cfg(test)]
mod security_tests {
    use super::*;
    #[test]
    fn archive_names_cannot_escape_or_carry_a_legacy_engine() {
        for name in [
            "../outside",
            "C:/Windows/system32/x.dll",
            "/absolute",
            "a\\b",
            "data/CON.txt",
            "data/a.",
            "data/a:stream",
            "sigmad.exe",
            "rclone.exe",
            "sigmadrive_bridge.dll",
            "other.exe",
            "components/sigmadesk/other.exe",
            "components/other/rustdesk.exe",
            "staged.json",
        ] {
            assert!(relative(name).is_err(), "{name}");
        }
        assert!(relative("sigmadrive_flutter.exe").is_ok());
        assert!(relative("components/sigmadesk/rustdesk.exe").is_err());
        assert!(relative("prerequisites/Dokan_x64.msi").is_ok());
    }
    #[test]
    fn corrupt_candidate_cannot_replace_an_existing_installation() {
        let work =
            std::env::temp_dir().join(format!("sigma-package-{}", uuid::Uuid::new_v4().simple()));
        std::fs::create_dir(&work).unwrap();
        let current = work.join("current.json");
        std::fs::write(&current, b"previous version").unwrap();
        let names = [
            "sigmadrive_flutter.exe",
            "sigmadrive_core.dll",
            "flutter_windows.dll",
            "public-oauth.json",
            "dokan2.dll",
            "prerequisites/Dokan_x64.msi",
        ];
        let manifest = Manifest {
            schema: 1,
            version: "0.3.0".into(),
            engine: "rust".into(),
            files: names
                .iter()
                .map(|name| Entry {
                    path: (*name).into(),
                    bytes: 3,
                    sha256: crate::trust::digest(b"yes"),
                })
                .collect(),
        };
        let header = serde_json::to_vec(&manifest).unwrap();
        let archive = work.join("candidate.package");
        let mut bytes = MAGIC.to_vec();
        bytes.extend_from_slice(&(header.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&header);
        for i in 0..names.len() {
            bytes.extend_from_slice(if i + 1 == names.len() { b"bad" } else { b"yes" });
        }
        std::fs::write(&archive, bytes).unwrap();
        assert!(
            extract(
                &archive,
                &work.join("candidate"),
                "0.3.0",
                &AtomicBool::new(false)
            )
            .is_err()
        );
        assert_eq!(std::fs::read(&current).unwrap(), b"previous version");
        // Only this test's fresh UUID directory is removed.
        std::fs::remove_dir_all(&work).unwrap();
    }
}
