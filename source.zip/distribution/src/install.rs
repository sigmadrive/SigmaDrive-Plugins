//! Version directories are immutable. Only a completely verified candidate may
//! replace the small current pointer; old binaries and user state are retained.
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use std::os::windows::{
    ffi::{OsStrExt, OsStringExt},
    fs::OpenOptionsExt,
};
use std::{
    io::Write,
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
};

pub fn local() -> Result<PathBuf> {
    use windows_sys::Win32::{
        System::Com::CoTaskMemFree,
        UI::Shell::{FOLDERID_LocalAppData, SHGetKnownFolderPath},
    };
    let mut raw = std::ptr::null_mut();
    ensure!(
        unsafe { SHGetKnownFolderPath(&FOLDERID_LocalAppData, 0, std::ptr::null_mut(), &mut raw) }
            >= 0
            && !raw.is_null(),
        "KnownFolder unavailable"
    );
    let n = (0..).take_while(|i| unsafe { *raw.add(*i) } != 0).count();
    let p = PathBuf::from(std::ffi::OsString::from_wide(unsafe {
        std::slice::from_raw_parts(raw, n)
    }));
    unsafe { CoTaskMemFree(raw.cast()) };
    Ok(p)
}
pub fn root() -> Result<PathBuf> {
    let path = local()?
        .join("Programs")
        .join(crate::identity::PRIVATE_INSTALL_DIRECTORY);
    crate::download::safe(&path).map_err(anyhow::Error::msg)?;
    std::fs::create_dir_all(&path)?;
    crate::identity::protect_own_local_directory(&path)?;
    Ok(path)
}
pub fn atomic(path: &Path, bytes: &[u8]) -> Result<()> {
    crate::download::safe(path).map_err(anyhow::Error::msg)?;
    let tmp = path.with_extension(format!("{}.tmp", uuid::Uuid::new_v4().simple()));
    let mut f = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&tmp)?;
    f.write_all(bytes)?;
    f.sync_all()?;
    drop(f);
    use windows_sys::Win32::Storage::FileSystem::{
        MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, MoveFileExW,
    };
    let a: Vec<u16> = tmp.as_os_str().encode_wide().chain(Some(0)).collect();
    let b: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();
    ensure!(
        unsafe {
            MoveFileExW(
                a.as_ptr(),
                b.as_ptr(),
                MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH,
            )
        } != 0,
        "atomic pointer write failed"
    );
    Ok(())
}
fn read(path: &Path) -> Result<Value> {
    crate::download::safe(path).map_err(anyhow::Error::msg)?;
    ensure!(path.metadata()?.len() <= 2 * 1024 * 1024, "metadata bound");
    Ok(serde_json::from_slice(&std::fs::read(path)?)?)
}
fn exclusive(path: &Path) -> Result<std::fs::File> {
    Ok(std::fs::OpenOptions::new()
        .create(true)
        .truncate(false)
        .read(true)
        .write(true)
        .share_mode(0)
        .open(path)?)
}
pub fn current(root: &Path) -> Result<Option<Value>> {
    let p = root.join("current.json");
    if !p.exists() {
        return Ok(None);
    }
    let v = read(&p)?;
    ensure!(
        crate::trust::valid_version(v["version"].as_str().unwrap_or("")),
        "invalid installed version"
    );
    Ok(Some(v))
}
fn selected(root: &Path, value: &Value) -> Result<(PathBuf, crate::package::Manifest)> {
    let v = value["version"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("selected version missing"))?;
    ensure!(crate::trust::valid_version(v), "invalid selected version");
    let dir = root.join("versions").join(v);
    let bytes = std::fs::read(dir.join("rust-core-manifest.json"))?;
    ensure!(bytes.len() <= 2 * 1024 * 1024, "installed manifest bound");
    ensure!(
        crate::trust::digest(&bytes) == value["manifest_sha256"].as_str().unwrap_or(""),
        "installed manifest changed"
    );
    let catalog = read_catalog(&dir.join("catalog.json"))?;
    let signed = crate::trust::verify_installed(&catalog).map_err(anyhow::Error::msg)?;
    ensure!(
        signed.version == v
            && signed.manifest_hash == crate::trust::digest(&bytes)
            && value["package_sha256"] == signed.hash
            && value["sequence"] == signed.sequence,
        "installed signature/file manifest mismatch"
    );
    let manifest: crate::package::Manifest = serde_json::from_slice(&bytes)?;
    ensure!(
        manifest.version == v && manifest.engine == "rust" && manifest.schema == 1,
        "installed manifest identity changed"
    );
    crate::package::verify(&dir, &manifest)?;
    Ok((dir, manifest))
}
pub fn executable(root: &Path) -> Result<PathBuf> {
    let pointer = current(root)?.ok_or_else(|| anyhow::anyhow!("Rust client is not installed"))?;
    Ok(selected(root, &pointer)?.0.join("sigmadrive_flutter.exe"))
}
pub fn prepare(
    root: &Path,
    catalog: &str,
    cancel: &AtomicBool,
    notify: &mut dyn FnMut(u32, &str),
) -> Result<Value> {
    // Legacy bootstrap reserves 95..100 for activation and launch after preparation.
    prepare_with_progress(root, catalog, cancel, &mut |p| notify(p.percent.min(92), p.message))
}

pub fn prepare_with_progress(
    root: &Path,
    catalog: &str,
    cancel: &AtomicBool,
    notify: &mut dyn FnMut(&crate::download::Progress),
) -> Result<Value> {
    let _lock = exclusive(&root.join("delivery.lock"))?;
    let release = crate::trust::verify(catalog, time::OffsetDateTime::now_utc())
        .map_err(anyhow::Error::msg)?;
    let ledger = root.join("catalog-sequence.json");
    let old = if ledger.exists() {
        read(&ledger)?["sequence"].as_u64().unwrap_or(0)
    } else {
        0
    };
    ensure!(release.sequence >= old, "catalog rollback denied");
    if release.sequence > old {
        atomic(
            &ledger,
            &serde_json::to_vec(&json!({"sequence":release.sequence}))?,
        )?;
    }
    if let Some(current) = current(root)? {
        let v = current["version"].as_str().unwrap_or("");
        if crate::trust::version_tuple(v).map_err(anyhow::Error::msg)?
            >= crate::trust::version_tuple(&release.version).map_err(anyhow::Error::msg)?
        {
            return Ok(
                json!({"state":"up_to_date","current_version":v,"latest_version":release.version}),
            );
        }
    }
    let cache = root.join("cache-v2");
    std::fs::create_dir_all(&cache)?;
    let prepared = crate::download::prepare_with_progress(&release, &cache, cancel, None, notify)
        .map_err(anyhow::Error::msg)?;
    ensure!(!cancel.load(Ordering::Acquire), "cancelled");
    let versions = root.join("versions");
    std::fs::create_dir_all(&versions)?;
    let candidate = versions.join(format!(
        "{}.preparing-{}",
        release.version,
        uuid::Uuid::new_v4().simple()
    ));
    let mut progress = crate::download::Progress { percent: 94, stage: "extract",
        message: "검증된 설치 파일을 새 버전 폴더에 풀고 파일별 무결성을 확인하고 있습니다.",
        received_bytes: prepared.received, reused_chunks: prepared.reused,
        downloaded_chunks: prepared.downloaded, total_chunks: release.chunks.len() };
    notify(&progress);
    let manifest = crate::package::extract(&prepared.path, &candidate, &release.version, cancel)?;
    progress.percent = 96;
    progress.stage = "candidate_verify";
    progress.message = "새 버전의 전체 파일과 서명된 목록을 다시 확인하고 있습니다.";
    notify(&progress);
    crate::package::verify(&candidate, &manifest)?;
    let manifest = serde_json::to_vec(&manifest)?;
    ensure!(
        crate::trust::digest(&manifest) == release.manifest_hash,
        "signed package manifest mismatch"
    );
    progress.percent = 97;
    progress.stage = "stage_publish";
    progress.message = "검증된 새 버전을 다음 실행용으로 저장하고 있습니다.";
    notify(&progress);
    atomic(&candidate.join("rust-core-manifest.json"), &manifest)?;
    atomic(&candidate.join("catalog.json"), catalog.as_bytes())?;
    let final_dir = versions.join(&release.version);
    let pointer = json!({"version":release.version,"manifest_sha256":crate::trust::digest(&manifest),"package_sha256":release.hash,"sequence":release.sequence});
    if final_dir.exists() {
        selected(root, &pointer)?;
    } else {
        std::fs::rename(&candidate, &final_dir)?;
    }
    atomic(&root.join("staged.json"), &serde_json::to_vec(&pointer)?)?;
    // Retain one assembled base package as a bounded CDC seed; raw chunk cache
    // remains content-addressed and is reused across versions.
    progress.percent = 98;
    progress.stage = "seed_save";
    progress.message = "다음 업데이트에서 재사용할 검증된 파일을 저장하고 있습니다.";
    notify(&progress);
    let seed = cache.join("installed-package.bin");
    let temporary = cache.join(format!("seed-{}.tmp", uuid::Uuid::new_v4().simple()));
    std::fs::copy(&prepared.path, &temporary)?;
    let input = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(&temporary)?;
    input.sync_all()?;
    drop(input);
    use windows_sys::Win32::Storage::FileSystem::{
        MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, MoveFileExW,
    };
    let a: Vec<u16> = temporary.as_os_str().encode_wide().chain(Some(0)).collect();
    let b: Vec<u16> = seed.as_os_str().encode_wide().chain(Some(0)).collect();
    ensure!(
        unsafe {
            MoveFileExW(
                a.as_ptr(),
                b.as_ptr(),
                MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH,
            )
        } != 0,
        "delta seed publication failed"
    );
    progress.percent = 100;
    progress.stage = "ready";
    progress.message = "업데이트 준비가 끝났습니다. 안전하게 재시작하면 적용됩니다.";
    notify(&progress);
    Ok(
        json!({"state":"ready","latest_version":release.version,"received_bytes":prepared.received,"reused_chunks":prepared.reused,"downloaded_chunks":prepared.downloaded,"next_launch":true}),
    )
}
pub fn core_idle() -> Result<bool> {
    let p = local()?.join("SigmaDriveRustCore/owner.lock");
    if !p.exists() {
        return Ok(true);
    }
    crate::download::safe(&p).map_err(anyhow::Error::msg)?;
    match std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .share_mode(0)
        .open(&p)
    {
        Ok(_) => Ok(true),
        Err(e) if e.raw_os_error() == Some(32) => Ok(false),
        Err(e) => Err(e.into()),
    }
}
pub fn apply_staged(root: &Path) -> Result<bool> {
    let _lock = exclusive(&root.join("delivery.lock"))?;
    let _idle = core_lock()?;
    let staged = root.join("staged.json");
    if !staged.exists() {
        return Ok(false);
    }
    let pointer = read(&staged)?;
    let (dir, _) = selected(root, &pointer)?;
    let catalog = read_catalog(&dir.join("catalog.json"))?;
    let release = crate::trust::verify(&catalog, time::OffsetDateTime::now_utc())
        .map_err(anyhow::Error::msg)?;
    ensure!(
        pointer["version"] == release.version
            && pointer["package_sha256"] == release.hash
            && pointer["sequence"] == release.sequence,
        "staged package identity changed"
    );
    if let Some(old) = current(root)? {
        if old == pointer {
            std::fs::remove_file(staged)?;
            return Ok(false);
        }
        ensure!(
            crate::trust::version_tuple(old["version"].as_str().unwrap_or(""))
                .map_err(anyhow::Error::msg)?
                < crate::trust::version_tuple(&release.version).map_err(anyhow::Error::msg)?,
            "version rollback denied"
        );
        atomic(&root.join("previous.json"), &serde_json::to_vec(&old)?)?;
    }
    atomic(&root.join("current.json"), &serde_json::to_vec(&pointer)?)?;
    std::fs::remove_file(staged)?;
    Ok(true)
}
pub fn rollback(root: &Path) -> Result<()> {
    let _lock = exclusive(&root.join("delivery.lock"))?;
    let _idle = core_lock()?;
    let previous = read(&root.join("previous.json"))?;
    selected(root, &previous)?;
    atomic(&root.join("current.json"), &serde_json::to_vec(&previous)?)?;
    Ok(())
}
pub fn launch(root: &Path, startup: bool) -> Result<std::process::Child> {
    use std::os::windows::process::CommandExt;
    let mut c = std::process::Command::new(executable(root)?);
    if startup {
        c.arg("--startup");
    }
    Ok(c.creation_flags(0x08000000).spawn()?)
}

fn read_catalog(path: &Path) -> Result<String> {
    crate::download::safe(path).map_err(anyhow::Error::msg)?;
    ensure!(path.metadata()?.len() <= 1024 * 1024, "catalog size bound");
    Ok(std::fs::read_to_string(path)?)
}

fn core_lock() -> Result<std::fs::File> {
    let dir = local()?.join(crate::identity::PRIVATE_STATE_DIRECTORY);
    crate::download::safe(&dir).map_err(anyhow::Error::msg)?;
    std::fs::create_dir_all(&dir)?;
    crate::identity::protect_own_local_directory(&dir)?;
    exclusive(&dir.join("owner.lock"))
        .map_err(|_| anyhow::anyhow!("update deferred: Rust client is still running"))
}

fn wide(value: &str) -> Vec<u16> {
    value.encode_utf16().chain(Some(0)).collect()
}
pub fn register_startup(root: &Path, enabled: bool) -> Result<()> {
    use windows_sys::Win32::System::Registry::*;
    let mut key = std::ptr::null_mut();
    let path = wide("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
    let name = wide("SigmaDriveRustCore");
    ensure!(
        unsafe {
            RegCreateKeyExW(
                HKEY_CURRENT_USER,
                path.as_ptr(),
                0,
                std::ptr::null(),
                0,
                KEY_QUERY_VALUE | KEY_SET_VALUE,
                std::ptr::null(),
                &mut key,
                std::ptr::null_mut(),
            )
        } == 0,
        "startup registration failed"
    );
    struct Key(HKEY);
    impl Drop for Key {
        fn drop(&mut self) {
            unsafe { RegCloseKey(self.0) };
        }
    }
    let _key = Key(key);
    let command = wide(&format!(
        "\"{}\" --startup",
        root.join("SigmaDrive.exe").display()
    ));
    if enabled {
        ensure!(
            unsafe {
                RegSetValueExW(
                    key,
                    name.as_ptr(),
                    0,
                    REG_SZ,
                    command.as_ptr().cast(),
                    (command.len() * 2) as u32,
                )
            } == 0,
            "startup write failed"
        );
    } else {
        let mut data = vec![0u16; 32768];
        let mut bytes = (data.len() * 2) as u32;
        let found = unsafe {
            RegQueryValueExW(
                key,
                name.as_ptr(),
                std::ptr::null(),
                std::ptr::null_mut(),
                data.as_mut_ptr().cast(),
                &mut bytes,
            )
        };
        if found == 0 && data[..bytes as usize / 2] == command {
            ensure!(
                unsafe { RegDeleteValueW(key, name.as_ptr()) } == 0,
                "startup removal failed"
            );
        }
    }
    Ok(())
}
pub fn register_app(root: &Path) -> Result<()> {
    use windows::{
        Win32::{
            System::Com::{
                CLSCTX_INPROC_SERVER, COINIT_APARTMENTTHREADED, CoCreateInstance, CoInitializeEx,
                CoUninitialize, IPersistFile,
            },
            UI::Shell::{IShellLinkW, ShellLink},
        },
        core::{Interface, PCWSTR},
    };
    let initialized = unsafe { CoInitializeEx(None, COINIT_APARTMENTTHREADED) };
    initialized.ok()?;
    struct Com;
    impl Drop for Com {
        fn drop(&mut self) {
            unsafe { CoUninitialize() };
        }
    }
    let _com = Com;
    let link: IShellLinkW = unsafe { CoCreateInstance(&ShellLink, None, CLSCTX_INPROC_SERVER) }?;
    let target = wide(&root.join("SigmaDrive.exe").to_string_lossy());
    unsafe { link.SetPath(PCWSTR(target.as_ptr())) }?;
    let desc = wide("SigmaDrive Rust + Flutter");
    unsafe { link.SetDescription(PCWSTR(desc.as_ptr())) }?;
    let persist: IPersistFile = link.cast()?;
    use windows_sys::Win32::{
        System::Com::CoTaskMemFree,
        UI::Shell::{FOLDERID_Programs, SHGetKnownFolderPath},
    };
    let mut raw = std::ptr::null_mut();
    ensure!(
        unsafe { SHGetKnownFolderPath(&FOLDERID_Programs, 0, std::ptr::null_mut(), &mut raw) } >= 0
            && !raw.is_null(),
        "Start menu unavailable"
    );
    let n = (0..).take_while(|i| unsafe { *raw.add(*i) } != 0).count();
    let programs = PathBuf::from(std::ffi::OsString::from_wide(unsafe {
        std::slice::from_raw_parts(raw, n)
    }));
    unsafe { CoTaskMemFree(raw.cast()) };
    let path = programs.join("SigmaDrive Rust.lnk");
    crate::download::safe(&path).map_err(anyhow::Error::msg)?;
    let path = wide(&path.to_string_lossy());
    unsafe { persist.Save(PCWSTR(path.as_ptr()), true) }?;
    Ok(())
}
fn process(pid: u32) -> Result<std::os::windows::io::OwnedHandle> {
    use std::os::windows::io::{AsRawHandle, FromRawHandle};
    use windows_sys::Win32::System::Threading::{OpenProcess, PROCESS_QUERY_LIMITED_INFORMATION};
    let h = unsafe { OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | 0x00100000, 0, pid) };
    ensure!(!h.is_null(), "update process unavailable");
    let h = unsafe { std::os::windows::io::OwnedHandle::from_raw_handle(h) };
    ensure!(
        crate::identity::same_process_user(h.as_raw_handle())?,
        "update target belongs to another Windows user"
    );
    Ok(h)
}
fn stamp(h: windows_sys::Win32::Foundation::HANDLE) -> Result<u64> {
    use windows_sys::Win32::{Foundation::FILETIME, System::Threading::GetProcessTimes};
    let mut c: FILETIME = unsafe { std::mem::zeroed() };
    let mut e = c;
    let mut k = c;
    let mut u = c;
    ensure!(
        unsafe { GetProcessTimes(h, &mut c, &mut e, &mut k, &mut u) } != 0,
        "cannot verify process creation"
    );
    Ok(((c.dwHighDateTime as u64) << 32) | c.dwLowDateTime as u64)
}
pub fn process_stamp(pid: u32) -> Result<u64> {
    use std::os::windows::io::AsRawHandle;
    stamp(process(pid)?.as_raw_handle())
}
pub fn wait_client_exit(root: &Path, pid: u32, creation: u64) -> Result<()> {
    wait_client_exit_ready(root, pid, creation, None)
}
pub fn wait_client_exit_ready(
    root: &Path,
    pid: u32,
    creation: u64,
    ready: Option<&str>,
) -> Result<()> {
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::System::Threading::WaitForSingleObject;
    let h = verified_update_process(&executable(root)?, pid, creation)?;
    // Retain the validated process handle before permitting the app to exit.
    if let Some(token) = ready {
        atomic(
            &handoff_path(root, token)?,
            &serde_json::to_vec(&json!({"pid":pid,"creation":creation}))?,
        )?;
    }
    ensure!(
        unsafe { WaitForSingleObject(h.as_raw_handle(), 120000) } == 0,
        "safe update deferred: app did not exit"
    );
    Ok(())
}
fn verified_update_process(
    expected: &Path,
    pid: u32,
    creation: u64,
) -> Result<std::os::windows::io::OwnedHandle> {
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::System::Threading::QueryFullProcessImageNameW;
    let h = process(pid)?;
    ensure!(
        stamp(h.as_raw_handle())? == creation,
        "update PID was reused"
    );
    let mut path = vec![0u16; 32768];
    let mut n = path.len() as u32;
    ensure!(
        unsafe { QueryFullProcessImageNameW(h.as_raw_handle(), 0, path.as_mut_ptr(), &mut n) } != 0,
        "update process image unavailable"
    );
    let path = PathBuf::from(std::ffi::OsString::from_wide(&path[..n as usize]));
    ensure!(
        std::fs::canonicalize(&path)? == std::fs::canonicalize(expected)?,
        "update target is not the selected Rust client"
    );
    Ok(h)
}
pub fn handoff_path(root: &Path, token: &str) -> Result<PathBuf> {
    ensure!(
        token.len() == 32 && token.bytes().all(|b| b.is_ascii_hexdigit()),
        "invalid update handoff token"
    );
    Ok(root.join("health").join(format!("update-{token}.json")))
}
pub fn launch_checked(root: &Path, startup: bool) -> Result<()> {
    use std::os::windows::process::CommandExt;
    ensure!(
        core_idle()?,
        "SigmaDrive Rust is already running; use its update menu"
    );
    let token = uuid::Uuid::new_v4().simple().to_string();
    let health = root.join("health").join(format!("{token}.json"));
    std::fs::create_dir_all(health.parent().unwrap())?;
    let pointer = current(root)?.ok_or_else(|| anyhow::anyhow!("no installed client"))?;
    let mut command = std::process::Command::new(executable(root)?);
    command
        .env("SIGMA_RUST_READY_TOKEN", &token)
        .creation_flags(0x08000000);
    if startup {
        command.arg("--startup");
    }
    let mut child = command.spawn()?;
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(60);
    loop {
        if health.is_file() {
            let v = read(&health)?;
            ensure!(
                v["token"] == token
                    && v["pid"] == child.id()
                    && v["version"] == pointer["version"]
                    && v["ui_ready"] == true,
                "startup confirmation mismatch"
            );
            let _ = std::fs::remove_file(health);
            let _ = std::fs::remove_file(root.join("rollback-pending.json"));
            return Ok(());
        }
        if child.try_wait()?.is_some() {
            if root.join("previous.json").is_file() {
                rollback(root)?;
                launch(root, startup)?;
            }
            anyhow::bail!("new client failed to start; previous version retained");
        }
        if std::time::Instant::now() > deadline {
            atomic(
                &root.join("rollback-pending.json"),
                b"{\"reason\":\"startup_unconfirmed\"}",
            )?;
            anyhow::bail!(
                "startup confirmation delayed; active app was not terminated, rollback is deferred until it exits"
            );
        }
        std::thread::sleep(std::time::Duration::from_millis(100));
    }
}
#[cfg(test)]
mod handoff_tests {
    use super::*;
    #[test]
    fn handoff_rejects_reused_pid_and_wrong_image_before_acknowledgement() {
        let pid = std::process::id();
        let creation = process_stamp(pid).unwrap();
        let image = std::env::current_exe().unwrap();
        verified_update_process(&image, pid, creation).unwrap();
        assert!(verified_update_process(&image, pid, creation + 1).is_err());
        assert!(
            verified_update_process(&image.with_file_name("other.exe"), pid, creation).is_err()
        );
        let root = std::env::temp_dir();
        for token in [
            "",
            "../outside",
            "ffffffffffffffffffffffffffffffff/",
            "zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz",
        ] {
            assert!(handoff_path(&root, token).is_err());
        }
    }
}
