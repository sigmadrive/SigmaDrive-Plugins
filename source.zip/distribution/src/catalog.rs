//! Small signed channel metadata may be stale on a mutable CDN path. Compare
//! independently verified candidates; payload chunks still prefer the CDN.
use crate::trust::{self, Release, Result};
pub struct Candidate {
    pub raw: String,
    pub release: Release,
    pub source: &'static str,
}
pub fn verify(raw: String, source: &'static str) -> Result<Candidate> {
    let release = trust::verify(&raw, time::OffsetDateTime::now_utc())?;
    Ok(Candidate {
        raw,
        release,
        source,
    })
}
pub fn select(cdn: Result<Candidate>, origin: Result<Candidate>) -> Result<Candidate> {
    match (cdn, origin) {
        (Ok(a), Ok(b)) => {
            if a.release.sequence == b.release.sequence {
                if a.release.hash != b.release.hash
                    || a.release.version != b.release.version
                    || a.release.manifest_hash != b.release.manifest_hash
                    || a.release.commit != b.release.commit
                {
                    return Err(
                        "catalog equivocation: same sequence has different release identity".into(),
                    );
                }
                return Ok(a);
            }
            let (new, old) = if a.release.sequence > b.release.sequence {
                (a, b)
            } else {
                (b, a)
            };
            if trust::version_tuple(&new.release.version)?
                < trust::version_tuple(&old.release.version)?
            {
                return Err("new catalog attempts a version rollback".into());
            }
            Ok(new)
        }
        (Ok(v), Err(_)) | (Err(_), Ok(v)) => Ok(v),
        (Err(a), Err(b)) => Err(format!("no verified catalog; CDN: {a}; GitHub: {b}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn candidate(seq: u64, version: &str, source: &'static str) -> Result<Candidate> {
        Ok(Candidate {
            raw: version.into(),
            source,
            release: Release {
                filename: String::new(),
                version: version.into(),
                sequence: seq,
                manifest_hash: version.into(),
                verification: "test-only",
                hash: version.into(),
                size: 1,
                commit: version.into(),
                chunks: vec![],
            },
        })
    }
    #[test]
    fn stale_http200_cdn_uses_newer_verified_origin() {
        let chosen = select(
            candidate(8, "0.3.5", "cdn"),
            candidate(11, "0.3.8", "github"),
        )
        .unwrap();
        assert_eq!(chosen.source, "github");
        assert_eq!(chosen.release.sequence, 11);
    }
    #[test]
    fn current_cdn_survives_stale_or_unavailable_origin() {
        assert_eq!(
            select(
                candidate(11, "0.3.8", "cdn"),
                candidate(10, "0.3.7", "github")
            )
            .unwrap()
            .source,
            "cdn"
        );
        assert!(select(candidate(11, "0.3.8", "cdn"), Err("network timeout".into())).is_ok());
    }
    #[test]
    fn unverified_candidates_never_establish_a_release() {
        assert!(verify("{}".into(), "cdn").is_err());
        assert!(select(Err("tampered".into()), Err("expired".into())).is_err());
        assert_eq!(
            select(Err("tampered".into()), candidate(11, "0.3.8", "github"))
                .unwrap()
                .source,
            "github"
        );
    }
    #[test]
    fn equivocation_and_newer_sequence_version_rollback_fail_closed() {
        assert!(
            select(
                candidate(11, "0.3.8", "cdn"),
                candidate(11, "0.3.9", "github")
            )
            .is_err()
        );
        assert!(
            select(
                candidate(12, "0.3.6", "cdn"),
                candidate(11, "0.3.8", "github")
            )
            .is_err()
        );
        assert_eq!(
            select(
                candidate(11, "0.3.8", "cdn"),
                candidate(11, "0.3.8", "github")
            )
            .unwrap()
            .source,
            "cdn"
        );
    }
}
