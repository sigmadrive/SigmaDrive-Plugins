use crate::{
    download,
    trust::{self, Chunk, Release, Result},
};
use std::{
    collections::BTreeMap,
    fs::{self, OpenOptions},
    io::{Read, Write},
    os::windows::fs::OpenOptionsExt,
    path::Path,
    sync::atomic::{AtomicBool, Ordering},
};
// Must match core/internal/delivery/delta.go. Boundaries are not a trust input.
fn table() -> [u64; 256] {
    let mut out = [0; 256];
    let mut x = 0x7369676d61647276u64;
    for v in &mut out {
        x = x.wrapping_add(0x9e3779b97f4a7c15);
        let mut z = x;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
        *v = z ^ (z >> 31);
    }
    out
}
pub fn cut(data: &[u8]) -> usize {
    let gear = table();
    let mut h = 0u64;
    for (i, b) in data.iter().enumerate() {
        h = (h << 1).wrapping_add(gear[*b as usize]);
        let n = i + 1;
        if n >= 1024 * 1024 || n >= 64 * 1024 && h & ((1 << 18) - 1) == 0 {
            return n;
        }
    }
    data.len()
}
pub fn decode(ch: &Chunk, wire: Vec<u8>) -> Result<Vec<u8>> {
    let w = ch.transport();
    if wire.len() as u64 != w.size || trust::digest(&wire) != w.hash {
        return Err("wire chunk integrity mismatch".into());
    }
    if ch.wire.is_none() {
        return Ok(wire);
    }
    let mut b = Vec::new();
    flate2::read::MultiGzDecoder::new(wire.as_slice())
        .take(ch.size + 1)
        .read_to_end(&mut b)
        .map_err(|e| e.to_string())?;
    if b.len() as u64 != ch.size || trust::digest(&b) != ch.hash {
        return Err("decoded chunk integrity mismatch".into());
    }
    Ok(b)
}
pub fn seed(r: &Release, dir: &Path, cancel: &AtomicBool, log: &mut impl Write) -> Result<()> {
    let mut need: BTreeMap<String, u64> = r
        .chunks
        .iter()
        .filter(|c| {
            download::verified(&dir.join(format!("{}.bin", c.hash)), c.size, &c.hash).is_err()
        })
        .map(|c| (c.hash.clone(), c.size))
        .collect();
    let base = dir.join("installed-package.bin");
    download::safe(&base)?;
    let Ok(mut f) = OpenOptions::new().read(true).share_mode(1).open(&base) else {
        return Ok(());
    };
    if f.metadata().map_err(|e| e.to_string())?.len() > 256 * 1024 * 1024 {
        return Err("previous package budget".into());
    }
    let mut pending = Vec::new();
    let mut eof = false;
    while !need.is_empty() {
        if cancel.load(Ordering::Relaxed) {
            return Err("cancelled".into());
        }
        while pending.len() < 1024 * 1024 && !eof {
            let mut b = vec![0u8; 1024 * 1024 - pending.len()];
            let n = f.read(&mut b).map_err(|e| e.to_string())?;
            if n == 0 {
                eof = true;
            } else {
                pending.extend_from_slice(&b[..n]);
            }
        }
        if pending.is_empty() {
            break;
        }
        let n = cut(&pending);
        let hash = trust::digest(&pending[..n]);
        if need.get(&hash) == Some(&(n as u64)) {
            let path = dir.join(format!("{hash}.bin"));
            download::safe(&path)?;
            if path.exists() {
                fs::remove_file(&path).map_err(|e| e.to_string())?;
            }
            let mut out = OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(&path)
                .map_err(|e| e.to_string())?;
            out.write_all(&pending[..n])
                .and_then(|_| out.sync_all())
                .map_err(|e| e.to_string())?;
            writeln!(
                log,
                "{}",
                serde_json::json!({"event":"seed","sha256":hash,"bytes":n})
            )
            .map_err(|e| e.to_string())?;
            need.remove(&hash);
        }
        pending.drain(..n);
    }
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn boundary_vector_matches_go() {
        let mut b = vec![0u8; 3 << 20];
        let mut x = 17u64;
        for v in &mut b {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            *v = x as u8;
        }
        let mut data = b.as_slice();
        let mut cuts = Vec::new();
        while !data.is_empty() {
            let n = cut(data);
            cuts.push(n);
            data = &data[n..];
        }
        assert_eq!(
            cuts,
            vec![
                103863, 912216, 106885, 236924, 370438, 227935, 67558, 87521, 147047, 870477, 14864
            ]
        );
    }
    #[test]
    fn decoded_bytes_and_budget_are_verified() {
        let raw = vec![7u8; 100000];
        let mut w = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
        w.write_all(&raw).unwrap();
        let wire = w.finish().unwrap();
        let mut c = Chunk {
            hash: trust::digest(&raw),
            size: raw.len() as u64,
            wire: Some((trust::digest(&wire), wire.len() as u64)),
        };
        assert_eq!(decode(&c, wire.clone()).unwrap(), raw);
        c.size = 1;
        assert!(decode(&c, wire.clone()).is_err());
        c.size = raw.len() as u64;
        c.hash = "0".repeat(64);
        assert!(decode(&c, wire.clone()).is_err());
        let mut corrupt = wire;
        corrupt[12] ^= 1;
        assert!(decode(&c, corrupt).is_err());
    }
}
