//! Shared Rust-only bootstrap and automatic-update implementation. Catalog trust
//! and content-addressed v2 chunks are shared by the installer and loaded core.
pub mod catalog;
pub mod component_scope;
pub mod delta;
pub mod download;
#[path = "../../rust-core/src/identity_windows.rs"]
pub mod identity;
pub mod install;
pub mod package;
pub mod trust;
