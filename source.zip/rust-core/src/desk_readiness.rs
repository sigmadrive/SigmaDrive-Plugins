//! Optional authority metadata stays private to a host runtime. It is never
//! copied into public status, diagnostics, signed claims, or persistent state.
//! Only fixed local timing codes may be drained after the caller revalidates
//! the current runtime; their values never include authority metadata.
use crate::{desk_lease::Lease, desk_registration::Observation};
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::time::{Duration, Instant};
use zeroize::Zeroizing;

#[derive(Default)]
pub struct Capability {
    identity: Option<Value>,
    supported: bool,
}
#[derive(Debug, PartialEq, Eq)]
pub enum Recovery {
    None,
    ReprobeIdle,
    EndSession,
}
impl Capability {
    pub fn observe(&mut self, remote: &Value, identity: &Value) {
        self.identity = Some(identity.clone());
        self.supported = remote["readiness_version"].as_u64() == Some(1);
    }
    pub fn advertise(&self, body: &mut Value, identity: &Value) {
        if self.supported && self.identity.as_ref() == Some(identity) {
            body["readiness_version"] = json!(1);
            body["readiness_mode"] = json!("udp-ack-v1");
        }
    }
    pub fn reset(&mut self, identity: &Value) {
        if self.identity.as_ref() == Some(identity) {
            self.supported = false;
        }
    }
    pub fn recovery(
        status: Option<u16>,
        advertised: bool,
        phase: &str,
        session: &str,
        starting: bool,
    ) -> Recovery {
        if status != Some(400) || !advertised {
            return Recovery::None;
        }
        if phase == "stopped" && session.is_empty() && !starting {
            Recovery::ReprobeIdle
        } else {
            Recovery::EndSession
        }
    }
}
pub struct Binding {
    mode: String,
    session: String,
    nonce: Zeroizing<String>,
    token: [u8; 32],
    generation: u32,
    lease_sequence: u64,
    accepted: u32,
    highest_sent: u32,
    local_timings: LocalTimings,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LocalTimingCode {
    ModeAck,
    ModeLegacy,
    RegistrationObserved,
    ProofAccepted,
}
impl LocalTimingCode {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::ModeAck => "mode_ack",
            Self::ModeLegacy => "mode_legacy",
            Self::RegistrationObserved => "registration_observed",
            Self::ProofAccepted => "proof_accepted",
        }
    }
}
pub struct LocalTiming {
    pub code: LocalTimingCode,
    pub elapsed: Duration,
}
struct LocalTimings {
    started: Instant,
    closed: bool,
    observed: bool,
    accepted: bool,
    pending: Vec<LocalTiming>,
}
impl LocalTimings {
    fn new(ack: bool, started: Instant) -> Self {
        Self {
            started,
            closed: false,
            observed: false,
            accepted: false,
            pending: vec![LocalTiming {
                code: if ack { LocalTimingCode::ModeAck } else { LocalTimingCode::ModeLegacy },
                elapsed: Duration::ZERO,
            }],
        }
    }
    fn observed(&mut self, now: Instant) {
        if !self.closed && !self.observed {
            self.observed = true;
            self.pending.push(LocalTiming { code: LocalTimingCode::RegistrationObserved,
                elapsed: now.saturating_duration_since(self.started) });
        }
    }
    fn accepted(&mut self, now: Instant) {
        if !self.closed && !self.accepted {
            self.accepted = true;
            self.pending.push(LocalTiming { code: LocalTimingCode::ProofAccepted,
                elapsed: now.saturating_duration_since(self.started) });
        }
    }
}
fn token_hash(token: &str) -> Result<[u8; 32]> {
    ensure!(
        token.len() == 64 && token.bytes().all(|b| b.is_ascii_hexdigit()),
        "SigmaDesk registration readiness transport invalid"
    );
    Ok(Sha256::digest(token.as_bytes()).into())
}
fn number(v: &Value, key: &str) -> Result<u32> {
    let value = v[key].as_u64().and_then(|n| u32::try_from(n).ok());
    ensure!(
        value.is_some(),
        "SigmaDesk registration readiness metadata invalid"
    );
    Ok(value.unwrap())
}
fn metadata<'a>(remote: &'a Value, lease: &Lease) -> Result<&'a Value> {
    ensure!(
        lease.until > Instant::now(),
        "SigmaDesk registration readiness lease expired"
    );
    ensure!(
        remote["readiness_version"].as_u64() == Some(1),
        "SigmaDesk registration readiness capability missing"
    );
    let v = &remote["readiness"];
    ensure!(
        v.as_object().is_some_and(|m| m.keys().all(|key| matches!(
            key.as_str(),
            "version"
                | "mode"
                | "session"
                | "nonce"
                | "lease_sequence"
                | "generation"
                | "accepted_revision"
                | "freshness_ms"
                | "result"
                | "ready"
        ))),
        "SigmaDesk registration readiness metadata invalid"
    );
    ensure!(
        v["version"].as_u64() == Some(1)
            && v["freshness_ms"].as_u64() == Some(30_000)
            && v["session"] == lease.binding["session_id"]
            && v["lease_sequence"].as_u64() == Some(lease.sequence)
            && v["ready"].is_boolean()
            && v.get("nonce").is_none_or(Value::is_string),
        "SigmaDesk registration readiness lease binding invalid"
    );
    ensure!(
        matches!(
            v["result"].as_str(),
            Some("waiting" | "accepted" | "duplicate" | "stale" | "rejected" | "legacy")
        ),
        "SigmaDesk registration readiness result invalid"
    );
    Ok(v)
}
impl Binding {
    /// Attach compatibility only to this exact, already-produced fresh HOST
    /// readiness evidence. Never create readiness from the engine pin itself.
    pub(crate) fn append_streaming(&self, body:&mut Value, lease:&Lease,
        engine_pin:&str, now:Instant) -> Result<bool> {
        ensure!(self.ack_mode() && lease.browser && lease.binding["kind"]=="browser"
            && lease.until>now && lease.sequence==self.lease_sequence
            && lease.binding["session_id"]==self.session
            && body["session"]==self.session
            && body["readiness_version"].as_u64()==Some(1)
            && body["readiness_mode"]=="udp-ack-v1"
            && body["readiness_nonce"].as_str()==Some(self.nonce.as_str())
            && body["readiness_generation"].as_u64()==Some(self.generation as u64)
            && body["readiness_lease_sequence"].as_u64()==Some(self.lease_sequence)
            && engine_pin.len()==64
            && engine_pin.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b)),
            "SigmaDesk streaming readiness binding changed");
        let revision=body["readiness_revision"].as_u64().and_then(|v|u32::try_from(v).ok());
        let fresh=body["readiness_age_ms"].as_u64().is_some_and(|v|v<30_000);
        ensure!(revision.is_some_and(|v|v>=self.accepted && v<=self.highest_sent)
            && body["readiness_ready"].is_boolean(),
            "SigmaDesk streaming readiness evidence invalid");
        if body["phase"]!="active" || body["readiness_ready"]!=true
            || !fresh || revision.unwrap_or(0)<=1 {return Ok(false)}
        body["streaming_capability_version"]=json!(1);
        body["streaming_capability_mode"]=json!(crate::desk_streaming::MODE);
        body["streaming_engine_manifest_sha256"]=json!(engine_pin);
        Ok(true)
    }
    /// Caller must already have verified the exact local identity, HOST signed
    /// lease, desktop/cancellation epoch, and transport credential.
    pub fn create(remote: &Value, lease: &Lease, token: &str, generation: u32) -> Result<Option<Self>> {
        if remote["readiness_version"].as_u64() != Some(1) {
            ensure!(
                remote.get("readiness").is_none(),
                "SigmaDesk registration readiness capability missing"
            );
            return Ok(None);
        }
        let v = metadata(remote, lease)?;
        let mode = v["mode"].as_str().unwrap_or("");
        ensure!(
            matches!(mode, "udp-ack-v1" | "legacy-timer"),
            "SigmaDesk registration readiness mode invalid"
        );
        let nonce = v["nonce"].as_str().unwrap_or("");
        if mode == "udp-ack-v1" {
            ensure!(
                generation > 0
                    && nonce.len() == 64
                    && nonce
                        .bytes()
                        .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
                    && number(v, "generation")? == 0
                    && number(v, "accepted_revision")? == 0
                    && v["result"] == "waiting"
                    && v["ready"] == false,
                "SigmaDesk registration readiness fresh generation required"
            );
        } else {
            ensure!(
                nonce.is_empty()
                    && number(v, "generation")? == 0
                    && number(v, "accepted_revision")? == 0
                    && v["result"] == "legacy",
                "SigmaDesk registration readiness legacy metadata invalid"
            );
        }
        Ok(Some(Self {
            mode: mode.into(),
            session: lease.binding["session_id"].as_str().unwrap_or("").into(),
            nonce: Zeroizing::new(nonce.into()),
            token: token_hash(token)?,
            generation,
            lease_sequence: lease.sequence,
            accepted: 0,
            highest_sent: 0,
            local_timings: LocalTimings::new(mode == "udp-ack-v1", Instant::now()),
        }))
    }
    pub fn ack_mode(&self) -> bool {
        self.mode == "udp-ack-v1"
    }
    /// Drains fixed local codes only. Wrong/expired binding or a retired runtime
    /// must never publish delayed diagnostics into a replacement assignment.
    pub fn take_local_timings(&mut self, lease: &Lease, now: Instant, current: bool) -> Vec<LocalTiming> {
        if !current || lease.until <= now || lease.sequence != self.lease_sequence
            || lease.binding["session_id"] != self.session
        {
            self.local_timings.closed = true;
            self.local_timings.pending.clear();
            return Vec::new();
        }
        if self.local_timings.closed { return Vec::new(); }
        std::mem::take(&mut self.local_timings.pending)
    }
    /// Called only after the renewed HOST lease and current identity/desktop/
    /// epoch have been verified. A lost response can make the submitted HOST
    /// sequence stale: resync only these response counters, never an ACK time,
    /// observation revision, readiness proof, or the immutable session mode.
    pub fn observe(&mut self, remote: &Value, lease: &Lease, token: &str) -> Result<()> {
        let v = metadata(remote, lease)?;
        ensure!(
            v["mode"] == self.mode
                && v["session"] == self.session
                && token_hash(token)? == self.token
                && v["nonce"].as_str().unwrap_or("") == self.nonce.as_str(),
            "SigmaDesk registration readiness runtime changed"
        );
        let generation = number(v, "generation")?;
        let accepted = number(v, "accepted_revision")?;
        if self.ack_mode() {
            ensure!(
                (generation == self.generation || generation == 0 && accepted == 0)
                    && accepted >= self.accepted
                    && accepted <= self.highest_sent
                    && !matches!(v["result"].as_str(), Some("rejected" | "legacy"))
                    && (v["ready"] != true || accepted > 1 && generation == self.generation),
                "SigmaDesk registration readiness evidence rejected"
            );
        } else {
            ensure!(
                generation == 0 && accepted == 0 && v["result"] == "legacy",
                "SigmaDesk registration readiness mode changed"
            );
        }
        self.lease_sequence = lease.sequence;
        self.accepted = accepted;
        if self.ack_mode() && v["ready"] == true {
            self.local_timings.accepted(Instant::now());
        }
        Ok(())
    }
    pub fn evidence(
        &mut self,
        body: &mut Value,
        observed: Observation,
        phase: &str,
        lease: &Lease,
        now: Instant,
    ) -> Result<()> {
        if !self.ack_mode() {
            return Ok(());
        }
        ensure!(
            lease.until > now
                && lease.sequence == self.lease_sequence
                && observed.generation == self.generation
                && observed.revision > 0
                && observed.age_ms <= 30_000,
            "SigmaDesk registration readiness observation invalid"
        );
        // Binding revision 1 must be acknowledged before a fast engine's first
        // ACK is published. Startup heartbeats must not consume a ready revision.
        let (revision, ready, age) = if self.accepted == 0 {
            (1, false, 0)
        } else if phase != "active" && observed.ready {
            (self.accepted, false, 0)
        } else {
            (
                observed.revision,
                phase == "active" && observed.ready && observed.age_ms < 30_000,
                if phase == "active" && observed.ready && observed.age_ms < 30_000 {
                    observed.age_ms
                } else {
                    0
                },
            )
        };
        ensure!(
            revision >= self.accepted,
            "SigmaDesk registration readiness revision regressed"
        );
        body["readiness_version"] = json!(1);
        body["readiness_mode"] = json!("udp-ack-v1");
        body["readiness_generation"] = json!(self.generation);
        body["readiness_nonce"] = json!(self.nonce.as_str());
        body["readiness_lease_sequence"] = json!(self.lease_sequence);
        body["readiness_revision"] = json!(revision);
        body["readiness_ready"] = json!(ready);
        body["readiness_age_ms"] = json!(age);
        self.highest_sent = self.highest_sent.max(revision);
        if observed.ready && observed.revision > 1 && observed.age_ms < 30_000 {
            self.local_timings.observed(now);
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;
    const SESSION: &str = "0123456789abcdef0123456789abcdef";
    fn lease(sequence: u64, t: Instant) -> Lease {
        Lease {
            binding: json!({"session_id":SESSION}),
            sequence,
            until: t + Duration::from_secs(60),
            expires: 0,
            control: true,
            browser: true,
        }
    }
    fn remote(sequence: u64, generation: u32, accepted: u32) -> Value {
        json!({"readiness_version":1,"readiness":{"version":1,"mode":"udp-ack-v1","session":SESSION,
            "nonce":"a".repeat(64),"lease_sequence":sequence,"generation":generation,"accepted_revision":accepted,
            "freshness_ms":30000,"result":if accepted==0{"waiting"}else{"accepted"},"ready":accepted>1}})
    }
    fn observation(revision: u32) -> Observation {
        Observation {
            generation: 7,
            revision,
            ready: revision > 1,
            age_ms: 0,
        }
    }
    #[test]
    fn local_timing_codes_are_fixed_bounded_and_do_not_change_wire_evidence() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut binding = Binding::create(&remote(1, 0, 0), &first, &token, 7).unwrap().unwrap();
        let mode = binding.take_local_timings(&first, t, true);
        assert_eq!(mode.len(), 1);
        assert_eq!(mode[0].code.as_str(), "mode_ack");
        assert_eq!(mode[0].elapsed, Duration::ZERO);
        let mut body = json!({});
        binding.evidence(&mut body, observation(1), "starting", &first, t).unwrap();
        assert_eq!(body, json!({"readiness_version":1,"readiness_mode":"udp-ack-v1",
            "readiness_generation":7,"readiness_nonce":"a".repeat(64),
            "readiness_lease_sequence":1,"readiness_revision":1,
            "readiness_ready":false,"readiness_age_ms":0}));
        let next = lease(2, t);
        binding.observe(&remote(2, 7, 1), &next, &token).unwrap();
        binding.evidence(&mut body, observation(2), "active", &next, t + Duration::from_millis(12)).unwrap();
        assert_eq!(body.as_object().unwrap().len(), 8);
        assert_eq!(body["readiness_revision"], 2);
        assert_eq!(body["readiness_ready"], true);
        let observed = binding.take_local_timings(&next, t + Duration::from_millis(12), true);
        assert_eq!(observed.len(), 1);
        assert_eq!(observed[0].code.as_str(), "registration_observed");
        let accepted = lease(3, t);
        binding.observe(&remote(3, 7, 2), &accepted, &token).unwrap();
        let confirmed = binding.take_local_timings(&accepted, Instant::now(), true);
        assert_eq!(confirmed.len(), 1);
        assert_eq!(confirmed[0].code.as_str(), "proof_accepted");
        for sequence in 4..40 {
            binding.evidence(&mut body, observation(2), "active", &lease(sequence - 1, t), Instant::now()).unwrap();
            let mut duplicate = remote(sequence, 7, 2);
            duplicate["readiness"]["result"] = json!("duplicate");
            binding.observe(&duplicate, &lease(sequence, t), &token).unwrap();
            assert!(binding.take_local_timings(&lease(sequence, t), Instant::now(), true).is_empty());
        }
        for code in [LocalTimingCode::ModeAck, LocalTimingCode::ModeLegacy,
            LocalTimingCode::RegistrationObserved, LocalTimingCode::ProofAccepted] {
            assert!(matches!(code.as_str(), "mode_ack" | "mode_legacy" | "registration_observed" | "proof_accepted"));
        }
    }
    #[test]
    fn local_timing_requires_live_exact_binding_and_late_callbacks_never_reopen_it() {
        let t = Instant::now();
        let token = "b".repeat(64);
        for wrong in [
            Lease { binding: json!({"session_id":"fedcba9876543210fedcba9876543210"}), ..lease(1, t) },
            lease(2, t),
            Lease { until: t, ..lease(1, t) },
        ] {
            let first = lease(1, t);
            let mut binding = Binding::create(&remote(1, 0, 0), &first, &token, 7).unwrap().unwrap();
            assert!(binding.take_local_timings(&wrong, t, true).is_empty());
            // An obsolete callback may complete; diagnostics alone stay closed.
            let mut body = json!({});
            binding.evidence(&mut body, observation(2), "active", &first, t).unwrap();
            assert!(binding.take_local_timings(&first, t, true).is_empty());
            assert_eq!(body["readiness_revision"], 1); // Protocol bind-first rule is unchanged.
        }
        let first = lease(1, t);
        let mut binding = Binding::create(&remote(1, 0, 0), &first, &token, 7).unwrap().unwrap();
        assert!(binding.take_local_timings(&first, t, false).is_empty());
        assert!(binding.take_local_timings(&first, t, true).is_empty());
    }
    #[test]
    fn unverified_response_and_wrong_generation_cannot_earn_local_success_codes() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut binding = Binding::create(&remote(1, 0, 0), &first, &token, 7).unwrap().unwrap();
        binding.take_local_timings(&first, t, true);
        let mut bad = remote(2, 7, 2);
        bad["readiness"]["nonce"] = json!("synthetic-invalid-private-value");
        assert!(binding.observe(&bad, &lease(2, t), &token).is_err());
        let wrong = Observation { generation:8, ..observation(2) };
        let mut body = json!({"unchanged":true});
        assert!(binding.evidence(&mut body, wrong, "active", &first, t).is_err());
        assert_eq!(body, json!({"unchanged":true}));
        assert!(binding.take_local_timings(&first, t, true).is_empty());
    }
    #[test]
    fn response_first_capability_is_identity_scoped_and_legacy_requests_remain_old() {
        let mut c = Capability::default();
        let a = json!({"node":"a","member":"m"});
        let b = json!({"node":"b","member":"m"});
        let mut body = json!({"phase":"stopped"});
        c.advertise(&mut body, &a);
        assert!(body.get("readiness_version").is_none());
        c.observe(&json!({"readiness_version":1}), &a);
        c.advertise(&mut body, &a);
        assert_eq!(body["readiness_version"], 1);
        assert_eq!(body["readiness_mode"], "udp-ack-v1");
        let mut other = json!({});
        c.advertise(&mut other, &b);
        assert_eq!(other, json!({}));
        c.observe(&json!({}), &a);
        let mut old = json!({});
        c.advertise(&mut old, &a);
        assert_eq!(old, json!({}));
    }
    #[test]
    fn a_fast_ack_cannot_skip_initial_false_binding_or_be_consumed_by_starting_phase() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut b = Binding::create(&remote(1, 0, 0), &first, &token, 7)
            .unwrap()
            .unwrap();
        let mut body = json!({"session":SESSION,"phase":"starting"});
        b.evidence(&mut body, observation(2), "starting", &first, t)
            .unwrap();
        assert_eq!(body["readiness_revision"], 1);
        assert_eq!(body["readiness_ready"], false);
        assert_eq!(body["readiness_age_ms"], 0);
        let next = lease(2, t);
        b.observe(&remote(2, 7, 1), &next, &token).unwrap();
        b.evidence(&mut body, observation(2), "starting", &next, t)
            .unwrap();
        assert_eq!(body["readiness_revision"], 1);
        body["phase"] = json!("active");
        b.evidence(&mut body, observation(2), "active", &next, t).unwrap();
        assert_eq!(body["readiness_revision"], 2);
        assert_eq!(body["readiness_ready"], true);
        assert_eq!(body["readiness_lease_sequence"], 2);
        b.observe(&remote(3, 7, 2), &lease(3, t), &token).unwrap();
    }
    #[test]
    fn wrong_runtime_nonce_token_sequence_and_downgrade_cannot_publish() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut b = Binding::create(&remote(1, 0, 0), &first, &token, 7)
            .unwrap()
            .unwrap();
        let mut body = json!({});
        b.evidence(&mut body, observation(1), "starting", &first, t)
            .unwrap();
        for field in [
            "nonce",
            "session",
            "mode",
            "lease_sequence",
            "generation",
            "accepted_revision",
            "freshness_ms",
            "result",
        ] {
            let mut bad = remote(2, 7, 1);
            bad["readiness"][field] = match field {
                "lease_sequence" => json!(1),
                "generation" => json!(8),
                "accepted_revision" => json!(2),
                "freshness_ms" => json!(60000),
                "result" => json!("rejected"),
                _ => json!("changed"),
            };
            assert!(b.observe(&bad, &lease(2, t), &token).is_err(), "{field}");
        }
        assert!(b.observe(&json!({}), &lease(2, t), &token).is_err());
        assert!(
            b.observe(&remote(2, 7, 1), &lease(2, t), &"c".repeat(64))
                .is_err()
        );
        let mut wrong = observation(2);
        wrong.generation = 8;
        assert!(b.evidence(&mut json!({}), wrong, "active", &first, t).is_err());
        assert!(
            b.evidence(
                &mut json!({}),
                observation(2),
                "active",
                &first,
                t + Duration::from_secs(60)
            )
            .is_err()
        );
        assert!(Binding::create(&remote(2, 7, 1), &lease(2, t), &token, 8).is_err());
        for unsupported in [json!(null), json!("1"), json!(1.0), json!(2)] {
            let mut bad = remote(1, 0, 0);
            bad["readiness_version"] = unsupported;
            assert!(Binding::create(&bad, &first, &token, 7).is_err());
        }
    }
    #[test]
    fn legacy_assignment_never_upgrades_and_flat_proof_has_exact_observed_age() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut legacy = remote(1, 0, 0);
        legacy["readiness"]["mode"] = json!("legacy-timer");
        legacy["readiness"].as_object_mut().unwrap().remove("nonce");
        legacy["readiness"]["result"] = json!("legacy");
        let mut b = Binding::create(&legacy, &first, &token, 7).unwrap().unwrap();
        assert!(!b.ack_mode());
        let mut body = json!({});
        b.evidence(&mut body, observation(2), "active", &first, t)
            .unwrap();
        assert_eq!(body, json!({}));
        assert!(b.observe(&remote(2, 0, 0), &lease(2, t), &token).is_err());
        let mut b = Binding::create(&remote(1, 0, 0), &first, &token, 7)
            .unwrap()
            .unwrap();
        b.evidence(&mut body, observation(1), "starting", &first, t)
            .unwrap();
        b.observe(&remote(2, 7, 1), &lease(2, t), &token).unwrap();
        let observed = Observation {
            age_ms: 29_999,
            ..observation(2)
        };
        b.evidence(&mut body, observed, "active", &lease(2, t), t)
            .unwrap();
        assert_eq!(body["readiness_age_ms"], 29_999);
        assert_eq!(body["readiness_ready"], true);
        b.evidence(
            &mut body,
            Observation {
                age_ms: 30_000,
                ..observed
            },
            "active",
            &lease(2, t),
            t,
        )
        .unwrap();
        assert_eq!(body["readiness_ready"], false);
        assert_eq!(body["readiness_age_ms"], 0);
        assert_eq!(body.as_object().unwrap().len(), 8);
    }
    #[test]
    fn only_advertised_idle_bad_request_can_trigger_legacy_capability_rediscovery() {
        assert_eq!(
            Capability::recovery(Some(400), true, "stopped", "", false),
            Recovery::ReprobeIdle
        );
        for (phase, session, starting) in [
            ("active", SESSION, false),
            ("starting", SESSION, true),
            ("stopped", "", true),
        ] {
            assert_eq!(
                Capability::recovery(Some(400), true, phase, session, starting),
                Recovery::EndSession
            );
        }
        for status in [
            None,
            Some(200),
            Some(401),
            Some(403),
            Some(404),
            Some(429),
            Some(500),
        ] {
            assert_eq!(
                Capability::recovery(status, true, "stopped", "", false),
                Recovery::None
            );
        }
        assert_eq!(
            Capability::recovery(Some(400), false, "stopped", "", false),
            Recovery::None
        );
        let identity = json!({"node":"a"});
        let mut c = Capability::default();
        c.observe(&json!({"readiness_version":1}), &identity);
        c.reset(&identity);
        let mut old = json!({});
        c.advertise(&mut old, &identity);
        assert_eq!(old, json!({}));
        c.observe(&json!({}), &identity);
        c.advertise(&mut old, &identity);
        assert_eq!(old, json!({}));
        c.observe(&json!({"readiness_version":1}), &identity);
        c.advertise(&mut old, &identity);
        assert_eq!(old["readiness_version"], 1);
    }
    #[test]
    fn old_new_server_and_rollback_matrix_never_retries_authorization_or_downgrades_a_session() {
        let identity = json!({"node":"synthetic-node","member":"synthetic-member"});
        let mut c = Capability::default();
        let request = |c: &Capability| {
            let mut body = json!({"phase":"stopped","session":""});
            c.advertise(&mut body, &identity);
            body
        };
        // Old server: both initial and subsequent requests contain only old fields.
        assert_eq!(request(&c).as_object().unwrap().len(), 2);
        c.observe(&json!({}), &identity);
        assert_eq!(request(&c).as_object().unwrap().len(), 2);
        // New server: the discovery request is old-shaped, the next poll advertises both fields.
        c.observe(&json!({"readiness_version":1}), &identity);
        let advertised = request(&c);
        assert_eq!(advertised["readiness_version"], 1);
        assert_eq!(advertised["readiness_mode"], "udp-ack-v1");
        // Strict old server after rollback: only this idle400 resets capability.
        assert_eq!(
            Capability::recovery(Some(400), true, "stopped", "", false),
            Recovery::ReprobeIdle
        );
        c.reset(&identity);
        assert_eq!(request(&c).as_object().unwrap().len(), 2);
        c.observe(&json!({}), &identity);
        assert_eq!(request(&c).as_object().unwrap().len(), 2);
        c.observe(&json!({"readiness_version":1}), &identity);
        assert_eq!(
            Capability::recovery(Some(400), true, "active", SESSION, false),
            Recovery::EndSession
        );
        assert_eq!(request(&c)["readiness_mode"], "udp-ack-v1");
        for denied in [401, 403] {
            assert_eq!(
                Capability::recovery(Some(denied), true, "stopped", "", false),
                Recovery::None
            );
        }
    }
    #[test]
    fn lost_bind_and_fresh_ack_resync_preserve_observation_revision_age_and_cleared_proof() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut b = Binding::create(&remote(1, 0, 0), &first, &token, 7)
            .unwrap()
            .unwrap();
        let mut body = json!({});
        b.evidence(&mut body, observation(2), "starting", &first, t)
            .unwrap();
        assert_eq!(body["readiness_revision"], 1);
        assert_eq!(body["readiness_ready"], false);
        // The bind response (HOST sequence2) was lost; the response to old seq1
        // carries a freshly verified seq3 and already accepted bind revision1.
        let mut stale = remote(3, 7, 1);
        stale["readiness"]["result"] = json!("stale");
        b.observe(&stale, &lease(3, t), &token).unwrap();
        assert_eq!((b.lease_sequence, b.accepted, b.highest_sent), (3, 1, 1));
        b.evidence(&mut body, observation(2), "active", &lease(3, t), t)
            .unwrap();
        assert_eq!(body["readiness_revision"], 2);
        assert_eq!(body["readiness_ready"], true);
        // The ready response (seq4) was also lost. Resync does not manufacture
        // revision3, overwrite the actual observed age, or refresh a proof.
        let mut stale = remote(5, 7, 2);
        stale["readiness"]["result"] = json!("stale");
        b.observe(&stale, &lease(5, t), &token).unwrap();
        assert_eq!((b.lease_sequence, b.accepted, b.highest_sent), (5, 2, 2));
        let observed = Observation {
            age_ms: 10_000,
            ..observation(2)
        };
        b.evidence(
            &mut body,
            observed,
            "active",
            &lease(5, t),
            t + Duration::from_secs(10),
        )
        .unwrap();
        assert_eq!(body["readiness_revision"], 2);
        assert_eq!(body["readiness_age_ms"], 10_000);
        assert_eq!(body["readiness_lease_sequence"], 5);
        assert_eq!(body["readiness_mode"], "udp-ack-v1");
        let mut cleared = remote(6, 7, 2);
        cleared["readiness"]["result"] = json!("waiting");
        cleared["readiness"]["ready"] = json!(false);
        b.observe(&cleared, &lease(6, t), &token).unwrap();
        b.evidence(
            &mut body,
            Observation {
                age_ms: 11_000,
                ..observed
            },
            "active",
            &lease(6, t),
            t + Duration::from_secs(11),
        )
        .unwrap();
        assert_eq!(body["readiness_revision"], 2);
        assert_eq!(body["readiness_age_ms"], 11_000);
        // Only an independently advanced ACK revision can request a new proof.
        b.evidence(
            &mut body,
            observation(3),
            "active",
            &lease(6, t),
            t + Duration::from_secs(11),
        )
        .unwrap();
        assert_eq!(body["readiness_revision"], 3);
        assert_eq!(body["readiness_age_ms"], 0);
        b.observe(&remote(7, 7, 3), &lease(7, t), &token).unwrap();
    }
    #[test]
    fn stale_result_cannot_bypass_immutable_binding_unsent_revision_or_live_lease_checks() {
        let t = Instant::now();
        let token = "b".repeat(64);
        let first = lease(1, t);
        let mut b = Binding::create(&remote(1, 0, 0), &first, &token, 7)
            .unwrap()
            .unwrap();
        b.evidence(&mut json!({}), observation(1), "starting", &first, t)
            .unwrap();
        b.observe(&remote(2, 7, 1), &lease(2, t), &token).unwrap();
        b.evidence(&mut json!({}), observation(2), "active", &lease(2, t), t)
            .unwrap();
        let before = (b.lease_sequence, b.accepted, b.highest_sent);
        for field in [
            "nonce",
            "session",
            "mode",
            "generation",
            "accepted_revision",
            "lease_sequence",
            "result",
        ] {
            let mut bad = remote(4, 7, 2);
            bad["readiness"]["result"] = json!("stale");
            bad["readiness"][field] = match field {
                "generation" => json!(8),
                "accepted_revision" => json!(3),
                "lease_sequence" => json!(3),
                "result" => json!("rejected"),
                _ => json!("synthetic-never-display"),
            };
            let error = b.observe(&bad, &lease(4, t), &token).unwrap_err();
            assert!(!error.to_string().contains("synthetic-never-display"));
            assert_eq!((b.lease_sequence, b.accepted, b.highest_sent), before);
        }
        let mut stale = remote(4, 7, 2);
        stale["readiness"]["result"] = json!("stale");
        assert!(b.observe(&stale, &lease(4, t), &"c".repeat(64)).is_err());
        let mut expired = lease(4, t);
        expired.until = Instant::now() - Duration::from_millis(1);
        assert!(b.observe(&stale, &expired, &token).is_err());
        assert_eq!((b.lease_sequence, b.accepted, b.highest_sent), before);
        let mut regressed = stale;
        regressed["readiness"]["accepted_revision"] = json!(0);
        assert!(b.observe(&regressed, &lease(4, t), &token).is_err());
    }
}
