//! Bounded observation of registration control datagrams only. Payloads remain
//! opaque to the TCP adapters and are forwarded without modification. No raw
//! packet, public key or delegated engine ID is exposed as diagnostics.
use std::{
    collections::{HashMap, VecDeque},
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

pub const FRESHNESS: Duration = Duration::from_millis(30_000);
const MAX_CHANNELS: usize = 8;
const MAX_PENDING: usize = 8;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Observation {
    pub generation: u32,
    pub revision: u32,
    pub ready: bool,
    pub age_ms: u32,
}
struct Channel {
    pk_pending: Option<Instant>,
    pk_ok: Option<Instant>,
    registered: bool,
    peers: VecDeque<Instant>,
}
struct State {
    revision: u32,
    stopped: bool,
    next_channel: u64,
    channels: HashMap<u64, Channel>,
    ready: Option<(u64, Instant)>,
}
pub struct Registration {
    expected: String,
    generation: u32,
    state: Mutex<State>,
    wake: Option<Arc<tokio::sync::Notify>>,
}
impl Registration {
    pub fn new(expected: String) -> Self {
        let bytes = *uuid::Uuid::new_v4().as_bytes();
        let generation = u32::from_le_bytes(bytes[..4].try_into().unwrap()).max(1);
        Self::with_generation(expected, generation)
    }
    fn with_generation(expected: String, generation: u32) -> Self {
        Self {
            expected,
            generation,
            state: Mutex::new(State {
                revision: 1,
                stopped: false,
                next_channel: 0,
                channels: HashMap::new(),
                ready: None,
            }),
            wake: None,
        }
    }
    pub fn with_wake(mut self, wake: Arc<tokio::sync::Notify>) -> Self {
        self.wake = Some(wake);
        self
    }
    pub fn open(&self) -> Option<u64> {
        let mut s = self.state.lock().ok()?;
        if s.stopped || s.channels.len() >= MAX_CHANNELS {
            return None;
        }
        s.next_channel = s.next_channel.checked_add(1)?;
        let id = s.next_channel;
        s.channels.insert(
            id,
            Channel {
                pk_pending: None,
                pk_ok: None,
                registered: false,
                peers: VecDeque::new(),
            },
        );
        Some(id)
    }
    fn advance(&self, s: &mut State) {
        if let Some(next) = s.revision.checked_add(1) {
            s.revision = next;
        } else {
            s.stopped = true;
            s.ready = None;
            s.channels.clear();
        }
        if let Some(wake) = &self.wake {
            wake.notify_one();
        }
    }
    fn reset(&self, s: &mut State, id: u64) {
        if s.ready.is_some_and(|(channel, _)| channel == id) {
            s.ready = None;
        }
        self.advance(s);
    }
    /// Called only after successful upstream send AND current engine-job ownership.
    /// False invalidates the channel; its task must close instead of matching a
    /// late response against a newer registration attempt on that same stream.
    pub fn sent(&self, id: u64, bytes: &[u8], now: Instant) -> bool {
        let packet = packet(bytes, &self.expected);
        let Ok(mut s) = self.state.lock() else {
            return false;
        };
        if s.stopped {
            return false;
        }
        let Some(c) = s.channels.get_mut(&id) else {
            return false;
        };
        match packet {
            Packet::Pk => {
                c.pk_pending = Some(now);
                c.pk_ok = None;
                c.registered = false;
                c.peers.clear();
                if s.ready.is_some() {
                    s.ready = None;
                    self.advance(&mut s);
                }
            }
            Packet::Peer => {
                if c.pk_ok.is_none() {
                    return true;
                }
                if (!c.registered
                    && c.pk_ok
                        .is_some_and(|at| now.saturating_duration_since(at) >= FRESHNESS))
                    || c.peers
                        .front()
                        .is_some_and(|at| now.saturating_duration_since(*at) >= FRESHNESS)
                    || c.peers.len() == MAX_PENDING
                {
                    s.channels.remove(&id);
                    self.reset(&mut s, id);
                    return false;
                }
                c.peers.push_back(now);
            }
            _ => {}
        }
        true
    }
    /// Called only after successful downstream UDP delivery to the current job.
    pub fn delivered(&self, id: u64, bytes: &[u8], now: Instant) {
        let packet = packet(bytes, &self.expected);
        let Ok(mut s) = self.state.lock() else {
            return;
        };
        if s.stopped {
            return;
        }
        let Some(c) = s.channels.get_mut(&id) else {
            return;
        };
        match packet {
            Packet::PkOk => {
                if c.pk_pending
                    .take()
                    .is_some_and(|at| now.saturating_duration_since(at) < FRESHNESS)
                {
                    c.pk_ok = Some(now);
                }
            }
            Packet::PeerOk => {
                if c.pk_ok.is_none() {
                    return;
                }
                let Some(sent) = c.peers.pop_front() else {
                    return;
                };
                if now.saturating_duration_since(sent) >= FRESHNESS {
                    s.channels.remove(&id);
                    self.reset(&mut s, id);
                    return;
                }
                c.registered = true;
                self.advance(&mut s);
                if !s.stopped {
                    s.ready = Some((id, now));
                }
            }
            Packet::Reset => {
                c.pk_pending = None;
                c.pk_ok = None;
                c.registered = false;
                c.peers.clear();
                self.reset(&mut s, id);
            }
            _ => {}
        }
    }
    pub fn close(&self, id: u64) {
        if let Ok(mut s) = self.state.lock() {
            if s.channels
                .remove(&id)
                .is_some_and(|c| c.pk_pending.is_some() || c.pk_ok.is_some())
            {
                self.reset(&mut s, id);
            }
        }
    }
    pub fn stop(&self) {
        if let Ok(mut s) = self.state.lock() {
            if !s.stopped {
                s.ready = None;
                s.channels.clear();
                self.advance(&mut s);
                s.stopped = true;
            }
        }
    }
    pub fn observation(&self, now: Instant) -> Observation {
        let Ok(mut s) = self.state.lock() else {
            return Observation {
                generation: self.generation,
                revision: u32::MAX,
                ready: false,
                age_ms: 0,
            };
        };
        if s.ready
            .is_some_and(|(_, at)| now.saturating_duration_since(at) >= FRESHNESS)
        {
            s.ready = None;
            self.advance(&mut s);
        }
        Observation {
            generation: self.generation,
            revision: s.revision,
            ready: !s.stopped && s.ready.is_some(),
            age_ms: s
                .ready
                .map(|(_, at)| now.saturating_duration_since(at).as_millis().min(30_000) as u32)
                .unwrap_or(0),
        }
    }
    pub fn relevant(bytes: &[u8]) -> bool {
        matches!(envelope(bytes), Some((6 | 7 | 15 | 16, _)))
    }
}

#[derive(Debug, PartialEq, Eq)]
enum Packet {
    Pk,
    Peer,
    PkOk,
    PeerOk,
    Reset,
    Other,
}
enum Field<'a> {
    Integer(u64),
    Bytes(&'a [u8]),
}
fn varint(input: &mut &[u8]) -> Option<u64> {
    let mut value = 0u64;
    for n in 0..10 {
        let (&byte, rest) = input.split_first()?;
        *input = rest;
        if n == 9 && byte > 1 {
            return None;
        }
        value |= u64::from(byte & 127) << (n * 7);
        if byte & 128 == 0 {
            return (n == 0 || byte != 0).then_some(value);
        }
    }
    None
}
fn fields(mut input: &[u8]) -> Option<Vec<(u32, Field<'_>)>> {
    let mut out = Vec::new();
    while !input.is_empty() {
        if out.len() == 8 {
            return None;
        }
        let tag = varint(&mut input)?;
        let key = u32::try_from(tag >> 3).ok()?;
        if key == 0 || out.iter().any(|(old, _)| *old == key) {
            return None;
        }
        let field = match tag & 7 {
            0 => Field::Integer(varint(&mut input)?),
            2 => {
                let n = usize::try_from(varint(&mut input)?).ok()?;
                if n > input.len() {
                    return None;
                }
                let (value, rest) = input.split_at(n);
                input = rest;
                Field::Bytes(value)
            }
            _ => return None,
        };
        out.push((key, field));
    }
    Some(out)
}
fn envelope(bytes: &[u8]) -> Option<(u32, &[u8])> {
    if bytes.is_empty() || bytes.len() > 4096 {
        return None;
    }
    let f = fields(bytes)?;
    if f.len() != 1 {
        return None;
    }
    match f.into_iter().next()? {
        (tag, Field::Bytes(body)) => Some((tag, body)),
        _ => None,
    }
}
fn packet(bytes: &[u8], expected: &str) -> Packet {
    let Some((tag, body)) = envelope(bytes) else {
        return Packet::Other;
    };
    let Some(f) = fields(body) else {
        return Packet::Other;
    };
    match tag {
        6 => {
            let mut id = false;
            for (key, field) in f {
                match (key, field) {
                    (1, Field::Bytes(value)) if value == expected.as_bytes() => id = true,
                    (2, Field::Integer(_)) => {}
                    _ => return Packet::Other,
                }
            }
            if id { Packet::Peer } else { Packet::Other }
        }
        15 => {
            let (mut id, mut uuid, mut pk) = (false, false, false);
            for (key, field) in f {
                match (key, field) {
                    (1, Field::Bytes(value)) if value == expected.as_bytes() => id = true,
                    (2, Field::Bytes(value)) if (1..=128).contains(&value.len()) => uuid = true,
                    (3, Field::Bytes(value)) if value.len() == 32 => pk = true,
                    (4, Field::Bytes(value)) if value.is_empty() || value == expected.as_bytes() => {}
                    (5, Field::Integer(0 | 1)) => {}
                    _ => return Packet::Other,
                }
            }
            if id && uuid && pk {
                Packet::Pk
            } else {
                Packet::Other
            }
        }
        16 => {
            let mut ok = true;
            for (key, field) in f {
                match (key, field) {
                    (1, Field::Integer(value)) if value <= 8 => ok = value == 0,
                    (2, Field::Integer(value)) if value <= u32::MAX as u64 => {}
                    _ => return Packet::Other,
                }
            }
            if ok { Packet::PkOk } else { Packet::Reset }
        }
        7 => {
            let mut request = false;
            for (key, field) in f {
                match (key, field) {
                    (2, Field::Integer(value @ (0 | 1))) => request = value == 1,
                    _ => return Packet::Other,
                }
            }
            if request { Packet::Reset } else { Packet::PeerOk }
        }
        _ => Packet::Other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const ID: &str = "123456789";
    fn wrap(tag: u8, body: &[u8]) -> Vec<u8> {
        let mut out = if tag < 16 {
            vec![(tag << 3) | 2]
        } else {
            vec![0x82, 1]
        };
        out.push(body.len() as u8);
        out.extend_from_slice(body);
        out
    }
    fn pk() -> Vec<u8> {
        let mut body = vec![10, 9];
        body.extend_from_slice(ID.as_bytes());
        body.extend_from_slice(&[18, 16]);
        body.extend_from_slice(&[2; 16]);
        body.extend_from_slice(&[26, 32]);
        body.extend_from_slice(&[3; 32]);
        wrap(15, &body)
    }
    fn peer() -> Vec<u8> {
        let mut body = vec![10, 9];
        body.extend_from_slice(ID.as_bytes());
        wrap(6, &body)
    }
    fn registered(r: &Registration, c: u64, t: Instant) {
        assert!(r.sent(c, &pk(), t));
        r.delivered(c, &wrap(16, &[]), t + Duration::from_millis(1));
        assert!(r.sent(c, &peer(), t + Duration::from_millis(2)));
        r.delivered(c, &wrap(7, &[]), t + Duration::from_millis(3));
    }
    #[test]
    fn only_typed_current_pk_then_peer_ack_can_advance_readiness() {
        let t = Instant::now();
        let r = Registration::with_generation(ID.into(), 7);
        let c = r.open().unwrap();
        r.delivered(c, &[], t);
        r.delivered(c, &wrap(16, &[]), t);
        r.delivered(c, &wrap(7, &[]), t);
        r.sent(c, &peer(), t);
        r.delivered(c, &wrap(7, &[]), t);
        assert_eq!(
            r.observation(t),
            Observation {
                generation: 7,
                revision: 1,
                ready: false,
                age_ms: 0
            }
        );
        r.sent(c, &pk(), t);
        r.delivered(c, &wrap(16, &[]), t);
        assert!(!r.observation(t).ready); // PK OK alone is not ready.
        r.delivered(c, &wrap(7, &[]), t);
        assert!(!r.observation(t).ready);
        r.sent(c, &peer(), t);
        r.delivered(c, &wrap(7, &[16, 0]), t);
        assert_eq!(
            r.observation(t),
            Observation {
                generation: 7,
                revision: 2,
                ready: true,
                age_ms: 0
            }
        );
    }
    #[test]
    fn duplicate_unpaired_ack_cannot_extend_freshness_or_rearm_an_expired_proof() {
        let t = Instant::now();
        let r = Registration::with_generation(ID.into(), 9);
        let c = r.open().unwrap();
        registered(&r, c, t);
        let ack = t + Duration::from_millis(3);
        r.delivered(c, &wrap(7, &[]), ack + Duration::from_secs(20));
        assert_eq!(r.observation(ack + Duration::from_secs(20)).age_ms, 20_000);
        let expired = r.observation(ack + FRESHNESS);
        assert!(!expired.ready);
        assert_eq!(expired.revision, 3);
        r.delivered(c, &wrap(7, &[]), ack + FRESHNESS);
        assert_eq!(r.observation(ack + FRESHNESS), expired);
        assert!(r.sent(c, &peer(), ack + FRESHNESS));
        r.delivered(c, &wrap(7, &[]), ack + FRESHNESS);
        assert!(r.observation(ack + FRESHNESS).ready);
        assert_eq!(r.observation(ack + FRESHNESS).revision, 4);
    }
    #[test]
    fn channel_replacement_stop_and_stale_pending_ack_fail_closed() {
        let t = Instant::now();
        let r = Registration::with_generation(ID.into(), 11);
        let old = r.open().unwrap();
        registered(&r, old, t);
        r.close(old);
        let c = r.open().unwrap();
        r.delivered(old, &wrap(7, &[]), t);
        r.delivered(c, &wrap(7, &[]), t);
        assert!(!r.observation(t).ready);
        r.sent(c, &pk(), t);
        r.delivered(c, &wrap(16, &[]), t);
        r.sent(c, &peer(), t);
        r.delivered(c, &wrap(7, &[]), t + FRESHNESS);
        assert!(!r.observation(t + FRESHNESS).ready);
        let c = r.open().unwrap();
        registered(&r, c, t + FRESHNESS);
        r.stop();
        r.delivered(c, &wrap(7, &[]), t + FRESHNESS);
        assert!(!r.observation(t + FRESHNESS).ready);
        assert!(r.open().is_none());
    }
    #[test]
    fn request_pk_error_wrong_identity_and_ambiguous_protobuf_never_earn_readiness() {
        let t = Instant::now();
        let r = Registration::with_generation(ID.into(), 13);
        let c = r.open().unwrap();
        let mut other = pk();
        other[4] = b'9';
        r.sent(c, &other, t);
        r.delivered(c, &wrap(16, &[]), t);
        r.sent(c, &peer(), t);
        r.delivered(c, &wrap(7, &[]), t);
        assert!(!r.observation(t).ready);
        registered(&r, c, t);
        r.delivered(c, &wrap(7, &[16, 1]), t);
        assert!(!r.observation(t).ready);
        r.sent(c, &pk(), t);
        r.delivered(c, &wrap(16, &[8, 7]), t);
        r.sent(c, &peer(), t);
        r.delivered(c, &wrap(7, &[]), t);
        assert!(!r.observation(t).ready);
        for malformed in [
            vec![],
            vec![0x3a],
            vec![0x3a, 1],
            vec![0x3a, 0, 0x3a, 0],
            vec![0x3a, 4, 16, 0, 16, 0],
            vec![0x3a, 3, 16, 0x80, 0],
            vec![0; 4097],
        ] {
            assert_eq!(packet(&malformed, ID), Packet::Other);
        }
    }
    #[test]
    fn bounded_channels_pending_and_different_runtime_generations_do_not_mix() {
        let t = Instant::now();
        let a = Registration::with_generation(ID.into(), 21);
        let b = Registration::with_generation(ID.into(), 22);
        let c = a.open().unwrap();
        registered(&a, c, t);
        assert!(!b.observation(t).ready);
        assert_ne!(a.observation(t).generation, b.observation(t).generation);
        for _ in 1..MAX_CHANNELS {
            assert!(a.open().is_some());
        }
        assert!(a.open().is_none());
        for _ in 0..MAX_PENDING {
            assert!(a.sent(c, &peer(), t));
        }
        assert!(!a.sent(c, &peer(), t));
        assert!(!a.observation(t).ready);
    }
}
