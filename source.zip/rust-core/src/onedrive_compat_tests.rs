//! Synthetic Graph responses exercise the actual patched OpenDAL operator.
//! No user credentials, cloud calls or installed application state are used.
use opendal::{Buffer, HttpBody, HttpTransport, HttpTransporter, Operator, services};
use serde_json::{Value, json};

fn item(name: &str, facet: Value) -> Value {
    let mut v = json!({"id":name,"name":name,"lastModifiedDateTime":"2026-10-21T00:00:00Z","eTag":"fixture-revision","size":3});
    v.as_object_mut()
        .unwrap()
        .extend(facet.as_object().unwrap().clone());
    v
}
#[derive(Clone)]
struct GraphFixture;
impl HttpTransport for GraphFixture {
    async fn fetch(&self, req: http::Request<Buffer>) -> opendal::Result<http::Response<HttpBody>> {
        assert_eq!(req.method(), http::Method::GET);
        assert_eq!(req.uri().host(), Some("graph.microsoft.com"));
        let p = req.uri().path();
        let v = if req.uri().query().unwrap_or("").contains("fixture-next") {
            json!({"value":[item("last.txt",json!({"file":{"mimeType":"text/plain"}}))]})
        } else if p.ends_with("/children") || p.ends_with(":/children") {
            json!({"@odata.nextLink":"https://graph.microsoft.com/v1.0/me/drive/root/children?fixture-next=1", "value":[
                item("folder",json!({"folder":{}})),
                item("document.txt",json!({"file":{},"parentReference":{"path":"/drives/another/root:/wrong"}})),
                item("shortcut",json!({"remoteItem":{"folder":{},"id":"external-id"}}))
            ]})
        } else if p.ends_with("shortcut") {
            item("shortcut", json!({"remoteItem":{"file":{}}}))
        } else {
            item("root", json!({"folder":{}}))
        };
        let b = serde_json::to_vec(&v).unwrap();
        let n = b.len() as u64;
        Ok(http::Response::builder()
            .header(http::header::CONTENT_LENGTH, n)
            .body(HttpBody::new(
                futures_util::stream::iter(vec![Ok(Buffer::from(b))]),
                Some(n),
            ))
            .unwrap())
    }
}
fn operator(root: &str) -> Operator {
    let op = Operator::new(
        services::Onedrive::default()
            .root(root)
            .access_token("synthetic-fixture-token"),
    )
    .unwrap();
    let context = op
        .base_context()
        .with_http_transport(HttpTransporter::new(GraphFixture));
    op.with_context(context)
}
#[tokio::test]
async fn optional_facets_and_special_items_do_not_break_paginated_listing() {
    let op = operator("/");
    let entries = op.list("/").await.unwrap();
    assert!(
        entries
            .iter()
            .any(|e| e.path() == "folder/" && e.metadata().is_dir())
    );
    assert!(
        entries
            .iter()
            .any(|e| e.path() == "document.txt" && e.metadata().is_file())
    );
    assert!(!entries.iter().any(|e| e.path() == "shortcut"));
    assert!(entries.iter().any(|e| e.path() == "last.txt"));
    assert!(op.stat("/").await.unwrap().is_dir());
    assert_eq!(
        op.stat("shortcut").await.unwrap_err().kind(),
        opendal::ErrorKind::Unsupported
    );
}
#[tokio::test]
async fn nested_root_does_not_relocate_items_from_parent_reference() {
    let entries = operator("/base/").list("nested/").await.unwrap();
    assert!(entries.iter().any(|e| e.path() == "nested/document.txt"));
    assert!(entries.iter().any(|e| e.path() == "nested/last.txt"));
    assert!(
        !entries
            .iter()
            .any(|e| e.path().contains("wrong") || e.path().contains("base/"))
    );
}
