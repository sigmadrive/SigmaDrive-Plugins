//! Product core. No Go daemon, gRPC forwarding, worker CLI or rclone dependency.
use anyhow::{Result, bail, ensure};
use opendal::{Operator, services};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    path::PathBuf,
    sync::{Arc, OnceLock},
};

mod api;
mod auth;
mod authority;
mod availability;
mod cloud;
mod desk;
mod desk_http;
mod desk_notify;
mod desk_retirement;
mod desk_codec_startup;
mod desk_local_diagnostics;
#[cfg(windows)]
mod desk_assets;
mod desk_lease;
mod desk_registration;
mod desk_readiness;
mod desk_streaming;
#[cfg(windows)]
mod desk_local_owner;
mod desk_transport;
mod desk_transport_trace;
mod desk_transport_tls;
#[cfg(windows)]
mod desk_windows;
mod diagnostics;
mod driver;
mod engine;
mod ffi;
mod gateway;
pub mod identity;
mod jobs;
pub mod leases;
mod metadata;
#[cfg(windows)]
mod mount2;
#[cfg(test)]
mod onedrive_compat_tests;
mod opener;
mod peer_client;
mod peer_jobs;
pub mod peer_tls;
mod permissions;
pub mod permit;
mod portal;
mod profile;
mod provider_http;
pub mod publication;
mod registration;
pub mod relay;
mod replace;
pub mod s3_store;
mod safe;
pub mod share_fs;
mod sharing;
mod startup;
mod state;
mod storage;
mod stream;
mod update;
mod v2;
pub use ffi::call_json;

pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub fn remote_path(root: &str, path: &str) -> String {
    [root.trim_matches('/'), path.trim_matches('/')]
        .into_iter()
        .filter(|s| !s.is_empty())
        .collect::<Vec<_>>()
        .join("/")
}
static CORE: OnceLock<Arc<state::Core>> = OnceLock::new();
#[derive(Clone, Serialize, Deserialize)]
pub struct Config {
    pub provider: String,
    pub root: String,
    pub options: HashMap<String, String>,
    #[serde(default)]
    pub work: PathBuf,
    #[serde(default)]
    pub mode: String,
    #[serde(default)]
    pub mount: String,
}
impl Config {
    pub fn get(&self, k: &str) -> &str {
        self.options.get(k).map(String::as_str).unwrap_or("")
    }
    pub fn operator(&self) -> Result<Operator> {
        engine::checked(&self.root)?;
        let op = match self.provider.as_str() {
            "drive" => Operator::new(
                services::Gdrive::default()
                    .root(&self.root)
                    .access_token(self.get("access_token")),
            )?,
            "onedrive" => Operator::new(
                services::Onedrive::default()
                    .root(&self.root)
                    .access_token(self.get("access_token")),
            )?,
            "s3" => {
                let url = reqwest::Url::parse(self.get("endpoint"))?;
                ensure!(
                    url.scheme() == "https"
                        || (url.scheme() == "http"
                            && url
                                .host_str()
                                .is_some_and(|h| h == "127.0.0.1" || h == "[::1]")),
                    "S3 requires HTTPS outside loopback"
                );
                ensure!(
                    url.username().is_empty()
                        && url.password().is_none()
                        && url.query().is_none()
                        && url.fragment().is_none(),
                    "invalid S3 endpoint"
                );
                Operator::new(
                    services::S3::default()
                        .root(&self.root)
                        .bucket(self.get("bucket"))
                        .endpoint(self.get("endpoint"))
                        .region(self.get("region"))
                        .access_key_id(self.get("access_key_id"))
                        .secret_access_key(self.get("secret_access_key")),
                )?
            }
            "fs" => Operator::new(services::Fs::default().root(self.get("local_root")))?,
            _ => bail!("provider is not implemented by this Rust core"),
        };
        if matches!(self.provider.as_str(), "drive" | "onedrive") {
            let transport = opendal::HttpTransporter::new(provider_http::ProviderTransport {
                inner: op.base_context().http_transport().clone(),
                connection: self.get("connection_id").to_owned(),
                provider: self.provider.clone(),
            });
            let context = op.base_context().with_http_transport(transport);
            Ok(op.with_context(context))
        } else {
            Ok(op)
        }
    }
}

fn runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(4)
            .enable_all()
            .build()
            .expect("Rust core runtime")
    })
}
pub fn call(method: &str, body: Value) -> Result<Value> {
    ensure!(body.is_object(), "core request body must be an object");
    if method == "GetCloudRegistrations" {
        return registration::options().map_err(anyhow::Error::msg);
    }
    if method == "OpenExternalUrl" {
        opener::open(
            body["url"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("URL required"))?,
        )
        .map_err(anyhow::Error::msg)?;
        return Ok(json!({}));
    }
    if method == "GetLoginStartup" {
        return startup::perform(None).map_err(anyhow::Error::msg);
    }
    if method == "SetLoginStartup" {
        return startup::perform(Some(
            body["enabled"]
                .as_bool()
                .ok_or_else(|| anyhow::anyhow!("enabled boolean required"))?,
        ))
        .map_err(anyhow::Error::msg);
    }
    let mut body = body;
    if method == "StartSignIn" {
        registration::fill_defaults(&mut body).map_err(anyhow::Error::msg)?;
    }
    runtime().block_on(async {
        let core = core()?;
        let _operation = state::Operation::begin(core.clone());
        api::dispatch(core, method, body).await
    })
}
fn core() -> Result<Arc<state::Core>> {
    // OS lock refuses a racing second initializer; never open the legacy data root.
    if let Some(c) = CORE.get() {
        return Ok(c.clone());
    }
    static INIT: std::sync::Mutex<()> = std::sync::Mutex::new(());
    let _guard = INIT
        .lock()
        .map_err(|_| anyhow::anyhow!("core initialization lock failed"))?;
    if let Some(c) = CORE.get() {
        return Ok(c.clone());
    }
    let c = Arc::new(state::Core::open()?);
    let _ = rustls::crypto::ring::default_provider().install_default();
    CORE.set(c.clone())
        .map_err(|_| anyhow::anyhow!("core already initialized"))?;
    jobs::start_scheduler(c.clone());
    desk::start(c.clone());
    update::start(c.clone());
    let background = c.clone();
    let reports = c.clone();
    let renewals = c.clone();
    runtime().spawn(async move {
        loop {
            let _ = auth::renew_member(&renewals).await;
            tokio::time::sleep(std::time::Duration::from_secs(60)).await;
        }
    });
    let revocations = c.clone();
    runtime().spawn(async move {
        loop {
            let _ = permissions::flush_revocations(&revocations).await;
            tokio::time::sleep(std::time::Duration::from_secs(5)).await;
        }
    });
    let publications = c.clone();
    runtime().spawn(async move {
        loop {
            let _ = gateway::reconcile(&publications).await;
            tokio::time::sleep(std::time::Duration::from_secs(5)).await;
        }
    });
    runtime().spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(10));
        interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        loop {
            interval.tick().await;
            if authority::report(&reports).await.is_ok() {
                let enrolled = reports
                    .data
                    .read()
                    .await
                    .share_identity
                    .as_ref()
                    .is_some_and(|i| i["state"] == "enrolled");
                if enrolled {
                    let _ = authority::call(
                        &reports,
                        "POST",
                        "/v1/node/presence",
                        Some(json!({"endpoint":""})),
                    )
                    .await;
                }
            }
        }
    });
    let leases = c.leases.clone();
    runtime().spawn(async move {
        loop {
            leases.expire();
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
        }
    });
    runtime().spawn(async move {
        loop {
            if !background
                .update
                .draining
                .load(std::sync::atomic::Ordering::Acquire)
            {
                let drives = background
                    .data
                    .read()
                    .await
                    .drives
                    .values()
                    .filter(|d| d["auto_mount"] == true || d["resume_on_update"] == true)
                    .filter_map(|d| d["id"].as_str().map(str::to_owned))
                    .collect::<Vec<_>>();
                for id in drives {
                    if background
                        .update
                        .draining
                        .load(std::sync::atomic::Ordering::Acquire)
                    {
                        break;
                    }
                    if background.mounts.lock().is_ok_and(|m| m.contains_key(&id)) {
                        continue;
                    }
                    let _operation = state::Operation::begin(background.clone());
                    if let Err(e) = storage::mount(background.clone(), &id).await
                        && let Some(d) = background.data.write().await.drives.get_mut(&id)
                    {
                        d["readiness"] = json!("recovery_required");
                        d["recovery_error"] = json!(e.to_string());
                    }
                }
            }
            tokio::time::sleep(std::time::Duration::from_secs(30)).await;
        }
    });
    Ok(c)
}

pub fn can_exit() -> bool {
    let Some(core) = CORE.get() else {
        return true;
    };
    core.mounts.try_lock().is_ok_and(|m| m.is_empty())
        && core.desk.idle()
        && core.publisher.try_lock().is_ok_and(|p| p.is_none())
        && core.transfers.try_lock().is_ok_and(|j| j.is_empty())
        && core.leases.active() == 0
        && core.operations.load(std::sync::atomic::Ordering::Acquire) == 0
        && core.flows.try_lock().is_ok_and(|flows| flows.is_empty())
}
pub fn update_exit_ready() -> bool {
    CORE.get().is_some_and(|core| update::exit_requested(core)) && can_exit()
}
pub fn capabilities() -> Value {
    json!({"engine":"rust", "version":VERSION, "go":false, "rclone":false,
        "transport":"direct-ffi", "acceptance":"NOT_RUN", "migration":"IMPLEMENTING"})
}
