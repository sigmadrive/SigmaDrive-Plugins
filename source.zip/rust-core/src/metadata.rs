//! A bounded, short-lived display cache. Commit preconditions never use it.
use anyhow::Result;
use opendal::Operator;
use serde::{Deserialize, Serialize};
use std::{
    collections::HashMap,
    sync::{
        Mutex,
        atomic::{AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Default)]
pub struct Meta {
    pub dir: bool,
    pub size: u64,
    pub etag: String,
    pub modified: String,
}
impl Meta {
    pub fn of(m: &opendal::Metadata) -> Self {
        Self {
            dir: m.is_dir(),
            size: m.content_length(),
            etag: m.etag().unwrap_or("").into(),
            modified: m.last_modified().map(|t| t.to_string()).unwrap_or_default(),
        }
    }
}
struct Entry {
    at: Instant,
    value: Option<Meta>,
}
type DirectoryCache = HashMap<String, (Instant, Vec<(String, Meta)>)>;
pub struct Cache {
    entries: Mutex<HashMap<String, Entry>>,
    dirs: Mutex<DirectoryCache>,
    ttl: Duration,
    limit: usize,
    pub hits: AtomicU64,
    pub requests: AtomicU64,
    pub lists: AtomicU64,
}
impl Cache {
    pub fn new(ttl: Duration, limit: usize) -> Self {
        Self {
            entries: Mutex::new(HashMap::new()),
            dirs: Mutex::new(HashMap::new()),
            ttl,
            limit,
            hits: AtomicU64::new(0),
            requests: AtomicU64::new(0),
            lists: AtomicU64::new(0),
        }
    }
    pub fn invalidate(&self, p: &str) {
        self.entries.lock().unwrap().remove(p);
        let parent = p
            .rsplit_once('/')
            .map(|(a, _)| format!("{a}/"))
            .unwrap_or("/".into());
        self.dirs.lock().unwrap().remove(&parent);
    }
    pub fn put(&self, p: &str, value: Option<Meta>) {
        let mut es = self.entries.lock().unwrap();
        if es.len() >= self.limit
            && !es.contains_key(p)
            && let Some(key) = es.iter().min_by_key(|(_, v)| v.at).map(|(k, _)| k.clone())
        {
            es.remove(&key);
        }
        es.insert(
            p.into(),
            Entry {
                at: Instant::now(),
                value,
            },
        );
    }
    pub async fn stat(&self, op: &Operator, p: &str) -> Result<Option<Meta>> {
        {
            let es = self.entries.lock().unwrap();
            if let Some(e) = es.get(p)
                && e.at.elapsed() < self.ttl
            {
                self.hits.fetch_add(1, Ordering::Relaxed);
                return Ok(e.value.clone());
            }
        }
        {
            let parent = p
                .rsplit_once('/')
                .map(|(a, _)| format!("{a}/"))
                .unwrap_or("/".into());
            let dirs = self.dirs.lock().unwrap();
            if let Some((at, entries)) = dirs.get(&parent)
                && at.elapsed() < self.ttl
            {
                self.hits.fetch_add(1, Ordering::Relaxed);
                return Ok(entries
                    .iter()
                    .find(|(n, _)| n.trim_end_matches('/') == p)
                    .map(|(_, m)| m.clone()));
            }
        }
        self.requests.fetch_add(1, Ordering::Relaxed);
        let v = fresh(op, p).await?;
        self.put(p, v.clone());
        Ok(v)
    }
    pub async fn list(&self, op: &Operator, p: &str) -> Result<Vec<(String, Meta)>> {
        {
            let dirs = self.dirs.lock().unwrap();
            if let Some((at, names)) = dirs.get(p)
                && at.elapsed() < self.ttl
            {
                self.hits.fetch_add(1, Ordering::Relaxed);
                return Ok(names.clone());
            }
        }
        self.lists.fetch_add(1, Ordering::Relaxed);
        let v = op
            .list(p)
            .await
            .map_err(|e| anyhow::anyhow!("list {:?}", e.kind()))?
            .into_iter()
            .map(|e| (e.path().to_owned(), Meta::of(e.metadata())))
            .collect::<Vec<_>>();
        let mut dirs = self.dirs.lock().unwrap();
        if dirs.len() >= 128 {
            dirs.clear()
        }
        dirs.insert(p.into(), (Instant::now(), v.clone()));
        Ok(v)
    }
    pub fn metrics(&self) -> serde_json::Value {
        serde_json::json!({"hits":self.hits.load(Ordering::Relaxed),"stat_requests":self.requests.load(Ordering::Relaxed),"list_requests":self.lists.load(Ordering::Relaxed),"entries":self.entries.lock().unwrap().len(),"ttl_ms":self.ttl.as_millis(),"limit":self.limit})
    }
}
pub async fn fresh(op: &Operator, p: &str) -> Result<Option<Meta>> {
    match op.stat(p).await {
        Ok(m) => Ok(Some(Meta::of(&m))),
        Err(e) if e.kind() == opendal::ErrorKind::NotFound => Ok(None),
        Err(e) => anyhow::bail!("metadata {:?}", e.kind()),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bounded_and_invalidated() {
        let c = Cache::new(Duration::from_millis(5), 2);
        c.put("a", None);
        c.put("b", None);
        c.put("c", None);
        assert_eq!(c.entries.lock().unwrap().len(), 2);
        c.invalidate("c");
        assert_eq!(c.entries.lock().unwrap().len(), 1);
    }
}
