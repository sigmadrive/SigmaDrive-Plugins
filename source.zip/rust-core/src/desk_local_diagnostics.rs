//! Explicit local-only, in-memory one-shot diagnostics consent. Never a remote
//! access permission and never a persisted engine/global environment setting.
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use sha2::{Digest,Sha256};
use std::{sync::Mutex,time::{Duration,Instant}};

const MAX_PENDING:Duration=Duration::from_secs(60*60);
const OLD_ENGINE:&str="14ce73097c27869a3f98562e49e936663015abd7629d144244fc17eaff160ae1";
// Root must review and explicitly pin a NEW complete engine manifest in a new
// signed client before this can become available. No RPC/env/version override.
const REVIEWED_NEW_ENGINE_MANIFEST:Option<&str>=Some("d794bddb4dcaba30ab31b4c24beaa41fd739472f6369530cfaad2bbc082e8f1b");

#[derive(Clone,Eq,PartialEq)]
pub(crate) struct ReviewedPin(String);
impl ReviewedPin {
    pub(crate) fn reviewed(value:&str)->Option<Self>{(value!=OLD_ENGINE&&value.len()==64&&value.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))).then(||Self(value.into()))}
    fn matches(&self,value:&str)->bool{self.0==value}
}
pub(crate) fn configured_for_manifest(manifest:&str)->Option<ReviewedPin>{
    REVIEWED_NEW_ENGINE_MANIFEST.and_then(ReviewedPin::reviewed).filter(|pin|pin.matches(manifest))
}
#[derive(Clone,Eq,PartialEq)]
pub(crate) struct Context {digest:[u8;32],generation:u64}
impl Context {
    pub(crate) fn new(parts:&[&str],auth_epoch:u64,generation:u64)->Result<Self>{
        ensure!(!parts.is_empty()&&parts.iter().all(|s|!s.is_empty()&&s.len()<=32768&&!s.chars().any(char::is_control)),"Local diagnostics context unavailable");
        let mut h=Sha256::new();h.update(b"sigmadesk/local-diagnostics-context/v1\0");
        for part in parts {h.update((part.len()as u64).to_le_bytes());h.update(part.as_bytes());}
        h.update(auth_epoch.to_le_bytes());h.update(generation.to_le_bytes());Ok(Self{digest:h.finalize().into(),generation})
    }
}
#[derive(Default)]
enum State {#[default]Off,Armed{context:Context,pin:ReviewedPin,until:Instant},Consumed,Expired}
#[derive(Default)]
// reason: 0 normal, 1 local cancel, 2 expiry, 3 context mismatch, 4 boundary clear.
struct Inner {generation:u64,state:State,reason:u8}
#[derive(Default)]
pub(crate) struct Controller(Mutex<Inner>);
impl Controller {
    // Consent has its own boundary, independent of session/history maintenance.
    // The generation, state and reason share one lock: a late arm cannot undo
    // an explicit clear/cancel and the externally visible reason cannot race it.
    pub(crate) fn generation(&self)->Result<u64>{
        let s=self.0.lock().map_err(|_|anyhow::anyhow!("Local diagnostics state unavailable"))?;
        ensure!(s.generation<u64::MAX,"Local diagnostics boundary exhausted");Ok(s.generation)
    }
    pub(crate) fn is_generation(&self,generation:u64)->Result<bool>{Ok(self.generation()?==generation)}
    pub(crate) fn arm(&self,context:Context,pin:Option<ReviewedPin>,now:Instant,ttl:Duration)->Result<()> {
        let pin=pin.ok_or_else(||anyhow::anyhow!("검토된 새 진단 엔진이 아직 준비되지 않았습니다."))?;
        ensure!(!ttl.is_zero()&&ttl<=MAX_PENDING,"Local diagnostics expiry bound");
        let until=now.checked_add(ttl).ok_or_else(||anyhow::anyhow!("Local diagnostics expiry overflow"))?;
        let mut s=self.0.lock().map_err(|_|anyhow::anyhow!("Local diagnostics state unavailable"))?;
        Self::expire(&mut s,now);
        ensure!(s.generation<u64::MAX&&context.generation==s.generation,"Local diagnostics context changed");
        ensure!(!matches!(s.state,State::Armed{..}),"다음 접속 1회 진단이 이미 대기 중입니다.");
        s.state=State::Armed{context,pin,until};s.reason=0;Ok(())
    }
    fn expire(s:&mut Inner,now:Instant){if matches!(s.state,State::Armed{until,..}if until<=now){s.state=State::Expired;s.reason=2;}}
    fn invalidate(s:&mut Inner,reason:u8){s.generation=s.generation.saturating_add(1);s.state=State::Off;s.reason=reason;}
    pub(crate) fn cancel_pending(&self)->Result<()> {
        let mut s=self.0.lock().map_err(|_|anyhow::anyhow!("Local diagnostics state unavailable"))?;
        ensure!(!matches!(s.state,State::Consumed),"진단은 이미 이번 접속에 사용됐습니다. 접속을 종료하면 자동으로 멈춥니다.");
        Self::invalidate(&mut s,1);Ok(())
    }
    pub(crate) fn clear(&self){if let Ok(mut s)=self.0.lock(){Self::invalidate(&mut s,4);}}
    /// Call only after existing signed assignment + complete asset verification
    /// and context/startup cancellation checks. The caller supplies an exact
    /// reviewed manifest, not a display version or unverified file name.
    pub(crate) fn consume(&self,context:&Context,pin:Option<ReviewedPin>,verified_manifest:&str,namespace:&str,now:Instant)->Result<bool>{
        let mut s=self.0.lock().map_err(|_|anyhow::anyhow!("Local diagnostics state unavailable"))?;Self::expire(&mut s,now);
        let State::Armed{context:expected,pin:armed_pin,..}=&s.state else{return Ok(false)};
        if expected!=context||context.generation!=s.generation {Self::invalidate(&mut s,3);return Ok(false);}
        if pin.as_ref()!=Some(armed_pin)||!armed_pin.matches(verified_manifest)||namespace.len()!=64||!namespace.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b)){return Ok(false);}
        s.state=State::Consumed;s.reason=0;Ok(true)
    }
    pub(crate) fn snapshot(&self,now:Instant,pin_ready:bool)->Value {
        let Ok(mut s)=self.0.lock()else{return json!({"schema":1,"state_code":4,"remaining_ms":0,"pin_ready":0,"reason_code":0})};Self::expire(&mut s,now);
        let (state,remaining)=match &s.state{State::Off=>(0,0),State::Armed{until,..}=>(1,until.saturating_duration_since(now).as_millis().min(MAX_PENDING.as_millis())as u64),State::Consumed=>(2,0),State::Expired=>(3,0)};
        json!({"schema":1,"state_code":state,"remaining_ms":remaining,"pin_ready":u8::from(pin_ready),"reason_code":s.reason})
    }
}

#[cfg(test)]
mod tests {
    use super::*;use std::sync::{Arc,Barrier};
    const NEW:&str="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    const NS:&str="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    #[test]fn signed_release_pin_matches_the_complete_embedded_new_engine_manifest(){
        let expected=hex::encode(Sha256::digest(include_str!("../public/sigmadesk-files.json").as_bytes()));
        assert_eq!(REVIEWED_NEW_ENGINE_MANIFEST,Some(expected.as_str()));
        assert!(configured_for_manifest(&expected).is_some());
        assert!(configured_for_manifest(OLD_ENGINE).is_none());
    }
    fn context_at(generation:u64)->Context{Context::new(&["sid","desktop","node","member","pin","profile","root","manifest"],1,generation).unwrap()}
    fn context()->Context{context_at(0)}
    fn pin()->Option<ReviewedPin>{ReviewedPin::reviewed(NEW)}
    #[test]fn default_off_and_unpinned_old_engine_cannot_arm(){let c=Controller::default();let now=Instant::now();assert_eq!(c.snapshot(now,false),json!({"schema":1,"state_code":0,"remaining_ms":0,"pin_ready":0,"reason_code":0}));assert!(configured_for_manifest(OLD_ENGINE).is_none());assert!(configured_for_manifest(NEW).is_none());assert!(c.arm(context(),None,now,MAX_PENDING).is_err());assert!(!c.consume(&context(),pin(),NEW,NS,now).unwrap());}
    #[test]fn reviewed_pin_is_exact_new_lowercase_manifest_not_version(){for p in [OLD_ENGINE,"0.3.3-rust","",NS.trim_end_matches('a'),"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"]{assert!(ReviewedPin::reviewed(p).is_none());}assert!(pin().is_some());}
    #[test]fn pending_expiry_is_monotonic_and_at_most60min(){let now=Instant::now();let c=Controller::default();assert!(c.arm(context(),pin(),now,Duration::ZERO).is_err());assert!(c.arm(context(),pin(),now,MAX_PENDING+Duration::from_nanos(1)).is_err());c.arm(context(),pin(),now,MAX_PENDING).unwrap();assert_eq!(c.snapshot(now,true)["remaining_ms"],3_600_000);assert!(!c.consume(&context(),pin(),NEW,NS,now+MAX_PENDING).unwrap());assert_eq!(c.snapshot(now+MAX_PENDING,true)["state_code"],3);}
    #[test]fn verified_exact_context_consumes_once(){let now=Instant::now();let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();assert!(c.consume(&context(),pin(),NEW,NS,now).unwrap());assert!(!c.consume(&context(),pin(),NEW,NS,now).unwrap());assert_eq!(c.snapshot(now,true)["state_code"],2);assert!(c.cancel_pending().is_err());}
    #[test]fn concurrent_startups_only_one_can_consume(){let c=Arc::new(Controller::default());let now=Instant::now();c.arm(context(),pin(),now,MAX_PENDING).unwrap();let start=Arc::new(Barrier::new(9));let workers=(0..8).map(|_|{let c=c.clone();let start=start.clone();std::thread::spawn(move||{start.wait();c.consume(&context(),pin(),NEW,NS,now).unwrap()})}).collect::<Vec<_>>();start.wait();assert_eq!(workers.into_iter().map(|w|w.join().unwrap()).filter(|won|*won).count(),1);}
    #[test]fn cancel_before_consume_and_boundary_clear_prevent_enable(){let now=Instant::now();let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();c.cancel_pending().unwrap();assert!(!c.consume(&context(),pin(),NEW,NS,now).unwrap());let next=context_at(c.generation().unwrap());c.arm(next.clone(),pin(),now,MAX_PENDING).unwrap();c.clear();assert!(!c.consume(&next,pin(),NEW,NS,now).unwrap());}
    #[test]fn profile_identity_desktop_or_epoch_change_clears_pending(){let now=Instant::now();for i in 0..8{let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();let mut parts=["sid","desktop","node","member","pin","profile","root","manifest"];parts[i]="changed";let other=Context::new(&parts,1,0).unwrap();assert!(!c.consume(&other,pin(),NEW,NS,now).unwrap());assert_eq!(c.snapshot(now,true)["state_code"],0);assert_eq!(c.snapshot(now,true)["reason_code"],3);}for(other_auth,other_epoch)in [(2,0),(1,1)]{let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();let other=Context::new(&["sid","desktop","node","member","pin","profile","root","manifest"],other_auth,other_epoch).unwrap();assert!(!c.consume(&other,pin(),NEW,NS,now).unwrap());assert_eq!(c.snapshot(now,true)["reason_code"],3);}}
    #[test]fn unknown_pin_and_invalid_namespace_never_consume(){let now=Instant::now();let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();for m in [OLD_ENGINE,"unknown",NEW]{let ns=if m==NEW{"invalid"}else{NS};assert!(!c.consume(&context(),pin(),m,ns,now).unwrap());}assert_eq!(c.snapshot(now,true)["state_code"],1);assert!(c.consume(&context(),pin(),NEW,NS,now).unwrap());}
    #[test]fn arm_pin_is_bound_even_if_a_different_reviewed_gate_is_supplied_later(){let now=Instant::now();let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();let other="cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";assert!(!c.consume(&context(),ReviewedPin::reviewed(other),other,NS,now).unwrap());assert!(c.consume(&context(),pin(),NEW,NS,now).unwrap());}
    #[test]fn snapshot_is_numeric_fixed_schema_without_context_or_pin(){let now=Instant::now();let c=Controller::default();c.arm(context(),pin(),now,MAX_PENDING).unwrap();let s=c.snapshot(now,true);assert_eq!(s.as_object().unwrap().len(),5);assert!(s.as_object().unwrap().values().all(Value::is_u64));for word in ["sid","node","member","profile","namespace",NEW,NS]{assert!(!s.to_string().contains(word));}}
    #[test]fn reasons_distinguish_cancel_expiry_and_explicit_boundary_without_claiming_engine_output(){
        let c=Controller::default();let now=Instant::now();c.arm(context(),pin(),now,MAX_PENDING).unwrap();
        c.cancel_pending().unwrap();assert_eq!(c.snapshot(now,true)["reason_code"],1);
        let next=context_at(c.generation().unwrap());c.arm(next,pin(),now,MAX_PENDING).unwrap();
        let expired=c.snapshot(now+MAX_PENDING,true);assert_eq!(expired["state_code"],3);assert_eq!(expired["reason_code"],2);assert_eq!(expired["remaining_ms"],0);
        c.clear();let clear=c.snapshot(now,true);assert_eq!(clear["state_code"],0);assert_eq!(clear["reason_code"],4);assert_eq!(clear["remaining_ms"],0);
        let next=context_at(c.generation().unwrap());c.arm(next.clone(),pin(),now,MAX_PENDING).unwrap();
        assert!(c.consume(&next,pin(),NEW,NS,now).unwrap());assert_eq!(c.snapshot(now,true)["reason_code"],0);
    }
    #[test]fn explicit_clear_wins_against_an_arm_already_resolving_its_context(){
        for cancel in [false,true]{
            let c=Arc::new(Controller::default());let now=Instant::now();let old=context_at(c.generation().unwrap());
            let ready=Arc::new(Barrier::new(2));let resume=Arc::new(Barrier::new(2));
            let late={let c=c.clone();let ready=ready.clone();let resume=resume.clone();std::thread::spawn(move||{ready.wait();resume.wait();c.arm(old,pin(),now,MAX_PENDING)})};
            ready.wait();if cancel{c.cancel_pending().unwrap();}else{c.clear();}resume.wait();
            assert!(late.join().unwrap().is_err());let s=c.snapshot(now,true);assert_eq!(s["state_code"],0);assert_eq!(s["reason_code"],if cancel{1}else{4});
        }
    }
    #[test]fn late_old_consume_cannot_replace_a_clear_reason_or_consume_a_new_boundary_grant(){
        let c=Controller::default();let now=Instant::now();let old=context();c.arm(old.clone(),pin(),now,MAX_PENDING).unwrap();c.clear();
        assert!(!c.consume(&old,pin(),NEW,NS,now).unwrap());assert_eq!(c.snapshot(now,true)["reason_code"],4);
        let fresh=context_at(c.generation().unwrap());c.arm(fresh.clone(),pin(),now,MAX_PENDING).unwrap();
        assert!(!c.consume(&old,pin(),NEW,NS,now).unwrap());assert_eq!(c.snapshot(now,true)["reason_code"],3);
        assert!(!c.consume(&fresh,pin(),NEW,NS,now).unwrap());
    }
    #[test]fn generation_never_wraps_and_exhaustion_cannot_rearm(){
        let c=Controller::default();let now=Instant::now();c.0.lock().unwrap().generation=u64::MAX-1;
        c.clear();assert!(c.generation().is_err());assert!(c.arm(context_at(u64::MAX),pin(),now,MAX_PENDING).is_err());
        c.clear();assert_eq!(c.0.lock().unwrap().generation,u64::MAX);assert_eq!(c.snapshot(now,true)["reason_code"],4);
    }
    #[test]fn poisoned_controller_exposes_only_unavailable_numeric_snapshot_and_never_consumes(){
        let c=Arc::new(Controller::default());let worker=c.clone();let _=std::thread::spawn(move||{let _held=worker.0.lock().unwrap();panic!("fixture poison");}).join();
        assert!(c.generation().is_err());assert!(c.consume(&context(),pin(),NEW,NS,Instant::now()).is_err());
        assert_eq!(c.snapshot(Instant::now(),true),json!({"schema":1,"state_code":4,"remaining_ms":0,"pin_ready":0,"reason_code":0}));
    }
}
