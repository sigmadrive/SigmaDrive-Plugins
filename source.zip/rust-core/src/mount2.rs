//! Native cache namespace. Office backup/temp renames are held locally until CAS.
use crate::{Config, engine::checked, safe, v2::Engine};
use anyhow::{Result, ensure};
use dokan::*;
use std::{
    collections::HashMap,
    fs::{self, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    sync::{
        Arc, Mutex, RwLock, Weak,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    },
    time::{Duration, SystemTime},
};
use widestring::{U16CStr, U16CString};
use winapi::{shared::ntstatus::*, um::winnt};
struct Node {
    engine: Arc<Engine>,
    path: RwLock<String>,
    writers: AtomicUsize,
    dirty: AtomicBool,
    deleted: AtomicBool,
    write_failed: AtomicBool,
}
pub struct Ctx {
    owner: Option<Arc<crate::state::Core>>,
    node: Arc<Node>,
    dir: bool,
    writer: bool,
}
impl Drop for Ctx {
    fn drop(&mut self) {
        if let Some(c) = &self.owner {
            c.mount_handles.fetch_sub(1, Ordering::AcqRel);
        }
    }
}
struct Fs {
    e: Arc<Engine>,
    children: Vec<(String, Arc<Engine>)>,
    rt: tokio::runtime::Handle,
    nodes: Mutex<HashMap<String, Weak<Node>>>,
}
fn err(e: impl std::fmt::Display) -> i32 {
    let s = e.to_string();
    if s.contains("not found") {
        STATUS_OBJECT_NAME_NOT_FOUND
    } else {
        eprintln!("PoC V2 local operation failed");
        STATUS_IO_DEVICE_ERROR
    }
}
impl Fs {
    fn route(&self, path: &str) -> OperationResult<(Arc<Engine>, String)> {
        if self.children.is_empty() || path.is_empty() {
            return Ok((self.e.clone(), path.to_owned()));
        }
        let (head, tail) = path.split_once('/').unwrap_or((path, ""));
        self.children
            .iter()
            .find(|(name, _)| name.eq_ignore_ascii_case(head))
            .map(|(_, e)| (e.clone(), tail.to_owned()))
            .ok_or(STATUS_OBJECT_NAME_NOT_FOUND)
    }
    fn key(engine: &Engine, p: &str) -> String {
        format!("{}:{p}", engine.cfg.work.display())
    }
    fn info(&self, e: &Engine, p: &str) -> OperationResult<(bool, u64)> {
        if e.hidden.lock().unwrap().contains(p) {
            return Err(STATUS_OBJECT_NAME_NOT_FOUND);
        }
        if let Ok(m) = fs::metadata(e.local(p).map_err(err)?) {
            return Ok((m.is_dir(), m.len()));
        }
        if p.is_empty() {
            return Ok((true, 0));
        }
        if safe::transient(p) {
            return Err(STATUS_OBJECT_NAME_NOT_FOUND);
        }
        match self.rt.block_on(e.cache.stat(&e.op, p)).map_err(err)? {
            Some(m) => Ok((m.dir, m.size)),
            None => Err(STATUS_OBJECT_NAME_NOT_FOUND),
        }
    }
    fn node(&self, e: &Arc<Engine>, p: &str) -> Arc<Node> {
        let mut nodes = self.nodes.lock().unwrap();
        let key = Self::key(e, p);
        if let Some(n) = nodes.get(&key).and_then(Weak::upgrade) {
            return n;
        }
        let n = Arc::new(Node {
            engine: e.clone(),
            path: RwLock::new(p.into()),
            writers: AtomicUsize::new(0),
            dirty: AtomicBool::new(false),
            deleted: AtomicBool::new(false),
            write_failed: AtomicBool::new(false),
        });
        nodes.insert(key, Arc::downgrade(&n));
        n
    }
    fn finalize(&self, n: &Node) -> Result<()> {
        if n.write_failed.load(Ordering::SeqCst) && !n.deleted.load(Ordering::SeqCst) {
            return n.engine.mark(&n.path.read().unwrap(), false);
        }
        if n.dirty.load(Ordering::SeqCst) && !n.deleted.load(Ordering::SeqCst) {
            let p = n.path.read().unwrap().clone();
            OpenOptions::new()
                .write(true)
                .open(n.engine.local(&p)?)?
                .sync_all()?;
            n.engine.mark(&p, true)?;
        } else if !n.deleted.load(Ordering::SeqCst) {
            n.engine.close_unchanged(&n.path.read().unwrap())?;
        }
        Ok(())
    }
}
impl<'c, 'h: 'c> FileSystemHandler<'c, 'h> for Fs {
    type Context = Ctx;
    fn create_file(
        &'h self,
        name: &U16CStr,
        _: &IO_SECURITY_CONTEXT,
        access: u32,
        _: u32,
        _: u32,
        disp: u32,
        options: u32,
        _: &mut OperationInfo<'c, 'h, Self>,
    ) -> OperationResult<CreateFileInfo<Ctx>> {
        let owner = crate::CORE.get().cloned();
        let _admission = owner
            .as_ref()
            .map(|c| c.mount_admission.lock().map_err(|_| STATUS_DEVICE_BUSY))
            .transpose()?;
        if owner
            .as_ref()
            .is_some_and(|c| c.update.draining.load(Ordering::Acquire))
        {
            return Err(STATUS_DEVICE_BUSY);
        }
        let full = checked(&name.to_string_lossy()).map_err(|_| STATUS_OBJECT_NAME_INVALID)?;
        let (e, p) = self.route(&full)?;
        let _g = e.lock.lock().unwrap();
        let m = self.info(&e, &p);
        let exists = m.is_ok();
        if let Err(e) = m
            && e != STATUS_OBJECT_NAME_NOT_FOUND
        {
            return Err(e);
        }
        if !exists && !matches!(disp, 0 | 2 | 3 | 5) {
            return Err(STATUS_OBJECT_NAME_NOT_FOUND);
        }
        if exists && disp == 2 {
            return Err(STATUS_OBJECT_NAME_COLLISION);
        }
        let dir = if exists {
            m.unwrap().0
        } else {
            options & 1 != 0
        };
        if dir && options & 0x40 != 0 {
            return Err(STATUS_FILE_IS_A_DIRECTORY);
        }
        if !dir && options & 1 != 0 {
            return Err(STATUS_NOT_A_DIRECTORY);
        }
        let writer = !dir
            && (access & (winnt::GENERIC_WRITE | winnt::FILE_WRITE_DATA | winnt::FILE_APPEND_DATA)
                != 0
                || !exists
                || matches!(disp, 0 | 4 | 5));
        if e.cfg.get("read_only") == "true"
            && (writer || !exists || matches!(disp, 0 | 4 | 5) || access & winnt::DELETE != 0)
        {
            return Err(STATUS_ACCESS_DENIED);
        }
        let local = e.local(&p).map_err(err)?;
        let n = self.node(&e, &p);
        let mut dirty = false;
        if !exists {
            if dir {
                self.rt
                    .block_on(e.op.create_dir(&format!("{p}/")))
                    .map_err(err)?;
                fs::create_dir_all(&local).map_err(err)?
            } else {
                e.remember(&p, None).map_err(err)?;
                e.mark(&p, false).map_err(err)?;
                if let Some(parent) = local.parent() {
                    fs::create_dir_all(parent).map_err(err)?
                }
                OpenOptions::new()
                    .create_new(true)
                    .write(true)
                    .open(&local)
                    .map_err(err)?
                    .sync_all()
                    .map_err(err)?;
                dirty = true
            }
            e.hide(&p, false).map_err(err)?;
        } else if !dir {
            self.rt.block_on(e.hydrate(&p)).map_err(err)?;
            if matches!(disp, 0 | 4 | 5) {
                if fs::metadata(&local).map_err(err)?.permissions().readonly() {
                    return Err(STATUS_ACCESS_DENIED);
                }
                OpenOptions::new()
                    .write(true)
                    .open(&local)
                    .map_err(err)?
                    .set_len(0)
                    .map_err(err)?;
                dirty = true
            }
            if writer && n.writers.load(Ordering::SeqCst) == 0 {
                e.mark(&p, false).map_err(err)?;
            }
        }
        if writer {
            if n.writers.load(Ordering::SeqCst) == 0 {
                n.write_failed.store(false, Ordering::SeqCst);
                n.dirty.store(false, Ordering::SeqCst);
            }
            n.writers.fetch_add(1, Ordering::SeqCst);
        }
        if dirty {
            n.dirty.store(true, Ordering::SeqCst);
        }
        if let Some(c) = &owner {
            c.mount_handles.fetch_add(1, Ordering::AcqRel);
        }
        drop(_admission);
        Ok(CreateFileInfo {
            context: Ctx {
                owner,
                node: n,
                dir,
                writer,
            },
            is_dir: dir,
            new_file_created: !exists,
        })
    }
    fn cleanup(&'h self, _: &U16CStr, info: &OperationInfo<'c, 'h, Self>, c: &'c Ctx) {
        if info.delete_on_close() {
            let _g = c.node.engine.lock.lock().unwrap();
            let p = c.node.path.read().unwrap().clone();
            if let Ok(local) = c.node.engine.local(&p)
                && !c.dir
            {
                let _ = fs::remove_file(local);
                let _ = c.node.engine.hide(&p, true);
                let j = c.node.engine.journal(&p);
                if j.exists() {
                    let _ = fs::remove_file(j);
                }
                c.node.deleted.store(true, Ordering::SeqCst);
            }
        }
    }
    fn close_file(&'h self, _: &U16CStr, _: &OperationInfo<'c, 'h, Self>, c: &'c Ctx) {
        if c.writer {
            let _g = c.node.engine.lock.lock().unwrap();
            if c.node.writers.fetch_sub(1, Ordering::SeqCst) == 1 && self.finalize(&c.node).is_err()
            {
                eprintln!("PoC V2 incomplete close held")
            }
        }
    }
    fn read_file(
        &'h self,
        _: &U16CStr,
        offset: i64,
        b: &mut [u8],
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<u32> {
        if offset < 0 {
            return Err(STATUS_INVALID_PARAMETER);
        }
        let p = c.node.path.read().unwrap().clone();
        let mut f = OpenOptions::new()
            .read(true)
            .open(c.node.engine.local(&p).map_err(err)?)
            .map_err(err)?;
        f.seek(SeekFrom::Start(offset as u64)).map_err(err)?;
        Ok(f.read(b).map_err(err)? as u32)
    }
    fn write_file(
        &'h self,
        _: &U16CStr,
        offset: i64,
        b: &[u8],
        info: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<u32> {
        let append = info.write_to_eof() || offset == -1;
        if (offset < 0 && !append) || !c.writer {
            return Err(STATUS_ACCESS_DENIED);
        }
        let _g = c.node.engine.lock.lock().unwrap();
        let p = c.node.path.read().unwrap().clone();
        let limit = c
            .node
            .engine
            .cfg
            .get("cache_file_quota_bytes")
            .parse::<u64>()
            .unwrap_or(u64::MAX);
        let local_meta = fs::metadata(c.node.engine.local(&p).map_err(err)?).map_err(err)?;
        if local_meta.permissions().readonly() {
            return Err(STATUS_ACCESS_DENIED);
        }
        let current = local_meta.len();
        let end = if append {
            current.saturating_add(b.len() as u64)
        } else {
            (offset as u64).saturating_add(b.len() as u64)
        };
        if end > limit {
            c.node.write_failed.store(true, Ordering::SeqCst);
            return Err(STATUS_DISK_FULL);
        }
        let mut f = OpenOptions::new()
            .write(true)
            .open(c.node.engine.local(&p).map_err(err)?)
            .map_err(err)?;
        if append {
            f.seek(SeekFrom::End(0)).map_err(err)?;
        } else {
            f.seek(SeekFrom::Start(offset as u64)).map_err(err)?;
        }
        if let Err(e) = f.write_all(b) {
            c.node.write_failed.store(true, Ordering::SeqCst);
            return Err(err(e));
        }
        c.node.dirty.store(true, Ordering::SeqCst);
        Ok(b.len() as u32)
    }
    fn flush_file_buffers(
        &'h self,
        _: &U16CStr,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        if !c.dir && c.writer {
            OpenOptions::new()
                .write(true)
                .open(
                    c.node
                        .engine
                        .local(&c.node.path.read().unwrap())
                        .map_err(err)?,
                )
                .map_err(err)?
                .sync_all()
                .map_err(err)?;
        }
        Ok(())
    }
    fn get_file_information(
        &'h self,
        _: &U16CStr,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<FileInfo> {
        let p = c.node.path.read().unwrap().clone();
        let (d, s) = self.info(&c.node.engine, &p)?;
        let local = c.node.engine.local(&p).map_err(err)?;
        let m = fs::metadata(local).ok();
        let now = SystemTime::now();
        Ok(FileInfo {
            attributes: if m.as_ref().is_some_and(|m| m.permissions().readonly()) && !d {
                winnt::FILE_ATTRIBUTE_READONLY
            } else if d {
                winnt::FILE_ATTRIBUTE_DIRECTORY
            } else {
                winnt::FILE_ATTRIBUTE_NORMAL
            },
            creation_time: m.as_ref().and_then(|m| m.created().ok()).unwrap_or(now),
            last_access_time: m.as_ref().and_then(|m| m.accessed().ok()).unwrap_or(now),
            last_write_time: m.as_ref().and_then(|m| m.modified().ok()).unwrap_or(now),
            file_size: if d { 0 } else { s },
            number_of_links: 1,
            file_index: u64::from_str_radix(
                &crate::engine::hash(
                    format!(
                        "{}:{}:{p}",
                        c.node.engine.cfg.get("connection_id"),
                        c.node.engine.cfg.root
                    )
                    .as_bytes(),
                )[..16],
                16,
            )
            .unwrap(),
        })
    }
    fn find_files(
        &'h self,
        _: &U16CStr,
        mut fill: impl FnMut(&FindData) -> FillDataResult,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        if !self.children.is_empty() && Arc::ptr_eq(&c.node.engine, &self.e) {
            for (name, _) in &self.children {
                let now = SystemTime::now();
                fill(&FindData {
                    attributes: winnt::FILE_ATTRIBUTE_DIRECTORY,
                    creation_time: now,
                    last_access_time: now,
                    last_write_time: now,
                    file_size: 0,
                    file_name: U16CString::from_str(name).map_err(err)?,
                })
                .map_err(err)?;
            }
            return Ok(());
        }
        let p = c.node.path.read().unwrap().clone();
        let dir = if p.is_empty() {
            "/".into()
        } else {
            format!("{p}/")
        };
        let mut names = std::collections::BTreeMap::new();
        if !c.node.engine.cfg.work.join("offline").exists() {
            for (n, m) in self
                .rt
                .block_on(c.node.engine.cache.list(&c.node.engine.op, &dir))
                .map_err(err)?
            {
                if !c
                    .node
                    .engine
                    .hidden
                    .lock()
                    .unwrap()
                    .contains(n.trim_end_matches('/'))
                {
                    names.insert(
                        n.trim_end_matches('/')
                            .rsplit('/')
                            .next()
                            .unwrap()
                            .to_owned(),
                        (m.dir, m.size),
                    );
                }
            }
        }
        let local = c.node.engine.local(&p).map_err(err)?;
        fs::create_dir_all(&local).map_err(err)?;
        for e in fs::read_dir(local).map_err(err)? {
            let e = e.map_err(err)?;
            let m = e.metadata().map_err(err)?;
            names.insert(
                e.file_name().to_string_lossy().to_string(),
                (m.is_dir(), m.len()),
            );
        }
        for (n, (d, s)) in names {
            let now = SystemTime::now();
            fill(&FindData {
                attributes: if d {
                    winnt::FILE_ATTRIBUTE_DIRECTORY
                } else {
                    winnt::FILE_ATTRIBUTE_NORMAL
                },
                creation_time: now,
                last_access_time: now,
                last_write_time: now,
                file_size: if d { 0 } else { s },
                file_name: U16CString::from_str(n).map_err(err)?,
            })
            .map_err(err)?
        }
        Ok(())
    }
    fn move_file(
        &'h self,
        _: &U16CStr,
        new: &U16CStr,
        replace: bool,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        let full = checked(&new.to_string_lossy()).map_err(err)?;
        let (target_engine, to) = self.route(&full)?;
        if !Arc::ptr_eq(&target_engine, &c.node.engine)
            || to.is_empty()
            || c.node.engine.cfg.get("read_only") == "true"
        {
            return Err(STATUS_NOT_SAME_DEVICE);
        }
        let _g = c.node.engine.lock.lock().unwrap();
        let from = c.node.path.read().unwrap().clone();
        if self.info(&c.node.engine, &to).is_ok() && !replace {
            return Err(STATUS_OBJECT_NAME_COLLISION);
        }
        if !safe::transient(&from) && !safe::transient(&to) {
            return Err(STATUS_NOT_SUPPORTED);
        }
        let src = c.node.engine.local(&from).map_err(err)?;
        let dst = c.node.engine.local(&to).map_err(err)?;
        if let Some(d) = dst.parent() {
            fs::create_dir_all(d).map_err(err)?
        }
        if !safe::transient(&to) && !c.node.engine.cfg.work.join("bases").exists() {
            return Err(STATUS_IO_DEVICE_ERROR);
        }
        fs::rename(src, dst).map_err(err)?;
        let old = c.node.engine.journal(&from);
        if old.exists() {
            fs::remove_file(old).map_err(err)?
        }
        c.node.engine.hide(&from, true).map_err(err)?;
        c.node.engine.hide(&to, false).map_err(err)?;
        *c.node.path.write().unwrap() = to.clone();
        c.node.dirty.store(true, Ordering::SeqCst);
        let mut nodes = self.nodes.lock().unwrap();
        nodes.remove(&Self::key(&c.node.engine, &from));
        nodes.insert(Self::key(&c.node.engine, &to), Arc::downgrade(&c.node));
        drop(nodes);
        if c.node.writers.load(Ordering::SeqCst) == 0 {
            c.node.engine.mark(&to, true).map_err(err)?
        } else {
            c.node.engine.mark(&to, false).map_err(err)?
        }
        Ok(())
    }
    fn delete_file(
        &'h self,
        _: &U16CStr,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        if c.node.engine.cfg.get("read_only") == "true" {
            return Err(STATUS_ACCESS_DENIED);
        }
        let p = c.node.path.read().unwrap().clone();
        let j = c.node.engine.journal(&p);
        if j.exists() {
            let r: crate::v2::Record =
                serde_json::from_slice(&fs::read(j).map_err(err)?).map_err(err)?;
            if !r.ready && r.base.is_some() {
                return Err(STATUS_CANNOT_DELETE);
            }
        }
        if c.node.engine.base(&p).map_err(err)?.is_some() {
            return Err(STATUS_NOT_SUPPORTED);
        }
        Ok(())
    }
    fn set_end_of_file(
        &'h self,
        _: &U16CStr,
        len: i64,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        if len < 0 || !c.writer {
            return Err(STATUS_ACCESS_DENIED);
        }
        let p = c.node.path.read().unwrap().clone();
        if len as u64
            > c.node
                .engine
                .cfg
                .get("cache_file_quota_bytes")
                .parse::<u64>()
                .unwrap_or(u64::MAX)
        {
            c.node.write_failed.store(true, Ordering::SeqCst);
            return Err(STATUS_DISK_FULL);
        }
        if fs::metadata(c.node.engine.local(&p).map_err(err)?)
            .map_err(err)?
            .permissions()
            .readonly()
        {
            return Err(STATUS_ACCESS_DENIED);
        }
        OpenOptions::new()
            .write(true)
            .open(c.node.engine.local(&p).map_err(err)?)
            .map_err(err)?
            .set_len(len as u64)
            .map_err(err)?;
        c.node.dirty.store(true, Ordering::SeqCst);
        Ok(())
    }
    fn set_allocation_size(
        &'h self,
        _: &U16CStr,
        len: i64,
        _: &OperationInfo<'c, 'h, Self>,
        _: &'c Ctx,
    ) -> OperationResult<()> {
        if len < 0 {
            Err(STATUS_INVALID_PARAMETER)
        } else {
            Ok(())
        }
    }
    fn set_file_attributes(
        &'h self,
        _: &U16CStr,
        a: u32,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        if c.node.engine.cfg.get("read_only") == "true" {
            return Err(STATUS_ACCESS_DENIED);
        }
        let p = c
            .node
            .engine
            .local(&c.node.path.read().unwrap())
            .map_err(err)?;
        let w = U16CString::from_os_str(p).map_err(err)?;
        if unsafe { winapi::um::fileapi::SetFileAttributesW(w.as_ptr(), a) } == 0 {
            Err(STATUS_IO_DEVICE_ERROR)
        } else {
            Ok(())
        }
    }
    fn set_file_time(
        &'h self,
        _: &U16CStr,
        _: FileTimeOperation,
        access: FileTimeOperation,
        write: FileTimeOperation,
        _: &OperationInfo<'c, 'h, Self>,
        c: &'c Ctx,
    ) -> OperationResult<()> {
        if c.node.engine.cfg.get("read_only") == "true" {
            return Err(STATUS_ACCESS_DENIED);
        }
        use std::os::windows::fs::OpenOptionsExt;
        let mut times = fs::FileTimes::new();
        if let FileTimeOperation::SetTime(t) = access {
            times = times.set_accessed(t)
        }
        if let FileTimeOperation::SetTime(t) = write {
            times = times.set_modified(t)
        }
        OpenOptions::new()
            .read(true)
            .access_mode(winnt::FILE_WRITE_ATTRIBUTES)
            .open(
                c.node
                    .engine
                    .local(&c.node.path.read().unwrap())
                    .map_err(err)?,
            )
            .map_err(err)?
            .set_times(times)
            .map_err(err)?;
        Ok(())
    }
    fn get_disk_free_space(
        &'h self,
        _: &OperationInfo<'c, 'h, Self>,
    ) -> OperationResult<DiskSpaceInfo> {
        let w = U16CString::from_os_str(&self.e.cfg.work).map_err(err)?;
        let (mut a, mut t, mut f) = (0u64, 0u64, 0u64);
        if unsafe {
            winapi::um::fileapi::GetDiskFreeSpaceExW(
                w.as_ptr(),
                &mut a as *mut _ as _,
                &mut t as *mut _ as _,
                &mut f as *mut _ as _,
            )
        } == 0
        {
            return Err(STATUS_IO_DEVICE_ERROR);
        }
        Ok(DiskSpaceInfo {
            byte_count: t,
            free_byte_count: f,
            available_byte_count: a,
        })
    }
    fn get_volume_information(
        &'h self,
        _: &OperationInfo<'c, 'h, Self>,
    ) -> OperationResult<VolumeInfo> {
        Ok(VolumeInfo {
            name: U16CString::from_str("SigmaDrive").unwrap(),
            serial_number: 0x53445632,
            max_component_length: 255,
            fs_flags: winnt::FILE_CASE_PRESERVED_NAMES | winnt::FILE_UNICODE_ON_DISK,
            fs_name: U16CString::from_str("SigmaDriveFS").unwrap(),
        })
    }
}
pub fn run(
    cfg: Config,
    op: opendal::Operator,
    rt: tokio::runtime::Handle,
    stop: Arc<AtomicBool>,
    e: Arc<Engine>,
    children: Vec<(String, Arc<Engine>)>,
) -> Result<()> {
    let letter = cfg.mount.to_ascii_uppercase();
    ensure!(
        letter.len() == 2 && letter.ends_with(':') && !"ACDPXZ".contains(&letter[..1]),
        "dedicated test letter required"
    );
    ensure!(
        !std::path::Path::new(&format!("{letter}\\")).exists(),
        "test letter occupied"
    );
    let _ = op;
    rt.block_on(e.cache.list(&e.op, "/"))?;
    let fs = Fs {
        e: e.clone(),
        children: children.clone(),
        rt: rt.clone(),
        nodes: Mutex::new(HashMap::new()),
    };
    let point = U16CString::from_str(&letter)?;
    let scope = crate::engine::hash(cfg.work.to_string_lossy().as_bytes());
    let unc = U16CString::from_str(format!(
        "\\\\SigmaDriveRust\\R-{}-{}",
        &scope[..12],
        &letter[..1]
    ))?;
    let options = MountOptions {
        flags: MountFlags::NETWORK
            | MountFlags::CURRENT_SESSION
            | if cfg.get("mount_read_only") == "true" {
                MountFlags::WRITE_PROTECT
            } else {
                MountFlags::empty()
            },
        unc_name: Some(&unc),
        timeout: Duration::from_secs(60),
        ..Default::default()
    };
    static DOKAN: std::sync::Once = std::sync::Once::new();
    DOKAN.call_once(init);
    let mut mount = FileSystemMounter::new(&fs, &point, &options);
    let filesystem = mount.mount()?;
    println!(
        "{}",
        serde_json::json!({"mounted":letter,"pid":std::process::id(),"engine":"v2"})
    );
    let handle = rt.clone();

    let signal = stop.clone();
    let worker_e = e.clone();
    let recovery_engines: Vec<_> = if children.is_empty() {
        vec![e.clone()]
    } else {
        children.into_iter().map(|(_, e)| e).collect()
    };
    let worker = std::thread::spawn(move || {
        loop {
            if worker_e.cfg.work.join("stop").exists() || signal.load(Ordering::Acquire) {
                let _ = unmount(U16CString::from_str(&worker_e.cfg.mount).unwrap());
                break;
            }
            for recovery_engine in &recovery_engines {
                match handle.block_on(recovery_engine.recover()) {
                    Ok(r) => {
                        let _ = crate::engine::atomic(
                            &worker_e.cfg.work.join("worker.json"),
                            &serde_json::to_vec(&r).unwrap(),
                        );
                    }
                    Err(_) => {
                        eprintln!("PoC V2 pending writeback retained");
                    }
                }
            }
            std::thread::sleep(Duration::from_millis(500));
        }
    });
    drop(filesystem);
    stop.store(true, Ordering::SeqCst);
    let _ = worker.join();
    let _ = atomic_metrics(&e);

    Ok(())
}
fn atomic_metrics(e: &Engine) -> Result<()> {
    crate::engine::atomic(
        &e.cfg.work.join("cache-metrics.json"),
        &serde_json::to_vec(&e.cache.metrics())?,
    )
}
