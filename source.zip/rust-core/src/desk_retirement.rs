//! Terminal receipts only compact local tombstones. They NEVER authorize an engine.
use anyhow::{Result, ensure};
use base64::{Engine, engine::general_purpose::STANDARD};
use ed25519_dalek::{Signature, VerifyingKey};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    time::{Duration, Instant},
};

const CAPACITY: usize = 128;
const QUIET: Duration = Duration::from_secs(90);
#[derive(Clone, PartialEq, Eq)]
pub(crate) struct Context {
    fingerprint: [u8; 32],
    member: String,
    node: String,
    pin: String,
    desktop: String,
}
impl Context {
    pub(crate) fn new(local: &Value, desktop: &str, auth_epoch: u64) -> Result<Self> {
        let get = |key: &str| {
            local[key]
                .as_str()
                .filter(|s| !s.is_empty() && s.len() <= 512 && !s.chars().any(char::is_control))
                .map(str::to_owned)
                .ok_or_else(|| anyhow::anyhow!("SigmaDesk retirement identity unavailable"))
        };
        ensure!(
            !desktop.is_empty() && desktop.len() <= 512,
            "SigmaDesk retirement desktop unavailable"
        );
        let member = get("member")?;
        let node = get("node")?;
        let pin = get("pin")?;
        let desktop = hex::encode(Sha256::digest(desktop.as_bytes()));
        let mut h = Sha256::new();
        h.update(b"sigmadesk/local-retirement-context/v1\0");
        for s in [&member, &node, &pin, &desktop] {
            h.update((s.len() as u64).to_le_bytes());
            h.update(s.as_bytes());
        }
        h.update(auth_epoch.to_le_bytes());
        Ok(Self {
            fingerprint: h.finalize().into(),
            member,
            node,
            pin,
            desktop,
        })
    }
}
#[derive(Clone, Copy)]
pub(crate) struct LeaseBound {
    pub sequence: u64,
    pub expires: i64,
    pub until: Instant,
    pub browser: bool,
}
struct Entry {
    context: Option<Context>,
    role: Option<String>,
    kind: Option<&'static str>,
    sequence: u64,
    expires: i64,
    ready_after: Instant,
    revision: u64,
    retry_at: Instant,
}
#[derive(Clone)]
pub(crate) struct Ticket {
    id: String,
    context: Context,
    role: String,
    kind: Option<&'static str>,
    sequence: u64,
    expires: i64,
    revision: u64,
}
impl Ticket {
    pub(crate) fn body(&self) -> Value {
        json!({"id":self.id,"role":self.role,"desktop_sha256":self.context.desktop})
    }
}
#[derive(Default)]
pub(crate) struct Ledger {
    entries: HashMap<String, Entry>,
    serial: u64,
    untracked_retirement: bool,
}
impl Ledger {
    pub(crate) fn retire(
        &mut self,
        id: &str,
        context: Option<Context>,
        role: Option<&str>,
        lease: Option<LeaseBound>,
        now: Instant,
    ) {
        if !crate::desk_lease::valid_id(id) {
            return;
        }
        if self.entries.contains_key(id) {
            return;
        }
        if self.entries.len() >= CAPACITY {
            self.untracked_retirement = true;
            return;
        }
        let Some(serial) = self.serial.checked_add(1) else {
            self.untracked_retirement = true;
            return;
        };
        self.serial = serial;
        let role = role
            .filter(|r| matches!(*r, "host" | "viewer"))
            .map(str::to_owned);
        let ready_after = std::cmp::max(now + QUIET, lease.map(|l| l.until).unwrap_or(now));
        self.entries.insert(
            id.to_owned(),
            Entry {
                context,
                role,
                kind: lease.map(|l| if l.browser { "browser" } else { "native" }),
                sequence: lease.map(|l| l.sequence).unwrap_or(0),
                expires: lease.map(|l| l.expires).unwrap_or(0),
                ready_after,
                revision: serial,
                retry_at: ready_after,
            },
        );
    }
    pub(crate) fn contains(&self, id: &str) -> bool {
        self.entries.contains_key(id)
    }
    // A verified assignment can complete a cancellation recorded just before
    // startup registration. This never removes the tombstone or grants access.
    pub(crate) fn bind_retired(&mut self,id:&str,context:&Context,role:&str,lease:LeaseBound,now:Instant)->bool {
        let Some(e)=self.entries.get_mut(id) else{return false};
        let kind=if lease.browser{"browser"}else{"native"};
        if !matches!(role,"host"|"viewer") || e.context.as_ref().is_some_and(|c|c!=context)
            || e.role.as_ref().is_some_and(|r|r!=role) || e.kind.is_some_and(|k|k!=kind) {return false}
        let Some(serial)=self.serial.checked_add(1) else{self.untracked_retirement=true;return false};
        self.serial=serial;e.revision=serial;e.context=Some(context.clone());e.role=Some(role.into());e.kind=Some(kind);
        e.sequence=e.sequence.max(lease.sequence);e.expires=e.expires.max(lease.expires);
        e.ready_after=e.ready_after.max(now+QUIET).max(lease.until);e.retry_at=e.ready_after;
        true
    }
    pub(crate) fn blocked(&self, id: &str) -> bool {
        self.contains(id) || self.untracked_retirement || self.entries.len() >= CAPACITY
    }
    pub(crate) fn admission_blocked(&self,id:&str,already_active:bool)->bool {
        // Backpressure holds NEW starts. A live, separately verified lease may
        // renew; an actual terminal ID is blocked even if a resource remains.
        self.contains(id)||(!already_active&&self.blocked(id))
    }
    pub(crate) fn summary(&self) -> Value {
        json!({"pending":self.entries.len(),"capacity":CAPACITY,
        "backpressure":self.untracked_retirement||self.entries.len()>=CAPACITY,"untracked_retirement":self.untracked_retirement})
    }
    pub(crate) fn ticket(&mut self, current: &Context, now: Instant) -> Option<Ticket> {
        let (id, e) = self
            .entries
            .iter_mut()
            .filter(|(_, e)| {
                e.context.as_ref() == Some(current)
                    && e.role.is_some()
                    && now >= e.ready_after
                    && now >= e.retry_at
            })
            .min_by_key(|(_, e)| e.retry_at)?;
        // One background query at a time. Backoff also applies to old/disabled servers.
        e.retry_at = now + Duration::from_secs(30);
        Some(Ticket {
            id: id.clone(),
            context: current.clone(),
            role: e.role.clone()?,
            kind: e.kind,
            sequence: e.sequence,
            expires: e.expires,
            revision: e.revision,
        })
    }
    pub(crate) fn compact(
        &mut self,
        t: &Ticket,
        proof: Proof,
        current: &Context,
        now: Instant,
        quiescent: bool,
    ) -> bool {
        if !quiescent
            || &t.context != current
            || (proof.revision != t.revision
                || proof.id != t.id
                || proof.context != current.fingerprint)
        {
            return false;
        }
        let Some(e) = self.entries.get(&t.id) else {
            return false;
        };
        if e.revision != t.revision || e.context.as_ref() != Some(current) || now < e.ready_after {
            return false;
        }
        self.entries.remove(&t.id);
        true
    }
}
pub(crate) struct Proof {
    revision: u64,
    id: String,
    context: [u8; 32],
}
pub(crate) fn verify(response: &Value, ticket: &Ticket, server_ms: i64) -> Result<Proof> {
    let key: [u8; 32] = STANDARD
        .decode(crate::desk_lease::PUBLIC_KEY)?
        .try_into()
        .map_err(|_| anyhow::anyhow!("SigmaDesk retirement trust key denied"))?;
    verify_key(response, ticket, server_ms, &key)
}
fn verify_key(response: &Value, t: &Ticket, server_ms: i64, key: &[u8; 32]) -> Result<Proof> {
    ensure!(
        response
            .as_object()
            .is_some_and(|o| o.len() == 1 && o.contains_key("terminal_receipt")),
        "SigmaDesk terminal response denied"
    );
    let env = &response["terminal_receipt"];
    ensure!(
        env.as_object().is_some_and(|o| o.len() == 2
            && o.contains_key("payload")
            && o.contains_key("signature")),
        "SigmaDesk terminal envelope denied"
    );
    let raw = STANDARD.decode(
        env["payload"]
            .as_str()
            .filter(|s| s.len() <= 8192)
            .unwrap_or(""),
    )?;
    ensure!(
        !raw.is_empty() && raw.len() <= 4096,
        "SigmaDesk terminal payload denied"
    );
    let signature = Signature::from_slice(
        &STANDARD.decode(
            env["signature"]
                .as_str()
                .filter(|s| s.len() <= 128)
                .unwrap_or(""),
        )?,
    )?;
    VerifyingKey::from_bytes(key)?.verify_strict(
        &[b"sigmadrive/remote-terminal-receipt/v1\0".as_slice(), &raw].concat(),
        &signature,
    )?;
    let v = crate::desk_lease::unique(&raw)?;
    let fields = [
        "schema",
        "authority_epoch",
        "session_id",
        "kind",
        "role",
        "member_id",
        "node_id",
        "pin",
        "team_id",
        "desktop_sha256",
        "status",
        "terminal_at_ms",
        "final_sequence",
        "max_issued_lease_expires_ms",
        "issued_ms",
    ];
    ensure!(
        v.as_object()
            .is_some_and(|o| o.len() == fields.len() && fields.iter().all(|k| o.contains_key(*k))),
        "SigmaDesk terminal fields denied"
    );
    ensure!(
        v["schema"] == "sigmadrive.remote-terminal-receipt/v1"
            && v["session_id"] == t.id
            && v["role"] == t.role
            && v["member_id"] == t.context.member
            && v["node_id"] == t.context.node
            && v["pin"] == t.context.pin
            && v["desktop_sha256"] == t.context.desktop,
        "SigmaDesk terminal binding denied"
    );
    ensure!(
        matches!(v["kind"].as_str(), Some("native" | "browser"))
            && t.kind.is_none_or(|k| v["kind"] == k),
        "SigmaDesk terminal kind denied"
    );
    ensure!(
        v["authority_epoch"]
            .as_str()
            .is_some_and(|s| s.len() == 32 && crate::desk_lease::valid_id(s))
            && v["team_id"]
                .as_str()
                .is_some_and(|s| !s.is_empty() && s.len() <= 512 && !s.chars().any(char::is_control)),
        "SigmaDesk terminal context denied"
    );
    ensure!(
        matches!(
            v["status"].as_str(),
            Some("revoked" | "expired" | "ended" | "stopped")
        ),
        "SigmaDesk terminal status denied"
    );
    let seq = v["final_sequence"]
        .as_u64()
        .ok_or_else(|| anyhow::anyhow!("SigmaDesk terminal sequence denied"))?;
    let expiry = v["max_issued_lease_expires_ms"]
        .as_i64()
        .ok_or_else(|| anyhow::anyhow!("SigmaDesk terminal expiry denied"))?;
    let issued = v["issued_ms"].as_i64().unwrap_or(0);
    let terminal = v["terminal_at_ms"].as_i64().unwrap_or(0);
    ensure!(
        server_ms > 0
            && issued > 0
            && terminal > 0
            && terminal <= issued
            && issued >= expiry
            && (issued - server_ms).unsigned_abs() <= 30000
            && seq >= t.sequence
            && expiry >= t.expires
            && ((seq == 0 && expiry == 0 && t.sequence == 0 && t.expires == 0)
                || (seq > 0 && expiry > 0)),
        "SigmaDesk terminal timing denied"
    );
    Ok(Proof {
        revision: t.revision,
        id: t.id.clone(),
        context: t.context.fingerprint,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use ed25519_dalek::{Signer, SigningKey};
    fn context() -> Context {
        Context::new(&json!({"member":"m","node":"n","pin":"p"}), "desktop", 1).unwrap()
    }
    fn fixture(t: &Ticket, key: &SigningKey, mutate: impl FnOnce(&mut Value)) -> Value {
        let mut v = json!({"schema":"sigmadrive.remote-terminal-receipt/v1","authority_epoch":"a".repeat(32),"session_id":t.id,"kind":"native","role":t.role,"member_id":"m","node_id":"n","pin":"p","team_id":"team","desktop_sha256":t.context.desktop,"status":"ended","terminal_at_ms":160000,"final_sequence":3,"max_issued_lease_expires_ms":160000,"issued_ms":200000});
        mutate(&mut v);
        let raw = serde_json::to_vec(&v).unwrap();
        let sig = key.sign(&[b"sigmadrive/remote-terminal-receipt/v1\0".as_slice(), &raw].concat());
        json!({"terminal_receipt":{"payload":STANDARD.encode(raw),"signature":STANDARD.encode(sig.to_bytes())}})
    }
    fn retired(ledger: &mut Ledger, n: u64, c: &Context, now: Instant) {
        ledger.retire(
            &format!("{n:032x}"),
            Some(c.clone()),
            Some("host"),
            Some(LeaseBound {
                sequence: 2,
                expires: 150000,
                until: now + Duration::from_secs(60),
                browser: false,
            }),
            now,
        );
    }
    #[test]
    fn more_than_128_acknowledged_expired_sessions_do_not_poison_fresh_ids() {
        let mut ledger = Ledger::default();
        let c = context();
        let key = SigningKey::from_bytes(&[43; 32]);
        let mut now = Instant::now();
        for n in 1..=512 {
            retired(&mut ledger, n, &c, now);
            assert!(ledger.contains(&format!("{n:032x}")));
            assert!(ledger.ticket(&c, now).is_none());
            now += QUIET;
            let t = ledger.ticket(&c, now).unwrap();
            let proof = verify_key(
                &fixture(&t, &key, |_| {}),
                &t,
                200000,
                &key.verifying_key().to_bytes(),
            )
            .unwrap();
            assert!(ledger.compact(&t, proof, &c, now, true));
            assert!(!ledger.blocked(&format!("{:032x}", n + 1)));
        }
        assert_eq!(ledger.summary()["pending"], 0);
    }
    #[test]
    fn capacity_and_untracked_cancel_remain_fail_closed_without_arbitrary_eviction() {
        let mut l = Ledger::default();
        let c = context();
        let now = Instant::now();
        for n in 1..=128 {
            retired(&mut l, n, &c, now)
        }
        assert!(l.blocked(&format!("{:032x}", 129)));
        assert!(!l.contains(&format!("{:032x}", 129)));
        assert!(l.admission_blocked(&format!("{:032x}",129),false));
        assert!(!l.admission_blocked(&format!("{:032x}",129),true));
        assert!(l.admission_blocked(&format!("{:032x}",1),true));
        retired(&mut l, 129, &c, now);
        assert_eq!(l.summary()["untracked_retirement"], true);
        assert_eq!(l.summary()["pending"], 128);
    }
    #[test]
    fn no_receipt_wrong_context_and_live_resources_cannot_compact() {
        let mut l = Ledger::default();
        let c = context();
        let now = Instant::now();
        retired(&mut l, 1, &c, now);
        let t = l.ticket(&c, now + QUIET).unwrap();
        let key = SigningKey::from_bytes(&[43; 32]);
        let response = fixture(&t, &key, |_| {});
        let proof = || verify_key(&response, &t, 200000, &key.verifying_key().to_bytes()).unwrap();
        assert!(!l.compact(&t, proof(), &c, now, true));
        assert!(!l.compact(&t, proof(), &c, now + QUIET, false));
        let other =
            Context::new(&json!({"member":"m","node":"n","pin":"p"}), "desktop", 2).unwrap();
        assert!(!l.compact(&t, proof(), &other, now + QUIET, true));
        assert!(l.contains(&t.id));
    }
    #[test]
    fn signature_binding_rollback_active_and_unknown_fields_are_rejected() {
        let mut l = Ledger::default();
        let c = context();
        let now = Instant::now();
        retired(&mut l, 1, &c, now);
        let t = l.ticket(&c, now + QUIET).unwrap();
        let key = SigningKey::from_bytes(&[43; 32]);
        for (field, value) in [
            ("member_id", json!("other")),
            ("node_id", json!("other")),
            ("pin", json!("other")),
            ("role", json!("viewer")),
            ("desktop_sha256", json!("0".repeat(64))),
            ("kind", json!("browser")),
            ("status", json!("approved")),
            ("final_sequence", json!(1)),
            ("max_issued_lease_expires_ms", json!(149999)),
            ("issued_ms", json!(159999)),
            ("untrusted", json!(true)),
        ] {
            let response = fixture(&t, &key, |v| v[field] = value);
            assert!(
                verify_key(&response, &t, 200000, &key.verifying_key().to_bytes()).is_err(),
                "{field}"
            );
        }
        let response = fixture(&t, &key, |_| {});
        assert!(
            verify_key(
                &response,
                &t,
                200000,
                &SigningKey::from_bytes(&[44; 32]).verifying_key().to_bytes()
            )
            .is_err()
        );
    }
    #[test]
    fn pending_cancel_requires_proof_of_no_issued_grants() {
        let c = context();
        let mut l = Ledger::default();
        let now = Instant::now();
        l.retire(&"a".repeat(32), Some(c.clone()), Some("viewer"), None, now);
        let t = l.ticket(&c, now + QUIET).unwrap();
        let key = SigningKey::from_bytes(&[43; 32]);
        let v = fixture(&t, &key, |v| {
            v["role"] = json!("viewer");
            v["final_sequence"] = json!(0);
            v["max_issued_lease_expires_ms"] = json!(0)
        });
        let proof = verify_key(&v, &t, 200000, &key.verifying_key().to_bytes()).unwrap();
        assert!(l.compact(&t, proof, &c, now + QUIET, true));
    }
    #[test]
    fn verified_startup_can_complete_but_never_clear_an_incomplete_cancel(){
        let c=context();let now=Instant::now();let id="f".repeat(32);let mut l=Ledger::default();
        l.retire(&id,Some(c.clone()),None,None,now);
        assert!(l.ticket(&c,now+QUIET).is_none());
        let bound=LeaseBound{sequence:2,expires:150000,until:now+Duration::from_secs(60),browser:false};
        assert!(l.bind_retired(&id,&c,"host",bound,now));assert!(l.blocked(&id));
        let t=l.ticket(&c,now+QUIET).unwrap();let key=SigningKey::from_bytes(&[43;32]);
        let proof=verify_key(&fixture(&t,&key,|_|{}),&t,200000,&key.verifying_key().to_bytes()).unwrap();
        let other=Context::new(&json!({"member":"other","node":"n","pin":"p"}),"desktop",1).unwrap();
        assert!(!l.bind_retired(&id,&other,"host",bound,now));
        assert!(!l.bind_retired(&id,&c,"viewer",bound,now));
        assert!(!l.bind_retired(&id,&c,"host",LeaseBound{browser:true,..bound},now));
        assert!(l.bind_retired(&id,&c,"host",bound,now+QUIET));
        assert!(!l.compact(&t,proof,&c,now+QUIET,true));
        let t=l.ticket(&c,now+QUIET+QUIET).unwrap();
        let proof=verify_key(&fixture(&t,&key,|_|{}),&t,200000,&key.verifying_key().to_bytes()).unwrap();
        assert!(l.compact(&t,proof,&c,now+QUIET+QUIET,true));
    }
    #[test]
    fn exact_go_signed_terminal_fixtures_verify_without_payload_reserialization() {
        for (raw, id, seq, expires) in [
            (
                include_str!("../tests/fixtures/terminal-receipt-v1.json"),
                "3".repeat(32),
                1,
                1792998060000,
            ),
            (
                include_str!("../tests/fixtures/terminal-receipt-zero-v1.json"),
                "4".repeat(32),
                0,
                0,
            ),
        ] {
            let f: Value = serde_json::from_str(raw).unwrap();
            let response =
                crate::desk_lease::unique(f["response_json"].as_str().unwrap().as_bytes()).unwrap();
            let key: [u8; 32] = STANDARD
                .decode(f["public_key_b64"].as_str().unwrap())
                .unwrap()
                .try_into()
                .unwrap();
            let context = Context {
                fingerprint: [1; 32],
                member: "11111111-1111-1111-1111-111111111111".into(),
                node: format!("pc-{}", "1".repeat(32)),
                pin: "a".repeat(64),
                desktop: "e".repeat(64),
            };
            let t = Ticket {
                id,
                context,
                role: "host".into(),
                kind: Some("native"),
                sequence: seq,
                expires,
                revision: 1,
            };
            let decoded = STANDARD
                .decode(response["terminal_receipt"]["payload"].as_str().unwrap())
                .unwrap();
            assert_eq!(decoded, f["payload_utf8"].as_str().unwrap().as_bytes());
            verify_key(&response, &t, 1792998060000, &key).unwrap();
        }
    }
    #[test]
    fn far_future_wall_receipt_never_bypasses_monotonic_quarantine() {
        let mut l = Ledger::default();
        let c = context();
        let now = Instant::now();
        retired(&mut l, 1, &c, now);
        let t = l.ticket(&c, now + QUIET).unwrap();
        let key = SigningKey::from_bytes(&[43; 32]);
        let p = verify_key(
            &fixture(&t, &key, |_| {}),
            &t,
            200000,
            &key.verifying_key().to_bytes(),
        )
        .unwrap();
        assert!(!l.compact(&t, p, &c, now + Duration::from_secs(89), true));
    }
}
