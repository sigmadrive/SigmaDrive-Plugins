//! Headless development host. Desktop directly loads the same core DLL.
use std::io::{self, BufRead};
fn main() {
    if std::env::args().any(|s| s == "--architecture") {
        println!("{}", sigmadrive_core::capabilities());
        return;
    }
    for line in io::stdin().lock().lines() {
        match line {
            Ok(s) => println!("{}", sigmadrive_core::call_json(s.as_bytes())),
            Err(_) => break,
        }
    }
}
