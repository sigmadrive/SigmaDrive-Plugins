use crate::{Config, state::Core};
use anyhow::{Result, bail, ensure};
use serde_json::{Value, json};
use std::{
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

pub struct Mount {
    pub stop: Arc<AtomicBool>,
    pub engine: Arc<crate::v2::Engine>,
    pub target: String,
    pub children: Vec<(String, Arc<crate::v2::Engine>)>,
    pub thread: Option<std::thread::JoinHandle<Result<()>>>,
}
impl Mount {
    pub fn engines(&self) -> Vec<Arc<crate::v2::Engine>> {
        if self.children.is_empty() {
            vec![self.engine.clone()]
        } else {
            self.children.iter().map(|(_, e)| e.clone()).collect()
        }
    }
    pub fn pending(&self) -> Result<u64> {
        self.engines()
            .iter()
            .try_fold(0, |n, e| Ok(n + pending(e)?))
    }
    pub fn resolve(&self, path: &str) -> Result<(Arc<crate::v2::Engine>, String)> {
        if self.children.is_empty() || path.is_empty() {
            return Ok((self.engine.clone(), path.to_owned()));
        }
        let (head, tail) = path.split_once('/').unwrap_or((path, ""));
        self.children
            .iter()
            .find(|(name, _)| name.eq_ignore_ascii_case(head))
            .map(|(_, e)| (e.clone(), tail.to_owned()))
            .ok_or_else(|| anyhow::anyhow!("folder is not part of this composite disk"))
    }
}
pub async fn config(core: &Core, id: &str, root: &str, work: std::path::PathBuf) -> Result<Config> {
    crate::engine::checked(root)?;
    crate::identity::private(&work)?;
    let c = crate::auth::fresh(core, id).await?;
    ensure!(
        c.preset != "profile"
            && c.options.get("sigma_profile_only").map(String::as_str) != Some("true"),
        "profile storage is not a file drive"
    );
    let mut options = c.options;
    for (k, v) in c.secrets {
        if matches!(
            k.as_str(),
            "access_key_id" | "secret_access_key" | "session_token"
        ) {
            options.insert(k, v);
        } else if k == "oauth_token" {
            let tok: Value = serde_json::from_str(&v)?;
            options.insert(
                "access_token".into(),
                tok["access_token"]
                    .as_str()
                    .ok_or_else(|| anyhow::anyhow!("provider credential missing"))?
                    .into(),
            );
        }
    }
    options.insert("connection_id".into(), id.into());
    Ok(Config {
        provider: c.provider,
        root: root.into(),
        options,
        work,
        mode: String::new(),
        mount: String::new(),
    })
}
pub fn pending(engine: &crate::v2::Engine) -> Result<u64> {
    Ok(std::fs::read_dir(engine.cfg.work.join("journal"))?
        .filter_map(|e| e.ok())
        .filter(|e| e.path().extension().is_some_and(|s| s == "json"))
        .count() as u64)
}
pub async fn pending_disk(core: &Core, id: &str) -> Result<u64> {
    let drive = core
        .data
        .read()
        .await
        .drives
        .get(id)
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("drive not registered"))?;
    let members = drive["members"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("drive members missing"))?;
    let root = core.root.join("mounts").join(id);
    let dirs = if members.len() == 1 {
        vec![root.join("journal")]
    } else {
        (0..members.len())
            .map(|i| root.join(format!("member-{i}")).join("journal"))
            .collect()
    };
    let mut count = 0;
    for path in dirs {
        if path.exists() {
            for entry in std::fs::read_dir(path)? {
                if entry?.path().extension().is_some_and(|e| e == "json") {
                    count += 1;
                }
            }
        }
    }
    Ok(count)
}
pub async fn mount(core: Arc<Core>, id: &str) -> Result<Value> {
    let _control = core.drive_control.lock().await;
    ensure!(
        crate::driver::status()["installed"] == true,
        "드라이브 구성요소가 필요합니다. 설정에서 Dokany 설치 후 다시 시도해 주세요."
    );
    let mut drive = core
        .data
        .read()
        .await
        .drives
        .get(id)
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("drive not registered"))?;
    ensure!(
        !core
            .mounts
            .lock()
            .map_err(|_| anyhow::anyhow!("mount lock unavailable"))?
            .contains_key(id),
        "drive already mounted"
    );
    let members = drive["members"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("drive members required"))?;
    ensure!(!members.is_empty(), "drive members required");
    let readonly =
        drive["access_mode"].as_str() == Some("ACCESS_READ_ONLY") || drive["access_mode"] == 2;
    let mut children = Vec::new();
    let mut configs = Vec::new();
    for (index, member) in members.iter().enumerate() {
        let connection = member["connection_id"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("connection required"))?;
        let work = if members.len() == 1 {
            core.root.join("mounts").join(id)
        } else {
            core.root
                .join("mounts")
                .join(id)
                .join(format!("member-{index}"))
        };
        let mut child = config(
            &core,
            connection,
            member["remote_path"].as_str().unwrap_or(""),
            work,
        )
        .await?;
        child
            .options
            .insert("read_only".into(), readonly.to_string());
        if !readonly && drive["allow_identity_swap"] == true {
            child
                .options
                .insert("allow_identity_swap".into(), "true".into());
        }
        child.mount = drive["target"].as_str().unwrap_or("").to_owned();
        if !readonly && child.provider != "drive" {
            crate::safe::probe(&child, &child.operator()?).await?;
        }
        configs.push(child);
    }
    let mut cfg = if configs.len() == 1 {
        configs.remove(0)
    } else {
        let namespace = core.root.join("mounts").join(id).join("namespace");
        crate::identity::private(&namespace)?;
        for (member, cfg) in members.iter().zip(configs) {
            let folder = member["folder"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("composite folder required"))?;
            let safe = crate::engine::checked(folder)?;
            ensure!(
                safe == folder && !safe.contains('/'),
                "invalid composite folder"
            );
            std::fs::create_dir_all(namespace.join(folder))?;
            children.push((
                folder.to_owned(),
                Arc::new(crate::v2::Engine::new(cfg.clone(), cfg.operator()?)?),
            ));
        }
        let work = core.root.join("mounts").join(id).join("root-cache");
        crate::identity::private(&work)?;
        Config {
            provider: "fs".into(),
            root: String::new(),
            options: std::collections::HashMap::from([
                (
                    "local_root".into(),
                    namespace.to_string_lossy().into_owned(),
                ),
                ("read_only".into(), "true".into()),
            ]),
            work,
            mode: String::new(),
            mount: String::new(),
        }
    };
    cfg.mount = drive["target"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("target letter required"))?
        .to_ascii_uppercase();
    ensure!(
        cfg.mount.len() == 2
            && cfg.mount.ends_with(':')
            && cfg.mount.as_bytes()[0].is_ascii_uppercase()
            && !"ACDPXZ".contains(&cfg.mount[..1]),
        "reserved or invalid drive letter"
    );
    ensure!(
        !std::path::Path::new(&format!("{}\\", cfg.mount)).exists(),
        "drive letter occupied"
    );
    if children.is_empty() {
        cfg.options.insert("read_only".into(), readonly.to_string());
    }
    cfg.options
        .insert("mount_read_only".into(), readonly.to_string());
    let op = cfg.operator()?;
    let engine = Arc::new(crate::v2::Engine::new(cfg.clone(), op.clone())?);
    let stop = Arc::new(AtomicBool::new(false));
    let task_stop = stop.clone();
    let task_engine = engine.clone();
    let task_children = children.clone();
    let handle = tokio::runtime::Handle::current();
    #[cfg(windows)]
    let thread = std::thread::spawn(move || {
        crate::mount2::run(cfg, op, handle, task_stop, task_engine, task_children)
    });
    #[cfg(not(windows))]
    {
        let _ = (cfg, op, handle, task_stop, task_engine);
        bail!("mount adapter not implemented for this OS");
    }
    #[cfg(windows)]
    {
        let target = drive["target"].as_str().unwrap().to_owned();
        for _ in 0..150 {
            if std::path::Path::new(&format!("{target}\\")).exists() {
                break;
            }
            if thread.is_finished() {
                return thread
                    .join()
                    .map_err(|_| anyhow::anyhow!("mount thread failed"))?
                    .and_then(|_| Err(anyhow::anyhow!("mount ended before ready")));
            }
            tokio::time::sleep(Duration::from_millis(200)).await;
        }
        if !std::path::Path::new(&format!("{target}\\")).exists() {
            stop.store(true, Ordering::Release);
            bail!("mount did not become ready; pending data retained");
        }
        core.mounts
            .lock()
            .map_err(|_| anyhow::anyhow!("mount lock failed"))?
            .insert(
                id.into(),
                Mount {
                    stop,
                    engine,
                    target: target.clone(),
                    children,
                    thread: Some(thread),
                },
            );
        drive["mounted"] = json!(true);
        drive["resume_on_update"] = json!(false);
        drive["driver"] = json!("dokany");
        drive["mount_point"] = json!(target);
        drive["engine"] = json!("rust");
        if drive.get("auto_mount").is_none() {
            drive["auto_mount"] = json!(true);
        }
        let mut data = core.data.write().await;
        let mut next = data.clone();
        next.drives.insert(id.into(), drive.clone());
        let saved = core.persist(&next);
        *data = next;
        saved.map_err(|_| {
            anyhow::anyhow!("drive is mounted, but automatic recovery settings could not be saved")
        })?;
        Ok(drive)
    }
}
pub async fn unmount(core: Arc<Core>, id: &str, update_resume: bool) -> Result<Value> {
    let _control = core.drive_control.lock().await;
    let (engines, stop, target) = {
        let m = core
            .mounts
            .lock()
            .map_err(|_| anyhow::anyhow!("mount lock failed"))?;
        let m = m
            .get(id)
            .ok_or_else(|| anyhow::anyhow!("drive is not mounted"))?;
        (m.engines(), m.stop.clone(), m.target.clone())
    };
    for engine in &engines {
        let cache = engine.clone();
        tokio::task::spawn_blocking(move || crate::runtime().block_on(cache.recover())).await??;
    }
    ensure!(
        engines
            .iter()
            .try_fold(0, |n, e| pending(e).map(|p| n + p))?
            == 0,
        "pending writes or conflicts remain; mount retained"
    );
    stop.store(true, Ordering::Release);
    for _ in 0..150 {
        if !std::path::Path::new(&format!("{target}\\")).exists() {
            break;
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
    ensure!(
        !std::path::Path::new(&format!("{target}\\")).exists(),
        "open file handles prevent safe unmount"
    );
    let mut mounted = core
        .mounts
        .lock()
        .map_err(|_| anyhow::anyhow!("mount lock failed"))?
        .remove(id)
        .ok_or_else(|| anyhow::anyhow!("mount changed"))?;
    if let Some(thread) = mounted.thread.take() {
        tokio::task::spawn_blocking(move || {
            thread
                .join()
                .map_err(|_| anyhow::anyhow!("mount thread failed"))?
        })
        .await??;
    }
    let mut data = core.data.write().await;
    let mut next = data.clone();
    let drive = next
        .drives
        .get_mut(id)
        .ok_or_else(|| anyhow::anyhow!("drive removed"))?;
    drive["mounted"] = json!(false);
    drive["resume_on_update"] = json!(update_resume);
    if !update_resume {
        drive["auto_mount"] = json!(false);
    }
    drive["mount_point"] = json!("");
    drive["pending_uploads"] = json!(
        engines
            .iter()
            .try_fold(0, |n, e| pending(e).map(|p| n + p))?
    );
    let out = drive.clone();
    core.persist(&next)?;
    *data = next;
    Ok(out)
}
pub async fn files(core: Arc<Core>, method: &str, body: Value) -> Result<Value> {
    let id = body["drive_id"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("drive ID required"))?;
    let full_path = crate::engine::checked(body["path"].as_str().unwrap_or(""))?;
    let (engine, path, target, children) = {
        let mounts = core
            .mounts
            .lock()
            .map_err(|_| anyhow::anyhow!("mount lock failed"))?;
        let mount = mounts
            .get(id)
            .ok_or_else(|| anyhow::anyhow!("Rust drive not mounted"))?;
        let (e, p) = mount.resolve(&full_path)?;
        (
            e,
            p,
            mount.target.clone(),
            mount
                .children
                .iter()
                .map(|(s, _)| s.clone())
                .collect::<Vec<_>>(),
        )
    };
    if method == "ListDriveFiles" && full_path.is_empty() && !children.is_empty() {
        return Ok(
            json!({"entries":children.into_iter().map(|name|json!({"name":name,"directory":true,"is_dir":true,"size":0})).collect::<Vec<_>>()}),
        );
    }
    match method {
        "ListDriveFiles" => {
            use futures_util::TryStreamExt;
            let folder = if path.is_empty() {
                "/".into()
            } else {
                format!("{}/", path.trim_end_matches('/'))
            };
            let mut list = engine.op.lister(&folder).await?;
            let mut entries = Vec::new();
            let mut truncated = false;
            while let Some(e) = list.try_next().await? {
                if entries.len() == 4096 {
                    truncated = true;
                    break;
                }
                entries.push(json!({"name":e.name().trim_end_matches('/'),"path":e.path(),"directory":e.metadata().is_dir(),"is_dir":e.metadata().is_dir(),"size":e.metadata().content_length(),"bytes":e.metadata().content_length()}));
            }
            Ok(json!({"entries":entries,"truncated":truncated}))
        }
        "ReadDriveText" => {
            let meta = engine.op.stat(&path).await?;
            ensure!(
                meta.content_length() <= 64 * 1024,
                "text preview exceeds bound"
            );
            let bytes = engine.op.read(&path).await?.to_vec();
            Ok(
                json!({"content":std::str::from_utf8(&bytes)?,"text":std::str::from_utf8(&bytes)?,"bytes":bytes.len()}),
            )
        }
        // Real OS writes run through the Rust mount; no duplicate upload implementation.
        "WriteDriveText" => {
            ensure!(engine.cfg.get("read_only") != "true", "drive is read-only");
            let text = body["text"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("text required"))?;
            ensure!(text.len() <= 64 * 1024, "text write exceeds bound");
            let target = std::path::PathBuf::from(format!("{target}\\")).join(&full_path);
            use std::io::Write;
            let mut f = std::fs::OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(target)?;
            f.write_all(text.as_bytes())?;
            f.sync_all()?;
            Ok(json!({"bytes":text.len(),"saved_locally":true,"cloud_committed":false}))
        }
        "CreateDriveFolder" => {
            ensure!(engine.cfg.get("read_only") != "true", "drive is read-only");
            std::fs::create_dir(std::path::PathBuf::from(format!("{target}\\")).join(full_path))?;
            Ok(json!({}))
        }
        _ => bail!("unsupported file request"),
    }
}

pub fn free_letters() -> Vec<String> {
    #[cfg(windows)]
    let occupied = unsafe { windows_sys::Win32::Storage::FileSystem::GetLogicalDrives() };
    #[cfg(not(windows))]
    let occupied = 0u32;
    (b'E'..=b'Y')
        .filter(|c| !b"PX".contains(c) && occupied & (1u32 << (*c - b'A')) == 0)
        .map(|c| format!("{}:", c as char))
        .collect()
}
