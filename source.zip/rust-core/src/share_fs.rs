//! Handle-relative shared roots. Incoming names cannot select ambient paths.
//! Writes publish a complete staging file; replacements retain the locked original.
use anyhow::{Result, ensure};
use cap_std::fs::{Dir, File, OpenOptions};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    io::{Read, Write},
    sync::Arc,
};

pub struct Root {
    dir: Arc<Dir>,
    pub bucket: String,
    pub writes: tokio::sync::Mutex<()>,
    hashes: std::sync::Mutex<std::collections::HashMap<String, String>>,
}
pub struct Opened {
    pub file: std::fs::File,
    pub size: u64,
    pub etag: String,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct Entry {
    pub key: String,
    pub size: u64,
    pub etag: String,
}
pub fn key(name: &str) -> Result<String> {
    let checked = crate::engine::checked(name)?;
    ensure!(
        !checked.is_empty()
            && checked == name
            && name.len() <= 1024
            && !name
                .split('/')
                .any(|s| s.is_empty() || s.starts_with(".sigma-")),
        "invalid shared object key"
    );
    Ok(checked)
}
pub fn bucket_valid(bucket: &str) -> bool {
    (3..=63).contains(&bucket.len())
        && bucket
            .bytes()
            .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
        && !bucket.starts_with('-')
        && !bucket.ends_with('-')
}
fn version(file: &std::fs::File) -> Result<(u64, String)> {
    let metadata = file.metadata()?;
    ensure!(metadata.is_file(), "not a shared regular file");
    #[cfg(windows)]
    {
        use std::os::windows::io::AsRawHandle;
        use windows_sys::Win32::Storage::FileSystem::{
            BY_HANDLE_FILE_INFORMATION, FILE_BASIC_INFO, FileBasicInfo, GetFileInformationByHandle,
            GetFileInformationByHandleEx,
        };
        let mut identity: BY_HANDLE_FILE_INFORMATION = unsafe { std::mem::zeroed() };
        let mut basic: FILE_BASIC_INFO = unsafe { std::mem::zeroed() };
        ensure!(
            unsafe { GetFileInformationByHandle(file.as_raw_handle(), &mut identity) } != 0
                && unsafe {
                    GetFileInformationByHandleEx(
                        file.as_raw_handle(),
                        FileBasicInfo,
                        (&mut basic as *mut FILE_BASIC_INFO).cast(),
                        std::mem::size_of::<FILE_BASIC_INFO>() as u32,
                    )
                } != 0,
            "shared file identity unavailable"
        );
        ensure!(
            identity.dwFileAttributes & 0x400 == 0,
            "shared reparse points are not served"
        );
        let scope = format!(
            "{}:{}:{}:{}:{}",
            identity.dwVolumeSerialNumber,
            identity.nFileIndexHigh,
            identity.nFileIndexLow,
            basic.ChangeTime,
            metadata.len()
        );
        Ok((
            metadata.len(),
            format!("\"{}\"", hex::encode(Sha256::digest(scope.as_bytes()))),
        ))
    }
    #[cfg(not(windows))]
    {
        let _ = metadata;
        anyhow::bail!("safe shared file identity not implemented on this OS")
    }
}
impl Root {
    pub fn open(folder: &std::path::Path, bucket: &str) -> Result<Self> {
        ensure!(
            folder.is_absolute()
                && !folder
                    .to_string_lossy()
                    .to_ascii_lowercase()
                    .starts_with("z:"),
            "choose a dedicated local shared folder"
        );
        let metadata = std::fs::symlink_metadata(folder)?;
        ensure!(
            metadata.is_dir() && !metadata.file_type().is_symlink(),
            "real shared directory required"
        );
        #[cfg(windows)]
        {
            use std::os::windows::fs::MetadataExt;
            ensure!(
                metadata.file_attributes() & 0x400 == 0,
                "shared root reparse denied"
            );
        }
        ensure!(
            (3..=63).contains(&bucket.len())
                && bucket
                    .bytes()
                    .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
                && !bucket.starts_with('-')
                && !bucket.ends_with('-'),
            "invalid shared bucket"
        );
        let root = Self {
            dir: Arc::new(Dir::open_ambient_dir(folder, cap_std::ambient_authority())?),
            bucket: bucket.into(),
            writes: tokio::sync::Mutex::new(()),
            hashes: std::sync::Mutex::new(std::collections::HashMap::new()),
        };
        root.recover_publications()?;
        Ok(root)
    }
    fn options(delete: bool) -> OpenOptions {
        let mut options = OpenOptions::new();
        options.read(true);
        #[cfg(windows)]
        {
            use cap_std::fs::OpenOptionsExt;
            options.share_mode(1);
            if delete {
                options.access_mode(0x80000000 | 0x00010000);
            }
        }
        options
    }
    pub fn read(&self, name: &str) -> Result<Opened> {
        let name = key(name)?;
        let file = self.dir.open_with(name, &Self::options(false))?.into_std();
        let (size, etag) = version(&file)?;
        Ok(Opened { file, size, etag })
    }
    fn parent(&self, name: &str) -> Result<(Dir, String)> {
        let name = key(name)?;
        let (parent, leaf) = name.rsplit_once('/').unwrap_or((".", &name));
        Ok((self.dir.open_dir(parent)?, leaf.into()))
    }
    pub fn list(&self, prefix: &str, after: &str, limit: usize) -> Result<(Vec<Entry>, bool)> {
        ensure!(
            prefix.len() <= 1024 && after.len() <= 1024 && (1..=1000).contains(&limit),
            "listing bounds invalid"
        );
        fn walk(dir: &Dir, path: &str, items: &mut Vec<String>, depth: usize) -> Result<()> {
            ensure!(depth <= 32, "shared directory depth limit");
            for entry in dir.entries()? {
                let entry = entry?;
                let name = entry.file_name().to_string_lossy().into_owned();
                if name.starts_with(".sigma-") {
                    continue;
                }
                let kind = entry.file_type()?;
                if kind.is_symlink() {
                    continue;
                }
                let full = if path.is_empty() {
                    name.clone()
                } else {
                    format!("{path}/{name}")
                };
                if key(&full).is_err() {
                    continue;
                }
                ensure!(items.len() < 65536, "shared listing capacity exceeded");
                if kind.is_dir() {
                    walk(&dir.open_dir(name)?, &full, items, depth + 1)?;
                } else if kind.is_file() {
                    items.push(full);
                }
            }
            Ok(())
        }
        let mut names = Vec::new();
        walk(&self.dir, "", &mut names, 0)?;
        names.sort();
        let names = names
            .into_iter()
            .filter(|n| n.starts_with(prefix) && n.as_str() > after)
            .take(limit + 1)
            .collect::<Vec<_>>();
        let more = names.len() > limit;
        let mut items = Vec::new();
        for name in names.into_iter().take(limit) {
            let opened = self.read(&name)?;
            items.push(Entry {
                key: name,
                size: opened.size,
                etag: opened.etag,
            });
        }
        Ok((items, more))
    }
    pub fn write_part(&self, upload: &str, number: i32, bytes: &[u8]) -> Result<String> {
        ensure!(
            upload.len() == 32
                && upload.bytes().all(|b| b.is_ascii_hexdigit())
                && (1..=10000).contains(&number)
                && bytes.len() <= 8 * 1024 * 1024,
            "multipart bounds invalid"
        );
        self.dir.create_dir_all(".sigma-uploads")?;
        let hash = hex::encode(Sha256::digest(bytes));
        let name = format!(".sigma-uploads/{upload}-{number}-{hash}");
        match self
            .dir
            .open_with(&name, OpenOptions::new().write(true).create_new(true))
        {
            Ok(mut f) => {
                f.write_all(bytes)?;
                f.sync_all()?;
            }
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
                let mut f = self.dir.open(&name)?;
                let mut old = Vec::new();
                f.read_to_end(&mut old)?;
                ensure!(old == bytes, "multipart checkpoint changed");
            }
            Err(e) => return Err(e.into()),
        }
        Ok(format!("\"{hash}\""))
    }
    pub fn manifest(&self, id: &str) -> Result<serde_json::Value> {
        ensure!(
            id.len() == 32 && id.bytes().all(|b| b.is_ascii_hexdigit()),
            "invalid upload ID"
        );
        let path = format!(".sigma-uploads/{id}.json");
        let mut f = self.dir.open(path)?;
        ensure!(
            f.metadata()?.len() <= 2 * 1024 * 1024,
            "multipart metadata bound"
        );
        let mut b = Vec::new();
        f.read_to_end(&mut b)?;
        Ok(serde_json::from_slice(&b)?)
    }
    pub fn save_manifest(&self, id: &str, value: &serde_json::Value) -> Result<()> {
        self.manifest(id)?;
        let bytes = serde_json::to_vec(value)?;
        ensure!(
            bytes.len() <= 2 * 1024 * 1024,
            "multipart metadata bound exceeded"
        );
        let temp = format!(".sigma-uploads/{id}-{}.tmp", uuid::Uuid::new_v4().simple());
        let mut f = self
            .dir
            .open_with(&temp, OpenOptions::new().write(true).create_new(true))?;
        f.write_all(&bytes)?;
        f.sync_all()?;
        drop(f);
        self.dir
            .rename(&temp, &self.dir, format!(".sigma-uploads/{id}.json"))?;
        Ok(())
    }
    pub fn create_upload(&self, manifest: &serde_json::Value) -> Result<String> {
        self.dir.create_dir_all(".sigma-uploads")?;
        let id = uuid::Uuid::new_v4().simple().to_string();
        let mut f = self.dir.open_with(
            format!(".sigma-uploads/{id}.json"),
            OpenOptions::new().write(true).create_new(true),
        )?;
        f.write_all(&serde_json::to_vec(manifest)?)?;
        f.sync_all()?;
        Ok(id)
    }
    pub fn assemble(
        &self,
        id: &str,
        parts: &[(i32, String)],
        stop: &std::sync::atomic::AtomicBool,
    ) -> Result<(File, String)> {
        ensure!(
            !parts.is_empty() && parts.len() <= 10000,
            "multipart parts invalid"
        );
        self.manifest(id)?;
        let name = format!(
            ".sigma-uploads/{id}-{}.complete",
            uuid::Uuid::new_v4().simple()
        );
        let mut output = self.dir.open_with(
            &name,
            OpenOptions::new().write(true).read(true).create_new(true),
        )?;
        for (expected, (number, etag)) in (1..).zip(parts.iter()) {
            ensure!(*number == expected, "multipart ordering invalid");
            let hash = etag.trim_matches('"');
            ensure!(
                hash.len() == 64 && hash.bytes().all(|b| b.is_ascii_hexdigit()),
                "invalid part hash"
            );
            let mut input = self
                .dir
                .open(format!(".sigma-uploads/{id}-{number}-{hash}"))?;
            let mut check = Sha256::new();
            let mut buffer = vec![0u8; 1024 * 1024];
            loop {
                ensure!(
                    !stop.load(std::sync::atomic::Ordering::Acquire),
                    "multipart operation stopped"
                );
                let n = input.read(&mut buffer)?;
                if n == 0 {
                    break;
                }
                check.update(&buffer[..n]);
                output.write_all(&buffer[..n])?;
            }
            ensure!(
                hex::encode(check.finalize()) == hash,
                "multipart part checksum changed"
            );
        }
        output.sync_all()?;
        Ok((output, name))
    }
    pub fn stage(&self, bytes: &[u8]) -> Result<(File, String)> {
        self.dir.create_dir_all(".sigma-uploads")?;
        let name = format!(".sigma-uploads/{}.complete", uuid::Uuid::new_v4().simple());
        let mut output = self.dir.open_with(
            &name,
            OpenOptions::new().write(true).read(true).create_new(true),
        )?;
        output.write_all(bytes)?;
        output.sync_all()?;
        Ok((output, name))
    }
    pub fn commit(
        &self,
        name: &str,
        staging: &str,
        expected: Option<&str>,
        none: bool,
    ) -> Result<String> {
        let _publication_lock = self.publication_lock()?;
        key(name)?;
        if let Some((parent, _)) = name.rsplit_once('/') {
            self.dir.create_dir_all(parent)?;
        }
        let (parent, leaf) = self.parent(name)?;
        let existing = match parent.open_with(&leaf, &Self::options(true)) {
            Ok(f) => Some(f),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => None,
            Err(e) => return Err(e.into()),
        };
        if let Some(file) = existing {
            let std = file.into_std();
            let (_, etag) = version(&std)?;
            ensure!(
                !none && expected == Some(etag.as_str()),
                "precondition failed; existing object preserved"
            );
            let backup = format!(".sigma-backup-{}", uuid::Uuid::new_v4().simple());
            // Persist the original's recovery location BEFORE removing its name.
            // A power loss must leave enough information to restore a missing
            // target without overwriting a concurrent writer's file.
            let journal = format!(".sigma-uploads/{}.intent", uuid::Uuid::new_v4().simple());
            self.dir.create_dir_all(".sigma-uploads")?;
            let mut intent = self
                .dir
                .open_with(&journal, OpenOptions::new().write(true).create_new(true))?;
            intent.write_all(&serde_json::to_vec(
                &serde_json::json!({"schema":1,"name":name,"backup":backup}),
            )?)?;
            intent.sync_all()?;
            drop(intent);
            rename_handle(&std, &parent, &backup)?;
            // No overwrite: if another writer wins the now vacant name, both the
            // immutable backup and new staging remain for explicit recovery.
            if let Err(e) = self.dir.hard_link(staging, &parent, &leaf) {
                let _ = parent.hard_link(&backup, &parent, &leaf);
                return Err(anyhow::anyhow!(
                    "publication conflict; original backup and new staging retained: {}",
                    e.kind()
                ));
            }
            // Removing the intent is safe only after the new target is visible.
            // The original backup and staging hardlink remain recovery evidence.
            self.dir.remove_file(&journal)?;
        } else {
            ensure!(expected.is_none(), "precondition failed; original missing");
            self.dir.hard_link(staging, &parent, &leaf)?;
        }
        // Retain the staging hardlink until the durable completion receipt is
        // acknowledged. This identifies our own commit after an ACK is lost.
        Ok(self.read(name)?.etag)
    }
    fn recover_publications(&self) -> Result<()> {
        let uploads = match self.dir.open_dir(".sigma-uploads") {
            Ok(dir) => dir,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(()),
            Err(e) => return Err(e.into()),
        };
        let _publication_lock = self.publication_lock()?;
        let mut count = 0;
        for entry in uploads.entries()? {
            let entry = entry?;
            let filename = entry.file_name().to_string_lossy().into_owned();
            let Some(id) = filename.strip_suffix(".intent") else {
                continue;
            };
            ensure!(
                id.len() == 32 && id.bytes().all(|b| b.is_ascii_hexdigit()),
                "invalid publication recovery journal"
            );
            count += 1;
            ensure!(
                count <= 4096,
                "publication recovery journal capacity exceeded"
            );
            let mut file = uploads.open_with(&filename, &Self::options(false))?;
            ensure!(
                file.metadata()?.len() <= 4096,
                "publication recovery journal bound"
            );
            let mut bytes = Vec::new();
            file.read_to_end(&mut bytes)?;
            let value: serde_json::Value = serde_json::from_slice(&bytes)?;
            ensure!(value["schema"] == 1, "unknown publication recovery journal");
            let name = key(value["name"].as_str().unwrap_or(""))?;
            let backup = value["backup"].as_str().unwrap_or("");
            let suffix = backup.strip_prefix(".sigma-backup-").unwrap_or("");
            ensure!(
                suffix.len() == 32 && suffix.bytes().all(|b| b.is_ascii_hexdigit()),
                "invalid original backup location"
            );
            let (parent, leaf) = self.parent(&name)?;
            match parent.open_with(&leaf, &Self::options(false)) {
                Ok(_) => {} // Never overwrite a visible target, even after a crash.
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                    // If rename never happened there is no backup. Otherwise,
                    // retain the backup and link it back using no-overwrite.
                    match parent.open_with(backup, &Self::options(false)) {
                        Ok(f) => {
                            version(&f.into_std())?;
                            match parent.hard_link(backup, &parent, &leaf) {
                                Ok(()) => {}
                                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {}
                                Err(e) => return Err(e.into()),
                            }
                        }
                        Err(e) if e.kind() == std::io::ErrorKind::NotFound => anyhow::bail!(
                            "publication recovery requires the retained original; journal preserved"
                        ),
                        Err(e) => return Err(e.into()),
                    }
                }
                Err(e) => return Err(e.into()),
            }
            drop(file);
            uploads.remove_file(filename)?;
        }
        Ok(())
    }
    fn publication_lock(&self) -> Result<File> {
        let mut options = OpenOptions::new();
        options.read(true).write(true).create(true);
        #[cfg(windows)]
        {
            use cap_std::fs::OpenOptionsExt;
            options.share_mode(0);
        }
        Ok(self.dir.open_with(".sigma-publication.lock", &options)?)
    }
    pub fn content_hash(&self, name: &str, stop: &std::sync::atomic::AtomicBool) -> Result<String> {
        let mut f = self.read(name)?;
        if let Some(hash) = self
            .hashes
            .lock()
            .ok()
            .and_then(|m| m.get(&f.etag).cloned())
        {
            return Ok(hash);
        }
        let mut hash = Sha256::new();
        let mut b = vec![0u8; 1024 * 1024];
        loop {
            ensure!(
                !stop.load(std::sync::atomic::Ordering::Acquire),
                "hash stopped"
            );
            let n = f.file.read(&mut b)?;
            if n == 0 {
                break;
            }
            hash.update(&b[..n]);
        }
        let hash = hex::encode(hash.finalize());
        self.remember_hash(&f.etag, &hash);
        Ok(hash)
    }
    pub fn remember_hash(&self, etag: &str, hash: &str) {
        if let Ok(mut m) = self.hashes.lock() {
            if m.len() >= 512 {
                m.clear();
            }
            m.insert(etag.into(), hash.into());
        }
    }
    pub fn committed_stage(
        &self,
        name: &str,
        stage: &str,
        hash: &str,
        stop: &std::sync::atomic::AtomicBool,
    ) -> Result<Option<String>> {
        let target = match self.read(name) {
            Ok(t) => t,
            Err(e)
                if e.downcast_ref::<std::io::Error>()
                    .is_some_and(|e| e.kind() == std::io::ErrorKind::NotFound) =>
            {
                return Ok(None);
            }
            Err(e) => return Err(e),
        };
        let source = self.dir.open(stage)?.into_std();
        let (_, version) = version(&source)?;
        if target.etag != version {
            return Ok(None);
        }
        ensure!(
            self.content_hash(name, stop)? == hash,
            "committed object changed; checkpoint retained"
        );
        Ok(Some(target.etag))
    }
    pub fn delete(&self, name: &str, expected: Option<&str>) -> Result<()> {
        let (parent, leaf) = self.parent(name)?;
        let original = parent.open_with(&leaf, &Self::options(true))?.into_std();
        let (_, etag) = version(&original)?;
        ensure!(
            expected == Some(etag.as_str()),
            "conditional delete requires current object revision"
        );
        rename_handle(
            &original,
            &parent,
            &format!(".sigma-deleted-{}", uuid::Uuid::new_v4().simple()),
        )?;
        Ok(())
    }
}
#[cfg(windows)]
fn rename_handle(file: &std::fs::File, parent: &Dir, name: &str) -> Result<()> {
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Storage::FileSystem::{
        FILE_RENAME_INFO, FileRenameInfo, SetFileInformationByHandle,
    };
    let name = name.encode_utf16().collect::<Vec<_>>();
    let bytes = std::mem::size_of::<FILE_RENAME_INFO>() + name.len() * 2;
    let mut storage = vec![0usize; bytes.div_ceil(std::mem::size_of::<usize>())];
    let info = storage.as_mut_ptr().cast::<FILE_RENAME_INFO>();
    unsafe {
        (*info).RootDirectory = parent.as_raw_handle();
        (*info).FileNameLength = (name.len() * 2) as u32;
        std::ptr::copy_nonoverlapping(name.as_ptr(), (*info).FileName.as_mut_ptr(), name.len());
        ensure!(
            SetFileInformationByHandle(
                file.as_raw_handle(),
                FileRenameInfo,
                info.cast(),
                bytes as u32
            ) != 0,
            "locked original could not be retained"
        );
    }
    Ok(())
}
#[cfg(not(windows))]
fn rename_handle(_: &std::fs::File, _: &Dir, _: &str) -> Result<()> {
    anyhow::bail!("safe replacement not implemented on this OS")
}

#[cfg(all(test, windows))]
mod tests {
    use super::*;
    struct Workspace(std::path::PathBuf);
    impl Workspace {
        fn new() -> Self {
            let p = std::env::temp_dir().join(format!(
                "sigma-rust-publication-{}",
                uuid::Uuid::new_v4().simple()
            ));
            std::fs::create_dir(&p).unwrap();
            Self(p)
        }
        fn interrupted(&self, external: bool) {
            std::fs::create_dir(self.0.join(".sigma-uploads")).unwrap();
            std::fs::write(
                self.0
                    .join(".sigma-backup-00000000000000000000000000000001"),
                b"original",
            )
            .unwrap();
            std::fs::write(self.0.join(".sigma-uploads/00000000000000000000000000000002.intent"),serde_json::to_vec(&serde_json::json!({"schema":1,"name":"document.txt","backup":".sigma-backup-00000000000000000000000000000001"})).unwrap()).unwrap();
            if external {
                std::fs::write(self.0.join("document.txt"), b"external winner").unwrap();
            }
        }
    }
    impl Drop for Workspace {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }
    #[test]
    fn interrupted_replacement_restores_original_without_deleting_backup() {
        let w = Workspace::new();
        w.interrupted(false);
        let root = Root::open(&w.0, "qa-bucket").unwrap();
        assert_eq!(
            std::fs::read(w.0.join("document.txt")).unwrap(),
            b"original"
        );
        assert!(
            w.0.join(".sigma-backup-00000000000000000000000000000001")
                .exists()
        );
        drop(root);
    }
    #[test]
    fn recovery_never_overwrites_an_external_winner() {
        let w = Workspace::new();
        w.interrupted(true);
        let root = Root::open(&w.0, "qa-bucket").unwrap();
        assert_eq!(
            std::fs::read(w.0.join("document.txt")).unwrap(),
            b"external winner"
        );
        assert_eq!(
            std::fs::read(w.0.join(".sigma-backup-00000000000000000000000000000001")).unwrap(),
            b"original"
        );
        drop(root);
    }
    #[test]
    fn invalid_recovery_path_is_rejected_with_journal_preserved() {
        let w = Workspace::new();
        w.interrupted(false);
        let p =
            w.0.join(".sigma-uploads/00000000000000000000000000000002.intent");
        std::fs::write(&p,br#"{"schema":1,"name":"../outside.txt","backup":".sigma-backup-00000000000000000000000000000001"}"#).unwrap();
        assert!(Root::open(&w.0, "qa-bucket").is_err());
        assert!(p.exists());
    }
}
