//! Explicit PC-local support snapshot. Never includes credentials, online
//! recovery keys, peer requests, file names or full private configuration.
use crate::state::Core;
use anyhow::Result;
use serde_json::{Value, json};
pub async fn export(core: &Core) -> Result<Value> {
    let data = core.data.read().await;
    let desk = core.desk.snapshot();
    let report = json!({"schema":1,"at":crate::state::now(),"version":crate::VERSION,"engine":"rust","transport":"direct-ffi","pid":std::process::id(),"started":core.started,"node":data.node,
        "member_present":data.member.is_some(),"profile_enabled":data.online.as_ref().map(|o|o.enabled),
        "connections":data.connections.values().map(|c|json!({"id":c.id,"provider":c.provider,"needs_auth":c.public()["needs_auth"]})).collect::<Vec<_>>(),
        "drives":data.drives.values().map(|d|json!({"id":d["id"],"auto_mount":d["auto_mount"]})).collect::<Vec<_>>(),
        "mounts":core.mounts.lock().map(|m|m.keys().cloned().collect::<Vec<_>>()).unwrap_or_default(),
        "jobs":data.jobs.values().map(|j|json!({"id":j["id"],"state":j["state"],"direction":j["direction"],"completed_bytes":j["completed_bytes"],"total_bytes":j["total_bytes"],"sha256":j["sha256"],"resources_released":j["resources_released"]})).collect::<Vec<_>>(),
        "active_peer_leases":core.leases.active(),"driver":crate::driver::status(),
        "sigmadesk":{"runtime":desk["runtime"],"events":desk["diagnostics"],"transport_observations":desk["transport_observations"]}});
    drop(data);
    let dir = core.root.join("diagnostics");
    std::fs::create_dir_all(&dir)?;
    let path = dir.join(format!("rust-{}.json", uuid::Uuid::new_v4().simple()));
    crate::identity::atomic(&path, &serde_json::to_vec_pretty(&report)?)?;
    Ok(
        json!({"path":path,"message":"진단 파일을 이 PC에 저장했습니다. 인증 정보와 파일 이름은 포함하지 않습니다."}),
    )
}
