//! Browser-host-only startup work selection for one reviewed engine manifest.
//! The current browser advertises VP9 only. The reviewed engine otherwise runs
//! a synthetic 1080p AV1 benchmark once in every fresh per-session profile.
//! This affects that unused benchmark, never assignment/transport permissions.
use std::collections::BTreeMap;

pub const REVIEWED_VP9_BROWSER_ENGINE: &str =
    "14ce73097c27869a3f98562e49e936663015abd7629d144244fc17eaff160ae1";

/// Call only while creating the private options of a verified browser HOST
/// assignment, after asset verification. Native and unreviewed engines keep
/// their original codec-selection/probe behavior. Do not override an explicit
/// option if a future profile builder starts supplying one.
pub fn select_browser_startup_work(
    browser_host: bool,
    verified_manifest: &str,
    options: &mut BTreeMap<&'static str, String>,
) -> bool {
    if !browser_host || verified_manifest != REVIEWED_VP9_BROWSER_ENGINE {
        return false;
    }
    if let std::collections::btree_map::Entry::Vacant(entry) = options.entry("av1-test") {
        entry.insert("N".into());
        true
    } else {
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn permissions() -> BTreeMap<&'static str, String> {
        BTreeMap::from([
            ("enable-keyboard", "N".into()),
            ("access-mode", "custom".into()),
            ("approve-mode", "password".into()),
            ("verification-method", "use-permanent-password".into()),
            ("id-whitelist", "987654321".into()),
            ("relay-server", "127.0.0.1:12345".into()),
            ("enable-file-transfer", "N".into()),
        ])
    }

    #[test]
    fn reviewed_browser_adds_exactly_one_unused_probe_option() {
        let mut options = permissions();
        let before = options.clone();
        assert!(select_browser_startup_work(true, REVIEWED_VP9_BROWSER_ENGINE, &mut options));
        assert_eq!(options.remove("av1-test").as_deref(), Some("N"));
        assert_eq!(options, before);
    }

    #[test]
    fn native_and_native_host_are_unchanged() {
        let mut options = permissions();
        let before = options.clone();
        assert!(!select_browser_startup_work(false, REVIEWED_VP9_BROWSER_ENGINE, &mut options));
        assert_eq!(options, before);
    }

    #[test]
    fn unknown_or_noncanonical_manifest_keeps_baseline() {
        for manifest in ["", "unknown", "14ce7309", "14CE73097C27869A3F98562E49E936663015ABD7629D144244FC17EAFF160AE1",
            "04ce73097c27869a3f98562e49e936663015abd7629d144244fc17eaff160ae1",
            "14ce73097c27869a3f98562e49e936663015abd7629d144244fc17eaff160ae1 "] {
            let mut options = permissions();
            let before = options.clone();
            assert!(!select_browser_startup_work(true, manifest, &mut options));
            assert_eq!(options, before);
        }
    }

    #[test]
    fn explicit_profile_choice_is_not_overwritten() {
        for explicit in ["Y", "N", "future-policy"] {
            let mut options = permissions();
            options.insert("av1-test", explicit.into());
            let before = options.clone();
            assert!(!select_browser_startup_work(true, REVIEWED_VP9_BROWSER_ENGINE, &mut options));
            assert_eq!(options, before);
        }
    }

    #[test]
    fn repeated_application_is_idempotent() {
        let mut options = permissions();
        assert!(select_browser_startup_work(true, REVIEWED_VP9_BROWSER_ENGINE, &mut options));
        let once = options.clone();
        assert!(!select_browser_startup_work(true, REVIEWED_VP9_BROWSER_ENGINE, &mut options));
        assert_eq!(options, once);
    }
}
