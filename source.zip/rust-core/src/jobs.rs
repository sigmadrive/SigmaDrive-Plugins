//! Durable product jobs. File bodies stay in Rust; cancel drops the HTTP future.
use crate::state::{Core, id};
use anyhow::{Result, bail, ensure};
use serde_json::{Value, json};
use std::{
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

pub async fn manage(core: Arc<Core>, body: Value) -> Result<Value> {
    let _control = core.job_control.lock().await;
    match body["action"].as_str().unwrap_or("status") {
        "status" => Ok(
            json!({"jobs":core.data.read().await.jobs.values().cloned().collect::<Vec<_>>(),"plugin_state":"builtin-rust"}),
        ),
        "start" | "upload" | "download" => {
            let connection = body["connection_id"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("connection ID required"))?;
            let _ = core.connection(connection).await?;
            let direction = body["direction"]
                .as_str()
                .unwrap_or(body["action"].as_str().unwrap_or("download"));
            ensure!(
                matches!(direction, "upload" | "download"),
                "direction required"
            );
            let path = crate::engine::checked(
                body["key"]
                    .as_str()
                    .or(body["path"].as_str())
                    .ok_or_else(|| anyhow::anyhow!("object path required"))?,
            )?;
            ensure!(!path.is_empty(), "file path required");
            let local = body[if direction == "upload" {
                "source"
            } else {
                "destination"
            }]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("local file required"))?;
            ensure!(
                PathBuf::from(local).is_absolute(),
                "local file must be absolute"
            );
            ensure!(
                !local.to_ascii_lowercase().starts_with("z:"),
                "existing Z is outside migration scope"
            );
            let jid = id("transfer");
            let binding = if direction == "upload" {
                source_binding(&std::fs::metadata(local)?)?
            } else {
                Value::Null
            };
            let job = json!({"id":jid,"connection_id":connection,"root":body["root"].as_str().unwrap_or(""),"key":path,"direction":direction,"source":if direction=="upload"{local}else{""},"source_binding":binding,"destination":if direction=="download"{local}else{""},"state":"queued","requested_state":"running","resume_on_restart":body["resume_on_restart"].as_bool().unwrap_or(true),"created_at":crate::state::now(),"completed_bytes":0,"total_bytes":0,"resources_released":true,"expected_sha256":body["expected_sha256"].as_str().unwrap_or("")});
            {
                let mut data = core.data.write().await;
                let mut next = data.clone();
                ensure!(
                    next.jobs.len() < 4096,
                    "transfer history capacity reached; existing jobs preserved"
                );
                next.jobs.insert(jid.clone(), job);
                core.persist(&next)?;
                *data = next;
            }
            launch(core.clone(), jid.clone()).await?;
            manage_status(&core).await
        }
        "pause" | "cancel" => {
            let pause_reason =
                if body["_update_drain"] == true && core.update.draining.load(Ordering::Acquire) {
                    "update"
                } else {
                    "user"
                };
            let jid = body["id"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("job ID required"))?;
            if core
                .data
                .read()
                .await
                .jobs
                .get(jid)
                .is_some_and(|j| j["state"] == "complete" || j["state"] == "cancelled")
            {
                return manage_status(&core).await;
            }
            let signal = core
                .transfers
                .lock()
                .map_err(|_| anyhow::anyhow!("job lock failed"))?
                .get(jid)
                .cloned();
            if let Some(signal) = signal {
                patch(&core,jid,json!({"requested_state":if body["action"]=="cancel"{"cancelled"}else{"paused"},"state":"pausing","pause_reason":pause_reason})).await?;
                signal.store(true, Ordering::Release);
            } else {
                let current = core
                    .data
                    .read()
                    .await
                    .jobs
                    .get(jid)
                    .cloned()
                    .ok_or_else(|| anyhow::anyhow!("job not registered"))?;
                ensure!(
                    current["state"] != "complete",
                    "completed transfer cannot be paused or cancelled"
                );
                let desired = if body["action"] == "cancel" {
                    "cancelled"
                } else {
                    "paused"
                };
                patch(
                    &core,
                    jid,
                    json!({"requested_state":desired,"state":desired,"resources_released":true,"pause_reason":pause_reason}),
                )
                .await?;
            }
            manage_status(&core).await
        }
        "resume" => {
            let jid = body["id"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("job ID required"))?;
            let data = core.data.read().await;
            let job = data
                .jobs
                .get(jid)
                .ok_or_else(|| anyhow::anyhow!("job not registered"))?;
            ensure!(
                matches!(job["state"].as_str(), Some("paused" | "failed")),
                "job cannot be resumed in its current state"
            );
            drop(data);
            patch(
                &core,
                jid,
                json!({"requested_state":"running","state":"queued"}),
            )
            .await?;
            launch(core.clone(), jid.into()).await?;
            manage_status(&core).await
        }
        _ => bail!("unsupported transfer action"),
    }
}
async fn manage_status(core: &Core) -> Result<Value> {
    Ok(
        json!({"jobs":core.data.read().await.jobs.values().cloned().collect::<Vec<_>>(),"plugin_state":"builtin-rust"}),
    )
}
async fn set(core: &Core, jid: &str, key: &str, value: Value) -> Result<()> {
    let mut data = core.data.write().await;
    let mut next = data.clone();
    let job = next
        .jobs
        .get_mut(jid)
        .ok_or_else(|| anyhow::anyhow!("job not registered"))?;
    job[key] = value;
    core.persist(&next)?;
    *data = next;
    Ok(())
}
async fn launch(core: Arc<Core>, jid: String) -> Result<()> {
    let job = core
        .data
        .read()
        .await
        .jobs
        .get(&jid)
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("job not registered"))?;
    ensure!(
        matches!(
            job["state"].as_str(),
            Some("queued" | "paused" | "failed" | "waiting_for_connection")
        ),
        "job is not resumable"
    );
    let signal = Arc::new(AtomicBool::new(false));
    {
        let mut active = core
            .transfers
            .lock()
            .map_err(|_| anyhow::anyhow!("job lock failed"))?;
        if active.contains_key(&jid) || active.len() >= 4 {
            return Ok(());
        }
        active.insert(jid.clone(), signal.clone());
    }
    if let Err(e) = patch(&core, &jid, json!({"state":"running","resources_released":false,"requested_state":"running","error":""})).await {
        core.transfers
            .lock()
            .map_err(|_| anyhow::anyhow!("job lock failed"))?
            .remove(&jid);
        return Err(e);
    }
    let rt = tokio::runtime::Handle::current();
    // Hashing and disk snapshot work must not block Flutter's FFI or async I/O threads.
    std::thread::spawn(move || {
        let result=rt.block_on(async {
            let operation=run(&core,&jid,&job,&signal);
            tokio::pin!(operation);
            loop {tokio::select! {
                r=&mut operation=>break r,
                _=tokio::time::sleep(Duration::from_millis(100))=>{if signal.load(Ordering::Acquire){break Err(anyhow::anyhow!("paused"));}}
            }}
        });
        rt.block_on(async {
            let _control = core.job_control.lock().await;
            let cancelled = core
                .data
                .read()
                .await
                .jobs
                .get(&jid)
                .is_some_and(|j| j["requested_state"] == "cancelled");
            let (state, error) = match result {
                Ok(_) => ("complete", String::new()),
                Err(e) if signal.load(Ordering::Acquire) => (
                    if cancelled { "cancelled" } else { "paused" },
                    e.to_string(),
                ),
                Err(e) if transient(&e) => ("waiting_for_connection", e.to_string()),
                Err(e) => ("failed", e.to_string()),
            };
            if patch(
                &core,
                &jid,
                json!({"state":state,"error":error,"resources_released":true,"retry_at":crate::state::now()+30_000}),
            )
            .await
            .is_err()
            {
                // Disk-full cannot turn a completed network future into a durable success.
                // Keep the last checkpoint, and expose the uncertain commit in memory.
                if let Some(job) = core.data.write().await.jobs.get_mut(&jid) {
                    job["state"] = json!("recovery_required");
                    job["error"] = json!("final state could not be saved; checkpoint retained");
                    job["resources_released"] = json!(true);
                }
            }
        });
        if let Ok(mut active) = core.transfers.lock() {
            active.remove(&jid);
        }
    });
    Ok(())
}
pub(crate) async fn patch(core: &Core, jid: &str, fields: Value) -> Result<()> {
    let mut data = core.data.write().await;
    let mut next = data.clone();
    let job = next
        .jobs
        .get_mut(jid)
        .ok_or_else(|| anyhow::anyhow!("job not registered"))?;
    for (k, v) in fields
        .as_object()
        .ok_or_else(|| anyhow::anyhow!("job patch must be an object"))?
    {
        job[k] = v.clone();
    }
    core.persist(&next)?;
    *data = next;
    Ok(())
}
pub(crate) fn copy_interruptible(
    input: &mut impl std::io::Read,
    output: &mut impl std::io::Write,
    stop: &AtomicBool,
) -> Result<()> {
    let mut buffer = vec![0u8; 1024 * 1024];
    loop {
        ensure!(!stop.load(Ordering::Acquire), "paused");
        let n = input.read(&mut buffer)?;
        if n == 0 {
            break;
        }
        output.write_all(&buffer[..n])?;
    }
    Ok(())
}
pub(crate) fn file_hash_interruptible(path: &std::path::Path, stop: &AtomicBool) -> Result<String> {
    use sha2::{Digest, Sha256};
    use std::io::Read;
    let mut input = std::fs::File::open(path)?;
    let mut hash = Sha256::new();
    let mut bytes = vec![0u8; 1024 * 1024];
    loop {
        ensure!(
            !stop.load(Ordering::Acquire),
            "hash paused; original and checkpoint retained"
        );
        let n = input.read(&mut bytes)?;
        if n == 0 {
            break;
        }
        hash.update(&bytes[..n]);
    }
    Ok(hex::encode(hash.finalize()))
}
pub(crate) fn source_binding(metadata: &std::fs::Metadata) -> Result<Value> {
    ensure!(metadata.is_file(), "upload source is not a file");
    let modified = metadata
        .modified()?
        .duration_since(std::time::UNIX_EPOCH)?
        .as_nanos()
        .to_string();
    let created = metadata
        .created()
        .ok()
        .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
        .map(|d| d.as_nanos().to_string());
    Ok(json!({"bytes":metadata.len(),"modified":modified,"created":created}))
}
pub fn start_scheduler(core: Arc<Core>) {
    tokio::spawn(async move {
        loop {
            if core.update.draining.load(Ordering::Acquire) {
                tokio::time::sleep(Duration::from_millis(250)).await;
                continue;
            }
            let mut queued = core
                .data
                .read()
                .await
                .jobs
                .values()
                .filter(|j| {
                    (j["state"] == "queued"
                        || (j["state"] == "waiting_for_connection"
                            && j["retry_at"].as_u64().unwrap_or(0) <= crate::state::now()))
                        && j["requested_state"] == "running"
                })
                .map(|j| {
                    (
                        j["created_at"].as_u64().unwrap_or(0),
                        j["id"].as_str().unwrap_or("").to_owned(),
                    )
                })
                .collect::<Vec<_>>();
            queued.sort();
            for (_, id) in queued {
                let _control = core.job_control.lock().await;
                let _ = launch(core.clone(), id).await;
            }
            tokio::time::sleep(Duration::from_secs(1)).await;
        }
    });
}
async fn run(core: &Core, jid: &str, job: &Value, stop: &AtomicBool) -> Result<Value> {
    if job["kind"] == "peer-s3" {
        return crate::peer_jobs::run(core, jid, job, stop).await;
    }
    let work = core.root.join("transfers").join(jid);
    let mut cfg = crate::storage::config(
        core,
        job["connection_id"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("connection required"))?,
        job["root"].as_str().unwrap_or(""),
        work.clone(),
    )
    .await?;
    cfg.options.insert(
        "path".into(),
        job["key"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("file path required"))?
            .into(),
    );
    cfg.options.insert(
        "expected_sha256".into(),
        job["expected_sha256"].as_str().unwrap_or("").into(),
    );
    if job["direction"] == "upload" {
        let source = PathBuf::from(
            job["source"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("source required"))?,
        );
        let snapshot = work.join("source.snapshot");
        if !snapshot.exists() {
            let temp = work.join("source.preparing");
            let mut input = std::fs::OpenOptions::new();
            input.read(true);
            #[cfg(windows)]
            {
                use std::os::windows::fs::OpenOptionsExt;
                input.share_mode(1);
            }
            let mut input = input.open(source)?;
            ensure!(input.metadata()?.is_file(), "source is not a file");
            ensure!(
                source_binding(&input.metadata()?)? == job["source_binding"],
                "source changed before snapshot; original retained"
            );
            let mut output = std::fs::OpenOptions::new()
                .create(true)
                .truncate(true)
                .write(true)
                .open(&temp)?;
            copy_interruptible(&mut input, &mut output, stop)?;
            ensure!(
                source_binding(&input.metadata()?)? == job["source_binding"],
                "source changed while snapshotting; original retained"
            );
            output.sync_all()?;
            drop(output);
            std::fs::rename(temp, &snapshot)?;
        }
        cfg.options
            .insert("source".into(), snapshot.to_string_lossy().into());
        set(core, jid, "total_bytes", json!(snapshot.metadata()?.len())).await?;
        let result = crate::stream::upload(&cfg).await?;
        ensure!(
            result["completed"] == true || result["complete"] == true,
            "upload not committed; checkpoint retained"
        );
        let sha = crate::jobs::file_hash_interruptible(&snapshot, stop)?;
        set(core, jid, "sha256", json!(sha)).await?;
        set(
            core,
            jid,
            "completed_bytes",
            json!(snapshot.metadata()?.len()),
        )
        .await?;
        Ok(result)
    } else {
        let op = cfg.operator()?;
        let size = op.stat(cfg.get("path")).await?.content_length();
        set(core, jid, "total_bytes", json!(size)).await?;
        let result = crate::engine::download(&cfg, &op).await?;
        ensure!(
            result["completed"] == true || result["complete"] == true,
            "download not complete; checkpoint retained"
        );
        let part = work.join("download.part");
        let destination = PathBuf::from(
            job["destination"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("destination required"))?,
        );
        let digest = crate::jobs::file_hash_interruptible(&part, stop)?;
        let receipt = work.join("publication.json");
        let expected = json!({"job":jid,"destination":destination,"sha256":digest,"bytes":size});
        if destination.exists() {
            ensure!(
                receipt.exists()
                    && serde_json::from_slice::<Value>(&std::fs::read(&receipt)?)? == expected
                    && destination.metadata()?.len() == size
                    && crate::jobs::file_hash_interruptible(&destination, stop)? == digest,
                "destination exists; original is preserved"
            );
        } else {
            let name = destination
                .file_name()
                .ok_or_else(|| anyhow::anyhow!("destination file name required"))?
                .to_string_lossy();
            let staging = destination.with_file_name(format!(
                ".{name}.{jid}.{}.partial",
                uuid::Uuid::new_v4().simple()
            ));
            let mut output = std::fs::OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(&staging)?;
            let mut input = std::fs::File::open(&part)?;
            copy_interruptible(&mut input, &mut output, stop)?;
            output.sync_all()?;
            drop(output);
            ensure!(
                crate::jobs::file_hash_interruptible(&staging, stop)? == digest,
                "destination copy checksum failed; recovery data retained"
            );
            crate::identity::atomic(&receipt, &serde_json::to_vec(&expected)?)?;
            #[cfg(windows)]
            {
                use std::os::windows::ffi::OsStrExt;
                use windows_sys::Win32::Storage::FileSystem::{
                    MOVEFILE_WRITE_THROUGH, MoveFileExW,
                };
                let a: Vec<u16> = staging.as_os_str().encode_wide().chain(Some(0)).collect();
                let b: Vec<u16> = destination
                    .as_os_str()
                    .encode_wide()
                    .chain(Some(0))
                    .collect();
                ensure!(
                    unsafe { MoveFileExW(a.as_ptr(), b.as_ptr(), MOVEFILE_WRITE_THROUGH) } != 0,
                    "destination publication failed; original and staging retained"
                );
            }
            #[cfg(not(windows))]
            {
                std::fs::hard_link(&staging, &destination)?;
                std::fs::remove_file(staging)?;
            }
        }
        set(core, jid, "sha256", json!(digest)).await?;
        set(core, jid, "completed_bytes", json!(size)).await?;
        Ok(result)
    }
}

fn transient(error: &anyhow::Error) -> bool {
    error.chain().any(|e| {
        e.downcast_ref::<crate::relay::Failure>().is_some_and(|e| {
            matches!(
                e,
                crate::relay::Failure::Offline | crate::relay::Failure::Capacity
            )
        }) || e.is::<crate::provider_http::Unavailable>()
            || e.downcast_ref::<opendal::Error>()
                .is_some_and(|e| e.is_temporary())
            || e.downcast_ref::<reqwest::Error>()
                .is_some_and(|e| e.is_connect() || e.is_timeout())
    })
}
