//! Product API implementation in this process. Unsupported work never forwards to Go.
use crate::state::{Connection, Core, id};
use anyhow::{Result, bail, ensure};
use serde_json::{Value, json};
use std::{collections::HashMap, sync::Arc};
fn required<'a>(b: &'a Value, k: &str) -> Result<&'a str> {
    b[k].as_str()
        .filter(|s| !s.is_empty())
        .ok_or_else(|| anyhow::anyhow!("{k} required"))
}

pub async fn dispatch(core: Arc<Core>, method: &str, body: Value) -> Result<Value> {
    if core
        .update
        .draining
        .load(std::sync::atomic::Ordering::Acquire)
    {
        ensure!(
            !matches!(
                method,
                "StartSignIn"
                    | "AddConnection"
                    | "RemoveConnection"
                    | "SaveDrive"
                    | "MountDrive"
                    | "DeleteDrive"
                    | "WriteDriveText"
                    | "CreateDriveFolder"
                    | "RetryUploads"
                    | "SaveSettings"
                    | "InstallDriveDriver"
            ),
            "safe restart is preparing; try again after restart"
        );
        if matches!(
            method,
            "ManageTransfers" | "ManageS3Browser" | "ManageTeamShare" | "ManageProfile"
        ) {
            ensure!(
                matches!(
                    body["action"].as_str(),
                    Some(
                        "status"
                            | "cloud_status"
                            | "member_status"
                            | "member_config"
                            | "pause"
                            | "cancel"
                            | "cloud_pause"
                            | "member_logout"
                            | "stop"
                            | "revoke-access"
                            | "reject-access"
                    )
                ),
                "safe restart is preparing; try again after restart"
            );
        }
    }
    match method {
        "GetStatus" => {
            let data = core.data.read().await;
            Ok(
                json!({"version":crate::VERSION,"engine":"rust","transport":"direct-ffi","data_dir":core.root,"started_unix":core.started/1000,"node":data.node,"go":false,"rclone":false,"pid":std::process::id(),"mounted_drives":core.mounts.lock().map(|m|m.len()).unwrap_or(0),"active_transfers":core.transfers.lock().map(|m|m.len()).unwrap_or(0),"active_peer_leases":core.leases.active(),"capabilities":crate::capabilities()}),
            )
        }
        "GetDriverStatus" => Ok(crate::driver::status()),
        "InstallDriveDriver" => crate::driver::install(),
        "ExportDiagnostics" => crate::diagnostics::export(&core).await,
        "GetCoreCapabilities" => Ok(crate::capabilities()),
        "GetSettings" => Ok(core.settings().await),
        "SaveSettings" => {
            if let Some(alias) = body.get("device_alias") {
                ensure!(
                    alias
                        .as_str()
                        .is_some_and(|s| s.len() <= 256 && !s.chars().any(char::is_control)),
                    "invalid device alias"
                );
            }
            let mut data = core.data.write().await;
            let mut next = data.clone();
            for key in ["language", "device_alias"] {
                if let Some(v) = body.get(key) {
                    next.settings[key] = v.clone();
                }
            }
            core.persist(&next)?;
            *data = next;
            drop(data);
            Ok(core.settings().await)
        }
        "ListProviders" => Ok(providers()),
        "ListConnections" => Ok(
            json!({"connections":core.data.read().await.connections.values().map(Connection::public).collect::<Vec<_>>()}),
        ),
        "AddConnection" => add_connection(&core, body).await,
        "RemoveConnection" => {
            let _control = core.drive_control.lock().await;
            let cid = required(&body, "id")?;
            let mut data = core.data.write().await;
            ensure!(
                !data.drives.values().any(|d| d["members"]
                    .as_array()
                    .is_some_and(|ms| ms.iter().any(|m| m["connection_id"] == cid))),
                "connection is referenced by a drive"
            );
            ensure!(
                !data
                    .jobs
                    .values()
                    .any(|j| j["connection_id"] == cid && j["state"] != "complete"),
                "connection has unfinished transfers"
            );
            let mut next = data.clone();
            ensure!(
                next.connections.remove(cid).is_some(),
                "connection not registered"
            );
            core.persist(&next)?;
            *data = next;
            Ok(json!({}))
        }
        "TestConnection" => {
            let cid = required(&body, "id")?;
            let cfg = crate::storage::config(
                &core,
                cid,
                body["remote_path"].as_str().unwrap_or(""),
                core.root.join("probes").join(cid),
            )
            .await?;
            let op = cfg.operator()?;
            let start = std::time::Instant::now();
            op.list("/").await?;
            // Listing is read-only. No silent write/delete probe during login.
            Ok(
                json!({"ok":true,"list_ms":start.elapsed().as_millis(),"can_write":false,"protection":"unverified","engine":"rust","write_probe_required":true,"protection_text":if cfg.provider=="onedrive"{"일반 파일·폴더만 디스크에 표시합니다. 공유 바로 가기·OneNote 등 특수 항목은 아직 지원하지 않으며 OneDrive 웹에서 확인할 수 있습니다."}else{""}}),
            )
        }
        "StartSignIn" => crate::auth::start(core, body).await,
        "FinishSignIn" => crate::auth::finish(&core, required(&body, "id")?).await,
        "CancelSignIn" => crate::auth::cancel(&core, required(&body, "id")?).await,
        "ListDrives" => {
            let mut drives = core
                .data
                .read()
                .await
                .drives
                .values()
                .cloned()
                .collect::<Vec<_>>();
            let mounts = core
                .mounts
                .lock()
                .map_err(|_| anyhow::anyhow!("mount state failed"))?;
            for d in &mut drives {
                if let Some(m) = mounts.get(d["id"].as_str().unwrap_or("")) {
                    d["pending_uploads"] = json!(m.pending()?);
                }
            }
            Ok(json!({"drives":drives}))
        }
        "SaveDrive" => save_drive(&core, body).await,
        "DeleteDrive" => {
            let _control = core.drive_control.lock().await;
            let did = required(&body, "id")?;
            ensure!(
                !core
                    .mounts
                    .lock()
                    .map_err(|_| anyhow::anyhow!("mount state failed"))?
                    .contains_key(did),
                "unmount drive first"
            );
            ensure!(
                crate::storage::pending_disk(&core, did).await? == 0,
                "pending journal prevents deletion"
            );
            let mut data = core.data.write().await;
            let mut next = data.clone();
            ensure!(next.drives.remove(did).is_some(), "drive not registered");
            core.persist(&next)?;
            *data = next;
            Ok(json!({}))
        }
        "MountDrive" => crate::storage::mount(core.clone(), required(&body, "id")?).await,
        "UnmountDrive" => {
            crate::storage::unmount(core.clone(), required(&body, "id")?, false).await
        }
        "ListDriveLetters" => Ok(json!({"free":crate::storage::free_letters()})),
        "ListDriveFiles" | "ReadDriveText" | "WriteDriveText" | "CreateDriveFolder" => {
            crate::storage::files(core, method, body).await
        }
        "ListUploads" | "RetryUploads" => {
            let did = required(&body, "id")?;
            let engines = core
                .mounts
                .lock()
                .map_err(|_| anyhow::anyhow!("mount state failed"))?
                .get(did)
                .map(|m| m.engines())
                .ok_or_else(|| anyhow::anyhow!("Rust drive not mounted"))?;
            if method == "RetryUploads" {
                let mut results = Vec::new();
                for e in engines {
                    results.push(
                        tokio::task::spawn_blocking(move || crate::runtime().block_on(e.recover()))
                            .await??,
                    );
                }
                return Ok(json!({"results":results}));
            }
            let mut uploads = Vec::new();
            for e in engines {
                for entry in std::fs::read_dir(e.cfg.work.join("journal"))? {
                    let path = entry?.path();
                    if path.extension().is_some_and(|s| s == "json") {
                        let r: crate::v2::Record = serde_json::from_slice(&std::fs::read(path)?)?;
                        uploads.push(json!({"connection_id":e.cfg.get("connection_id"),"path":r.path,"bytes":r.bytes,"state":if r.ready{"pending"}else{"open"}}));
                    }
                }
            }
            Ok(json!({"uploads":uploads}))
        }
        "ListConflicts" => {
            let drives = core
                .data
                .read()
                .await
                .drives
                .values()
                .cloned()
                .collect::<Vec<_>>();
            let mut conflicts = Vec::new();
            for drive in drives {
                let id = required(&drive, "id")?;
                let members = drive["members"]
                    .as_array()
                    .ok_or_else(|| anyhow::anyhow!("drive members missing"))?;
                for (index, member) in members.iter().enumerate() {
                    let root = core.root.join("mounts").join(id);
                    let conflicts_dir = if members.len() == 1 {
                        root
                    } else {
                        root.join(format!("member-{index}"))
                    }
                    .join("conflicts");
                    if !conflicts_dir.exists() {
                        continue;
                    }
                    for e in std::fs::read_dir(conflicts_dir)? {
                        let e = e?;
                        if e.path().extension().is_some_and(|s| s == "json") {
                            ensure!(
                                e.metadata()?.len() <= 1024 * 1024,
                                "conflict record exceeds limit"
                            );
                            let r: Value = serde_json::from_slice(&std::fs::read(e.path())?)?;
                            ensure!(
                                conflicts.len() < 4096,
                                "conflict listing capacity exceeded; records preserved"
                            );
                            conflicts.push(json!({"id":format!("{id}/{index}/{}",e.file_name().to_string_lossy()),"drive_id":id,"connection_id":member["connection_id"],"folder":member["folder"],"path":r["path"],"bytes":r["bytes"],"sha256":r["sha256"]}));
                        }
                    }
                }
            }
            Ok(json!({"conflicts":conflicts}))
        }
        "ManageTransfers" => crate::jobs::manage(core, body).await,
        "ManageProfile" => profile(&core, body).await,
        "ManageTeamShare" => crate::sharing::manage(core, body).await,
        "ManageS3Browser" => crate::peer_jobs::manage(core, body).await,
        "ManageDownloads" | "ManageUpdate" => crate::update::manage(core, body).await,
        "AcknowledgeStartup" => crate::update::acknowledge(),
        _ => bail!(
            "operation {method} is not implemented in the direct Rust core; no legacy forwarding"
        ),
    }
}
async fn add_connection(core: &Core, body: Value) -> Result<Value> {
    let catalog = required(&body, "catalog_id")?;
    ensure!(
        catalog == "s3",
        "use separate OAuth for cloud file accounts"
    );
    let values: HashMap<String, String> =
        serde_json::from_value(body.get("values").cloned().unwrap_or(json!({})))?;
    let mut conn = Connection {
        id: id("connection"),
        name: body["connection"]["name"].as_str().unwrap_or("S3").into(),
        provider: "s3".into(),
        preset: String::new(),
        options: HashMap::new(),
        secrets: HashMap::new(),
    };
    for key in ["endpoint", "region", "bucket"] {
        let v = values
            .get(key)
            .filter(|s| !s.is_empty())
            .ok_or_else(|| anyhow::anyhow!("{key} required"))?;
        conn.options.insert(key.into(), v.clone());
    }
    for key in ["access_key_id", "secret_access_key"] {
        let v = values
            .get(key)
            .filter(|s| !s.is_empty())
            .ok_or_else(|| anyhow::anyhow!("{key} required"))?;
        conn.secrets.insert(key.into(), v.clone());
    }
    let cfg = crate::Config {
        provider: "s3".into(),
        root: String::new(),
        options: conn
            .options
            .clone()
            .into_iter()
            .chain(conn.secrets.clone())
            .collect(),
        work: core.root.join("probes").join(&conn.id),
        mode: String::new(),
        mount: String::new(),
    };
    let _ = cfg.operator()?;
    let public = conn.public();
    let mut data = core.data.write().await;
    let mut next = data.clone();
    next.connections.insert(conn.id.clone(), conn);
    core.persist(&next)?;
    *data = next;
    Ok(public)
}
async fn save_drive(core: &Core, mut body: Value) -> Result<Value> {
    let _control = core.drive_control.lock().await;
    let did = body["id"]
        .as_str()
        .filter(|s| !s.is_empty())
        .map(str::to_owned)
        .unwrap_or_else(|| id("drive"));
    ensure!(
        did.starts_with("drive-") && did.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-'),
        "invalid Rust drive ID"
    );
    ensure!(
        !core
            .mounts
            .lock()
            .map_err(|_| anyhow::anyhow!("mount state failed"))?
            .contains_key(&did),
        "unmount before reconfiguring"
    );
    let members = body["members"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("drive members required"))?;
    ensure!(!members.is_empty(), "select a file connection");
    let mut names = std::collections::HashSet::new();
    for member in members {
        let c = core.connection(required(member, "connection_id")?).await?;
        ensure!(c.preset != "profile", "profile storage is not a file drive");
        crate::engine::checked(member["remote_path"].as_str().unwrap_or(""))?;
        if members.len() > 1 {
            let name = required(member, "folder")?;
            ensure!(
                !name.contains(['/', '\\', ':'])
                    && !matches!(name, "." | "..")
                    && names.insert(name.to_lowercase()),
                "duplicate or invalid namespace folder"
            );
        }
    }
    let target = if let Some(t) = body["target"].as_str().filter(|s| !s.is_empty()) {
        t.to_ascii_uppercase()
    } else {
        let data = core.data.read().await;
        crate::storage::free_letters()
            .into_iter()
            .find(|letter| !data.drives.values().any(|d| d["target"] == *letter))
            .ok_or_else(|| anyhow::anyhow!("사용 가능한 드라이브 문자가 없습니다."))?
    };
    ensure!(
        target.len() == 2
            && target.ends_with(':')
            && target.as_bytes()[0].is_ascii_uppercase()
            && !"ACDPXZ".contains(&target[..1]),
        "reserved or invalid drive letter"
    );
    body["id"] = json!(did);
    body["target"] = json!(target);
    body["mounted"] = json!(false);
    body["engine"] = json!("rust");
    let mut data = core.data.write().await;
    ensure!(
        !data
            .drives
            .iter()
            .any(|(other, d)| other != &did && d["target"] == target),
        "letter is already reserved"
    );
    let mut next = data.clone();
    next.drives.insert(did, body.clone());
    core.persist(&next)?;
    *data = next;
    Ok(body)
}
async fn profile(core: &Core, body: Value) -> Result<Value> {
    match body["action"].as_str().unwrap_or("status") {
        "member_config" => {
            let mut cfg = crate::auth::member_request(
                "https://console.sigmadrive.net",
                reqwest::Method::GET,
                "config",
                "",
                None,
            )
            .await?;
            cfg["membershipEndpoint"] = json!("https://console.sigmadrive.net");
            Ok(json!({"export_data":cfg.to_string()}))
        }
        "member_status" => {
            let mut member = core
                .data
                .read()
                .await
                .member
                .clone()
                .unwrap_or(json!({"signedIn":false}));
            if let Some(o) = member.as_object_mut() {
                o.remove("credential");
            }
            Ok(json!({"export_data":member.to_string()}))
        }
        "member_logout" => {
            core.desk.clear_http();
            core.desk.stop_all();
            core.auth_epoch
                .fetch_add(1, std::sync::atomic::Ordering::AcqRel);
            for flow in core.flows.lock().await.values() {
                flow.canceled
                    .store(true, std::sync::atomic::Ordering::Release);
            }
            crate::sharing::stop_all(core).await;
            let (old, node) = {
                let mut d = core.data.write().await;
                let old = d.member.clone();
                let node = d.share_identity.as_ref().map(|i| i["node"].clone());
                let mut next = d.clone();
                next.member = None;
                let saved = core.persist(&next);
                *d = next;
                core.desk.clear_http();
                saved?;
                (old, node)
            };
            let confirmed = if let Some(old) = old {
                crate::auth::member_request(
                    old["endpoint"].as_str().unwrap_or(""),
                    reqwest::Method::POST,
                    "logout",
                    old["credential"].as_str().unwrap_or(""),
                    Some(json!({"node":node.unwrap_or(Value::Null)})),
                )
                .await
                .is_ok()
            } else {
                true
            };
            Ok(json!({"signed_out":true,"server_confirmed":confirmed}))
        }
        "member_portal_status" => crate::portal::manage(core, false).await,
        "member_portal_open" => crate::portal::manage(core, true).await,
        "status" => Ok(
            json!({"profiles":[{"id":"rust-local","name":"이 Windows 사용자의 개인 설정"}],"current":"rust-local","current_id":"rust-local","engine":"rust"}),
        ),
        action if action.starts_with("cloud_") => crate::profile::manage(core, &body).await,
        _ => bail!(
            "Rust personal-profile operation not complete; existing profile is preserved separately"
        ),
    }
}
fn field(key: &str, name: &str, secret: bool) -> Value {
    json!({"key":key,"label":name,"required":true,"secret":secret,"kind":if secret{"password"}else{"text"}})
}
fn providers() -> Value {
    json!({"providers":[
        {"id":"drive","backend":"drive","name":"Google Drive","group":"drive","auth":"oauth","fields":[field("client_id","Client ID",false),field("client_secret","Client secret",true)]},
        {"id":"onedrive","backend":"onedrive","name":"OneDrive","group":"drive","auth":"oauth","fields":[field("client_id","Client ID",false)]},
        {"id":"s3","backend":"s3","name":"S3","group":"object","auth":"keys","fields":[field("endpoint","HTTPS endpoint",false),field("region","Region",false),field("bucket","Bucket",false),field("access_key_id","Access key",true),field("secret_access_key","Secret key",true)]}
    ]})
}
