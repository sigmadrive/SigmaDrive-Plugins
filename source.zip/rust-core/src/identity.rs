//! OS token identity and private state. No legacy profile or token import.
use anyhow::{Result, ensure};
use std::path::{Path, PathBuf};
#[cfg(windows)]
#[path = "identity_windows.rs"]
mod windows;
#[cfg(windows)]
pub use windows::{
    PRIVATE_STATE_DIRECTORY, current_sid, protect_own_local_directory, same_process_user,
};

#[cfg(windows)]
pub fn root() -> Result<PathBuf> {
    use std::{os::windows::ffi::OsStringExt, ptr::null_mut};
    use windows_sys::Win32::{
        System::Com::CoTaskMemFree,
        UI::Shell::{FOLDERID_LocalAppData, SHGetKnownFolderPath},
    };
    let mut raw = null_mut();
    ensure!(
        unsafe { SHGetKnownFolderPath(&FOLDERID_LocalAppData, 0, null_mut(), &mut raw) } >= 0
            && !raw.is_null(),
        "private KnownFolder unavailable"
    );
    let n = (0..).take_while(|i| unsafe { *raw.add(*i) } != 0).count();
    let path = PathBuf::from(std::ffi::OsString::from_wide(unsafe {
        std::slice::from_raw_parts(raw, n)
    }))
    .join(PRIVATE_STATE_DIRECTORY);
    unsafe { CoTaskMemFree(raw.cast()) };
    create_root_private(&path)?;
    private(&path)?;
    Ok(path)
}

#[cfg(windows)]
fn create_root_private(path: &Path) -> Result<()> {
    use std::os::windows::ffi::OsStrExt;
    use windows_sys::Win32::{
        Foundation::{ERROR_ALREADY_EXISTS, GetLastError, LocalFree},
        Security::{
            Authorization::ConvertStringSecurityDescriptorToSecurityDescriptorW,
            SECURITY_ATTRIBUTES,
        },
        Storage::FileSystem::CreateDirectoryW,
    };
    let sid = current_sid()?;
    let sddl: Vec<u16> = format!("O:{sid}D:P(A;OICI;FA;;;{sid})")
        .encode_utf16()
        .chain(Some(0))
        .collect();
    let mut descriptor = std::ptr::null_mut();
    ensure!(
        unsafe {
            ConvertStringSecurityDescriptorToSecurityDescriptorW(
                sddl.as_ptr(),
                1,
                &mut descriptor,
                std::ptr::null_mut(),
            )
        } != 0,
        "private directory security descriptor unavailable"
    );
    let attributes = SECURITY_ATTRIBUTES {
        nLength: std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,
        lpSecurityDescriptor: descriptor,
        bInheritHandle: 0,
    };
    let name: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();
    let result = unsafe { CreateDirectoryW(name.as_ptr(), &attributes) };
    let error = unsafe { GetLastError() };
    unsafe { LocalFree(descriptor) };
    ensure!(
        result != 0 || error == ERROR_ALREADY_EXISTS,
        "cannot atomically create private Rust core directory"
    );
    Ok(())
}
#[cfg(not(windows))]
pub fn root() -> Result<PathBuf> {
    anyhow::bail!("OS credential store and user directory gate not implemented for this OS")
}

pub fn private(path: &Path) -> Result<()> {
    // Check every existing ancestor before creating children; never follow a reparse point.
    for p in path.ancestors() {
        if let Ok(m) = std::fs::symlink_metadata(p) {
            ensure!(
                m.is_dir() && !m.file_type().is_symlink(),
                "private directory is not a real directory"
            );
            #[cfg(windows)]
            {
                use std::os::windows::fs::MetadataExt;
                ensure!(
                    m.file_attributes() & 0x400 == 0,
                    "private directory reparse denied"
                );
            }
        }
    }
    std::fs::create_dir_all(path)?;
    #[cfg(windows)]
    protect_own_local_directory(path)?;
    #[cfg(not(windows))]
    anyhow::bail!("OS private store unavailable");
    Ok(())
}

pub fn atomic(path: &Path, bytes: &[u8]) -> Result<()> {
    use std::io::Write;
    let tmp = path.with_extension(format!("{}.tmp", uuid::Uuid::new_v4()));
    let mut f = std::fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(&tmp)?;
    f.write_all(bytes)?;
    f.sync_all()?;
    drop(f);
    #[cfg(windows)]
    {
        use std::os::windows::ffi::OsStrExt;
        use windows_sys::Win32::Storage::FileSystem::{
            MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, MoveFileExW,
        };
        let a: Vec<u16> = tmp.as_os_str().encode_wide().chain(Some(0)).collect();
        let b: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();
        if unsafe {
            MoveFileExW(
                a.as_ptr(),
                b.as_ptr(),
                MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH,
            )
        } == 0
        {
            return Err(std::io::Error::last_os_error().into());
        }
    }
    #[cfg(not(windows))]
    {
        std::fs::rename(tmp, path)?;
        std::fs::File::open(
            path.parent()
                .ok_or_else(|| anyhow::anyhow!("parent unavailable"))?,
        )?
        .sync_all()?;
    }
    Ok(())
}
pub fn seal(bytes: &[u8]) -> Result<Vec<u8>> {
    crate::cloud::protect(bytes, true)
}
pub fn unseal(bytes: &[u8]) -> Result<Vec<u8>> {
    crate::cloud::protect(bytes, false)
}
