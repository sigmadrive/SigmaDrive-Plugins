//! Only app registration defaults, never account OAuth/refresh tokens.
use serde::Deserialize;
use serde_json::{Value, json};

#[derive(Deserialize, Default)]
#[serde(deny_unknown_fields)]
pub struct Registration {
    pub client_id: String,
    #[serde(default)]
    pub client_secret: String,
}
#[derive(Deserialize, Default)]
#[serde(deny_unknown_fields)]
pub struct Registrations {
    #[serde(default)]
    pub drive: Option<Registration>,
    #[serde(default)]
    pub onedrive: Option<Registration>,
}

fn location() -> Result<std::path::PathBuf, String> {
    if let Some(path) = std::env::var_os("SIGMA_FLUTTER_REGISTRATION_FILE") {
        return Ok(path.into());
    }
    crate::identity::root()
        .map(|p| p.join("app-registration.dpapi"))
        .map_err(|e| e.to_string())
}

pub fn load() -> Result<Registrations, String> {
    let path = location()?;
    if !path.exists() {
        if let Some(public_path) = std::env::var_os("SIGMA_FLUTTER_PUBLIC_REGISTRATION") {
            let raw =
                std::fs::read(public_path).map_err(|_| "공개 앱 등록 설정을 읽을 수 없습니다.")?;
            if raw.len() > 16384 {
                return Err("공개 앱 등록 설정 크기가 잘못되었습니다.".into());
            }
            let public: Registrations = serde_json::from_slice(&raw)
                .map_err(|_| "공개 앱 등록 설정 형식이 잘못되었습니다.")?;
            if public.drive.is_some()
                || public
                    .onedrive
                    .as_ref()
                    .is_some_and(|r| !r.client_secret.is_empty())
            {
                return Err("공개 설정에는 Microsoft public client ID만 허용합니다.".into());
            }
            return Ok(public);
        }
        let packaged = std::env::current_exe()
            .map_err(|_| "설치 경로를 확인하지 못했습니다.")?
            .parent()
            .ok_or("설치 경로 없음")?
            .join("public-oauth.json");
        if packaged.is_file() {
            let raw = std::fs::read(&packaged).map_err(|_| "공개 앱 등록을 읽지 못했습니다.")?;
            if raw.len() > 16384 {
                return Err("공개 앱 등록 크기 제한".into());
            }
            let v: Value = serde_json::from_slice(&raw).map_err(|_| "공개 앱 등록 형식 오류")?;
            if !v.as_object().is_some_and(|o| {
                o.keys().all(|k| {
                    matches!(
                        k.as_str(),
                        "schema" | "purpose" | "google_client_type" | "registrations"
                    )
                })
            }) || v["schema"] != 1
                || v["purpose"] != "desktop-public-oauth"
            {
                return Err("공개 앱 등록 용도 오류".into());
            }
            if !v["registrations"].is_object() {
                return Err("공개 앱 등록 없음".into());
            }
            let public: Registrations = serde_json::from_value(v["registrations"].clone())
                .map_err(|_| "공개 앱 등록 형식 오류")?;
            if public
                .drive
                .as_ref()
                .is_some_and(|r| !r.client_secret.is_empty())
            {
                return Err("공개 Google 등록에는 비밀키를 넣을 수 없습니다.".into());
            }
            if public
                .onedrive
                .as_ref()
                .is_some_and(|c| !c.client_secret.is_empty())
            {
                return Err("Microsoft public client에는 비밀키를 넣을 수 없습니다.".into());
            }
            if public.drive.is_some() && v["google_client_type"] != "installed" {
                return Err("Google Desktop 등록만 배포할 수 있습니다.".into());
            }
            return Ok(public);
        }
        return Ok(Registrations::default());
    }
    let sealed = std::fs::read(path).map_err(|_| "앱 등록 설정을 읽을 수 없습니다.")?;
    if sealed.len() > 1024 * 1024 {
        return Err("앱 등록 설정 크기가 잘못되었습니다.".into());
    }
    let plain = unseal(&sealed)?;
    serde_json::from_slice(&plain).map_err(|_| "앱 등록 설정 형식이 잘못되었습니다.".into())
}

pub fn options() -> Result<Value, String> {
    let settings = load()?;
    Ok(json!({"registrations":[
        {"catalog_id":"drive", "client_id":settings.drive.as_ref().map(|r|r.client_id.clone()), "configured":settings.drive.as_ref().is_some_and(|r| !r.client_id.is_empty())},
        {"catalog_id":"onedrive", "client_id":settings.onedrive.as_ref().map(|r|r.client_id.clone()), "configured":settings.onedrive.as_ref().is_some_and(|r| !r.client_id.is_empty())}
    ]}))
}

pub fn fill_defaults(body: &mut Value) -> Result<(), String> {
    let catalog = body["catalog_id"].as_str().unwrap_or("");
    let backend = match catalog {
        "drive" | "profile-google" => "drive",
        "onedrive" | "profile-onedrive" => "onedrive",
        _ => return Ok(()),
    };
    if !body["connection"]["id"].as_str().unwrap_or("").is_empty() {
        return Ok(());
    }
    let empty = json!({});
    let values = body.get("values").unwrap_or(&empty);
    if ["client_secret", "source_connection"]
        .iter()
        .any(|key| !values[*key].as_str().unwrap_or("").is_empty())
    {
        return Ok(());
    }
    let settings = load()?;
    let registration = if backend == "drive" {
        settings.drive
    } else {
        settings.onedrive
    };
    if let Some(r) = registration {
        let chosen = values["client_id"].as_str().unwrap_or("");
        if !chosen.is_empty() && chosen != r.client_id {
            return Ok(());
        }
        if body.get("values").is_none() {
            body["values"] = json!({});
        }
        body["values"]["client_id"] = json!(r.client_id);
        if !r.client_secret.is_empty() {
            body["values"]["client_secret"] = json!(r.client_secret);
        }
    }
    Ok(())
}

#[cfg(windows)]
fn unseal(bytes: &[u8]) -> Result<Vec<u8>, String> {
    use windows_sys::Win32::{
        Foundation::LocalFree,
        Security::Cryptography::{
            CRYPT_INTEGER_BLOB, CRYPTPROTECT_UI_FORBIDDEN, CryptUnprotectData,
        },
    };
    let input = CRYPT_INTEGER_BLOB {
        cbData: bytes.len() as u32,
        pbData: bytes.as_ptr() as *mut u8,
    };
    let mut output: CRYPT_INTEGER_BLOB = unsafe { std::mem::zeroed() };
    if unsafe {
        CryptUnprotectData(
            &input,
            std::ptr::null_mut(),
            std::ptr::null(),
            std::ptr::null(),
            std::ptr::null(),
            CRYPTPROTECT_UI_FORBIDDEN,
            &mut output,
        )
    } == 0
    {
        return Err("이 Windows 사용자로 앱 등록 설정을 열 수 없습니다.".into());
    }
    let plain =
        unsafe { std::slice::from_raw_parts(output.pbData, output.cbData as usize) }.to_vec();
    unsafe {
        LocalFree(output.pbData.cast());
    }
    Ok(plain)
}
#[cfg(not(windows))]
fn unseal(_: &[u8]) -> Result<Vec<u8>, String> {
    Err("이 OS의 앱 등록 보관함을 먼저 연결해야 합니다.".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn explicit_registration_and_profile_source_are_never_overwritten() {
        for mut body in [
            json!({"catalog_id":"drive","values":{"client_id":"custom"}}),
            json!({"catalog_id":"drive","values":{"source_connection":"profile-id"}}),
            json!({"catalog_id":"drive","connection":{"id":"existing"}}),
        ] {
            let before = body.clone();
            fill_defaults(&mut body).unwrap();
            assert_eq!(body, before);
        }
    }
}
