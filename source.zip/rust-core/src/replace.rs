//! Verified provider-specific replacement, never implicit unconditional fallback.
//! Drive v2 enforces commit CAS; OneDrive name-swap is explicitly opted in and
//! keeps the original item/permissions as a backup (NOT same-ID atomic replace).
use crate::{
    Config,
    cloud::{body, protect, send, valid_url},
    engine::{atomic, checked, hash},
    safe::encoded,
    v2::file_hash,
};
use anyhow::{Result, bail, ensure};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    fs::{self, File},
    io::{Read, Seek, SeekFrom},
    time::Duration,
};
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Identity {
    pub id: String,
    pub etag: String,
    pub name: String,
    pub size: u64,
    #[serde(default)]
    pub sha256: String,
}
fn client() -> Result<reqwest::Client> {
    Ok(reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .timeout(Duration::from_secs(180))
        .build()?)
}
fn api(cfg: &Config) -> String {
    format!(
        "https://graph.microsoft.com/v1.0/drives/{}",
        encoded(cfg.get("drive_id"))
    )
}
fn request(
    c: &reqwest::Client,
    cfg: &Config,
    m: reqwest::Method,
    url: String,
) -> reqwest::RequestBuilder {
    c.request(m, url)
        .bearer_auth(cfg.get("access_token"))
        .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
}
fn check_cfg(cfg: &Config) -> Result<()> {
    cfg.operator()?;
    ensure!(!checked(cfg.get("path"))?.is_empty(), "file path required");
    ensure!(
        matches!(cfg.provider.as_str(), "drive" | "onedrive"),
        "cloud required"
    );
    Ok(())
}
async fn metadata(c: &reqwest::Client, cfg: &Config, url: String) -> Result<Option<Identity>> {
    let r = send(request(c, cfg, reqwest::Method::GET, url)).await?;
    if r.status().as_u16() == 404 {
        return Ok(None);
    }
    let v = body(r).await?;
    let id = v["id"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("identity missing"))?
        .to_owned();
    let etag = if cfg.provider == "drive" {
        &v["etag"]
    } else {
        &v["eTag"]
    }
    .as_str()
    .ok_or_else(|| anyhow::anyhow!("strong revision missing"))?
    .to_owned();
    let name = if cfg.provider == "drive" {
        &v["title"]
    } else {
        &v["name"]
    }
    .as_str()
    .unwrap_or("")
    .to_owned();
    let size = if cfg.provider == "drive" {
        v["fileSize"]
            .as_str()
            .and_then(|s| s.parse().ok())
            .unwrap_or(0)
    } else {
        v["size"].as_u64().unwrap_or(0)
    };
    Ok(Some(Identity {
        id,
        etag,
        name,
        size,
        sha256: String::new(),
    }))
}
pub async fn by_id(cfg: &Config, id: &str) -> Result<Option<Identity>> {
    let c = client()?;
    metadata(
        &c,
        cfg,
        if cfg.provider == "drive" {
            format!("https://www.googleapis.com/drive/v2/files/{}", encoded(id))
        } else {
            format!("{}/items/{}", api(cfg), encoded(id))
        },
    )
    .await
}
/// Google range reads use the frozen file ID and v2 ETag. OpenDAL's Google
/// metadata omits a strong ETag; size/time alone are not a resume identity.
pub async fn drive_range(
    cfg: &Config,
    identity: &Identity,
    start: u64,
    end: u64,
) -> Result<Vec<u8>> {
    ensure!(
        cfg.provider == "drive"
            && start < end
            && end <= identity.size
            && end - start <= 8 * 1024 * 1024,
        "invalid frozen Google range"
    );
    let client = client()?;
    let response = send(
        request(
            &client,
            cfg,
            reqwest::Method::GET,
            format!(
                "https://www.googleapis.com/drive/v2/files/{}?alt=media",
                encoded(&identity.id)
            ),
        )
        .header("Range", format!("bytes={}-{}", start, end - 1))
        .header("If-Match", &identity.etag)
        .header("Accept-Encoding", "identity"),
    )
    .await?;
    ensure!(
        response.status() == 206,
        "Google conditional range rejected HTTP {}; partial retained",
        response.status().as_u16()
    );
    let expected = format!("bytes {}-{}/{}", start, end - 1, identity.size);
    ensure!(
        response
            .headers()
            .get("Content-Range")
            .and_then(|v| v.to_str().ok())
            == Some(expected.as_str()),
        "Google range revision/length mismatch"
    );
    use futures_util::StreamExt;
    let mut stream = response.bytes_stream();
    let mut bytes = Vec::with_capacity((end - start) as usize);
    while let Some(chunk) = stream.next().await {
        let chunk =
            chunk.map_err(|_| anyhow::anyhow!("Google range interrupted; checkpoint retained"))?;
        ensure!(
            bytes.len() + chunk.len() <= (end - start) as usize,
            "Google range exceeded bound"
        );
        bytes.extend_from_slice(&chunk);
    }
    ensure!(
        bytes.len() as u64 == end - start,
        "short Google range; checkpoint retained"
    );
    Ok(bytes)
}
pub async fn identity(cfg: &Config, p: &str) -> Result<Option<Identity>> {
    checked(p)?;
    cfg.operator()?;
    let c = client()?;
    if cfg.provider == "onedrive" {
        return metadata(
            &c,
            cfg,
            format!(
                "{}/root:/{}",
                api(cfg),
                encoded(&crate::remote_path(&cfg.root, p))
            ),
        )
        .await;
    }
    let full = crate::remote_path(&cfg.root, p);
    let mut parent = "root".to_string();
    for part in full.split('/') {
        let q = format!(
            "'{}' in parents and trashed=false and name='{}'",
            parent.replace('\'', "\\'"),
            part.replace('\\', "\\\\").replace('\'', "\\'")
        );
        let r = send(
            request(
                &c,
                cfg,
                reqwest::Method::GET,
                "https://www.googleapis.com/drive/v3/files".into(),
            )
            .query(&[("q", q.as_str()), ("fields", "files(id),nextPageToken")]),
        )
        .await?;
        let v = body(r).await?;
        let a = v["files"]
            .as_array()
            .ok_or_else(|| anyhow::anyhow!("identity lookup invalid"))?;
        ensure!(
            a.len() <= 1 && v["nextPageToken"].is_null(),
            "ambiguous cloud path; held"
        );
        if a.is_empty() {
            return Ok(None);
        }
        parent = a[0]["id"].as_str().unwrap().to_owned();
    }
    by_id(cfg, &parent).await
}
pub async fn digest_id(cfg: &Config, id: &str) -> Result<String> {
    stream_id(cfg, id, None).await
}
pub async fn stream_id(
    cfg: &Config,
    id: &str,
    destination: Option<&std::path::Path>,
) -> Result<String> {
    for attempt in 0..3 {
        match stream_id_once(cfg, id, destination).await {
            Ok(sha) => return Ok(sha),
            Err(e) if attempt < 2 && retryable_verification(&e.to_string()) => {
                tokio::time::sleep(Duration::from_millis(500 * (attempt + 1))).await;
            }
            Err(e) => return Err(e),
        }
    }
    unreachable!()
}
fn retryable_verification(message: &str) -> bool {
    message.contains("verification stream interrupted")
        || message.contains("cloud transport interrupted")
}
async fn stream_id_once(
    cfg: &Config,
    id: &str,
    destination: Option<&std::path::Path>,
) -> Result<String> {
    use sha2::{Digest, Sha256};
    use std::io::Write;
    // A progressing multi-GiB download must not inherit the metadata request's
    // 180-second wall deadline. Bound connect and inactivity separately.
    let c = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .connect_timeout(Duration::from_secs(15))
        .read_timeout(Duration::from_secs(45))
        .build()?;
    let url = if cfg.provider == "drive" {
        format!(
            "https://www.googleapis.com/drive/v3/files/{}?alt=media",
            encoded(id)
        )
    } else {
        format!("{}/items/{}/content", api(cfg), encoded(id))
    };
    let mut r = send(request(&c, cfg, reqwest::Method::GET, url)).await?;
    for _ in 0..5 {
        if !r.status().is_redirection() {
            break;
        }
        let next = r
            .headers()
            .get("location")
            .and_then(|h| h.to_str().ok())
            .ok_or_else(|| anyhow::anyhow!("download location absent"))?
            .to_owned();
        let u = reqwest::Url::parse(&next)
            .map_err(|_| anyhow::anyhow!("download authority invalid"))?;
        let h = u.host_str().unwrap_or("");
        ensure!(
            u.scheme() == "https"
                && (h.ends_with(".googleusercontent.com")
                    || h.ends_with(".googleapis.com")
                    || h.ends_with(".1drv.com")
                    || h.ends_with(".livefilestore.com")
                    || h.ends_with(".sharepoint.com")
                    || h == "my.microsoftpersonalcontent.com"),
            "download authority held"
        );
        r = send(c.get(next)).await?;
    }
    ensure!(
        r.status().is_success(),
        "verify HTTP {}",
        r.status().as_u16()
    );
    let mut sha = Sha256::new();
    let mut file = destination.map(File::create).transpose()?;
    let mut received = 0u64;
    while let Some(b) = r
        .chunk()
        .await
        .map_err(|_| anyhow::anyhow!("verification stream interrupted"))?
    {
        sha.update(&b);
        received += b.len() as u64;
        if let Some(f) = file.as_mut() {
            f.write_all(&b)?;
        }
        if cfg.get("cut_verify_body_once") == "true"
            && received >= 1024 * 1024
            && !cfg.work.join("verification-body-cut.json").exists()
        {
            atomic(
                &cfg.work.join("verification-body-cut.json"),
                &serde_json::to_vec(
                    &json!({"received_before_cut":received,"response_dropped":true,"global_network_changed":false}),
                )?,
            )?;
            bail!("verification stream interrupted: owned response drop");
        }
        // Hash and cache exactly the same response bytes.
    }
    if let Some(f) = file.as_mut() {
        f.sync_all()?;
    }
    Ok(hex::encode(sha.finalize()))
}
pub async fn verify_path(cfg: &Config, p: &str) -> Result<String> {
    let a = identity(cfg, p)
        .await?
        .ok_or_else(|| anyhow::anyhow!("verify missing object"))?;
    let sha = digest_id(cfg, &a.id).await?;
    let b = by_id(cfg, &a.id)
        .await?
        .ok_or_else(|| anyhow::anyhow!("verify object disappeared"))?;
    ensure!(a.etag == b.etag, "verify concurrent change; held");
    Ok(sha)
}
pub async fn capture(cfg: &Config) -> Result<Identity> {
    check_cfg(cfg)?;
    let mut a = identity(cfg, cfg.get("path"))
        .await?
        .ok_or_else(|| anyhow::anyhow!("replace target missing"))?;
    a.sha256 = digest_id(cfg, &a.id).await?;
    let b = by_id(cfg, &a.id)
        .await?
        .ok_or_else(|| anyhow::anyhow!("replace target missing"))?;
    ensure!(a.etag == b.etag, "capture concurrent change");
    Ok(a)
}
fn same(a: &Identity, b: &Identity) -> bool {
    a.id == b.id && a.etag == b.etag && a.name == b.name && a.size == b.size
}
#[derive(Serialize, Deserialize)]
struct State {
    scope: String,
    source_sha256: String,
    size: u64,
    base: Identity,
    url: String,
    offset: u64,
    phase: String,
    stage: Option<Identity>,
    backup: Option<Identity>,
    stage_path: String,
    backup_name: String,
}
fn save(cfg: &Config, s: &State) -> Result<()> {
    atomic(
        &cfg.work.join("replace.dpapi"),
        &protect(&serde_json::to_vec(s)?, true)?,
    )?;
    atomic(
        &cfg.work.join("replace-progress.json"),
        &serde_json::to_vec(
            &json!({"phase":s.phase,"offset":s.offset,"size":s.size,"source_sha256":s.source_sha256,"original_id":s.base.id,"backup_id":s.backup.as_ref().map(|v|&v.id),"identity_changes":cfg.provider=="onedrive"}),
        )?,
    )
}
async fn rename(cfg: &Config, id: &str, tag: &str, name: &str) -> Result<Identity> {
    let c = client()?;
    let (m, u, v) = if cfg.provider == "drive" {
        (
            reqwest::Method::PATCH,
            format!("https://www.googleapis.com/drive/v2/files/{}", encoded(id)),
            json!({"title":name}),
        )
    } else {
        (
            reqwest::Method::PATCH,
            format!("{}/items/{}", api(cfg), encoded(id)),
            json!({"name":name,"@microsoft.graph.conflictBehavior":"fail"}),
        )
    };
    let r = send(request(&c, cfg, m, u).header("If-Match", tag).json(&v)).await?;
    ensure!(
        r.status().is_success(),
        "conditional rename HTTP {}",
        r.status().as_u16()
    );
    by_id(cfg, id)
        .await?
        .ok_or_else(|| anyhow::anyhow!("rename identity absent"))
}
async fn conflict(cfg: &Config, s: &mut State) -> Result<Value> {
    s.phase = "conflict".into();
    save(cfg, s)?;
    bail!("ConditionNotMatch: source, remote target and backup retained")
}
async fn commit_gate(cfg: &Config) -> Result<()> {
    if cfg.get("wait_before_commit") == "true" {
        atomic(
            &cfg.work.join("before-commit.json"),
            br#"{"qa_only":true,"client_precheck_complete":true}"#,
        )?;
        let end = std::time::Instant::now() + Duration::from_secs(900);
        while !cfg.work.join("continue-commit").exists() {
            ensure!(
                std::time::Instant::now() < end,
                "QA commit gate expired; original retained"
            );
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
    }
    Ok(())
}
pub async fn upload(cfg: &Config) -> Result<Value> {
    check_cfg(cfg)?;
    ensure!(
        !cfg.work.as_os_str().is_empty(),
        "private replacement cache required"
    );
    fs::create_dir_all(&cfg.work)?;
    let source = std::path::Path::new(cfg.get("source"));
    let size = source.metadata()?.len();
    let sha = file_hash(source)?;
    let base: Identity = serde_json::from_str(cfg.get("base_identity"))
        .map_err(|_| anyhow::anyhow!("frozen replacement identity required"))?;
    let scope = hash(&serde_json::to_vec(&(
        cfg.provider.clone(),
        cfg.root.clone(),
        cfg.get("connection_id"),
        cfg.get("drive_id"),
        cfg.get("path"),
        &base.id,
        &base.etag,
    ))?);
    let file = cfg.work.join("replace.dpapi");
    let mut s: State = if file.exists() {
        serde_json::from_slice(&protect(&fs::read(file)?, false)?)?
    } else {
        let parent = cfg
            .get("path")
            .rsplit_once('/')
            .map(|(a, _)| format!("{a}/"))
            .unwrap_or_default();
        State {
            scope: scope.clone(),
            source_sha256: sha.clone(),
            size,
            base: base.clone(),
            url: String::new(),
            offset: 0,
            phase: "uploading".into(),
            stage: None,
            backup: None,
            stage_path: format!("{parent}SigmaDrive-pending-{}.bin", &scope[..24]),
            backup_name: format!("SigmaDrive-backup-{}.bin", &scope[..24]),
        }
    };
    ensure!(
        s.scope == scope && s.size == size && s.source_sha256 == sha && same(&s.base, &base),
        "replacement source/scope changed; retained"
    );
    save(cfg, &s)?;
    if s.phase == "conflict" {
        bail!("ConditionNotMatch: unresolved replacement conflict retained")
    }
    let current = identity(cfg, cfg.get("path")).await?;
    if let Some(ref now) = current
        && now.size == size
        && !same(now, &s.base)
        && (s.phase == "published" || !s.url.is_empty() || s.stage.is_some())
        && digest_id(cfg, &now.id).await? == sha
    {
        s.phase = "published".into();
        s.offset = size;
        save(cfg, &s)?;
        return Ok(
            json!({"completed":true,"completion_reconciled":true,"received_bytes":0,"reused_bytes":size,"sha256":sha,"identity_changes":cfg.provider=="onedrive","backup":s.backup}),
        );
    }
    let c = client()?;
    if cfg.provider == "drive" {
        if current.as_ref().is_none_or(|x| !same(x, &s.base)) {
            return conflict(cfg, &mut s).await;
        }
        if s.url.is_empty() {
            let r = send(
                request(
                    &c,
                    cfg,
                    reqwest::Method::PUT,
                    format!(
                        "https://www.googleapis.com/upload/drive/v2/files/{}?uploadType=resumable",
                        encoded(&s.base.id)
                    ),
                )
                .header("If-Match", &s.base.etag)
                .header("X-Upload-Content-Length", size)
                .header("X-Upload-Content-Type", "application/octet-stream")
                .json(&json!({})),
            )
            .await?;
            if r.status().as_u16() == 412 {
                return conflict(cfg, &mut s).await;
            }
            ensure!(
                r.status().is_success(),
                "conditional init HTTP {}",
                r.status().as_u16()
            );
            s.url = r
                .headers()
                .get("location")
                .and_then(|h| h.to_str().ok())
                .ok_or_else(|| anyhow::anyhow!("replacement session missing"))?
                .to_owned();
            valid_url("drive", &s.url)?;
            save(cfg, &s)?;
        } else {
            valid_url("drive", &s.url)?;
            let r = send(
                c.put(&s.url)
                    .bearer_auth(cfg.get("access_token"))
                    .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
                    .header("If-Match", &s.base.etag)
                    .header("Content-Length", 0)
                    .header("Content-Range", format!("bytes */{size}")),
            )
            .await?;
            if r.status().as_u16() == 412 {
                return conflict(cfg, &mut s).await;
            }
            if r.status().as_u16() == 308 {
                s.offset = match r.headers().get("range") {
                    Some(h) => {
                        h.to_str()?
                            .strip_prefix("bytes=0-")
                            .ok_or_else(|| anyhow::anyhow!("unexpected replacement range"))?
                            .parse::<u64>()?
                            + 1
                    }
                    None => 0,
                };
            } else {
                ensure!(
                    r.status().is_success(),
                    "replacement status HTTP {}; retained",
                    r.status().as_u16()
                );
                s.offset = size;
            }
            ensure!(s.offset <= size, "invalid replacement offset");
            save(cfg, &s)?;
        }
        if size == 0 {
            let r = send(
                c.put(&s.url)
                    .bearer_auth(cfg.get("access_token"))
                    .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
                    .header("If-Match", &s.base.etag)
                    .header("Content-Length", 0)
                    .header("Content-Range", "bytes */0"),
            )
            .await?;
            if r.status().as_u16() == 412 {
                return conflict(cfg, &mut s).await;
            }
            ensure!(
                r.status().is_success(),
                "empty replacement HTTP {}",
                r.status().as_u16()
            );
        }
        let reused = s.offset;
        let mut sent = 0;
        let mut parts = 0;
        let mut f = File::open(source)?;
        f.seek(SeekFrom::Start(s.offset))?;
        while s.offset < size {
            let count = (size - s.offset).min(10 * 1024 * 1024);
            let mut b = vec![0; count as usize];
            f.read_exact(&mut b)?;
            let before = s.offset;
            if before + count == size {
                ensure!(
                    file_hash(source)? == sha,
                    "replacement source changed before commit; original retained"
                );
                commit_gate(cfg).await?;
            }
            if before + count == size && cfg.get("stop_before_commit") == "true" {
                return Ok(
                    json!({"completed":false,"phase":"before_commit","offset":before,"received_bytes":sent,"reused_bytes":reused}),
                );
            }
            let mut req = c
                .put(&s.url)
                .bearer_auth(cfg.get("access_token"))
                .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
                .header("If-Match", &s.base.etag)
                .header("Content-Length", count)
                .header(
                    "Content-Range",
                    format!("bytes {before}-{}/{size}", before + count - 1),
                );
            if cfg.get("cut_body_once") == "true" && !cfg.work.join("body-cut.json").exists() {
                use futures_util::StreamExt;
                let first = b[..b.len().min(65536)].to_vec();
                let stream =
                    futures_util::stream::once(async move { Ok::<_, std::io::Error>(first) })
                        .chain(futures_util::stream::once(async {
                            tokio::time::sleep(Duration::from_secs(1)).await;
                            Err(std::io::Error::new(
                                std::io::ErrorKind::ConnectionAborted,
                                "owned replacement fault",
                            ))
                        }));
                let r = crate::cloud::send(req.body(reqwest::Body::wrap_stream(stream))).await;
                atomic(
                    &cfg.work.join("body-cut.json"),
                    &serde_json::to_vec(
                        &json!({"transport_error":r.is_err(),"partial_body_bytes":65536,"offset":before}),
                    )?,
                )?;
                ensure!(r.is_err(), "partial fault did not interrupt");
                bail!("partial replacement body interrupted; original/source retained");
            }
            req = req.body(b);
            let r = send(req).await?;
            let code = r.status().as_u16();
            if code == 412 {
                return conflict(cfg, &mut s).await;
            }
            ensure!(
                code == 308 || r.status().is_success(),
                "replacement fragment HTTP {code}"
            );
            s.offset = before + count;
            sent += count;
            parts += 1;
            if s.offset == size
                && cfg.get("drop_commit_response_once") == "true"
                && !cfg.work.join("commit-response-dropped").exists()
            {
                atomic(
                    &cfg.work.join("commit-response-dropped"),
                    b"owned response loss",
                )?;
                bail!("replacement commit response lost; reconcile before retry");
            }
            save(cfg, &s)?;
            if cfg.get("stop_after_parts").parse::<u64>().unwrap_or(0) > 0
                && parts >= cfg.get("stop_after_parts").parse::<u64>().unwrap()
                && s.offset < size
            {
                return Ok(
                    json!({"completed":false,"offset":s.offset,"received_bytes":sent,"reused_bytes":reused}),
                );
            }
        }
        ensure!(
            digest_id(cfg, &s.base.id).await? == sha,
            "replacement final SHA mismatch; retained"
        );
        s.phase = "published".into();
        save(cfg, &s)?;
        return Ok(
            json!({"completed":true,"received_bytes":sent,"reused_bytes":reused,"bytes":size,"sha256":sha,"same_id":true,"commit_cas":"Google Drive v2 If-Match"}),
        );
    }
    if size <= 32 * 1024 * 1024 {
        if current.as_ref().is_none_or(|x| !same(x, &s.base)) {
            return conflict(cfg, &mut s).await;
        }
        let r = send(
            request(
                &c,
                cfg,
                reqwest::Method::PUT,
                format!("{}/items/{}/content", api(cfg), encoded(&s.base.id)),
            )
            .header("If-Match", &s.base.etag)
            .header("Content-Length", size)
            .body(fs::read(source)?),
        )
        .await?;
        if r.status().as_u16() == 412 {
            return conflict(cfg, &mut s).await;
        }
        ensure!(
            r.status().is_success(),
            "small replacement HTTP {}",
            r.status().as_u16()
        );
        ensure!(
            digest_id(cfg, &s.base.id).await? == sha,
            "small replacement integrity mismatch"
        );
        s.phase = "published".into();
        save(cfg, &s)?;
        return Ok(json!({"completed":true,"bytes":size,"same_id":true,"sha256":sha}));
    }
    ensure!(
        cfg.get("allow_identity_swap") == "true",
        "unsupported same-ID OneDrive large CAS; explicit identity-swap opt-in required"
    );
    if s.phase == "uploading" {
        if current.as_ref().is_none_or(|x| !same(x, &s.base)) {
            return conflict(cfg, &mut s).await;
        }
        let mut u = cfg.clone();
        u.work = cfg.work.join("stage-upload");
        u.options.insert("path".into(), s.stage_path.clone());
        u.options.remove("base_identity");
        let v = crate::cloud::upload(&u).await?;
        if v["completed"] != true {
            return Ok(v);
        }
        s.stage = identity(cfg, &s.stage_path).await?;
        ensure!(s.stage.is_some(), "staged identity missing");
        s.phase = "staged".into();
        s.offset = size;
        save(cfg, &s)?;
    }
    if cfg.get("stop_before_commit") == "true" && s.phase == "staged" {
        return Ok(
            json!({"completed":false,"phase":"staged","bytes":size,"original_preserved":true}),
        );
    }
    if s.phase == "staged" {
        ensure!(
            file_hash(source)? == sha,
            "replacement source changed before publication; original retained"
        );
        let now = identity(cfg, cfg.get("path")).await?;
        if now.as_ref().is_none_or(|x| !same(x, &s.base)) {
            // A rename acknowledgement can be lost; verify the original item by ID
            // and full frozen-content SHA before accepting the backed-up phase.
            if now.is_none() {
                if let Some(backup) = by_id(cfg, &s.base.id).await? {
                    if backup.name == s.backup_name
                        && !s.base.sha256.is_empty()
                        && digest_id(cfg, &backup.id).await? == s.base.sha256
                    {
                        s.backup = Some(backup);
                        s.phase = "backed_up".into();
                        save(cfg, &s)?;
                    } else {
                        return conflict(cfg, &mut s).await;
                    }
                } else {
                    return conflict(cfg, &mut s).await;
                }
            } else {
                return conflict(cfg, &mut s).await;
            }
        } else {
            commit_gate(cfg).await?;
            match rename(cfg, &s.base.id, &s.base.etag, &s.backup_name).await {
                Ok(b) => {
                    s.backup = Some(b);
                    s.phase = "backed_up".into();
                    save(cfg, &s)?;
                }
                Err(e) => {
                    if e.to_string().contains("HTTP 412") || e.to_string().contains("HTTP 409") {
                        return conflict(cfg, &mut s).await;
                    }
                    return Err(e);
                }
            }
        }
    }
    if s.phase == "backed_up" {
        if cfg.get("stop_after_backup") == "true" {
            return Ok(
                json!({"completed":false,"phase":"backed_up","backup_preserved":true,"path_temporarily_absent":true}),
            );
        }
        let b = s.backup.as_ref().unwrap();
        let now = by_id(cfg, &b.id)
            .await?
            .ok_or_else(|| anyhow::anyhow!("backup missing; retained"))?;
        if !same(&now, b) || identity(cfg, cfg.get("path")).await?.is_some() {
            return conflict(cfg, &mut s).await;
        }
        let stage = s.stage.as_ref().unwrap();
        match rename(cfg, &stage.id, &stage.etag, &s.base.name).await {
            Ok(_) => {
                if cfg.get("drop_publication_response_once") == "true"
                    && !cfg.work.join("publication-response-dropped").exists()
                {
                    atomic(
                        &cfg.work.join("publication-response-dropped"),
                        b"owned publication response loss",
                    )?;
                    bail!("publication response lost; originals retained for reconciliation");
                }
                s.phase = "published".into();
                save(cfg, &s)?;
            }
            Err(e) => {
                if e.to_string().contains("HTTP 409") || e.to_string().contains("HTTP 412") {
                    return conflict(cfg, &mut s).await;
                }
                return Err(e);
            }
        }
    }
    let published = identity(cfg, cfg.get("path"))
        .await?
        .ok_or_else(|| anyhow::anyhow!("publication missing"))?;
    ensure!(
        digest_id(cfg, &published.id).await? == sha,
        "published SHA mismatch; backups retained"
    );
    ensure!(
        file_hash(source)? == sha,
        "source changed; originals retained"
    );
    Ok(
        json!({"completed":true,"bytes":size,"sha256":sha,"same_id":false,"backup":s.backup,"new_id":published.id,"protocol":"journaled name swap / original retained / non-atomic namespace"}),
    )
}
#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;
    #[test]
    fn verification_retries_transport_but_not_conflict_or_bad_authority() {
        assert!(retryable_verification("verification stream interrupted"));
        assert!(retryable_verification(
            "cloud transport interrupted; checkpoint/source retained"
        ));
        assert!(!retryable_verification("verify HTTP 412"));
        assert!(!retryable_verification("download authority held"));
        assert!(!retryable_verification("verify concurrent change; held"));
    }
    fn fixture() -> (Config, State) {
        let work = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join(".local/replace-unit")
            .join(crate::v2::nonce());
        fs::create_dir_all(&work).unwrap();
        let source = work.join("source.bin");
        fs::write(&source, b"frozen source").unwrap();
        let base = Identity {
            id: "unit-id".into(),
            etag: "E1".into(),
            name: "original.bin".into(),
            size: 12,
            sha256: hash(b"old original"),
        };
        let cfg = Config {
            provider: "onedrive".into(),
            root: "SigmaDrive-OpenDAL-PoC-unit-replacement".into(),
            work: work.clone(),
            mode: String::new(),
            mount: String::new(),
            options: HashMap::from([
                ("source".into(), source.to_string_lossy().into()),
                ("path".into(), base.name.clone()),
                ("drive_id".into(), "unit-drive".into()),
                ("connection_id".into(), "unit-account".into()),
                ("access_token".into(), "unit-no-network".into()),
                (
                    "base_identity".into(),
                    serde_json::to_string(&base).unwrap(),
                ),
            ]),
        };
        let scope = hash(
            &serde_json::to_vec(&(
                cfg.provider.clone(),
                cfg.root.clone(),
                cfg.get("connection_id"),
                cfg.get("drive_id"),
                cfg.get("path"),
                &base.id,
                &base.etag,
            ))
            .unwrap(),
        );
        let s = State {
            scope,
            source_sha256: hash(b"frozen source"),
            size: 13,
            base,
            url: "https://my.microsoftpersonalcontent.com/upload?unit=secret".into(),
            offset: 0,
            phase: "uploading".into(),
            stage: None,
            backup: None,
            stage_path: "pending.bin".into(),
            backup_name: "backup.bin".into(),
        };
        save(&cfg, &s).unwrap();
        (cfg, s)
    }
    #[tokio::test]
    async fn replacement_rejects_changed_source_before_network() {
        let (cfg, _) = fixture();
        fs::write(cfg.get("source"), b"source mutation").unwrap();
        let e = upload(&cfg).await.unwrap_err().to_string();
        assert!(e.contains("source/scope changed"));
        assert_eq!(fs::read(cfg.get("source")).unwrap(), b"source mutation");
    }
    #[tokio::test]
    async fn replacement_binds_account_path_and_original_revision() {
        let (cfg, _) = fixture();
        for key in ["connection_id", "drive_id", "path"] {
            let mut changed = cfg.clone();
            changed.options.insert(key.into(), "different".into());
            let e = upload(&changed).await.unwrap_err().to_string();
            assert!(e.contains("source/scope changed"), "{key}: {e}");
        }
        let mut changed = cfg.clone();
        changed.root.push_str("-other");
        assert!(
            upload(&changed)
                .await
                .unwrap_err()
                .to_string()
                .contains("source/scope changed")
        );
        let mut changed = cfg.clone();
        let mut base: Identity = serde_json::from_str(changed.get("base_identity")).unwrap();
        base.etag = "E2".into();
        changed.options.insert(
            "base_identity".into(),
            serde_json::to_string(&base).unwrap(),
        );
        assert!(
            upload(&changed)
                .await
                .unwrap_err()
                .to_string()
                .contains("source/scope changed")
        );
    }
    #[test]
    fn checkpoint_tampering_does_not_expose_or_accept_session() {
        let (cfg, _) = fixture();
        let p = cfg.work.join("replace.dpapi");
        let mut bytes = fs::read(&p).unwrap();
        assert!(!bytes.windows(8).any(|b| b == b"https://"));
        let n = bytes.len() / 2;
        bytes[n] ^= 1;
        assert!(protect(&bytes, false).is_err());
        assert_eq!(fs::read(cfg.get("source")).unwrap(), b"frozen source");
    }
}
