//! Bounded cloud create uploads. Upload URLs are bearer secrets: DPAPI at rest,
//! never in progress/error output. Existing objects are deliberately held.
use crate::{
    Config,
    engine::{atomic, checked, hash},
    safe::encoded,
    v2::file_hash,
};
use anyhow::{Result, bail, ensure};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    fs::{self, File},
    io::{Read, Seek, SeekFrom},
    time::Duration,
};
const CHUNK: u64 = 10 * 1024 * 1024; // multiple of both 256 KiB and 320 KiB
#[derive(Serialize, Deserialize)]
struct Session {
    scope: String,
    sha256: String,
    size: u64,
    url: String,
    id: String,
    offset: u64,
    completed: bool,
    #[serde(default)]
    placeholder_etag: String,
}
#[cfg(windows)]
pub(crate) fn protect(input: &[u8], seal: bool) -> Result<Vec<u8>> {
    use winapi::um::{
        dpapi::{CRYPTPROTECT_UI_FORBIDDEN, CryptProtectData, CryptUnprotectData},
        winbase::LocalFree,
        wincrypt::DATA_BLOB,
    };
    let mut source = DATA_BLOB {
        cbData: input.len() as u32,
        pbData: input.as_ptr() as *mut u8,
    };
    let mut dest = DATA_BLOB {
        cbData: 0,
        pbData: std::ptr::null_mut(),
    };
    let ok = unsafe {
        if seal {
            CryptProtectData(
                &mut source,
                std::ptr::null(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                CRYPTPROTECT_UI_FORBIDDEN,
                &mut dest,
            )
        } else {
            CryptUnprotectData(
                &mut source,
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                CRYPTPROTECT_UI_FORBIDDEN,
                &mut dest,
            )
        }
    };
    ensure!(ok != 0, "Windows session protection failed");
    let bytes = unsafe { std::slice::from_raw_parts(dest.pbData, dest.cbData as usize).to_vec() };
    unsafe {
        LocalFree(dest.pbData as *mut _);
    }
    Ok(bytes)
}
#[cfg(not(windows))]
fn protect(_: &[u8], _: bool) -> Result<Vec<u8>> {
    bail!("OS protected session store required")
}
fn save(cfg: &Config, s: &Session) -> Result<()> {
    atomic(
        &cfg.work.join("session.dpapi"),
        &protect(&serde_json::to_vec(s)?, true)?,
    )?;
    atomic(
        &cfg.work.join("progress.json"),
        &serde_json::to_vec(
            &json!({"offset":s.offset,"size":s.size,"completed":s.completed,"sha256":s.sha256,"protected":true}),
        )?,
    )
}
pub(crate) fn valid_url(provider: &str, url: &str) -> Result<()> {
    let u = reqwest::Url::parse(url).map_err(|_| anyhow::anyhow!("invalid session URL"))?;
    let h = u.host_str().unwrap_or("");
    let allowed = if provider == "drive" {
        h == "www.googleapis.com" || h == "content.googleapis.com"
    } else {
        h.ends_with(".1drv.com")
            || h.ends_with(".sharepoint.com")
            || h.ends_with(".onedrive.com")
            || h.ends_with(".storage.live.com")
            || h == "my.microsoftpersonalcontent.com"
    };
    ensure!(
        u.scheme() == "https"
            && u.username().is_empty()
            && u.password().is_none()
            && u.port_or_known_default() == Some(443)
            && allowed,
        "untrusted session authority"
    );
    Ok(())
}
pub(crate) async fn send(b: reqwest::RequestBuilder) -> Result<reqwest::Response> {
    crate::provider_http::send(b).await
}
pub(crate) async fn body(r: reqwest::Response) -> Result<Value> {
    let code = r.status();
    ensure!(code.is_success(), "cloud metadata HTTP {}", code.as_u16());
    r.json()
        .await
        .map_err(|_| anyhow::anyhow!("invalid cloud metadata"))
}
fn auth(
    c: &reqwest::Client,
    cfg: &Config,
    m: reqwest::Method,
    u: String,
) -> reqwest::RequestBuilder {
    c.request(m, u)
        .bearer_auth(cfg.get("access_token"))
        .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
}
async fn folder(c: &reqwest::Client, cfg: &Config) -> Result<String> {
    let mut parent = "root".to_string();
    let name = cfg.get("path");
    let full = crate::remote_path(&cfg.root, name);
    let parts = full.split('/').collect::<Vec<_>>();
    for part in &parts[..parts.len() - 1] {
        ensure!(!part.is_empty(), "empty directory component");
        let q = format!(
            "'{}' in parents and trashed=false and name='{}'",
            parent.replace('\'', "\\'"),
            part.replace('\\', "\\\\").replace('\'', "\\'")
        );
        let v = body(
            send(
                auth(
                    c,
                    cfg,
                    reqwest::Method::GET,
                    "https://www.googleapis.com/drive/v3/files".into(),
                )
                .query(&[
                    ("q", q.as_str()),
                    ("fields", "files(id,mimeType),nextPageToken"),
                ]),
            )
            .await?,
        )
        .await?;
        let a = v["files"]
            .as_array()
            .ok_or_else(|| anyhow::anyhow!("folder list invalid"))?;
        ensure!(
            v["nextPageToken"].is_null() && a.len() <= 1,
            "ambiguous folder"
        );
        parent = if a.is_empty() {
            body(send(auth(c,cfg,reqwest::Method::POST,"https://www.googleapis.com/drive/v3/files".into()).json(&json!({"name":part,"mimeType":"application/vnd.google-apps.folder","parents":[parent]}))).await?).await?["id"].as_str().ok_or_else(||anyhow::anyhow!("folder ID missing"))?.to_owned()
        } else {
            ensure!(
                a[0]["mimeType"] == "application/vnd.google-apps.folder",
                "parent is not folder"
            );
            a[0]["id"].as_str().unwrap().to_owned()
        };
    }
    Ok(parent)
}
async fn init(c: &reqwest::Client, cfg: &Config, s: &mut Session) -> Result<()> {
    let path = cfg.get("path");
    if cfg.provider == "drive" {
        let parent = folder(c, cfg).await?;
        if s.id.is_empty() {
            s.id=body(send(auth(c,cfg,reqwest::Method::GET,"https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files".into())).await?).await?["ids"][0].as_str().ok_or_else(||anyhow::anyhow!("generated ID absent"))?.to_owned();
            save(cfg, s)?;
        }
        let r = send(
            auth(
                c,
                cfg,
                reqwest::Method::POST,
                "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable".into(),
            )
            .header("X-Upload-Content-Length", s.size)
            .header("X-Upload-Content-Type", "application/octet-stream")
            .json(&json!({"id":s.id,"name":path.rsplit('/').next().unwrap(),"parents":[parent]})),
        )
        .await?;
        ensure!(
            r.status().is_success(),
            "session init HTTP {}",
            r.status().as_u16()
        );
        s.url = r
            .headers()
            .get("location")
            .and_then(|h| h.to_str().ok())
            .ok_or_else(|| anyhow::anyhow!("session location absent"))?
            .to_owned();
    } else {
        let u = format!(
            "https://graph.microsoft.com/v1.0/drives/{}/root:/{}:/createUploadSession",
            encoded(cfg.get("drive_id")),
            encoded(&crate::remote_path(&cfg.root, path))
        );
        let v=body(send(auth(c,cfg,reqwest::Method::POST,u).json(&json!({"item":{"@microsoft.graph.conflictBehavior":"fail","name":path.rsplit('/').next().unwrap()}}))).await?).await?;
        s.url = v["uploadUrl"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("upload URL absent"))?
            .to_owned();
        valid_url(&cfg.provider, &s.url)?;
        // OneDrive Personal reserves a zero-byte item during session creation.
        // Bind that reservation's identity/revision before accepting a resume.
        let response = send(auth(c, cfg, reqwest::Method::GET, one_item_url(cfg))).await?;
        if response.status().as_u16() != 404 {
            let item = body(response).await?;
            ensure!(
                item["size"].as_u64() == Some(0),
                "new upload reservation not empty; held"
            );
            s.id = item["id"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("reservation ID absent"))?
                .to_owned();
            s.placeholder_etag = item["eTag"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("reservation revision absent"))?
                .to_owned();
        }
    }
    valid_url(&cfg.provider, &s.url)?;
    s.offset = 0;
    save(cfg, s)
}
fn one_item_url(cfg: &Config) -> String {
    format!(
        "https://graph.microsoft.com/v1.0/drives/{}/root:/{}",
        encoded(cfg.get("drive_id")),
        encoded(&crate::remote_path(&cfg.root, cfg.get("path")))
    )
}
fn google_offset(r: &reqwest::Response, size: u64) -> Result<u64> {
    let at = match r.headers().get("range") {
        None => 0,
        Some(h) => {
            let x = h.to_str().map_err(|_| anyhow::anyhow!("invalid range"))?;
            ensure!(x.starts_with("bytes=0-"), "noncontiguous cloud range");
            x[8..].parse::<u64>()? + 1
        }
    };
    ensure!(at <= size, "cloud offset overflow");
    Ok(at)
}
fn one_offset(v: &Value, size: u64) -> Result<u64> {
    let a = v["nextExpectedRanges"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("cloud offset absent"))?;
    ensure!(a.len() == 1, "fragmented cloud range held");
    let n = a[0]
        .as_str()
        .unwrap_or("")
        .split('-')
        .next()
        .unwrap_or("")
        .parse::<u64>()?;
    ensure!(n <= size, "cloud offset overflow");
    Ok(n)
}
pub async fn remote_hash(op: &opendal::Operator, p: &str) -> Result<String> {
    use sha2::{Digest, Sha256};
    let size = op
        .stat(p)
        .await
        .map_err(|e| anyhow::anyhow!("verify stat {:?}", e.kind()))?
        .content_length();
    let reader = op
        .reader(p)
        .await
        .map_err(|e| anyhow::anyhow!("verify reader {:?}", e.kind()))?;
    let mut h = Sha256::new();
    let mut at = 0;
    while at < size {
        let end = (at + CHUNK).min(size);
        let b = reader
            .read(at..end)
            .await
            .map_err(|e| anyhow::anyhow!("verify range {:?}", e.kind()))?
            .to_vec();
        ensure!(b.len() as u64 == end - at, "short verification range");
        h.update(b);
        at = end;
    }
    Ok(hex::encode(h.finalize()))
}
pub async fn upload(cfg: &Config) -> Result<Value> {
    ensure!(
        cfg.provider == "drive" || cfg.provider == "onedrive",
        "cloud provider required"
    );
    ensure!(
        !cfg.work.as_os_str().is_empty(),
        "private checkpoint required"
    );
    fs::create_dir_all(&cfg.work)?;
    checked(cfg.get("path"))?;
    let op = cfg.operator()?;
    let source = std::path::Path::new(cfg.get("source"));
    let size = source.metadata()?.len();
    let sha = file_hash(source)?;
    let scope = hash(&serde_json::to_vec(&(
        cfg.provider.clone(),
        cfg.root.clone(),
        cfg.get("connection_id"),
        cfg.get("drive_id"),
        cfg.get("path"),
    ))?);
    let checkpoint = cfg.work.join("session.dpapi");
    let mut s: Session = if checkpoint.exists() {
        serde_json::from_slice(&protect(&fs::read(checkpoint)?, false)?)?
    } else {
        Session {
            scope: scope.clone(),
            sha256: sha.clone(),
            size,
            url: String::new(),
            id: String::new(),
            offset: 0,
            completed: false,
            placeholder_etag: String::new(),
        }
    };
    ensure!(
        s.scope == scope && s.size == size && s.sha256 == sha,
        "upload source/scope changed; source retained"
    );
    let c = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .timeout(Duration::from_secs(120))
        .build()?;
    save(cfg, &s)?; // bind source/scope even if initiation or validation fails
    // Name conflicts are held. Existing content is never implicitly replaced.
    if let Some(m) = crate::metadata::fresh(&op, cfg.get("path")).await? {
        if m.size == size
            && !s.url.is_empty()
            && crate::replace::verify_path(cfg, cfg.get("path")).await? == sha
        {
            s.completed = true;
            s.offset = size;
            save(cfg, &s)?;
            return Ok(
                json!({"completed":true,"reused_bytes":size,"received_bytes":0,"sha256":sha,"completion_reconciled":true}),
            );
        }
        let own_reservation =
            if cfg.provider == "onedrive" && !s.url.is_empty() && m.size == 0 && !s.id.is_empty() {
                let item =
                    body(send(auth(&c, cfg, reqwest::Method::GET, one_item_url(cfg))).await?)
                        .await?;
                item["id"] == s.id && item["eTag"] == s.placeholder_etag
            } else {
                false
            };
        ensure!(
            own_reservation,
            "AlreadyExists: large create conflict; source retained"
        );
    }
    ensure!(!s.completed, "completed object disappeared; held");
    if s.url.is_empty() {
        init(&c, cfg, &mut s).await?;
    } else {
        valid_url(&cfg.provider, &s.url)?;
        let request = if cfg.provider == "drive" {
            c.put(&s.url)
                .bearer_auth(cfg.get("access_token"))
                .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
                .header("Content-Length", 0)
                .header("Content-Range", format!("bytes */{size}"))
        } else {
            c.get(&s.url)
        };
        let r = send(request).await?;
        if r.status().as_u16() == 404 || r.status().as_u16() == 410 {
            init(&c, cfg, &mut s).await?;
        } else if cfg.provider == "drive" {
            if r.status().as_u16() == 308 {
                s.offset = google_offset(&r, size)?;
            } else {
                ensure!(
                    r.status().is_success(),
                    "session status HTTP {}",
                    r.status().as_u16()
                );
                s.offset = size;
            }
        } else {
            s.offset = one_offset(&body(r).await?, size)?;
        }
        save(cfg, &s)?;
    }
    let reused = s.offset;
    if size == 0 && cfg.provider == "drive" {
        let r = send(
            c.put(&s.url)
                .bearer_auth(cfg.get("access_token"))
                .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
                .header("Content-Length", 0)
                .header("Content-Range", "bytes */0"),
        )
        .await?;
        ensure!(
            r.status().is_success(),
            "empty upload HTTP {}",
            r.status().as_u16()
        );
    }
    let mut sent = 0u64;
    let mut f = File::open(source)?;
    f.seek(SeekFrom::Start(s.offset))?;
    let stop = cfg.get("stop_after_parts").parse::<u64>().unwrap_or(0);
    let mut parts = 0;
    while s.offset < size {
        let before = s.offset;
        let count = (size - s.offset).min(CHUNK);
        let mut b = vec![0; count as usize];
        f.read_exact(&mut b)?;
        let mut req = c
            .put(&s.url)
            .header("Content-Length", count)
            .header(
                "Content-Range",
                format!("bytes {}-{}/{size}", s.offset, s.offset + count - 1),
            )
            .body(b);
        if cfg.provider == "drive" {
            req = req
                .bearer_auth(cfg.get("access_token"))
                .header("X-Sigma-Local-Connection", cfg.get("connection_id"));
        }
        if cfg.get("cut_body_once") == "true" && !cfg.work.join("body-cut.json").exists() {
            use futures_util::StreamExt;
            // Send a real partial HTTP body, then fail the stream while the
            // advertised Content-Length still promises a full fragment.
            f.seek(SeekFrom::Start(before))?;
            let mut first = vec![0; count.min(65536) as usize];
            f.read_exact(&mut first)?;
            let stream = futures_util::stream::once(async move { Ok::<_, std::io::Error>(first) })
                .chain(futures_util::stream::once(async {
                    tokio::time::sleep(Duration::from_millis(1000)).await;
                    Err(std::io::Error::new(
                        std::io::ErrorKind::ConnectionAborted,
                        "owned QA upload stream cut",
                    ))
                }));
            let failed = crate::cloud::send(req.body(reqwest::Body::wrap_stream(stream))).await;
            atomic(
                &cfg.work.join("body-cut.json"),
                &serde_json::to_vec(
                    &json!({"transport_error":failed.is_err(),"partial_body_bytes":count.min(65536),"declared_body_bytes":count,"offset_before":before,"global_network_changed":false}),
                )?,
            )?;
            ensure!(failed.is_err(), "QA partial body did not interrupt request");
            bail!("QA partial upload body interrupted; checkpoint/source retained");
        }
        // QA fault cuts ONLY this upload request, never the PC network or Z.
        if cfg.get("cut_request_once") == "true" && !cfg.work.join("request-cut.json").exists() {
            let outcome =
                tokio::time::timeout(Duration::from_millis(10), crate::cloud::send(req)).await;
            atomic(
                &cfg.work.join("request-cut.json"),
                &serde_json::to_vec(
                    &json!({"request_cancelled":outcome.is_err(),"response_discarded":outcome.is_ok(),"scope":"owned upload only","offset_before":before}),
                )?,
            )?;
            drop(outcome);
            bail!("QA upload request interrupted; checkpoint/source retained");
        }
        let r = send(req).await?;
        let status = r.status().as_u16();
        sent += count;
        if cfg.provider == "drive" {
            if status == 308 {
                s.offset = google_offset(&r, size)?;
            } else {
                ensure!(
                    status == 200 || status == 201,
                    "upload HTTP {status}; source retained"
                );
                s.offset = size;
            }
        } else {
            if status == 202 {
                s.offset = one_offset(&body(r).await?, size)?;
            } else {
                ensure!(
                    status == 200 || status == 201,
                    "upload HTTP {status}; source retained"
                );
                s.offset = size;
            }
        }
        ensure!(
            s.offset > before && s.offset <= before + count,
            "cloud offset outside submitted contiguous fragment"
        );
        save(cfg, &s)?;
        parts += 1;
        let delay = cfg.get("delay_ms").parse::<u64>().unwrap_or(0);
        if delay > 0 {
            tokio::time::sleep(Duration::from_millis(delay)).await;
        }
        if stop > 0 && parts >= stop && s.offset < size {
            return Ok(
                json!({"completed":false,"reused_bytes":reused,"received_bytes":sent,"offset":s.offset,"protected":true}),
            );
        }
    }
    ensure!(
        file_hash(source)? == sha,
        "source changed during upload; retained"
    );
    ensure!(
        crate::replace::verify_path(cfg, cfg.get("path")).await? == sha,
        "postcommit SHA mismatch; source retained"
    );
    s.completed = true;
    save(cfg, &s)?;
    Ok(
        json!({"completed":true,"reused_bytes":reused,"received_bytes":sent,"total_bytes":size,"sha256":sha,"buffer_bytes":CHUNK,"protected":true,"protocol":format!("{} durable resumable upload",cfg.provider)}),
    )
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn protected_checkpoint_roundtrip() {
        let x = b"https://secret.example/upload?token=never-plaintext";
        let b = protect(x, true).unwrap();
        assert!(!String::from_utf8_lossy(&b).contains("never-plaintext"));
        assert_eq!(protect(&b, false).unwrap(), x);
    }
    #[test]
    fn host_boundaries() {
        assert!(valid_url("onedrive", "https://sn3302.up.1drv.com/up/test").is_ok());
        assert!(valid_url("onedrive", "https://1drv.com.attacker.test/up").is_err());
        assert!(valid_url("drive", "http://www.googleapis.com/upload").is_err());
    }
    #[test]
    fn offset_bounds() {
        assert_eq!(
            one_offset(&json!({"nextExpectedRanges":["10485760-"]}), 20000000).unwrap(),
            10485760
        );
        assert!(one_offset(&json!({"nextExpectedRanges":["100-","200-"]}), 1000).is_err());
    }
}
