pub fn open(url: &str) -> Result<(), String> {
    let uri = reqwest::Url::parse(url).map_err(|_| "올바른 HTTPS 주소가 아닙니다.")?;
    let host = uri.host_str().unwrap_or("");
    if uri.scheme() != "https"
        || !uri.username().is_empty()
        || uri.password().is_some()
        || uri.port().is_some_and(|p| p != 443)
        || !(host == "accounts.google.com"
            || host == "login.microsoftonline.com"
            || host == "sigmadrive.net"
            || host.ends_with(".sigmadrive.net"))
    {
        return Err("허용된 로그인·SigmaDrive 웹 주소만 열 수 있습니다.".into());
    }
    #[cfg(windows)]
    let mut command = {
        let mut c = std::process::Command::new("rundll32.exe");
        c.arg("url.dll,FileProtocolHandler");
        use std::os::windows::process::CommandExt;
        c.creation_flags(0x08000000);
        c
    };
    #[cfg(target_os = "macos")]
    let mut command = std::process::Command::new("open");
    #[cfg(all(unix, not(target_os = "macos")))]
    let mut command = std::process::Command::new("xdg-open");
    command
        .arg(url)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn()
        .map_err(|_| "시스템 브라우저를 열지 못했습니다.")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn untrusted_urls_never_launch_a_process() {
        for bad in [
            "file:///C:/Windows/notepad.exe",
            "https://accounts.google.com.evil.invalid/",
            "https://accounts.google.com@evil.invalid/",
            "http://accounts.google.com/",
            "https://evil.invalid/",
        ] {
            assert!(open(bad).is_err());
        }
    }
}
