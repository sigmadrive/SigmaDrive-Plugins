//! Member-owned portal address. Display labels never replace member authorization.
use crate::state::{Core, now};
use anyhow::{Result, ensure};
use futures_util::StreamExt;
use serde_json::{Value, json};
use std::time::Duration;

const ENDPOINT: &str = "https://www.sigmadrive.net/api/member/portal";

fn valid_portal_label(label: &str) -> bool {
    let hex = |s: &str| {
        s.bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    };
    // Keep existing opaque addresses usable during the readable-address rollout.
    if label.len() == 32 && hex(label) {
        return true;
    }
    let Some((id, suffix)) = label.rsplit_once('-') else {
        return false;
    };
    !id.is_empty()
        && id.len() <= 52
        && id
            .bytes()
            .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
        && !id.starts_with('-')
        && !id.ends_with('-')
        && suffix.len() == 8
        && hex(suffix)
}

fn checked_url(raw: &str) -> Result<()> {
    let url = reqwest::Url::parse(raw)?;
    let label = url
        .host_str()
        .and_then(|h| h.strip_suffix(".user.sigmadrive.net"))
        .and_then(|h| h.strip_prefix("u-"))
        .ok_or_else(|| anyhow::anyhow!("invalid portal host"))?;
    ensure!(valid_portal_label(label), "invalid portal identifier");
    // Exact serialization rejects credentials, ports, paths, escapes and query secrets.
    ensure!(
        raw == format!("https://u-{label}.user.sigmadrive.net/"),
        "invalid canonical portal URL"
    );
    Ok(())
}

fn checked(value: &Value, member: &str) -> Result<Value> {
    ensure!(value["memberId"] == member, "portal member mismatch");
    ensure!(
        value["entryUrl"] == "https://www.sigmadrive.net/",
        "invalid portal entry"
    );
    let name = value["displayName"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("invalid portal name"))?;
    ensure!(name.len() <= 256 && name.chars().count() <= 64 && !name.chars().any(|c| c.is_control() || matches!(c, '\u{061c}' | '\u{200b}'..='\u{200f}' | '\u{202a}'..='\u{202e}' | '\u{2060}'..='\u{206f}' | '\u{feff}')), "invalid portal name");
    match value["addressState"].as_str() {
        Some("unassigned") => ensure!(value["portalUrl"].is_null(), "invalid unassigned portal"),
        Some("assigned") => {
            let raw = value["portalUrl"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("portal URL missing"))?;
            checked_url(raw)?;
        }
        _ => anyhow::bail!("invalid portal address state"),
    }
    // Never forward additional response fields (e.g. credentials) to Flutter or the browser.
    let mut result = json!({"memberId":member,"addressState":value["addressState"],"portalUrl":value["portalUrl"],"displayName":name});
    if let Some(canonical) = value.get("canonicalPortalUrl").filter(|v| !v.is_null()) {
        ensure!(
            value["addressState"] == "assigned",
            "canonical portal requires assigned address"
        );
        checked_url(
            canonical
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("invalid canonical portal URL"))?,
        )?;
        result["canonicalPortalUrl"] = canonical.clone();
    }
    Ok(result)
}

async fn request(credential: &str, allocate: bool) -> Result<Value> {
    ensure!(
        credential.len() == 43
            && credential
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-'),
        "invalid member credential"
    );
    let client = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .tls_version_min(reqwest::tls::Version::TLS_1_3)
        .timeout(Duration::from_secs(10))
        .build()?;
    let mut req = client
        .request(
            if allocate {
                reqwest::Method::POST
            } else {
                reqwest::Method::GET
            },
            ENDPOINT,
        )
        .bearer_auth(credential)
        .header("Accept", "application/json");
    if allocate {
        req = req.json(&json!({}));
    }
    let response = req.send().await.map_err(|_| {
        anyhow::anyhow!("portal service unavailable; membership and shares were not changed")
    })?;
    ensure!(
        response.status() == reqwest::StatusCode::OK,
        "portal service HTTP {}",
        response.status().as_u16()
    );
    let mut stream = response.bytes_stream();
    let mut bytes = Vec::new();
    while let Some(part) = stream.next().await {
        let part = part.map_err(|_| anyhow::anyhow!("portal response interrupted"))?;
        ensure!(
            bytes.len() + part.len() <= 8192,
            "portal response too large"
        );
        bytes.extend_from_slice(&part);
    }
    Ok(serde_json::from_slice(&bytes)?)
}

pub async fn manage(core: &Core, open: bool) -> Result<Value> {
    let member = core
        .data
        .read()
        .await
        .member
        .clone()
        .ok_or_else(|| anyhow::anyhow!("member login required"))?;
    let id = member["memberId"]
        .as_str()
        .filter(|s| !s.is_empty())
        .ok_or_else(|| anyhow::anyhow!("member identity missing"))?;
    let credential = member["credential"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("member credential missing"))?;
    ensure!(
        member["expiresAt"].as_u64().unwrap_or(0) > now(),
        "membership renewal required"
    );
    let mut portal = checked(&request(credential, false).await?, id)?;
    {
        let data = core.data.read().await;
        let current = data.member.as_ref();
        ensure!(
            current.is_some_and(|m| m["memberId"] == id
                && m["credential"] == credential
                && m["expiresAt"].as_u64().unwrap_or(0) > now()),
            "member changed during portal lookup"
        );
    }
    // Only an explicit Open action may allocate. Status lookups never create addresses.
    if open && portal["addressState"] == "unassigned" {
        portal = checked(&request(credential, true).await?, id)?;
    }
    let data = core.data.read().await;
    ensure!(
        data.member.as_ref().is_some_and(|m| m["memberId"] == id
            && m["credential"] == credential
            && m["expiresAt"].as_u64().unwrap_or(0) > now()),
        "member changed during portal lookup"
    );
    if open {
        let url = portal
            .get("canonicalPortalUrl")
            .unwrap_or(&portal["portalUrl"])
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("portal address not assigned"))?;
        // Keep identity read lock until browser dispatch; account switching cannot interleave here.
        crate::opener::open(url).map_err(anyhow::Error::msg)?;
    }
    Ok(portal)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn assigned() -> Value {
        json!({"memberId":"member-a","addressState":"assigned","portalUrl":"https://u-0123456789abcdef0123456789abcdef.user.sigmadrive.net/","displayName":"내 공간","entryUrl":"https://www.sigmadrive.net/","credential":"must-not-escape"})
    }
    #[test]
    fn response_is_owner_bound_and_redacted() {
        let value = assigned();
        assert!(checked(&value, "member-b").is_err());
        let out = checked(&value, "member-a").unwrap();
        assert!(out.get("credential").is_none());
        assert_eq!(out["displayName"], "내 공간");
    }
    #[test]
    fn canonical_address_is_optional_and_has_the_same_origin_and_owner_checks() {
        let mut value = assigned();
        value["canonicalPortalUrl"] = json!("https://u-cmars-f1a409eb.user.sigmadrive.net/");
        let result = checked(&value, "member-a").unwrap();
        assert_eq!(result["canonicalPortalUrl"], value["canonicalPortalUrl"]);
        assert_eq!(result["portalUrl"], value["portalUrl"]);
        assert!(result.get("credential").is_none());
        assert!(checked(&value, "member-b").is_err());
        for bad in [
            json!("https://u-cmars-f1a409eb.user.sigmadrive.net.evil.invalid/"),
            json!("https://u-cmars-f1a409eb.user.sigmadrive.net/?token=secret"),
            json!(123),
        ] {
            value["canonicalPortalUrl"] = bad;
            assert!(checked(&value, "member-a").is_err());
        }
        value["canonicalPortalUrl"] = Value::Null;
        assert!(checked(&value, "member-a").is_ok());
        value["addressState"] = json!("unassigned");
        value["portalUrl"] = Value::Null;
        value["canonicalPortalUrl"] = json!("https://u-cmars-f1a409eb.user.sigmadrive.net/");
        assert!(checked(&value, "member-a").is_err());
    }
    #[test]
    fn only_canonical_personal_root_is_accepted() {
        for bad in [
            "https://cmars-google-com.user.sigmadrive.net/",
            "https://cmars-google-a9emf.user.sigmadrive.net/",
            "https://u-0123456789abcdef0123456789abcdef.user.sigmadrive.net.evil.invalid/",
            "https://u-0123456789abcdef0123456789abcdef.relay.sigmadrive.net/",
            "https://u-0123456789abcdef0123456789abcdef.user.sigmadrive.net/?credential=secret",
            "https://u-0123456789abcdef0123456789abcdef.user.sigmadrive.net/#desk",
            "https://user:secret@u-0123456789abcdef0123456789abcdef.user.sigmadrive.net/",
            "https://u-0123456789ABCDEF0123456789ABCDEF.user.sigmadrive.net/",
            "https://u-0123456789abcdef0123456789abcdef.user.sigmadrive.net:443/",
            "http://u-0123456789abcdef0123456789abcdef.user.sigmadrive.net/",
            "file:///C:/Windows/notepad.exe",
        ] {
            let mut value = assigned();
            value["portalUrl"] = json!(bad);
            assert!(checked(&value, "member-a").is_err(), "{bad}");
        }
        assert!(checked(&assigned(), "member-a").is_ok());
    }
    #[test]
    fn readable_address_accepts_bounded_id_and_eight_hex_suffix() {
        for label in [
            "cmars-f1a409eb".to_owned(),
            "first-last-1234abcd".to_owned(),
            format!("{}-1234abcd", "a".repeat(52)),
        ] {
            let mut value = assigned();
            value["portalUrl"] = json!(format!("https://u-{label}.user.sigmadrive.net/"));
            assert!(checked(&value, "member-a").is_ok(), "{label}");
            assert!(checked(&value, "another-member").is_err());
        }
        for label in [
            "-1234abcd".to_owned(),
            "-cmars-1234abcd".to_owned(),
            "cmars--1234abcd".to_owned(),
            "cmars-1234abc".to_owned(),
            "cmars-1234abcde".to_owned(),
            "cmars-1234abcg".to_owned(),
            "cmars-1234ABCd".to_owned(),
            "cmars_name-1234abcd".to_owned(),
            "cmars.example-1234abcd".to_owned(),
            format!("{}-1234abcd", "a".repeat(53)),
        ] {
            let mut value = assigned();
            value["portalUrl"] = json!(format!("https://u-{label}.user.sigmadrive.net/"));
            assert!(checked(&value, "member-a").is_err(), "{label}");
        }
        for ending in [":443/", "/#desk", "/?credential=secret", ".evil.invalid/"] {
            let mut value = assigned();
            value["portalUrl"] = json!(format!(
                "https://u-cmars-1234abcd.user.sigmadrive.net{ending}"
            ));
            assert!(checked(&value, "member-a").is_err());
        }
    }
    #[test]
    fn unassigned_is_explicit_and_alias_cannot_hide_the_url() {
        let mut value = assigned();
        value["addressState"] = json!("unassigned");
        assert!(checked(&value, "member-a").is_err());
        value["portalUrl"] = Value::Null;
        assert!(checked(&value, "member-a").is_ok());
        value["displayName"] = json!("bad\u{202e}name");
        assert!(checked(&value, "member-a").is_err());
    }
}
