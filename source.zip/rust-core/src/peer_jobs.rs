//! PC-local, durable S3 peer jobs. No names/byte counts leave for the control plane.
use crate::{
    peer_client::Reply,
    state::{Core, id},
};
use anyhow::{Result, bail, ensure};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::Digest;
use std::{
    io::{Read, Seek, Write},
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

async fn rows(core: &Core) -> Value {
    json!({"downloads":core.data.read().await.jobs.values().filter(|j|j["kind"]=="peer-s3").cloned().collect::<Vec<_>>()})
}
pub async fn manage(core: Arc<Core>, body: Value) -> Result<Value> {
    let action = body["action"].as_str().unwrap_or("status");
    if action == "status" {
        return Ok(rows(&core).await);
    }
    if matches!(action, "pause" | "resume" | "cancel") {
        {
            let d = core.data.read().await;
            ensure!(
                d.jobs
                    .get(body["id"].as_str().unwrap_or(""))
                    .is_some_and(|j| j["kind"] == "peer-s3"),
                "peer job not registered"
            );
        }
        crate::jobs::manage(core.clone(), body).await?;
        return Ok(rows(&core).await);
    }
    let share = body["share"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("share ID required"))?;
    let pin = body["peer_pin"].as_str().unwrap_or("");
    let peer = crate::peer_client::open(&core, share, pin).await?;
    let credentials = peer.credentials().await?;
    match action {
        "list" => {
            let mut query = vec![("list-type", "2".into())];
            if let Some(c) = body["continuation"].as_str().filter(|s| !s.is_empty()) {
                ensure!(c.len() <= 2048, "continuation too long");
                query.push(("continuation-token", c.into()));
            }
            let response = peer.s3("GET", "", &query, &[], vec![]).await?;
            response.success()?;
            #[derive(Deserialize)]
            struct Object {
                #[serde(rename = "Key")]
                key: String,
                #[serde(rename = "Size")]
                size: u64,
                #[serde(rename = "ETag")]
                etag: String,
            }
            #[derive(Deserialize)]
            struct List {
                #[serde(rename = "Contents", default)]
                objects: Vec<Object>,
                #[serde(rename = "NextContinuationToken", default)]
                next: String,
            }
            let list: List = quick_xml::de::from_reader(response.body.as_slice())?;
            ensure!(list.objects.len() <= 1000, "peer list bound");
            let mut out = rows(&core).await;
            out["objects"] = json!(
                list.objects
                    .into_iter()
                    .map(|o| json!({"key":o.key,"size":o.size,"etag":o.etag}))
                    .collect::<Vec<_>>()
            );
            out["bucket"] = credentials["bucket"].clone();
            out["writable"] = credentials["write"].clone();
            out["continuation"] = json!(list.next);
            out["endpoint"] = json!("End-to-end pinned TLS relay");
            Ok(out)
        }
        "delete" => {
            let key = crate::share_fs::key(body["key"].as_str().unwrap_or(""))?;
            let etag = body["etag"]
                .as_str()
                .filter(|s| !s.is_empty())
                .ok_or_else(|| anyhow::anyhow!("current revision required"))?;
            ensure!(credentials["write"] == true, "write approval required");
            peer.s3(
                "DELETE",
                &key,
                &[],
                &[("if-match".into(), etag.into())],
                vec![],
            )
            .await?
            .success()?;
            Ok(rows(&core).await)
        }
        "upload" | "download" => {
            let key = crate::share_fs::key(body["key"].as_str().unwrap_or(""))?;
            ensure!(
                action != "upload" || credentials["write"] == true,
                "write approval required"
            );
            let local = body[if action == "upload" {
                "source"
            } else {
                "destination"
            }]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("local file required"))?;
            ensure!(
                Path::new(local).is_absolute() && !local.to_ascii_lowercase().starts_with("z:"),
                "choose a dedicated path outside existing Z"
            );
            if action == "download" {
                ensure!(
                    !Path::new(local).exists(),
                    "destination exists; original retained"
                );
            }
            let jid = id("peer-job");
            let binding = if action == "upload" {
                crate::jobs::source_binding(&std::fs::metadata(local)?)?
            } else {
                Value::Null
            };
            let job = json!({"id":jid,"kind":"peer-s3","share":share,"peer_pin":pin,"direction":action,"key":key,"source":if action=="upload"{local}else{""},"destination":if action=="download"{local}else{""},"source_binding":binding,"state":"queued","requested_state":"running","resume_on_restart":true,"resources_released":true,"created_at":crate::state::now(),"completed_bytes":0,"total_bytes":0,"bytes_per_second":body["bytes_per_second"].as_u64().unwrap_or(0)});
            {
                let _single = core.job_control.lock().await;
                let mut d = core.data.write().await;
                let mut next = d.clone();
                ensure!(next.jobs.len() < 4096, "job history capacity");
                next.jobs.insert(jid, job);
                core.persist(&next)?;
                *d = next;
            }
            Ok(rows(&core).await)
        }
        _ => bail!("unsupported S3 browser action"),
    }
}
#[derive(Serialize, Deserialize, Default)]
struct Checkpoint {
    scope: String,
    source_hash: String,
    size: u64,
    etag: String,
    upload: String,
    offset: u64,
    #[serde(default)]
    parts: Vec<(i32, String, u64)>,
    #[serde(default)]
    complete: bool,
}
fn header<'a>(r: &'a Reply, name: &str) -> Result<&'a str> {
    r.headers
        .get(name)
        .and_then(|h| h.to_str().ok())
        .ok_or_else(|| anyhow::anyhow!("peer response missing {name}"))
}
fn save(path: &Path, state: &Checkpoint) -> Result<()> {
    crate::identity::atomic(path, &serde_json::to_vec(state)?)?;
    Ok(())
}
fn stopped(stop: &AtomicBool) -> Result<()> {
    ensure!(!stop.load(Ordering::Acquire), "paused");
    Ok(())
}
fn xml(v: &str) -> String {
    v.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}
async fn pace(rate: u64, bytes: u64, started: std::time::Instant, stop: &AtomicBool) -> Result<()> {
    if rate > 0 {
        let wait =
            Duration::from_secs_f64(bytes as f64 / rate as f64).saturating_sub(started.elapsed());
        let until = std::time::Instant::now() + wait;
        while std::time::Instant::now() < until {
            stopped(stop)?;
            tokio::time::sleep(
                Duration::from_millis(50)
                    .min(until.saturating_duration_since(std::time::Instant::now())),
            )
            .await;
        }
    }
    Ok(())
}
pub async fn run(core: &Core, jid: &str, job: &Value, stop: &AtomicBool) -> Result<Value> {
    let work = core.root.join("transfers").join(jid);
    std::fs::create_dir_all(&work)?;
    let path = work.join("peer-checkpoint.json");
    let share = job["share"].as_str().unwrap_or("");
    let pin = job["peer_pin"].as_str().unwrap_or("");
    let key = crate::share_fs::key(job["key"].as_str().unwrap_or(""))?;
    let peer = crate::peer_client::open(core, share, pin).await?;
    let creds = peer.credentials().await?;
    let scope = hex::encode(sha2::Sha256::digest(serde_json::to_vec(&json!([
        share,
        pin,
        key,
        job["direction"],
        creds["bucket"]
    ]))?));
    let mut state: Checkpoint = if path.exists() {
        ensure!(
            path.metadata()?.len() <= 2 * 1024 * 1024,
            "checkpoint bound"
        );
        serde_json::from_slice(&std::fs::read(&path)?)?
    } else {
        Checkpoint {
            scope: scope.clone(),
            ..Default::default()
        }
    };
    ensure!(
        state.scope == scope,
        "checkpoint share/device/bucket conflict"
    );
    if job["direction"] == "upload" {
        ensure!(creds["write"] == true, "write authority required");
        let snapshot = work.join("source.snapshot");
        if !snapshot.exists() {
            let mut options = std::fs::OpenOptions::new();
            options.read(true);
            #[cfg(windows)]
            {
                use std::os::windows::fs::OpenOptionsExt;
                options.share_mode(1);
            }
            let mut original = options.open(
                job["source"]
                    .as_str()
                    .ok_or_else(|| anyhow::anyhow!("source missing"))?,
            )?;
            ensure!(
                crate::jobs::source_binding(&original.metadata()?)? == job["source_binding"],
                "source changed; original retained"
            );
            let temp = work.join("source.preparing");
            let mut out = std::fs::OpenOptions::new()
                .create(true)
                .truncate(true)
                .write(true)
                .open(&temp)?;
            crate::jobs::copy_interruptible(&mut original, &mut out, stop)?;
            out.sync_all()?;
            drop(out);
            ensure!(
                crate::jobs::source_binding(&original.metadata()?)? == job["source_binding"],
                "source changed during snapshot"
            );
            std::fs::rename(temp, &snapshot)?;
        }
        let hash = crate::jobs::file_hash_interruptible(&snapshot, stop)?;
        let size = snapshot.metadata()?.len();
        ensure!(
            state.source_hash.is_empty() || state.source_hash == hash,
            "immutable source mismatch"
        );
        state.source_hash = hash.clone();
        state.size = size;
        if state.upload.is_empty() {
            let head = peer.s3("HEAD", &key, &[], &[], vec![]).await?;
            if head.status == 404 {
                state.etag = String::new();
            } else {
                head.success()?;
                state.etag = header(&head, "etag")?.into();
            }
            let init = peer
                .s3("POST", &key, &[("uploads", String::new())], &[], vec![])
                .await?;
            init.success()?;
            #[derive(Deserialize)]
            struct Init {
                #[serde(rename = "UploadId")]
                id: String,
            }
            let init: Init = quick_xml::de::from_reader(init.body.as_slice())?;
            ensure!(
                init.id.len() <= 128 && !init.id.is_empty(),
                "invalid upload ID"
            );
            state.upload = init.id;
            save(&path, &state)?;
        }
        if !state.parts.is_empty() && !state.complete {
            #[derive(Deserialize)]
            struct Part {
                #[serde(rename = "PartNumber")]
                n: i32,
                #[serde(rename = "ETag")]
                e: String,
                #[serde(rename = "Size")]
                size: u64,
            }
            #[derive(Deserialize)]
            struct Parts {
                #[serde(rename = "Part", default)]
                p: Vec<Part>,
                #[serde(rename = "IsTruncated", default)]
                more: bool,
                #[serde(rename = "NextPartNumberMarker", default)]
                next: i32,
            }
            let mut verified = Vec::new();
            let mut marker = 0;
            loop {
                let r = peer
                    .s3(
                        "GET",
                        &key,
                        &[
                            ("uploadId", state.upload.clone()),
                            ("part-number-marker", marker.to_string()),
                        ],
                        &[],
                        vec![],
                    )
                    .await?;
                r.success()?;
                let list: Parts = quick_xml::de::from_reader(r.body.as_slice())?;
                ensure!(list.p.len() <= 1000, "part response bound");
                for p in list.p {
                    verified.push((p.n, p.e, p.size));
                }
                if !list.more {
                    break;
                }
                ensure!(
                    list.next > marker && list.next <= 10000,
                    "multipart pagination invalid"
                );
                marker = list.next;
            }
            for part in &state.parts {
                ensure!(
                    verified.contains(part),
                    "acknowledged part changed; source retained"
                );
            }
        }
        let mut source = std::fs::File::open(&snapshot)?;
        let mut offset = state.parts.iter().map(|p| p.2).sum::<u64>();
        source.seek(std::io::SeekFrom::Start(offset))?;
        ensure!(offset <= size, "checkpoint offset invalid");
        crate::jobs::patch(core,jid,json!({"state":"uploading","total_bytes":size,"completed_bytes":offset,"reused_bytes":offset})).await?;
        while offset < size || (size == 0 && state.parts.is_empty()) {
            stopped(stop)?;
            let started = std::time::Instant::now();
            let mut bytes = vec![0u8; (size - offset).min(8 * 1024 * 1024) as usize];
            source.read_exact(&mut bytes)?;
            let len = bytes.len() as u64;
            let n = state.parts.len() as i32 + 1;
            ensure!(n <= 10000, "multipart file too large");
            let r = peer
                .s3(
                    "PUT",
                    &key,
                    &[
                        ("uploadId", state.upload.clone()),
                        ("partNumber", n.to_string()),
                    ],
                    &[],
                    bytes,
                )
                .await?;
            r.success()?;
            let etag = header(&r, "etag")?.to_owned();
            state.parts.push((n, etag, len));
            offset += len;
            state.offset = offset;
            save(&path, &state)?;
            crate::jobs::patch(core, jid, json!({"completed_bytes":offset})).await?;
            pace(
                job["bytes_per_second"].as_u64().unwrap_or(0),
                len,
                started,
                stop,
            )
            .await?;
        }
        if !state.complete {
            let mut body = String::from("<CompleteMultipartUpload>");
            for (n, e, _) in &state.parts {
                body.push_str(&format!(
                    "<Part><PartNumber>{n}</PartNumber><ETag>{}</ETag></Part>",
                    xml(e)
                ));
            }
            body.push_str("</CompleteMultipartUpload>");
            let condition = if state.etag.is_empty() {
                ("if-none-match".into(), "*".into())
            } else {
                ("if-match".into(), state.etag.clone())
            };
            let r = peer
                .s3(
                    "POST",
                    &key,
                    &[("uploadId", state.upload.clone())],
                    &[condition, ("content-type".into(), "application/xml".into())],
                    body.into_bytes(),
                )
                .await?;
            r.success()?;
            ensure!(
                !String::from_utf8_lossy(&r.body).contains("<Error>"),
                "multipart commit failed"
            );
            let final_head = peer.s3("HEAD", &key, &[], &[], vec![]).await?;
            final_head.success()?;
            ensure!(
                header(&final_head, "x-amz-meta-sigma-sha256")? == hash
                    && header(&final_head, "content-length")?.parse::<u64>()? == size,
                "remote checksum mismatch; source retained"
            );
            state.complete = true;
            save(&path, &state)?;
        }
        crate::jobs::patch(core, jid, json!({"sha256":hash,"completed_bytes":size})).await?;
    } else {
        let head = peer.s3("HEAD", &key, &[], &[], vec![]).await?;
        head.success()?;
        let size = header(&head, "content-length")?.parse::<u64>()?;
        let etag = header(&head, "etag")?.to_owned();
        let hash = header(&head, "x-amz-meta-sigma-sha256")?.to_owned();
        ensure!(
            hash.len() == 64 && hash.bytes().all(|b| b.is_ascii_hexdigit()),
            "remote checksum required"
        );
        if state.etag.is_empty() {
            state.etag = etag.clone();
            state.source_hash = hash.clone();
            state.size = size;
            save(&path, &state)?;
        }
        ensure!(
            state.etag == etag && state.source_hash == hash && state.size == size,
            "source changed; partial/original retained"
        );
        let part = work.join("download.part");
        let mut output = std::fs::OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(&part)?;
        ensure!(
            output.metadata()?.len() >= state.offset,
            "checkpoint data missing"
        );
        output.set_len(state.offset)?;
        output.seek(std::io::SeekFrom::Start(state.offset))?;
        crate::jobs::patch(core,jid,json!({"state":"downloading","total_bytes":size,"completed_bytes":state.offset,"reused_bytes":state.offset})).await?;
        while state.offset < size {
            stopped(stop)?;
            let started = std::time::Instant::now();
            let end = (state.offset + 8 * 1024 * 1024).min(size) - 1;
            let r = peer
                .s3(
                    "GET",
                    &key,
                    &[],
                    &[
                        ("if-match".into(), etag.clone()),
                        ("range".into(), format!("bytes={}-{end}", state.offset)),
                    ],
                    vec![],
                )
                .await?;
            ensure!(r.status == 206, "range rejected HTTP {}", r.status);
            let len = end + 1 - state.offset;
            ensure!(
                r.body.len() as u64 == len
                    && header(&r, "etag")? == etag
                    && header(&r, "content-range")?
                        == format!("bytes {}-{end}/{size}", state.offset),
                "range/source identity mismatch"
            );
            output.write_all(&r.body)?;
            output.sync_all()?;
            state.offset += len;
            save(&path, &state)?;
            crate::jobs::patch(core, jid, json!({"completed_bytes":state.offset})).await?;
            pace(
                job["bytes_per_second"].as_u64().unwrap_or(0),
                len,
                started,
                stop,
            )
            .await?;
        }
        drop(output);
        ensure!(
            crate::jobs::file_hash_interruptible(&part, stop)? == hash,
            "download checksum mismatch; partial retained"
        );
        peer.s3("HEAD", &key, &[], &[("if-match".into(), etag)], vec![])
            .await?
            .success()?;
        let destination = PathBuf::from(
            job["destination"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("destination missing"))?,
        );
        let receipt = work.join("local-publication.json");
        let expected = json!({"job":jid,"destination":destination,"bytes":size,"sha256":hash});
        if destination.exists() {
            ensure!(
                receipt.exists()
                    && serde_json::from_slice::<Value>(&std::fs::read(&receipt)?)? == expected
                    && crate::jobs::file_hash_interruptible(&destination, stop)? == hash,
                "destination collision; original retained"
            );
        } else {
            let staging = destination.with_file_name(format!(
                ".sigma-{jid}.{}.partial",
                uuid::Uuid::new_v4().simple()
            ));
            let mut out = std::fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&staging)?;
            let mut source = std::fs::File::open(&part)?;
            crate::jobs::copy_interruptible(&mut source, &mut out, stop)?;
            out.sync_all()?;
            drop(out);
            ensure!(
                crate::jobs::file_hash_interruptible(&staging, stop)? == hash,
                "local copy checksum mismatch"
            );
            crate::identity::atomic(&receipt, &serde_json::to_vec(&expected)?)?;
            std::fs::hard_link(&staging, &destination)?;
            let _ = std::fs::remove_file(staging);
        }
        state.complete = true;
        save(&path, &state)?;
        crate::jobs::patch(core, jid, json!({"sha256":hash,"completed_bytes":size})).await?;
    }
    Ok(json!({"completed":true,"source_preserved":true}))
}
