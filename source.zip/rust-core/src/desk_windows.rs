//! Windows owner/session boundary and an owned kill-on-close process tree.
//! No service installation, elevation, active-console switching or shared profile.
use crate::desk_transport::Proxy;
use anyhow::{Result, ensure};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    fs::{File, OpenOptions},
    io::Read,
    os::windows::{
        ffi::{OsStrExt, OsStringExt},
        fs::OpenOptionsExt,
    },
    path::{Path, PathBuf},
    ptr::{null, null_mut},
};
use windows_sys::Win32::{
    Foundation::{CloseHandle, HANDLE, LocalFree},
    Security::{Authorization::*, *},
    System::{Com::CoTaskMemFree, JobObjects::*, Threading::*},
    UI::Shell::{FOLDERID_RoamingAppData, SHGetKnownFolderPath},
};
mod prepared;
pub(crate) use prepared::{AssetCache, AssetContext};
pub fn engine_bytes() -> u64 {
    crate::desk_assets::bytes()
}
fn engine_root() -> Result<PathBuf> {
    crate::desk_assets::root()
}
// Runtime consumes only the pinned, already installed component. Installation,
// update and general root repair keep their existing whole-tree behavior.
fn runtime_engine_root() -> Result<sigmadrive_distribution::component_scope::ScopedComponent> {
    let manifest = crate::desk_assets::manifest()?;
    let relative = PathBuf::from("components").join("sigmadesk")
        .join(hex::encode(Sha256::digest(crate::desk_assets::MANIFEST.as_bytes())));
    let expected = manifest.files.iter().map(|asset| asset.path.clone()).collect::<Vec<_>>();
    sigmadrive_distribution::component_scope::existing_component(&relative, &expected)
}
fn wide(s: &std::ffi::OsStr) -> Vec<u16> {
    s.encode_wide().chain(Some(0)).collect()
}
fn last() -> anyhow::Error {
    std::io::Error::last_os_error().into()
}
fn roaming() -> Result<PathBuf> {
    let mut raw = null_mut();
    ensure!(
        unsafe { SHGetKnownFolderPath(&FOLDERID_RoamingAppData, 0, null_mut(), &mut raw) } >= 0
            && !raw.is_null(),
        "SigmaDesk Known Folder unavailable"
    );
    let n = (0..).take_while(|i| unsafe { *raw.add(*i) } != 0).count();
    let p = PathBuf::from(std::ffi::OsString::from_wide(unsafe {
        std::slice::from_raw_parts(raw, n)
    }));
    unsafe { CoTaskMemFree(raw.cast()) };
    Ok(p)
}
pub fn desktop() -> Result<String> {
    use windows_sys::Win32::System::RemoteDesktop::*;
    let sid = crate::identity::current_sid()?;
    let mut session = 0;
    ensure!(
        unsafe { ProcessIdToSessionId(GetCurrentProcessId(), &mut session) } != 0 && session != 0,
        "interactive Windows user session required"
    );
    fn text(session: u32, kind: WTS_INFO_CLASS) -> Result<String> {
        let mut raw = null_mut();
        let mut len = 0;
        ensure!(
            unsafe { WTSQuerySessionInformationW(null_mut(), session, kind, &mut raw, &mut len) }
                != 0,
            "Windows desktop owner unavailable"
        );
        let result = (|| {
            ensure!(
                !raw.is_null() && (2..=65536).contains(&len) && len % 2 == 0,
                "Windows desktop metadata invalid"
            );
            let chars = unsafe { std::slice::from_raw_parts(raw, len as usize / 2) };
            ensure!(chars.last() == Some(&0), "unterminated desktop metadata");
            Ok(String::from_utf16(&chars[..chars.len() - 1])?)
        })();
        unsafe { WTSFreeMemory(raw.cast()) };
        result
    }
    let user = text(session, WTSUserName)?;
    let domain = text(session, WTSDomainName)?;
    ensure!(!user.is_empty(), "Windows desktop has no owner");
    let name = wide(std::ffi::OsStr::new(&format!("{domain}\\{user}")));
    let mut size = 0;
    let mut domain_len = 0;
    let mut kind = 0;
    unsafe {
        LookupAccountNameW(
            null(),
            name.as_ptr(),
            null_mut(),
            &mut size,
            null_mut(),
            &mut domain_len,
            &mut kind,
        )
    };
    ensure!(
        (1..=65536).contains(&size) && domain_len <= 32768,
        "desktop SID unavailable"
    );
    let mut owner = vec![0u8; size as usize];
    let mut resolved = vec![0u16; domain_len as usize];
    ensure!(
        unsafe {
            LookupAccountNameW(
                null(),
                name.as_ptr(),
                owner.as_mut_ptr().cast(),
                &mut size,
                resolved.as_mut_ptr(),
                &mut domain_len,
                &mut kind,
            )
        } != 0,
        "desktop SID lookup failed"
    );
    let mut actual = null_mut();
    ensure!(
        unsafe { ConvertSidToStringSidW(owner.as_mut_ptr().cast(), &mut actual) } != 0,
        "desktop SID conversion failed"
    );
    let n = (0..)
        .take_while(|i| unsafe { *actual.add(*i) } != 0)
        .count();
    let actual_sid = String::from_utf16(unsafe { std::slice::from_raw_parts(actual, n) });
    unsafe { LocalFree(actual.cast()) };
    ensure!(
        actual_sid? == sid,
        "SigmaDesk process does not own this Windows desktop"
    );
    Ok(hex::encode(Sha256::digest(format!(
        "sigmadrive/desktop-context/v1\0{sid}\0{session}"
    ))))
}
fn private(path: &Path, base: &Path) -> Result<()> {
    ensure!(
        path.starts_with(base) && path.components().count() <= base.components().count() + 2,
        "private SigmaDesk profile scope denied"
    );
    sigmadrive_distribution::download::safe(path).map_err(anyhow::Error::msg)?;
    std::fs::create_dir_all(path)?;
    let sid = crate::identity::current_sid()?;
    let name = wide(path.as_os_str());
    let mut owner = null_mut();
    let mut old = null_mut();
    let code = unsafe {
        GetNamedSecurityInfoW(
            name.as_ptr(),
            SE_FILE_OBJECT,
            OWNER_SECURITY_INFORMATION,
            &mut owner,
            null_mut(),
            null_mut(),
            null_mut(),
            &mut old,
        )
    };
    ensure!(code == 0, "SigmaDesk profile owner unavailable");
    let mut owner_string = null_mut();
    let converted = unsafe { ConvertSidToStringSidW(owner, &mut owner_string) };
    let owned = if converted != 0 {
        let n = (0..)
            .take_while(|i| unsafe { *owner_string.add(*i) } != 0)
            .count();
        let s = String::from_utf16(unsafe { std::slice::from_raw_parts(owner_string, n) });
        unsafe { LocalFree(owner_string.cast()) };
        s.is_ok_and(|s| s == sid || s == "S-1-5-32-544")
    } else {
        false
    };
    unsafe { LocalFree(old) };
    ensure!(owned, "foreign SigmaDesk profile owner denied");
    let sddl = wide(std::ffi::OsStr::new(&format!(
        "O:{sid}D:P(A;OICI;FA;;;{sid})"
    )));
    let mut sd = null_mut();
    ensure!(
        unsafe {
            ConvertStringSecurityDescriptorToSecurityDescriptorW(
                sddl.as_ptr(),
                1,
                &mut sd,
                null_mut(),
            )
        } != 0,
        "SigmaDesk private ACL unavailable"
    );
    let mut acl = null_mut();
    let mut present = 0;
    let mut defaulted = 0;
    let mut new_owner = null_mut();
    let got = unsafe {
        GetSecurityDescriptorDacl(sd, &mut present, &mut acl, &mut defaulted) != 0
            && GetSecurityDescriptorOwner(sd, &mut new_owner, &mut defaulted) != 0
    };
    let applied = got
        && unsafe {
            SetNamedSecurityInfoW(
                name.as_ptr(),
                SE_FILE_OBJECT,
                OWNER_SECURITY_INFORMATION
                    | DACL_SECURITY_INFORMATION
                    | PROTECTED_DACL_SECURITY_INFORMATION,
                new_owner,
                null_mut(),
                acl,
                null_mut(),
            )
        } == 0;
    unsafe { LocalFree(sd) };
    ensure!(applied, "SigmaDesk private ACL failed");
    Ok(())
}
pub fn engine_files() -> Result<Vec<File>> {
    let root = engine_root()?;
    engine_files_at(&root)
}
pub fn engine_files_at(root: &Path) -> Result<Vec<File>> {
    let manifest = crate::desk_assets::manifest()?;
    verify_engine_files(root, &manifest)
}
fn verify_engine_files(root: &Path, manifest: &crate::desk_assets::Manifest) -> Result<Vec<File>> {
    verify_engine_files_until(root, manifest, &|| Ok(()))
}
fn verify_engine_files_until(root: &Path, manifest: &crate::desk_assets::Manifest,
    current: &(impl Fn() -> Result<()> + ?Sized)) -> Result<Vec<File>> {
    let mut paths = std::collections::HashSet::new();
    let mut handles = vec![];
    for asset in &manifest.files {
        current()?;
        ensure!(
            !asset.path.is_empty()
                && asset
                    .path
                    .split('/')
                    .all(|p| !p.is_empty() && p != "." && p != ".." && !p.contains(['\\', ':']))
                && paths.insert(asset.path.as_str()),
            "SigmaDesk asset path denied"
        );
        let file = root.join(&asset.path);
        sigmadrive_distribution::download::safe(&file).map_err(anyhow::Error::msg)?;
        let mut handle = OpenOptions::new().read(true).share_mode(1).open(file)?;
        ensure!(
            handle.metadata()?.is_file() && handle.metadata()?.len() == asset.bytes,
            "SigmaDesk engine size mismatch"
        );
        let mut h = Sha256::new();
        let mut buf = [0; 65536];
        loop {
            current()?;
            let n = handle.read(&mut buf)?;
            if n == 0 {
                break;
            }
            h.update(&buf[..n]);
        }
        ensure!(
            hex::encode(h.finalize()) == asset.sha256,
            "SigmaDesk engine hash mismatch"
        );
        handles.push(handle);
    }
    ensure!(
        paths.contains(manifest.entry.as_str())
            && paths.contains("librustdesk.dll")
            && paths.contains("flutter_windows.dll"),
        "SigmaDesk Flutter engine incomplete"
    );
    engine_inventory(root, root, &paths)?;
    current()?;
    Ok(handles)
}
fn engine_inventory(
        root: &Path,
        dir: &Path,
        expected: &std::collections::HashSet<&str>,
    ) -> Result<()> {
        for item in std::fs::read_dir(dir)? {
            let item = item?;
            let path = item.path();
            sigmadrive_distribution::download::safe(&path).map_err(anyhow::Error::msg)?;
            let kind = item.file_type()?;
            if kind.is_dir() {
                let relative=path.strip_prefix(root)?.to_string_lossy().replace('\\', "/")+"/";
                ensure!(expected.iter().any(|name|name.starts_with(&relative)),
                    "unlisted SigmaDesk engine directory");
                engine_inventory(root, &path, expected)?;
            } else {
                let relative = path
                    .strip_prefix(root)?
                    .to_string_lossy()
                    .replace('\\', "/");
                ensure!(
                    kind.is_file() && expected.contains(relative.as_str()),
                    "unlisted SigmaDesk engine asset"
                );
            }
        }
    Ok(())
}
// New stage events report individual durations; existing milestone events keep
// their cumulative elapsed times. Never record operation values or raw errors.
fn stage<T>(trace: &crate::desk::Runtime, session: &str, role: &str,
    event: &'static str, operation: impl FnOnce() -> Result<T>) -> Result<T> {
    let started = std::time::Instant::now();
    trace.record(event, session, role, "begin", std::time::Duration::ZERO, None);
    let result = operation();
    trace.record(event, session, role, if result.is_ok() { "ok" } else { "failed" }, started.elapsed(), None);
    result
}

// These files contain a session-scoped delegated password or its peer hash.
// Own their cleanup before the first write, including all later `?` paths.
// The guard remains inside Engine so normal stop has the same cleanup rule.
struct DelegatedCredentials {
    main: PathBuf,
    peer: PathBuf,
}
impl DelegatedCredentials {
    fn new(root: &Path, prefix: &str, peer: &str) -> Self {
        Self {
            main: root.join(format!("{prefix}.toml")),
            peer: root.join("peers").join(format!("{peer}.toml")),
        }
    }
    fn clear(&self) {
        for (path, peer) in [(&self.main, false), (&self.peer, true)] {
            // If a malformed/partial file cannot be rewritten, remove only
            // this exact credential file. Never sweep a profile directory.
            if clear_password(path, peer).is_err() {
                let _ = std::fs::remove_file(path);
            }
        }
    }
}
impl Drop for DelegatedCredentials {
    fn drop(&mut self) { self.clear(); }
}

// Unlike a general settings write, a failed credential write must also erase
// its own temporary plaintext file. The parent directory is already private
// and the profile's deny-share lock is held by the caller throughout startup.
fn write_credential(path: &Path, bytes: &[u8]) -> Result<()> {
    use std::io::Write;
    struct Pending { path: PathBuf, file: Option<File> }
    impl Drop for Pending {
        fn drop(&mut self) {
            self.file.take();
            let _ = std::fs::remove_file(&self.path);
        }
    }
    let temporary = path.with_extension(format!("{}.tmp", uuid::Uuid::new_v4()));
    let file = OpenOptions::new().create_new(true).write(true).open(&temporary)?;
    let mut pending = Pending { path: temporary, file: Some(file) };
    pending.file.as_mut().unwrap().write_all(bytes)?;
    pending.file.as_ref().unwrap().sync_all()?;
    pending.file.take();
    use windows_sys::Win32::Storage::FileSystem::{
        MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, MoveFileExW,
    };
    if unsafe {
        MoveFileExW(
            wide(pending.path.as_os_str()).as_ptr(), wide(path.as_os_str()).as_ptr(),
            MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH,
        )
    } == 0 { return Err(last()); }
    Ok(())
}

// Until successful publication, every raw launch HANDLE belongs to this
// guard. In particular, cancellation after job setup must close the job, and
// failure before job assignment must terminate the still-suspended process.
struct EngineLaunch {
    job: HANDLE,
    process: HANDLE,
    thread: HANDLE,
}
impl EngineLaunch {
    fn new() -> Result<Self> {
        let job = unsafe { CreateJobObjectW(null(), null()) };
        ensure!(!job.is_null(), "SigmaDesk process job unavailable");
        let guard = Self { job, process: null_mut(), thread: null_mut() };
        let mut limits: JOBOBJECT_EXTENDED_LIMIT_INFORMATION = unsafe { std::mem::zeroed() };
        limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        if unsafe {
            SetInformationJobObject(
                guard.job,
                JobObjectExtendedLimitInformation,
                (&limits as *const JOBOBJECT_EXTENDED_LIMIT_INFORMATION).cast(),
                std::mem::size_of_val(&limits) as u32,
            )
        } == 0 {
            return Err(last());
        }
        Ok(guard)
    }
    // Called immediately after a successful CreateProcessW, before any
    // fallible operation. No HANDLE may remain outside its owner on failure.
    fn created(&mut self, pi: PROCESS_INFORMATION) {
        debug_assert!(self.process.is_null() && self.thread.is_null());
        self.process = pi.hProcess;
        self.thread = pi.hThread;
    }
    fn close_thread(&mut self) {
        if !self.thread.is_null() {
            unsafe { CloseHandle(self.thread) };
            self.thread = null_mut();
        }
    }
    fn into_handles(mut self) -> (HANDLE, HANDLE) {
        self.close_thread();
        let job = std::mem::replace(&mut self.job, null_mut());
        let process = std::mem::replace(&mut self.process, null_mut());
        (job, process)
    }
}
impl Drop for EngineLaunch {
    fn drop(&mut self) {
        if !self.job.is_null() {
            // A registration helper can hold a duplicate job HANDLE. Explicit
            // termination therefore precedes close; kill-on-close alone is
            // insufficient for a failed startup with duplicate owners.
            unsafe { TerminateJobObject(self.job, 1) };
        }
        if !self.process.is_null() {
            unsafe {
                TerminateProcess(self.process, 1);
                WaitForSingleObject(self.process, 5000);
                CloseHandle(self.process);
            }
            self.process = null_mut();
        }
        self.close_thread();
        if !self.job.is_null() {
            unsafe { CloseHandle(self.job) };
            self.job = null_mut();
        }
    }
}
pub struct Engine {
    job: HANDLE,
    process: HANDLE,
    _assets: std::sync::Arc<prepared::PreparedAssets>,
    // Set only after full asset verification; held deny-write/delete handles
    // and the owned Job remain in this same object for its entire lifetime.
    verified_manifest_pin: String,
    credentials: DelegatedCredentials,
    _lock: File,
    pub proxy: Proxy,
    stopped: bool,
}
// Raw handles belong exclusively to this object, guarded by the desk runtime mutex.
unsafe impl Send for Engine {}
impl Engine {
    pub async fn start(
        decision: &Value,
        local: &Value,
        desktop: &str,
        control: bool,
        token: String,
        trace: &crate::desk::Runtime,
        epoch: u64,
        cancelled: &std::sync::atomic::AtomicBool,
        registration: Option<std::sync::Arc<crate::desk_registration::Registration>>,
        asset_context: AssetContext,
    ) -> Result<Self> {
        let started=std::time::Instant::now();
        let session=decision["binding"]["session_id"].as_str().unwrap_or("");
        let role=if decision["binding"]["kind"]=="browser" || decision["role"]=="host" {"host"}else{"viewer"};
        stage(trace, session, role, "engine_stage_desktop", || {
            ensure!(self::desktop()? == desktop, "Windows desktop changed");
            Ok(())
        })?;
        crate::desk::startup_allowed_for(trace,epoch,cancelled,session)?;
        ensure!(asset_context.matches(local, desktop), "SigmaDesk asset context changed");
        let assets = stage(trace, session, role, "engine_stage_verify", || {
            let current=|| crate::desk::startup_allowed_for(trace,epoch,cancelled,session);
            if role=="host" {trace.assets.acquire(&asset_context, &current)}
            else {prepared::PreparedAssets::prepare(asset_context.clone(), &current).map(std::sync::Arc::new)}
        })?;
        let component_root = assets.root.clone();
        let verified_manifest_pin=assets.context.manifest.clone();
        crate::desk::startup_allowed_for(trace,epoch,cancelled,session)?;
        trace.record("engine_assets_verified",session,role,"ok",started.elapsed(),None);
        let sid = decision["binding"]["session_id"].as_str().unwrap_or("");
        ensure!(
            crate::desk_lease::valid_id(sid),
            "SigmaDesk assignment ID invalid"
        );
        let namespace = hex::encode(Sha256::digest(format!(
            "sigmadrive/isolated-engine/v1\0{desktop}\0{}\0{sid}",
            local["node"].as_str().unwrap_or("")
        )));
        let prefix = format!("SigmaDesk-{namespace}");
        let (parent, root, lock) = stage(trace, session, role, "engine_stage_profile_dirs", || {
            let base = roaming()?;
            let parent = base.join(&prefix);
            private(&parent, &base)?;
            let root = parent.join("config");
            private(&root, &base)?;
            let lock = OpenOptions::new()
                .create(true)
                .truncate(false)
                .read(true)
                .write(true)
                .share_mode(0)
                .open(root.join("engine.lock"))?;
            Ok((parent, root, lock))
        })?;
        let host = decision["binding"]["kind"] == "browser" || decision["role"] == "host";
        let (host_id, peer_id) = if decision["binding"]["kind"] == "browser" {
            (
                crate::desk_lease::rdid(&decision["binding"]["host_rdid"])?,
                crate::desk_lease::rdid(&decision["binding"]["peer_rdid"])?,
            )
        } else {
            (
                crate::desk_lease::rdid(&decision["hostRdid"])?,
                crate::desk_lease::rdid(&decision["peerRdid"])?,
            )
        };
        let password = decision["password"].as_str().unwrap_or("");
        let salt = decision["salt"].as_str().unwrap_or("");
        ensure!(
            (32..=256).contains(&password.len()) && (24..=256).contains(&salt.len()),
            "SigmaDesk delegated credential invalid"
        );
        let owner = format!(
            "sigmadrive-sigmadesk-rust/{}",
            local["node"].as_str().unwrap_or("")
        );
        let marker = root.join("sigma-rust-owner.json");
        stage(trace, session, role, "engine_stage_profile_owner", || {
            if marker.exists() {
                ensure!(
                    std::fs::read_to_string(&marker)? == owner,
                    "SigmaDesk profile belongs to another node"
                );
            } else {
                ensure!(
                    std::fs::read_dir(&root)?.all(|e| e.is_ok_and(|e| e.file_name() == "engine.lock")),
                    "foreign SigmaDesk profile contents"
                );
                crate::identity::atomic(&marker, owner.as_bytes())?;
            }
            Ok(())
        })?;
        let credentials = DelegatedCredentials::new(&root, &prefix, host_id);
        let config = format!(
            "id = {}\nenc_id = \"\"\nkey_confirmed = false\npassword = {}\nsalt = {}\n",
            q(if host { host_id } else { peer_id }),
            q(password),
            q(salt)
        );
        stage(trace, session, role, "engine_stage_profile_main", || {
            write_credential(&credentials.main, config.as_bytes())
        })?;
        // Consume only after the existing verified assignment, complete pinned
        // assets, same Windows/user/profile context and startup cancellation
        // checks. No grant is returned/refunded after a later startup failure.
        crate::desk::startup_allowed_for(trace,epoch,cancelled,session)?;
        ensure!(self::desktop()?==desktop&&asset_context.matches(local,desktop),"Local diagnostics startup context changed");
        let local_diagnostics_enabled=trace.consume_local_diagnostics(&assets.context,&verified_manifest_pin,&namespace,epoch,cancelled,session)?;
        // Use the same consumed local-only one-shot grant for transport timing.
        let proxy = Proxy::start_with_registration_diagnostics(token, registration, local_diagnostics_enabled).await?;
        trace.track_start_proxy(&proxy)?;
        crate::desk::startup_allowed_for(trace,epoch,cancelled,session)?;
        trace.record("engine_proxy_bound",session,role,"ok",started.elapsed(),None);
        let mut options = std::collections::BTreeMap::from([
            ("sigma-engine-local-metrics-v1",if local_diagnostics_enabled{"Y"}else{"N"}.into()),
            ("custom-rendezvous-server", proxy.id.to_string()),
            ("relay-server", proxy.relay.to_string()),
            ("key", crate::desk_lease::SERVER_KEY.into()),
            ("api-server", "http://127.0.0.1:9".into()),
            ("access-mode", "custom".into()),
            ("approve-mode", "password".into()),
            ("verification-method", "use-permanent-password".into()),
            ("id-whitelist", peer_id.into()),
            (
                "enable-keyboard",
                if host && control { "Y" } else { "N" }.into(),
            ),
        ]);
        if host && proxy.registration.is_some()
            && crate::desk_streaming::fast_registration_allowed(&verified_manifest_pin) {
            options.insert("sigma-fast-register-v1","Y".into());
        }
        // The reviewed browser host advertises VP9 only. Its fresh private
        // profile does not need the unrelated synthetic AV1 calibration.
        crate::desk_codec_startup::select_browser_startup_work(
            host && decision["binding"]["kind"] == "browser",
            &verified_manifest_pin,
            &mut options,
        );
        for name in [
            "allow-websocket",
            "allow-insecure-tls-fallback",
            "direct-server",
            "enable-lan-discovery",
            "allow-remote-config-modification",
            "allow-remote-cm-modification",
            "allow-auto-update",
            "allow-auto-record-incoming",
            "allow-auto-record-outgoing",
            "allow-hide-cm",
            "allow-logon-screen-password",
        ] {
            options.insert(name, "N".into());
        }
        for name in [
            "enable-clipboard",
            "enable-file-transfer",
            "enable-camera",
            "enable-terminal",
            "enable-remote-printer",
            "enable-audio",
            "enable-tunnel",
            "enable-remote-restart",
            "enable-record-session",
            "enable-block-input",
            "enable-privacy-mode",
        ] {
            options.insert(name, "N".into());
        }
        stage(trace, session, role, "engine_stage_profile_options", || {
            crate::identity::atomic(
                &root.join(format!("{prefix}2.toml")),
                toml_options(options).as_bytes(),
            )
        })?;
        if !host {
            let peers = root.join("peers");
            private(&peers, &parent)?;
            let hash = Sha256::digest(format!("{password}{salt}"));
            let bytes = hash.iter().map(u8::to_string).collect::<Vec<_>>().join(",");
            let peer = format!(
                "password = [{bytes}]\n{PEER_DEFAULTS}view_only = {}\ndisable_clipboard = true\ndisable_audio = true\nenable-file-copy-paste = false\n[options]\ncustom-fps = '15'\nforce-always-relay = 'Y'\ndisable-clipboard = 'Y'\ndisable-audio = 'Y'\nenable-file-copy-paste = 'N'\n[ui_flutter]\n[info]\nusername = ''\nhostname = 'SigmaDesk'\nplatform = 'Windows'\n[transfer]\nwrite_jobs = []\nread_jobs = []\n",
                !control
            );
            stage(trace, session, role, "engine_stage_profile_peer", || {
                write_credential(&credentials.peer, peer.as_bytes())
            })?;
        }
        let exe = component_root.join("rustdesk.exe");
        crate::desk::startup_allowed_for(trace,epoch,cancelled,session)?;
        trace.record("engine_profile_ready",session,role,"ok",started.elapsed(),None);
        let mut command = format!(
            "\"{}\" {}",
            exe.to_string_lossy(),
            if host {
                "--server".into()
            } else {
                format!("--no-server --connect {host_id}")
            }
        );
        let command_wide = wide(std::ffi::OsStr::new(&command));
        let mut command_wide = command_wide;
        use zeroize::Zeroize;
        command.zeroize();
        let mut env = std::collections::BTreeMap::new();
        for name in [
            "SystemRoot",
            "APPDATA",
            "LOCALAPPDATA",
            "USERPROFILE",
            "TEMP",
            "TMP",
            "PATH",
        ] {
            if let Some(v) = std::env::var_os(name) {
                env.insert(name.to_owned(), v.to_string_lossy().into_owned());
            }
        }
        env.insert("SIGMADESK_ISOLATION_NAMESPACE".into(), namespace);
        let env = env
            .into_iter()
            .map(|(k, v)| format!("{k}={v}\0"))
            .collect::<String>()
            + "\0";
        let env = env.encode_utf16().collect::<Vec<_>>();
        let mut si: STARTUPINFOW = unsafe { std::mem::zeroed() };
        si.cb = std::mem::size_of_val(&si) as u32;
        let mut pi: PROCESS_INFORMATION = unsafe { std::mem::zeroed() };
        let mut launch = EngineLaunch::new()?;
        crate::desk::startup_allowed_for(trace,epoch,cancelled,session)?;
        let created = unsafe {
            CreateProcessW(
                wide(exe.as_os_str()).as_ptr(),
                command_wide.as_mut_ptr(),
                null(),
                null(),
                0,
                CREATE_SUSPENDED | CREATE_UNICODE_ENVIRONMENT,
                env.as_ptr().cast(),
                null(),
                &si,
                &mut pi,
            )
        };
        if created == 0 {
            return Err(last());
        }
        launch.created(pi);
        let assigned = unsafe { AssignProcessToJobObject(launch.job, launch.process) } != 0
            && (proxy.registration.is_none() || proxy.registration_job.bind(launch.job).is_ok());
        if !assigned {
            return Err(last());
        }
        let resumed = crate::desk::startup_allowed_for(trace,epoch,cancelled,session).is_ok()
            && unsafe { ResumeThread(launch.thread) } != u32::MAX;
        launch.close_thread();
        if !resumed {
            anyhow::bail!("SigmaDesk engine launch failed");
        }
        trace.record("engine_spawned",session,role,"ok",started.elapsed(),None);
        let (job, process) = launch.into_handles();
        Ok(Self {
            job,
            process,
            _assets: assets,
            verified_manifest_pin,
            credentials,
            _lock: lock,
            proxy,
            stopped: false,
        })
    }
    pub fn processes(&self) -> u32 {
        if self.stopped {
            return 0;
        }
        let mut info: JOBOBJECT_BASIC_ACCOUNTING_INFORMATION = unsafe { std::mem::zeroed() };
        if unsafe {
            QueryInformationJobObject(
                self.job,
                JobObjectBasicAccountingInformation,
                (&mut info as *mut JOBOBJECT_BASIC_ACCOUNTING_INFORMATION).cast(),
                std::mem::size_of_val(&info) as u32,
                null_mut(),
            )
        } == 0
        {
            return 0;
        }
        info.ActiveProcesses
    }
    pub fn registration_observation(&self, now: std::time::Instant) -> Option<crate::desk_registration::Observation> {
        let registration = self.proxy.registration.as_ref()?;
        if self.stopped || self.processes() == 0 || !self.proxy.registration_job.process(self.process) { registration.stop(); }
        Some(registration.observation(now))
    }
    pub fn streaming_manifest_pin(&self) -> Option<&str> {
        if self.stopped || !self._assets.pinned() || self.processes()==0
            || self.proxy.registration.is_none()
            || !self.proxy.registration_job.process(self.process) {return None}
        // Exit code259 can also be a completed process's real exit value.
        // The main process handle must be unsignaled, independently of live siblings.
        if unsafe{WaitForSingleObject(self.process,0)}!=windows_sys::Win32::Foundation::WAIT_TIMEOUT {return None}
        let mut code=0;
        if unsafe{GetExitCodeProcess(self.process,&mut code)}==0 || code!=259 {return None}
        Some(self.verified_manifest_pin.as_str())
    }
    pub fn exit_code(&self) -> Option<u32> {
        if self.stopped { return None; }
        let mut code=0;
        if unsafe{GetExitCodeProcess(self.process,&mut code)}==0 || code==259 {None}else{Some(code)}
    }
    pub fn stop(&mut self) {
        if self.stopped {
            return;
        }
        self.stopped = true;
        self.proxy.stop();
        unsafe {
            TerminateJobObject(self.job, 0);
            WaitForSingleObject(self.process, 5000);
            CloseHandle(self.process);
            CloseHandle(self.job)
        };
        self.process = null_mut();
        self.job = null_mut();
        self.credentials.clear();
    }
}
impl Drop for Engine {
    fn drop(&mut self) {
        self.stop();
    }
}
fn clear_password(path: &Path, peer: bool) -> Result<()> {
    if !path.exists() {
        return Ok(());
    }
    let text = std::fs::read_to_string(path)?;
    let content = text
        .lines()
        .map(|s| {
            if s.trim_start().starts_with("password =") {
                if peer {
                    "password = []"
                } else {
                    "password = \"\""
                }
            } else if !peer && s.trim_start().starts_with("salt =") {
                "salt = \"\""
            } else {
                s
            }
        })
        .collect::<Vec<_>>()
        .join("\n");
    crate::identity::atomic(path, content.as_bytes())
}
fn q(s: &str) -> String {
    serde_json::to_string(s).unwrap()
}
fn toml_options(values: std::collections::BTreeMap<&str, String>) -> String {
    let mut s = "[options]\n".to_owned();
    for (k, v) in values {
        s += &format!("{} = {}\n", q(k), q(&v));
    }
    s
}
const PEER_DEFAULTS: &str = "size = [0,0,0,0]\nsize_ft = [0,0,0,0]\nsize_pf = [0,0,0,0]\nview_style = 'adaptive'\nscroll_style = 'scrollauto'\nedge_scroll_edge_thickness = 100\nimage_quality = 'balanced'\ncustom_image_quality = [50]\nshow_remote_cursor = false\nlock_after_session_end = false\nterminal-persistent = false\nprivacy_mode = false\nallow_swap_key = false\nport_forwards = []\ndirect_failures = 1\nshow_quality_monitor = false\nfollow_remote_cursor = false\nfollow_remote_window = false\nshow_my_cursor = false\nsync-init-clipboard = false\ntrackpad-speed = 100\n";

#[cfg(test)]
mod tests {
    use super::*;

    struct Fixture(PathBuf);
    impl Fixture {
        fn new() -> Self {
            let root = std::env::temp_dir().join(format!("sigmadesk-startup-test-{}", uuid::Uuid::new_v4()));
            std::fs::create_dir(&root).unwrap();
            Self(root)
        }
        fn private() -> Self {
            let fixture = Self::new();
            private(&fixture.0, &std::env::temp_dir()).unwrap();
            fixture
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            // Resolve and bound every recursive cleanup to this test's own
            // direct child of the canonical temporary directory.
            let Ok(temp) = std::env::temp_dir().canonicalize() else { return };
            let Some(name) = self.0.file_name().and_then(|name| name.to_str()) else { return };
            let Some(id) = name.strip_prefix("sigmadesk-startup-test-") else { return };
            if uuid::Uuid::parse_str(id).is_err() { return; }
            let Ok(target) = self.0.canonicalize() else { return };
            if target.parent() == Some(temp.as_path()) && target.file_name() == self.0.file_name() {
                let _ = std::fs::remove_dir_all(target);
            }
        }
    }

    #[test]
    fn failed_startup_clears_main_and_peer_credentials_at_each_profile_stage() {
        for failure_after in 1..=3 {
            let fixture = Fixture::private();
            let prefix = "SigmaDesk-synthetic";
            let peer = "123456789";
            let main = fixture.0.join(format!("{prefix}.toml"));
            let peer_file = fixture.0.join("peers").join(format!("{peer}.toml"));
            let options = fixture.0.join(format!("{prefix}2.toml"));
            let marker = fixture.0.join("sigma-rust-owner.json");
            let unrelated = fixture.0.join("unrelated.toml");
            std::fs::write(&marker, b"synthetic owner").unwrap();
            std::fs::write(&unrelated, b"password = 'unrelated user value'").unwrap();
            let result: Result<()> = (|| {
                let credentials = DelegatedCredentials::new(&fixture.0, prefix, peer);
                write_credential(&credentials.main,
                    b"id = '123'\npassword = 'synthetic delegated password'\nsalt = 'synthetic salt'\n")?;
                if failure_after == 1 { anyhow::bail!("synthetic options failure"); }
                crate::identity::atomic(&options, b"[options]\naccess-mode = 'custom'\n")?;
                if failure_after == 2 { anyhow::bail!("synthetic peer-directory failure"); }
                private(&fixture.0.join("peers"), &fixture.0)?;
                write_credential(&credentials.peer, b"password = [1,2,3,4]\nview_only = true\n")?;
                anyhow::bail!("synthetic launch cancellation")
            })();
            assert!(result.is_err());
            let content = std::fs::read_to_string(&main).unwrap();
            assert!(content.contains("password = \"\""));
            assert!(content.contains("salt = \"\""));
            assert!(!content.contains("synthetic delegated password"));
            assert!(!content.contains("synthetic salt"));
            if peer_file.exists() {
                let peer_content = std::fs::read_to_string(&peer_file).unwrap();
                assert!(peer_content.contains("password = []"));
                assert!(peer_content.contains("view_only = true"));
                assert!(!peer_content.contains("1,2,3,4"));
            }
            assert_eq!(std::fs::read(&marker).unwrap(), b"synthetic owner");
            assert_eq!(std::fs::read(&unrelated).unwrap(), b"password = 'unrelated user value'");
            if failure_after > 1 {
                assert_eq!(std::fs::read(&options).unwrap(), b"[options]\naccess-mode = 'custom'\n");
            }
        }
    }

    #[test]
    fn credential_guard_moves_to_owner_and_clears_only_when_owner_drops() {
        struct Owner(DelegatedCredentials);
        let fixture = Fixture::private();
        let credentials = DelegatedCredentials::new(&fixture.0, "SigmaDesk-owner", "123456789");
        write_credential(&credentials.main, b"password = 'synthetic active password'\nsalt = 'salt'\n").unwrap();
        let owner = Owner(credentials);
        assert!(std::fs::read_to_string(&owner.0.main).unwrap().contains("synthetic active password"));
        let path = owner.0.main.clone();
        drop(owner);
        let cleared = std::fs::read_to_string(path).unwrap();
        assert_eq!(cleared, "password = \"\"\nsalt = \"\"");
    }

    #[test]
    fn credential_guard_removes_unreadable_partial_credential_without_profile_sweep() {
        let fixture = Fixture::private();
        let credentials = DelegatedCredentials::new(&fixture.0, "SigmaDesk-partial", "123456789");
        std::fs::write(&credentials.main, [0xff, 0xfe, 0xfd]).unwrap();
        let path = credentials.main.clone();
        let unrelated = fixture.0.join("keep.txt");
        std::fs::write(&unrelated, b"keep").unwrap();
        drop(credentials);
        assert!(!path.exists());
        assert_eq!(std::fs::read(unrelated).unwrap(), b"keep");
    }

    #[test]
    fn failed_credential_replace_removes_its_plaintext_temporary_file() {
        let fixture = Fixture::private();
        let path = fixture.0.join("SigmaDesk-blocked.toml");
        std::fs::write(&path, b"previous nonsecret value").unwrap();
        let deny_replace = OpenOptions::new().read(true).share_mode(0).open(&path).unwrap();
        assert!(write_credential(&path, b"password = 'synthetic failed-write secret'\n").is_err());
        drop(deny_replace);
        let names = std::fs::read_dir(&fixture.0).unwrap().map(|entry| {
            entry.unwrap().file_name().to_string_lossy().into_owned()
        }).collect::<Vec<_>>();
        assert_eq!(names, vec!["SigmaDesk-blocked.toml"]);
        assert_eq!(std::fs::read(path).unwrap(), b"previous nonsecret value");
    }

    fn assert_closed(handle: HANDLE) {
        let mut flags = 0;
        assert_eq!(unsafe { windows_sys::Win32::Foundation::GetHandleInformation(handle, &mut flags) }, 0);
    }
    fn duplicate(handle: HANDLE) -> std::os::windows::io::OwnedHandle {
        use std::os::windows::io::FromRawHandle;
        let mut copied = null_mut();
        assert_ne!(unsafe {
            windows_sys::Win32::Foundation::DuplicateHandle(
                GetCurrentProcess(), handle, GetCurrentProcess(), &mut copied, 0, 0,
                windows_sys::Win32::Foundation::DUPLICATE_SAME_ACCESS,
            )
        }, 0);
        unsafe { std::os::windows::io::OwnedHandle::from_raw_handle(copied) }
    }
    fn create_suspended_fixture(launch: &mut EngineLaunch) {
        // Launch only the already installed OS command interpreter, suspended
        // and without a window, network, user input or current-app attachment.
        let exe = PathBuf::from(std::env::var_os("SystemRoot").unwrap()).join("System32").join("cmd.exe");
        let mut command = wide(std::ffi::OsStr::new(&format!("\"{}\" /D /C exit 0", exe.display())));
        let mut startup: STARTUPINFOW = unsafe { std::mem::zeroed() };
        startup.cb = std::mem::size_of_val(&startup) as u32;
        let mut pi: PROCESS_INFORMATION = unsafe { std::mem::zeroed() };
        assert_ne!(unsafe {
            CreateProcessW(wide(exe.as_os_str()).as_ptr(), command.as_mut_ptr(), null(), null(), 0,
                CREATE_SUSPENDED | CREATE_NO_WINDOW, null(), null(), &startup, &mut pi)
        }, 0);
        launch.created(pi);
    }

    #[test]
    fn cancelled_startup_after_job_setup_closes_real_job_handle() {
        let runtime = crate::desk::Runtime::default();
        let cancelled = std::sync::atomic::AtomicBool::new(true);
        let mut observed = null_mut();
        let result: Result<()> = (|| {
            let launch = EngineLaunch::new()?;
            observed = launch.job;
            crate::desk::startup_allowed_for(&runtime, 0, &cancelled,
                "aabbccddeeff00112233445566778899")?;
            Ok(())
        })();
        assert!(result.is_err());
        assert!(!observed.is_null());
        assert_closed(observed);
    }

    #[test]
    fn failed_startup_before_job_assignment_terminates_suspended_process_and_closes_handles() {
        use std::os::windows::io::AsRawHandle;
        let mut launch = EngineLaunch::new().unwrap();
        create_suspended_fixture(&mut launch);
        let (job, process, thread) = (launch.job, launch.process, launch.thread);
        let observer = duplicate(process);
        assert_eq!(unsafe { WaitForSingleObject(observer.as_raw_handle(), 0) }, windows_sys::Win32::Foundation::WAIT_TIMEOUT);
        drop(launch);
        assert_closed(job);
        assert_closed(process);
        assert_closed(thread);
        assert_eq!(unsafe { WaitForSingleObject(observer.as_raw_handle(), 5000) }, windows_sys::Win32::Foundation::WAIT_OBJECT_0);
        let mut code = 0;
        assert_ne!(unsafe { GetExitCodeProcess(observer.as_raw_handle(), &mut code) }, 0);
        assert_eq!(code, 1);
    }

    #[test]
    fn failed_startup_after_assignment_terminates_job_even_with_duplicate_job_handle() {
        use std::os::windows::io::AsRawHandle;
        let mut launch = EngineLaunch::new().unwrap();
        create_suspended_fixture(&mut launch);
        assert_ne!(unsafe { AssignProcessToJobObject(launch.job, launch.process) }, 0);
        let observer = duplicate(launch.process);
        let job_observer = duplicate(launch.job);
        drop(launch);
        assert_eq!(unsafe { WaitForSingleObject(observer.as_raw_handle(), 5000) }, windows_sys::Win32::Foundation::WAIT_OBJECT_0);
        let mut info: JOBOBJECT_BASIC_ACCOUNTING_INFORMATION = unsafe { std::mem::zeroed() };
        assert_ne!(unsafe {
            QueryInformationJobObject(job_observer.as_raw_handle(), JobObjectBasicAccountingInformation,
                (&mut info as *mut JOBOBJECT_BASIC_ACCOUNTING_INFORMATION).cast(),
                std::mem::size_of_val(&info) as u32, null_mut())
        }, 0);
        assert_eq!(info.ActiveProcesses, 0);
    }

    #[test]
    fn successful_launch_transfers_process_and_job_ownership_without_termination() {
        use std::os::windows::io::{AsRawHandle, FromRawHandle, OwnedHandle};
        let mut launch = EngineLaunch::new().unwrap();
        create_suspended_fixture(&mut launch);
        assert_ne!(unsafe { AssignProcessToJobObject(launch.job, launch.process) }, 0);
        let resume = duplicate(launch.thread);
        let original_thread = launch.thread;
        let (job, process) = launch.into_handles();
        let job = unsafe { OwnedHandle::from_raw_handle(job) };
        let process = unsafe { OwnedHandle::from_raw_handle(process) };
        assert_closed(original_thread);
        assert_eq!(unsafe { WaitForSingleObject(process.as_raw_handle(), 0) }, windows_sys::Win32::Foundation::WAIT_TIMEOUT);
        let mut flags = 0;
        assert_ne!(unsafe { windows_sys::Win32::Foundation::GetHandleInformation(job.as_raw_handle(), &mut flags) }, 0);
        assert_ne!(unsafe { ResumeThread(resume.as_raw_handle()) }, u32::MAX);
        assert_eq!(unsafe { WaitForSingleObject(process.as_raw_handle(), 5000) }, windows_sys::Win32::Foundation::WAIT_OBJECT_0);
        let mut code = 1;
        assert_ne!(unsafe { GetExitCodeProcess(process.as_raw_handle(), &mut code) }, 0);
        assert_eq!(code, 0);
    }

    #[test]
    fn verified_engine_handles_keep_integrity_and_inventory_checks() {
        let fixture = Fixture::new();
        let bytes = b"synthetic engine fixture";
        let names = ["rustdesk.exe", "librustdesk.dll", "flutter_windows.dll"];
        let manifest = crate::desk_assets::Manifest {
            schema: 1,
            entry: "rustdesk.exe".into(),
            files: names.iter().map(|name| crate::desk_assets::Asset {
                path: (*name).into(),
                bytes: bytes.len() as u64,
                sha256: hex::encode(Sha256::digest(bytes)),
            }).collect(),
        };
        for name in names {
            std::fs::write(fixture.0.join(name), bytes).unwrap();
        }
        let handles = verify_engine_files(&fixture.0, &manifest).unwrap();
        assert_eq!(handles.len(), names.len());
        let entry = fixture.0.join("rustdesk.exe");
        assert!(OpenOptions::new().write(true).open(&entry).is_err());
        assert!(std::fs::remove_file(&entry).is_err());
        drop(handles);

        let mut tampered = bytes.to_vec();
        tampered[0] ^= 1;
        std::fs::write(&entry, tampered).unwrap();
        assert!(verify_engine_files(&fixture.0, &manifest).unwrap_err().to_string().contains("hash mismatch"));
        std::fs::write(&entry, bytes).unwrap();
        std::fs::write(fixture.0.join("unlisted.dll"), b"unexpected").unwrap();
        assert!(verify_engine_files(&fixture.0, &manifest).unwrap_err().to_string().contains("unlisted"));
    }

    #[test]
    fn verified_engine_handles_block_root_and_parent_directory_swaps() {
        let parent = Fixture::new();
        let moved_parent = Fixture(std::env::temp_dir().join(format!("sigmadesk-startup-test-{}", uuid::Uuid::new_v4())));
        let root = parent.0.join("engine");
        std::fs::create_dir(&root).unwrap();
        let bytes = b"synthetic engine fixture";
        let names = ["rustdesk.exe", "librustdesk.dll", "flutter_windows.dll"];
        let manifest = crate::desk_assets::Manifest {
            schema: 1,
            entry: "rustdesk.exe".into(),
            files: names.iter().map(|name| crate::desk_assets::Asset {
                path: (*name).into(), bytes: bytes.len() as u64,
                sha256: hex::encode(Sha256::digest(bytes)),
            }).collect(),
        };
        for name in names { std::fs::write(root.join(name), bytes).unwrap(); }
        let handles = verify_engine_files(&root, &manifest).unwrap();
        let renamed_root = root.with_file_name("engine-moved");
        let root_swap_allowed = std::fs::rename(&root, &renamed_root).is_ok();
        if root_swap_allowed { std::fs::rename(&renamed_root, &root).unwrap(); }
        let parent_swap_allowed = std::fs::rename(&parent.0, &moved_parent.0).is_ok();
        if parent_swap_allowed { std::fs::rename(&moved_parent.0, &parent.0).unwrap(); }
        drop(handles);
        assert!(!root_swap_allowed, "open verified files allowed engine root rename");
        assert!(!parent_swap_allowed, "open verified files allowed parent directory rename");
    }

    #[test]
    fn startup_stage_reports_duration_and_result_without_operation_data() {
        let runtime = crate::desk::Runtime::default();
        let session = "aabbccddeeff00112233445566778899";
        let value = stage(&runtime, session, "host", "engine_stage_verify", || {
            std::thread::sleep(std::time::Duration::from_millis(2));
            Ok("private result must not enter diagnostics")
        }).unwrap();
        assert_eq!(value, "private result must not enter diagnostics");
        let error = stage::<()>(&runtime, session, "host", "engine_stage_profile_main", || {
            anyhow::bail!("private path and credential must not enter diagnostics")
        }).unwrap_err();
        assert!(error.to_string().contains("private path"));
        let snapshot = runtime.snapshot();
        let rows = snapshot["diagnostics"].as_array().unwrap();
        assert_eq!(rows.len(), 4);
        assert_eq!(rows[0]["code"], "begin");
        assert_eq!(rows[1]["code"], "ok");
        assert!(rows[1]["elapsed_ms"].as_u64().unwrap() >= 1);
        assert_eq!(rows[3]["code"], "failed");
        assert!(!snapshot.to_string().contains("private"));
        for row in rows {
            assert!(row.as_object().unwrap().keys().all(|key| {
                ["at", "event", "session", "role", "code", "elapsed_ms", "exit_code"].contains(&key.as_str())
            }));
        }
    }
}
