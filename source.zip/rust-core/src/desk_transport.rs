//! RustDesk's native TCP/UDP transported over the existing fixed SigmaDesk WSS
//! gateway. These are engine-local adapters, not a Go daemon or file-core bridge.
use anyhow::{Result, ensure};
use crate::desk_transport_trace::{Trace, Route, End, Channel};
use crate::desk_transport_tls::{SessionTls, Stage as TlsStage, Outcome as TlsOutcome, Route as TlsRoute};
use futures_util::{SinkExt, StreamExt};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    net::SocketAddr,
    sync::{
        Arc,
        atomic::{AtomicU64, AtomicUsize, Ordering},
    },
};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::{TcpListener, TcpStream, UdpSocket},
    sync::{mpsc, watch},
};
use tokio_tungstenite::{
    tungstenite::{Message, client::IntoClientRequest, protocol::WebSocketConfig},
};

pub struct Proxy {
    pub(crate) observations: Arc<Trace>,
    pub id: SocketAddr,
    pub relay: SocketAddr,
    stop: watch::Sender<bool>,
    pub connections: Arc<AtomicUsize>,
    pub tasks: Arc<AtomicUsize>,
    pub active_relay: Arc<AtomicUsize>,
    pub relay_opened: Arc<AtomicU64>,
    token_hash: [u8; 32],
    pub registration: Option<Arc<crate::desk_registration::Registration>>,
    #[cfg(windows)]
    pub registration_job: Arc<crate::desk_local_owner::RegistrationJob>,
}
struct Count(Arc<AtomicUsize>);
struct RegistrationChannel(Option<(Arc<crate::desk_registration::Registration>, u64)>);
impl Drop for RegistrationChannel {
    fn drop(&mut self) { if let Some((registration, id)) = &self.0 { registration.close(*id); } }
}
impl Count {
    fn new(c: Arc<AtomicUsize>) -> Self {
        c.fetch_add(1, Ordering::AcqRel);
        Self(c)
    }
}
impl Drop for Count {
    fn drop(&mut self) {
        self.0.fetch_sub(1, Ordering::AcqRel);
    }
}
type Ws = tokio_tungstenite::WebSocketStream<tokio_tungstenite::MaybeTlsStream<TcpStream>>;
async fn dial(token: &str, route: &str, tls: &SessionTls) -> Result<Ws> {
    ensure!(
        matches!(route, "id" | "relay" | "udp"),
        "SigmaDesk transport route denied"
    );
    let mut req = format!("wss://rd-id.relay.sigmadrive.net/sigma-desk-native/{route}")
        .into_client_request()?;
    req.headers_mut()
        .insert("authorization", format!("Bearer {token}").parse()?);
    let mut config = WebSocketConfig::default();
    config.max_message_size = Some(1024 * 1024);
    config.max_frame_size = Some(1024 * 1024);
    let diagnostic_route=match route{"udp"=>TlsRoute::Registration,"id"=>TlsRoute::Id,"relay"=>TlsRoute::Relay,_=>anyhow::bail!("SigmaDesk transport route denied")};
    let observed=tls.metrics.begin_route(TlsStage::DialTotal,diagnostic_route);
    let result = tokio::time::timeout(
        std::time::Duration::from_secs(8),
        tls.connect(req, config, diagnostic_route),
    )
    .await;
    observed.finish(match &result {Ok(Ok(_))=>TlsOutcome::Ok,Ok(Err(_))=>TlsOutcome::Error,Err(_)=>TlsOutcome::Timeout});
    let (ws,_)=result.map_err(|_| anyhow::anyhow!("SigmaDesk transport timeout"))?
        .map_err(|_| anyhow::anyhow!("SigmaDesk transport unavailable"))?;
    Ok(ws)
}
impl Proxy {
    pub async fn start(token: String) -> Result<Self> {
        Self::start_with_registration(token, None).await
    }
    pub async fn start_with_registration(token: String, registration: Option<Arc<crate::desk_registration::Registration>>) -> Result<Self> {
        Self::start_with_registration_diagnostics(token,registration,false).await
    }
    pub(crate) async fn start_with_registration_diagnostics(token: String, registration: Option<Arc<crate::desk_registration::Registration>>, diagnostics_enabled:bool) -> Result<Self> {
        ensure!(
            token.len() == 64 && token.bytes().all(|b| b.is_ascii_hexdigit()),
            "SigmaDesk transport credential denied"
        );
        let id = TcpListener::bind("127.0.0.1:0").await?;
        let udp = Arc::new(UdpSocket::bind(id.local_addr()?).await?);
        // The deployed rendezvous server advertises this exact loopback relay.
        // A random port accepts no traffic addressed to that advertised endpoint.
        // Fail this session on a conflict; never replace another listener.
        let relay = TcpListener::bind("127.0.0.1:21117")
            .await
            .map_err(|_| anyhow::anyhow!("SigmaDesk relay port 21117 is already in use"))?;
        let (stop, _) = watch::channel(false);
        let count = Arc::new(AtomicUsize::new(0));
        let active_relay = Arc::new(AtomicUsize::new(0));
        let relay_opened = Arc::new(AtomicU64::new(0));
        let tasks = Arc::new(AtomicUsize::new(0));
        let observations=Arc::new(Trace::with_tls_diagnostics(diagnostics_enabled));
        let tls=Arc::new(SessionTls::native(observations.tls.clone())?);
        let this = Self {
            observations:observations.clone(),
            id: id.local_addr()?,
            relay: relay.local_addr()?,
            stop,
            connections: count.clone(),
            tasks: tasks.clone(),
            active_relay: active_relay.clone(),
            relay_opened: relay_opened.clone(),
            token_hash: Sha256::digest(token.as_bytes()).into(),
            registration: registration.clone(),
            #[cfg(windows)]
            registration_job: Arc::new(crate::desk_local_owner::RegistrationJob::default()),
        };
        let token = Arc::new(zeroize::Zeroizing::new(token));
        for (listener, route) in [(id, "id"), (relay, "relay")] {
            #[cfg(windows)]
            let endpoint = listener.local_addr()?;
            let mut ended = this.stop.subscribe();
            let token = token.clone();
            let observations=observations.clone();
            let tls=tls.clone();
            let count = count.clone();
            let relay_count = active_relay.clone();
            let opened = relay_opened.clone();
            let guard = Count::new(tasks.clone());
            tokio::spawn(async move {
                let _guard = guard;
                let slots = Arc::new(tokio::sync::Semaphore::new(16));
                let mut tasks = tokio::task::JoinSet::new();
                loop {
                    tokio::select! {biased;_=ended.wait_for(|v|*v)=>break,
                        Some(_)=tasks.join_next(),if !tasks.is_empty()=>{},
                        accepted=listener.accept()=>{let Ok((socket,addr))=accepted else{break};if !addr.ip().is_loopback(){continue;}
                            #[cfg(windows)]if !crate::desk_local_owner::tcp(endpoint,addr){continue;}
                            let Ok(permit)=slots.clone().try_acquire_owned()else{continue};let tls=tls.clone();let token=token.clone();let count=count.clone();let relay_count=relay_count.clone();let opened=opened.clone();let observed=observations.open(if route=="relay"{Route::Relay}else{Route::Id});tasks.spawn(async move{let _permit=permit;match dial(&token,route,&tls).await {Ok(ws)=>{observed.connected();let _c=Count::new(count);let _r=if route=="relay"{opened.fetch_add(1,Ordering::AcqRel);Some(Count::new(relay_count))}else{None};let result=if socket.set_nodelay(true).is_err(){End::LocalSetupError}else{stream(socket,ws,&observed).await};observed.end(result);},Err(e)=>observed.end(if e.to_string()=="SigmaDesk transport timeout"{End::DialTimeout}else{End::DialUnavailable})}});}
                    }
                }
                tasks.abort_all();
                while tasks.join_next().await.is_some() {}
            });
        }
        let mut ended = this.stop.subscribe();
        #[cfg(windows)]
        let registration_job = this.registration_job.clone();
        let guard = Count::new(tasks.clone());
        tokio::spawn(async move {
            let _guard = guard;
            let mut channels: HashMap<SocketAddr, mpsc::Sender<Vec<u8>>> = HashMap::new();
            let mut tasks = tokio::task::JoinSet::new();
            let mut buf = vec![0; 65507];
            loop {
                tokio::select! {biased;_=ended.wait_for(|v|*v)=>break,
                    Some(Ok(address))=tasks.join_next(),if !tasks.is_empty()=>{channels.remove(&address);},
                    received=udp.recv_from(&mut buf)=>{let Ok((n,address))=received else{break};if !address.ip().is_loopback(){continue;}
                        #[cfg(windows)]if !crate::desk_local_owner::udp(address){continue;}
                        if let std::collections::hash_map::Entry::Vacant(e)=channels.entry(address){
                            if tasks.len()>=8{continue;}let (tx,mut rx)=mpsc::channel::<Vec<u8>>(16);e.insert(tx);let tls=tls.clone();let token=token.clone();let udp=udp.clone();let count=count.clone();let registration=registration.clone();
                            #[cfg(windows)]let registration_job=registration_job.clone();
                            tasks.spawn(async move{let channel=registration.as_ref().and_then(|r|r.open());
                                let _channel_guard=RegistrationChannel(registration.clone().zip(channel));
                                if let Ok(ws)=dial(&token,"udp",&tls).await{let _c=Count::new(count);
                                    datagrams(ws,udp,address,&mut rx,registration,channel,move||{
                                        #[cfg(windows)]{registration_job.udp(address)}
                                        #[cfg(not(windows))]{false}
                                    },std::time::Instant::now).await;
                                }address});
                        }
                        if let Some(tx)=channels.get(&address){let _=tx.try_send(buf[..n].to_vec());}
                    }
                }
            }
            drop(channels);
            tasks.abort_all();
            while tasks.join_next().await.is_some() {}
        });
        Ok(this)
    }
    pub fn stop(&self) {
        if let Some(registration) = &self.registration { registration.stop(); }
        #[cfg(windows)]
        self.registration_job.clear();
        self.stop.send_replace(true);
    }
    pub fn matches_token(&self, token: &str) -> bool {
        token.len() == 64 && token.bytes().all(|b| b.is_ascii_hexdigit())
            && <[u8; 32]>::from(Sha256::digest(token.as_bytes())) == self.token_hash
    }
}
impl Drop for Proxy {
    fn drop(&mut self) {
        self.stop();
    }
}
async fn datagrams<W, O, C>(mut ws: W, udp: Arc<UdpSocket>, address: SocketAddr,
    rx: &mut mpsc::Receiver<Vec<u8>>, registration: Option<Arc<crate::desk_registration::Registration>>,
    channel: Option<u64>, owned: O, clock: C)
where W: futures_util::Sink<Message, Error=tokio_tungstenite::tungstenite::Error>
    + futures_util::Stream<Item=std::result::Result<Message,tokio_tungstenite::tungstenite::Error>> + Unpin,
    O: Fn() -> bool, C: Fn() -> std::time::Instant {
    loop { tokio::select! {
        bytes=rx.recv()=>{
            let Some(bytes)=bytes else{break};
            let observed=if channel.is_some()&&crate::desk_registration::Registration::relevant(&bytes){Some(bytes.clone())}else{None};
            if !matches!(tokio::time::timeout(std::time::Duration::from_secs(10),ws.send(Message::Binary(bytes.into()))).await,Ok(Ok(()))){break;}
            if let (Some(r),Some(id),Some(bytes))=(&registration,channel,observed){
                if owned(){if !r.sent(id,&bytes,clock()){break;}}else{r.close(id);}
            }
        },
        frame=ws.next()=>match frame{
            Some(Ok(Message::Binary(data))) if data.len()<=65507=>{
                let delivered=udp.send_to(&data,address).await.is_ok();
                if !registration_delivery(registration.as_ref(),channel,&data,delivered,&owned,&clock){break;}
            },
            Some(Ok(Message::Ping(_)|Message::Pong(_)))=>{},_=>break
        },
    }}
}
fn registration_delivery(registration: Option<&Arc<crate::desk_registration::Registration>>, channel: Option<u64>,
    data: &[u8], delivered: bool, owned: impl FnOnce()->bool, clock: impl FnOnce()->std::time::Instant) -> bool {
    if !delivered { return false; }
    if crate::desk_registration::Registration::relevant(data){if let(Some(r),Some(id))=(registration,channel){
        if owned(){r.delivered(id,data,clock());}else{r.close(id);}
    }}
    true
}
// Production keeps TcpStream's borrowed split; no additional per-byte mutex/bridge.
async fn stream(mut socket:TcpStream,ws:Ws,observed:&Channel)->End {
    let (reader,writer)=socket.split();
    stream_parts(reader,writer,ws,observed).await
}
async fn stream_parts<R,T,W>(mut reader:R,mut writer:T,ws:W,observed:&Channel)->End
where R:tokio::io::AsyncRead+Unpin,T:tokio::io::AsyncWrite+Unpin,
    W:futures_util::Sink<Message,Error=tokio_tungstenite::tungstenite::Error>
        +futures_util::Stream<Item=std::result::Result<Message,tokio_tungstenite::tungstenite::Error>>+Unpin {
    let (mut sink,mut source)=ws.split();
    let outbound=async {
        let mut first=true;let mut buf=[0;32768];
        loop {
            let n=match reader.read(&mut buf).await {Ok(0)=>return End::LocalEof,Ok(n)=>n,Err(_)=>return End::LocalReadError};
            if first {first=false;observed.first_local();}
            match tokio::time::timeout(std::time::Duration::from_secs(15),sink.send(Message::Binary(buf[..n].to_vec().into()))).await {
                Err(_)=>return End::RelayWriteTimeout,Ok(Err(_))=>return End::RelayWriteError,Ok(Ok(()))=>{}
            }
        }
    };
    let inbound=async {
        let mut first=true;
        loop {
            match source.next().await {
                None=>return End::RemoteEof,Some(Err(_))=>return End::RemoteReadError,
                Some(Ok(Message::Binary(data)))=>{
                    if first && !data.is_empty() {first=false;observed.first_remote();}
                    match tokio::time::timeout(std::time::Duration::from_secs(15),writer.write_all(&data)).await {
                        Err(_)=>return End::LocalWriteTimeout,Ok(Err(_))=>return End::LocalWriteError,Ok(Ok(()))=>{}
                    }
                },
                Some(Ok(Message::Ping(_)|Message::Pong(_)))=>{},
                Some(Ok(Message::Close(frame)))=>return if frame.as_ref().is_some_and(|f|f.code==tokio_tungstenite::tungstenite::protocol::frame::coding::CloseCode::Normal){End::RemoteCloseNormal}else{End::RemoteCloseOther},
                Some(Ok(_))=>return End::UnexpectedFrame,
            }
        }
    };
    tokio::select! {r=outbound=>r,r=inbound=>r}
}

#[cfg(test)]
mod tests {
    use super::*;
    type MemoryWs = tokio_tungstenite::WebSocketStream<tokio::io::DuplexStream>;
    async fn stream_fixture(local:tokio::io::DuplexStream,ws:MemoryWs,c:&Channel)->End {
        let (reader,writer)=tokio::io::split(local);
        stream_parts(reader,writer,ws,c).await
    }
    async fn memory_pair()->(MemoryWs,MemoryWs) {
        use tokio_tungstenite::tungstenite::protocol::Role;
        let (a,b)=tokio::io::duplex(256*1024);
        (tokio_tungstenite::WebSocketStream::from_raw_socket(a,Role::Client,None).await,
         tokio_tungstenite::WebSocketStream::from_raw_socket(b,Role::Server,None).await)
    }
    #[tokio::test]
    async fn local_eof_observation_is_not_a_network_root_cause_claim() {
        let (local,mut peer)=tokio::io::duplex(256*1024);let (ws,mut server)=memory_pair().await;
        let trace=Arc::new(Trace::default());let c=trace.open(Route::Relay);c.connected();
        let task=tokio::spawn(async move{let end=stream_fixture(local,ws,&c).await;c.end(end);end});
        peer.write_all(b"private-payload-not-logged").await.unwrap();
        assert_eq!(server.next().await.unwrap().unwrap(),Message::Binary(b"private-payload-not-logged".to_vec().into()));
        peer.shutdown().await.unwrap();assert_eq!(task.await.unwrap(),End::LocalEof);
        let s=trace.snapshot();assert_eq!(s["channels"][0]["end_observation"],"local_eof");
        assert!(!s.to_string().contains("private-payload"));assert!(!s["channels"][0]["first_local_bytes_ms"].is_null());
    }
    #[tokio::test]
    async fn remote_normal_close_and_binary_delivery_keep_fixed_direction_only() {
        let (local,mut peer)=tokio::io::duplex(256*1024);let (ws,mut server)=memory_pair().await;
        let trace=Arc::new(Trace::default());let c=trace.open(Route::Relay);c.connected();
        let task=tokio::spawn(async move{let end=stream_fixture(local,ws,&c).await;c.end(end);end});
        server.send(Message::Binary(b"synthetic-frame".to_vec().into())).await.unwrap();
        let mut buf=[0;15];peer.read_exact(&mut buf).await.unwrap();assert_eq!(&buf,b"synthetic-frame");
        server.close(Some(tokio_tungstenite::tungstenite::protocol::CloseFrame{
            code:tokio_tungstenite::tungstenite::protocol::frame::coding::CloseCode::Normal,
            reason:"secret-reason-must-not-export".into()})).await.unwrap();
        assert_eq!(task.await.unwrap(),End::RemoteCloseNormal);
        let s=trace.snapshot();assert_eq!(s["channels"][0]["first_observed_direction"],"relay_to_local");
        assert!(!s.to_string().contains("secret-reason"));assert!(!s["channels"][0]["first_relay_bytes_ms"].is_null());
    }
    #[tokio::test]
    async fn abrupt_socket_loss_is_distinct_from_normal_close() {
        let (local,_peer)=tokio::io::duplex(256*1024);let (ws,server)=memory_pair().await;
        let trace=Arc::new(Trace::default());let c=trace.open(Route::Relay);c.connected();
        let task=tokio::spawn(async move{let end=stream_fixture(local,ws,&c).await;c.end(end);end});
        drop(server);assert_eq!(task.await.unwrap(),End::RemoteReadError);
        assert_eq!(trace.snapshot()["channels"][0]["end_observation"],"remote_read_error");
    }
    #[tokio::test]
    async fn empty_binary_and_ping_are_not_first_relay_bytes() {
        let (local,_peer)=tokio::io::duplex(256*1024);let (ws,mut server)=memory_pair().await;
        let trace=Arc::new(Trace::default());let c=trace.open(Route::Relay);c.connected();
        let task=tokio::spawn(async move{let end=stream_fixture(local,ws,&c).await;c.end(end);end});
        server.send(Message::Binary(Vec::new().into())).await.unwrap();
        server.send(Message::Ping(Vec::new().into())).await.unwrap();
        server.close(None).await.unwrap();assert_eq!(task.await.unwrap(),End::RemoteCloseOther);
        assert!(trace.snapshot()["channels"][0]["first_relay_bytes_ms"].is_null());
    }
    #[tokio::test]
    async fn aborted_connection_records_cancellation_not_remote_fault() {
        let (local,_peer)=tokio::io::duplex(256*1024);let (ws,_server)=memory_pair().await;
        let trace=Arc::new(Trace::default());let c=trace.open(Route::Relay);c.connected();
        let task=tokio::spawn(async move{let end=stream_fixture(local,ws,&c).await;c.end(end);end});
        tokio::task::yield_now().await;task.abort();assert!(task.await.unwrap_err().is_cancelled());
        assert_eq!(trace.snapshot()["channels"][0]["end_observation"],"local_task_cancelled");
    }
    struct DatagramFixture {
        server: MemoryWs, sender: mpsc::Sender<Vec<u8>>, engine: UdpSocket,
        registration: Arc<crate::desk_registration::Registration>,
        clock: Arc<AtomicU64>, origin: Instant, task: Option<tokio::task::JoinHandle<()>>,
    }
    impl Drop for DatagramFixture { fn drop(&mut self) { if let Some(task)=&self.task { task.abort(); } } }
    impl DatagramFixture {
        async fn new(owned: bool) -> Self {
            use tokio_tungstenite::tungstenite::protocol::Role;
            let (a,b)=tokio::io::duplex(256*1024);
            let client=tokio_tungstenite::WebSocketStream::from_raw_socket(a,Role::Client,None).await;
            let server=tokio_tungstenite::WebSocketStream::from_raw_socket(b,Role::Server,None).await;
            let engine=UdpSocket::bind("127.0.0.1:0").await.unwrap();
            let udp=Arc::new(UdpSocket::bind("127.0.0.1:0").await.unwrap());
            let address=engine.local_addr().unwrap();
            let registration=Arc::new(crate::desk_registration::Registration::new("123456789".into()));
            let channel=registration.open().unwrap(); let observed=registration.clone();
            let origin=Instant::now(); let clock=Arc::new(AtomicU64::new(0)); let fake_clock=clock.clone();
            let (sender,mut receiver)=mpsc::channel(16);
            let task=tokio::spawn(async move {
                let _guard=RegistrationChannel(Some((observed.clone(),channel)));
                datagrams(client,udp,address,&mut receiver,Some(observed),Some(channel),move||owned,
                    move||origin+std::time::Duration::from_millis(fake_clock.load(Ordering::Acquire))).await;
            });
            Self { server,sender,engine,registration,clock,origin,task:Some(task) }
        }
        async fn send(&mut self, data: Vec<u8>) {
            self.sender.send(data.clone()).await.unwrap();
            let response=tokio::time::timeout(std::time::Duration::from_secs(2),self.server.next()).await.unwrap().unwrap().unwrap();
            assert_eq!(response,Message::Binary(data.into()));
        }
        async fn deliver(&mut self, data: Vec<u8>) {
            self.server.send(Message::Binary(data.clone().into())).await.unwrap();
            let mut received=vec![0;65507];
            let (n,_)=tokio::time::timeout(std::time::Duration::from_secs(2),self.engine.recv_from(&mut received)).await.unwrap().unwrap();
            assert_eq!(&received[..n],data.as_slice());
        }
        async fn finish(&mut self) {
            let task=self.task.take().unwrap();
            tokio::time::timeout(std::time::Duration::from_secs(2),task).await.unwrap().unwrap();
        }
    }
    fn pk_fixture() -> Vec<u8> {
        let mut body=vec![10,9]; body.extend_from_slice(b"123456789");
        body.extend_from_slice(&[18,16]);body.extend_from_slice(&[2;16]);body.extend_from_slice(&[26,32]);body.extend_from_slice(&[3;32]);
        let mut result=vec![0x7a,body.len() as u8];result.extend(body);result
    }
    fn peer_fixture() -> Vec<u8> { let mut result=vec![0x32,11,10,9];result.extend_from_slice(b"123456789");result }
    #[tokio::test]
    async fn bounded_udp_fixture_requires_successful_typed_delivery_and_resets_on_close() {
        let mut f=DatagramFixture::new(true).await;
        f.send(pk_fixture()).await; f.deliver(vec![0x82,1,0]).await;
        assert!(!f.registration.observation(f.origin).ready);
        f.send(peer_fixture()).await; f.deliver(vec![0x3a,0]).await;
        assert!(f.registration.observation(f.origin).ready);
        f.clock.store(20_000,Ordering::Release); f.deliver(vec![0x3a,0]).await;
        let observed=f.registration.observation(f.origin+std::time::Duration::from_secs(20));
        assert_eq!(observed.revision,2);assert_eq!(observed.age_ms,20_000);
        // The adapter's existing datagram cap also retires an established proof.
        f.server.send(Message::Binary(vec![0;65508].into())).await.unwrap();f.finish().await;
        assert!(!f.registration.observation(f.origin+std::time::Duration::from_secs(20)).ready);
    }
    #[tokio::test]
    async fn datagram_owner_and_failed_upstream_never_earn_registration_proof() {
        let mut f=DatagramFixture::new(false).await;
        f.send(pk_fixture()).await;f.deliver(vec![0x82,1,0]).await;
        f.send(peer_fixture()).await;f.deliver(vec![0x3a,0]).await;
        assert!(!f.registration.observation(f.origin).ready);
        let _=f.server.close(None).await;f.finish().await;
        let mut f=DatagramFixture::new(true).await;
        f.server.close(None).await.unwrap();let _=f.sender.send(pk_fixture()).await;f.finish().await;
        assert!(!f.registration.observation(f.origin).ready);
    }
    #[test]
    fn failed_downstream_udp_delivery_cannot_accept_pk_or_peer_ack() {
        let t=Instant::now();let r=Arc::new(crate::desk_registration::Registration::new("123456789".into()));
        let c=r.open().unwrap();let guard=RegistrationChannel(Some((r.clone(),c)));
        r.sent(c,&pk_fixture(),t);
        assert!(!registration_delivery(Some(&r),Some(c),&[0x82,1,0],false,
            ||panic!("failed delivery must not query ownership"),||panic!("failed delivery must not read clock")));
        r.sent(c,&peer_fixture(),t);
        registration_delivery(Some(&r),Some(c),&[0x3a,0],true,||true,||t);
        assert!(!r.observation(t).ready);drop(guard);
        let c=r.open().unwrap();let guard=RegistrationChannel(Some((r.clone(),c)));
        r.sent(c,&pk_fixture(),t);registration_delivery(Some(&r),Some(c),&[0x82,1,0],true,||true,||t);
        r.sent(c,&peer_fixture(),t);
        assert!(!registration_delivery(Some(&r),Some(c),&[0x3a,0],false,||true,||t));
        assert!(!r.observation(t).ready);drop(guard);
        r.delivered(c,&[0x3a,0],t);assert!(!r.observation(t).ready);
    }
    #[tokio::test]
    async fn stopped_proxy_releases_owned_loopback_tcp_udp_without_network_or_engine() {
        let p = Proxy::start("a".repeat(64)).await.unwrap();
        let id = p.id;
        let relay = p.relay;
        assert!(id.ip().is_loopback() && relay.ip().is_loopback());
        assert_eq!(relay.port(), 21117);
        assert!(Proxy::start("b".repeat(64)).await.is_err());
        assert_eq!(p.connections.load(Ordering::Acquire), 0);
        p.stop();
        let until = Instant::now() + std::time::Duration::from_secs(2);
        while p.tasks.load(Ordering::Acquire) > 0 && Instant::now() < until {
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        }
        assert_eq!(p.tasks.load(Ordering::Acquire), 0);
        assert!(TcpListener::bind(id).await.is_ok());
        assert!(TcpListener::bind(relay).await.is_ok());
        assert!(UdpSocket::bind(id).await.is_ok());
    }
    use std::time::Instant;
}
