//! SigmaDesk authority wire contract; payloads are verified verbatim. These
//! short leases are unrelated to file sharing approvals or transfer state.
use anyhow::{Result, ensure};
use base64::{Engine, engine::general_purpose::STANDARD};
use ed25519_dalek::{Signature, VerifyingKey};
use serde::Deserialize;
use serde_json::{Value, json};
use std::time::{Duration, Instant};

#[cfg(test)]
#[test]
fn stale_readiness_response_cannot_reach_resync_through_an_invalid_signed_host_lease() {
    use crate::{desk_readiness::Binding,desk_registration::Observation};
    let fixture:Value=serde_json::from_slice(include_bytes!("../tests/fixtures/readiness-v1.json")).unwrap();
    for case in fixture["cases"].as_array().unwrap(){
        let steps=case["steps"].as_array().unwrap();let t=Instant::now();
        let key:[u8;32]=STANDARD.decode(case["public_key"].as_str().unwrap()).unwrap().try_into().unwrap();
        let decision=|remote:&Value|remote.get("browser_decision").unwrap_or(&remote["decision"]).clone();
        let first=&steps[0]["response"];let initial=verify_key(&decision(first),&first["self"],"WinSta0\\Default",t,steps[0]["now_ms"].as_i64().unwrap(),None,&key).unwrap();
        let token=first["transport_token"].as_str().unwrap();let mut binding=Binding::create(first,&initial,token,123).unwrap().unwrap();
        binding.evidence(&mut json!({}),Observation{generation:123,revision:1,ready:false,age_ms:0},"starting",&initial,t).unwrap();
        let renewed=&steps[1]["response"];let mut stale=renewed.clone();stale["readiness"]["result"]=json!("stale");
        let original=decision(renewed);let mut corrupted=original.clone();
        let mut signature=STANDARD.decode(corrupted["lease"]["signature"].as_str().unwrap()).unwrap();signature[0]^=1;
        corrupted["lease"]["signature"]=json!(STANDARD.encode(signature));
        assert!(verify_key(&corrupted,&renewed["self"],"WinSta0\\Default",t,steps[1]["now_ms"].as_i64().unwrap(),Some(&initial),&key).is_err());
        let verified=verify_key(&original,&renewed["self"],"WinSta0\\Default",t,steps[1]["now_ms"].as_i64().unwrap(),Some(&initial),&key).unwrap();
        binding.observe(&stale,&verified,token).unwrap();
    }
}

#[cfg(test)]
#[test]
fn readiness_shared_authority_transcript_keeps_real_signed_leases_and_private_metadata_separate() {
    use crate::{desk_readiness::Binding, desk_registration::Observation};
    use sha2::{Digest, Sha256};
    let raw = include_bytes!("../tests/fixtures/readiness-v1.json");
    assert_eq!(hex::encode(Sha256::digest(raw)), "359cfbe26862d2348648d32bf56681c397e85fb0980a4e1acb1d9260a9ed708d");
    let transcript: Value = serde_json::from_slice(raw).unwrap();
    for case in transcript["cases"].as_array().unwrap() {
        let key: [u8; 32] = STANDARD.decode(case["public_key"].as_str().unwrap()).unwrap().try_into().unwrap();
        let steps = case["steps"].as_array().unwrap(); let base_ms = steps[0]["now_ms"].as_i64().unwrap();
        let origin = Instant::now(); let mut previous: Option<Lease> = None; let mut readiness: Option<Binding> = None;
        for step in steps {
            let label = step["label"].as_str().unwrap(); let remote = &step["response"];
            let now_ms = step["now_ms"].as_i64().unwrap(); let sent = origin + Duration::from_millis((now_ms-base_ms) as u64);
            let decision = remote.get("browser_decision").unwrap_or(&remote["decision"]);
            if let Some(binding) = readiness.as_mut() {
                if let Some(revision) = step["request"]["readiness_revision"].as_u64() {
                    let observed = Observation { generation: step["request"]["readiness_generation"].as_u64().unwrap() as u32,
                        revision: revision as u32, ready: step["request"]["readiness_ready"].as_bool().unwrap(),
                        age_ms: step["request"]["readiness_age_ms"].as_u64().unwrap() as u32 };
                    let mut body = json!({}); let result = binding.evidence(&mut body, observed,
                        step["request"]["phase"].as_str().unwrap(), previous.as_ref().unwrap(), sent);
                    if label == "generation_rejected" { assert!(result.is_err()); }
                    else {
                        result.unwrap();
                        for field in ["readiness_version", "readiness_mode", "readiness_nonce", "readiness_generation",
                            "readiness_lease_sequence", "readiness_revision", "readiness_ready", "readiness_age_ms"] {
                            assert_eq!(body[field], step["request"][field], "{label}/{field}");
                        }
                    }
                }
            }
            // Only the test fixture public key is used here; production verify()
            // still selects its unchanged compiled authority trust key.
            let verified = verify_key(decision, &remote["self"], "WinSta0\\Default", sent, now_ms, previous.as_ref(), &key).unwrap();
            let token = remote["transport_token"].as_str().unwrap();
            if let Some(binding) = readiness.as_mut() {
                let result = binding.observe(remote, &verified, token);
                if label == "generation_rejected" { assert!(result.is_err()); } else { result.unwrap(); }
            } else { readiness = Binding::create(remote, &verified, token, 123).unwrap(); }
            previous = Some(verified);
        }
    }
}

pub const AUTHORITY: &str = "https://rd-auth.relay.sigmadrive.net";
pub const PUBLIC_KEY: &str = "lbvLXCZ2HGLUJf1mT1Q3Q33sVeX+BhKxOr8tVLdxGmc=";
pub const SERVER_KEY: &str = "C5B/V7BdkLUnChvGrCSCLL/84uANWBXWA+lN6xuU3kI=";
pub const VIEW: &str = "remote.screen.view";
pub const CONTROL: &str = "remote.input.control";

// Deserialize values without accepting duplicate object keys, including in
// signed payloads. serde_json::Value alone silently keeps the final duplicate.
struct Unique(Value);
impl<'de> Deserialize<'de> for Unique {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> std::result::Result<Self, D::Error> {
        struct Visitor;
        impl<'de> serde::de::Visitor<'de> for Visitor {
            type Value = Unique;
            fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
                f.write_str("unique-key JSON")
            }
            fn visit_map<A: serde::de::MapAccess<'de>>(
                self,
                mut a: A,
            ) -> std::result::Result<Unique, A::Error> {
                let mut m = serde_json::Map::new();
                while let Some((k, Unique(v))) = a.next_entry::<String, Unique>()? {
                    if m.insert(k, v).is_some() {
                        return Err(serde::de::Error::custom("duplicate key"));
                    }
                }
                Ok(Unique(Value::Object(m)))
            }
            fn visit_seq<A: serde::de::SeqAccess<'de>>(
                self,
                mut a: A,
            ) -> std::result::Result<Unique, A::Error> {
                let mut v = vec![];
                while let Some(Unique(x)) = a.next_element()? {
                    v.push(x);
                }
                Ok(Unique(Value::Array(v)))
            }
            fn visit_str<E: serde::de::Error>(self, v: &str) -> std::result::Result<Unique, E> {
                Ok(Unique(json!(v)))
            }
            fn visit_bool<E: serde::de::Error>(self, v: bool) -> std::result::Result<Unique, E> {
                Ok(Unique(json!(v)))
            }
            fn visit_i64<E: serde::de::Error>(self, v: i64) -> std::result::Result<Unique, E> {
                Ok(Unique(json!(v)))
            }
            fn visit_u64<E: serde::de::Error>(self, v: u64) -> std::result::Result<Unique, E> {
                Ok(Unique(json!(v)))
            }
            fn visit_f64<E: serde::de::Error>(self, v: f64) -> std::result::Result<Unique, E> {
                Ok(Unique(json!(v)))
            }
            fn visit_unit<E: serde::de::Error>(self) -> std::result::Result<Unique, E> {
                Ok(Unique(Value::Null))
            }
        }
        d.deserialize_any(Visitor)
    }
}
pub fn unique(bytes: &[u8]) -> Result<Value> {
    ensure!(
        bytes.len() <= 1024 * 1024,
        "SigmaDesk response exceeds limit"
    );
    Ok(serde_json::from_slice::<Unique>(bytes)?.0)
}
pub fn valid_id(s: &str) -> bool {
    s.len() == 32
        && s.bytes()
            .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase())
}
pub fn rdid(v: &Value) -> Result<&str> {
    let s = v.as_str().unwrap_or("");
    ensure!(
        (6..=12).contains(&s.len()) && s.bytes().all(|b| b.is_ascii_digit()),
        "invalid SigmaDesk protocol identity"
    );
    Ok(s)
}
#[derive(Clone)]
pub struct Lease {
    pub binding: Value,
    pub sequence: u64,
    pub until: Instant,
    pub expires: i64,
    pub control: bool,
    pub browser: bool,
}
pub fn verify(
    decision: &Value,
    local: &Value,
    desktop: &str,
    sent: Instant,
    server_ms: i64,
    old: Option<&Lease>,
) -> Result<Lease> {
    let key: [u8; 32] = STANDARD
        .decode(PUBLIC_KEY)?
        .try_into()
        .map_err(|_| anyhow::anyhow!("invalid SigmaDesk trust key"))?;
    verify_key(decision, local, desktop, sent, server_ms, old, &key)
}
fn verify_key(
    decision: &Value,
    local: &Value,
    desktop: &str,
    sent: Instant,
    server_ms: i64,
    old: Option<&Lease>,
    key: &[u8; 32],
) -> Result<Lease> {
    let binding = &decision["binding"];
    let browser = binding["kind"] == "browser";
    ensure!(
        decision["active"] == true && valid_id(binding["session_id"].as_str().unwrap_or("")),
        "inactive SigmaDesk assignment"
    );
    let env = &decision["lease"];
    let payload = STANDARD.decode(env["payload"].as_str().unwrap_or(""))?;
    ensure!(
        !payload.is_empty() && payload.len() <= 16384,
        "SigmaDesk lease size denied"
    );
    let signature =
        Signature::from_slice(&STANDARD.decode(env["signature"].as_str().unwrap_or(""))?)?;
    let domain = if browser {
        "sigmadrive/browser-host-lease/v1\0"
    } else {
        "sigmadrive/remote-lease/v1\0"
    };
    VerifyingKey::from_bytes(key)?
        .verify_strict(&[domain.as_bytes(), &payload].concat(), &signature)?;
    let c = unique(&payload)?;
    ensure!(
        c.as_object().is_some_and(|o| o.keys().all(|k| [
            "schema",
            "binding",
            "sequence",
            "issued_ms",
            "expires_ms",
            "revoked",
            "scopes"
        ]
        .contains(&k.as_str()))),
        "unknown SigmaDesk lease field"
    );
    ensure!(
        c["schema"]
            == if browser {
                "sigmadrive.browser-host-lease/v1"
            } else {
                "sigmadrive.remote-lease/v1"
            }
            && c["binding"] == *binding
            && c["revoked"] == false,
        "SigmaDesk signed binding denied"
    );
    let fields = if browser {
        vec![
            "kind",
            "session_id",
            "participant_id",
            "host_member_id",
            "viewer_member_id",
            "host_node_id",
            "host_pin",
            "host_rdid",
            "peer_rdid",
            "origin",
            "host_desktop",
        ]
    } else {
        vec![
            "member_id",
            "peer_member_id",
            "host_node_id",
            "host_pin",
            "peer_node_id",
            "peer_pin",
            "session_id",
            "host_desktop",
            "peer_desktop",
        ]
    };
    ensure!(
        binding
            .as_object()
            .is_some_and(|o| o.keys().all(|k| fields.contains(&k.as_str()))),
        "unknown SigmaDesk binding field"
    );
    let host = browser || decision["role"] == "host";
    ensure!(
        host || decision["role"] == "viewer",
        "SigmaDesk role denied"
    );
    let (node, pin, member, desk) = if host {
        (
            binding["host_node_id"].clone(),
            binding["host_pin"].clone(),
            binding[if browser {
                "host_member_id"
            } else {
                "member_id"
            }]
            .clone(),
            &binding["host_desktop"],
        )
    } else {
        (
            binding["peer_node_id"].clone(),
            binding["peer_pin"].clone(),
            binding
                .get("peer_member_id")
                .filter(|v| v.as_str().is_some_and(|s| !s.is_empty()))
                .unwrap_or(&binding["member_id"])
                .clone(),
            &binding["peer_desktop"],
        )
    };
    ensure!(
        node == local["node"] && pin == local["pin"] && member == local["member"],
        "SigmaDesk local member/device binding denied"
    );
    // Even legacy single-session grants run in an isolated current-user engine.
    // A negotiated desktop binding must match exactly; never follow active user.
    ensure!(
        desk.as_str().is_none_or(|s| s.is_empty() || s == desktop),
        "SigmaDesk Windows desktop binding denied"
    );
    if browser {
        let origin = binding["origin"].as_str().unwrap_or("");
        let host = origin
            .strip_prefix("https://")
            .and_then(|s| s.strip_suffix(".user.sigmadrive.net"))
            .unwrap_or("");
        ensure!(
            !host.is_empty()
                && host.len() <= 63
                && host
                    .bytes()
                    .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
                && !host.starts_with('-')
                && !host.ends_with('-'),
            "SigmaDesk browser origin denied"
        );
        ensure!(
            valid_id(
                binding["participant_id"]
                    .as_str()
                    .unwrap_or("")
                    .strip_prefix("browser-")
                    .unwrap_or("")
            ),
            "invalid browser participant"
        );
        rdid(&binding["host_rdid"])?;
        rdid(&binding["peer_rdid"])?;
    } else {
        ensure!(
            binding["host_node_id"] != binding["peer_node_id"]
                && binding["host_pin"] != binding["peer_pin"],
            "SigmaDesk peer identity denied"
        );
        rdid(&decision["hostRdid"])?;
        rdid(&decision["peerRdid"])?;
    }
    let scopes = c["scopes"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("SigmaDesk scopes missing"))?;
    ensure!(
        !scopes.is_empty()
            && scopes.len() <= 2
            && scopes.contains(&json!(VIEW))
            && scopes.iter().all(|s| s == VIEW || s == CONTROL)
            && !(scopes.len() == 2 && scopes[0] == scopes[1]),
        "SigmaDesk scope denied"
    );
    let sequence = c["sequence"].as_u64().unwrap_or(0);
    let issued = c["issued_ms"].as_i64().unwrap_or(0);
    let expires = c["expires_ms"].as_i64().unwrap_or(0);
    let ttl = expires.checked_sub(issued).unwrap_or(0);
    let remaining = expires
        .checked_sub(server_ms)
        .and_then(|n| n.checked_sub(1000))
        .unwrap_or(0);
    ensure!(
        server_ms > 0
            && sequence > 0
            && (1..=90000).contains(&ttl)
            && (1..=90000).contains(&remaining)
            && issued <= server_ms + 30000,
        "SigmaDesk lease lifetime denied"
    );
    let control = scopes.contains(&json!(CONTROL));
    let until = sent + Duration::from_millis(remaining as u64);
    if let Some(old) = old {
        ensure!(
            old.binding == *binding
                && old.browser == browser
                && old.control == control
                && sequence > old.sequence
                && expires >= old.expires,
            "SigmaDesk renewal changed scope or rolled back"
        );
    }
    ensure!(until > Instant::now(), "SigmaDesk lease expired in transit");
    Ok(Lease {
        binding: binding.clone(),
        sequence,
        until,
        expires,
        control,
        browser,
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    use ed25519_dalek::{Signer, SigningKey};
    fn fixture() -> (Value, Value, SigningKey) {
        let local = json!({"node":"pc-host","pin":"host-pin","member":"member-host"});
        let key = SigningKey::from_bytes(&[18; 32]);
        let b = json!({"member_id":"member-host","host_node_id":"pc-host","host_pin":"host-pin","peer_node_id":"pc-peer","peer_pin":"peer-pin","session_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"});
        (
            json!({"active":true,"role":"host","binding":b,"hostRdid":"123456789","peerRdid":"987654321"}),
            local,
            key,
        )
    }
    fn sign(d: &mut Value, k: &SigningKey, seq: u64, scope: Vec<&str>) {
        let c = json!({"schema":"sigmadrive.remote-lease/v1","binding":d["binding"],"sequence":seq,"issued_ms":100000,"expires_ms":160000,"revoked":false,"scopes":scope});
        let p = serde_json::to_vec(&c).unwrap();
        let s = k.sign(&[b"sigmadrive/remote-lease/v1\0", p.as_slice()].concat());
        d["lease"] =
            json!({"payload":STANDARD.encode(p),"signature":STANDARD.encode(s.to_bytes())});
    }
    #[test]
    fn signature_scope_identity_and_expiry_are_mandatory() {
        let (mut d, l, k) = fixture();
        sign(&mut d, &k, 1, vec![VIEW]);
        let now = Instant::now();
        assert!(verify_key(&d, &l, "", now, 100000, None, &k.verifying_key().to_bytes()).is_ok());
        for bad in [
            json!({"node":"pc-other","pin":"host-pin","member":"member-host"}),
            json!({"node":"pc-host","pin":"other","member":"member-host"}),
        ] {
            assert!(
                verify_key(
                    &d,
                    &bad,
                    "",
                    now,
                    100000,
                    None,
                    &k.verifying_key().to_bytes()
                )
                .is_err()
            );
        }
        assert!(verify_key(&d, &l, "", now, 161000, None, &k.verifying_key().to_bytes()).is_err());
        sign(&mut d, &k, 2, vec![CONTROL]);
        assert!(verify_key(&d, &l, "", now, 100000, None, &k.verifying_key().to_bytes()).is_err());
    }
    #[test]
    fn duplicate_keys_and_renewal_scope_change_are_denied() {
        assert!(unique(br#"{"x":1,"x":2}"#).is_err());
        let (mut d, l, k) = fixture();
        let now = Instant::now();
        sign(&mut d, &k, 2, vec![VIEW]);
        let a = verify_key(&d, &l, "", now, 100000, None, &k.verifying_key().to_bytes()).unwrap();
        sign(&mut d, &k, 1, vec![VIEW]);
        assert!(
            verify_key(
                &d,
                &l,
                "",
                now,
                100000,
                Some(&a),
                &k.verifying_key().to_bytes()
            )
            .is_err()
        );
        sign(&mut d, &k, 3, vec![VIEW, CONTROL]);
        assert!(
            verify_key(
                &d,
                &l,
                "",
                now,
                100000,
                Some(&a),
                &k.verifying_key().to_bytes()
            )
            .is_err()
        );
    }
    #[test]
    fn browser_lease_cannot_be_reused_as_native_or_on_another_desktop() {
        let (mut d, l, k) = fixture();
        d["binding"] = json!({"kind":"browser","session_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","participant_id":"browser-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","host_member_id":"member-host","viewer_member_id":"member-peer","host_node_id":"pc-host","host_pin":"host-pin","host_rdid":"123456789","peer_rdid":"987654321","origin":"https://opaque.user.sigmadrive.net","host_desktop":"sid/session"});
        let claims = json!({"schema":"sigmadrive.browser-host-lease/v1","binding":d["binding"],"sequence":1,"issued_ms":100000,"expires_ms":160000,"revoked":false,"scopes":[VIEW]});
        let bytes = serde_json::to_vec(&claims).unwrap();
        let signature = k.sign(&[b"sigmadrive/browser-host-lease/v1\0", bytes.as_slice()].concat());
        d["lease"] = json!({"payload":STANDARD.encode(&bytes),"signature":STANDARD.encode(signature.to_bytes())});
        let now = Instant::now();
        let check = |d: &Value, desktop| {
            verify_key(
                d,
                &l,
                desktop,
                now,
                100000,
                None,
                &k.verifying_key().to_bytes(),
            )
        };
        assert!(check(&d, "sid/session").is_ok());
        assert!(check(&d, "other/session").is_err());
        let native_signature =
            k.sign(&[b"sigmadrive/remote-lease/v1\0", bytes.as_slice()].concat());
        d["lease"]["signature"] = json!(STANDARD.encode(native_signature.to_bytes()));
        assert!(check(&d, "sid/session").is_err());
    }
}
