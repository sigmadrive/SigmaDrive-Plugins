//! Authorize the client side of engine loopback sockets, not the accepting
//! core's own TCP row. Other Windows users/sessions cannot borrow its WSS token.
use std::{
    net::SocketAddr,
    os::windows::io::{AsRawHandle, FromRawHandle, OwnedHandle},
};
use windows_sys::Win32::{
    NetworkManagement::IpHelper::*,
    System::{JobObjects::IsProcessInJob, RemoteDesktop::ProcessIdToSessionId, Threading::*},
};
fn rows<T: Copy>(udp: bool) -> Option<Vec<T>> {
    unsafe {
        let mut size = 0;
        let query = |p, n| {
            if udp {
                GetExtendedUdpTable(p, n, 0, 2, UDP_TABLE_OWNER_PID, 0)
            } else {
                GetExtendedTcpTable(p, n, 0, 2, TCP_TABLE_OWNER_PID_ALL, 0)
            }
        };
        query(std::ptr::null_mut(), &mut size);
        for _ in 0..2 {
            if !(4..=8 * 1024 * 1024).contains(&size) {
                return None;
            }
            let mut bytes = vec![0u8; size as usize];
            let status = query(bytes.as_mut_ptr().cast(), &mut size);
            if status == 122 {
                continue;
            }
            if status != 0 || size < 4 || size as usize > bytes.len() {
                return None;
            }
            let count = u32::from_ne_bytes(bytes[..4].try_into().ok()?) as usize;
            if count > (size as usize - 4) / std::mem::size_of::<T>() {
                return None;
            }
            return Some(
                (0..count)
                    .map(|i| {
                        std::ptr::read_unaligned(
                            bytes
                                .as_ptr()
                                .add(4 + i * std::mem::size_of::<T>())
                                .cast::<T>(),
                        )
                    })
                    .collect(),
            );
        }
        None
    }
}
fn own(pid: u32) -> bool {
    unsafe {
        let mut expected = 0;
        let mut actual = 0;
        if ProcessIdToSessionId(GetCurrentProcessId(), &mut expected) == 0
            || expected == 0
            || ProcessIdToSessionId(pid, &mut actual) == 0
            || actual != expected
        {
            return false;
        }
        let process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
        if process.is_null() {
            return false;
        }
        let process = OwnedHandle::from_raw_handle(process.cast());
        crate::identity::same_process_user(process.as_raw_handle().cast()).unwrap_or(false)
    }
}
fn port(p: u32) -> u16 {
    u16::from_be((p & 65535) as u16)
}
pub fn tcp(local: SocketAddr, peer: SocketAddr) -> bool {
    let (SocketAddr::V4(local), SocketAddr::V4(peer)) = (local, peer) else {
        return false;
    };
    let Some(rows) = rows::<MIB_TCPROW_OWNER_PID>(false) else {
        return false;
    };
    let owners: Vec<_> = rows
        .iter()
        .filter(|r| {
            port(r.dwLocalPort) == peer.port()
                && port(r.dwRemotePort) == local.port()
                && r.dwLocalAddr == u32::from_ne_bytes(peer.ip().octets())
                && r.dwRemoteAddr == u32::from_ne_bytes(local.ip().octets())
        })
        .map(|r| r.dwOwningPid)
        .collect();
    !owners.is_empty() && owners.into_iter().all(own)
}
pub fn udp(peer: SocketAddr) -> bool {
    let SocketAddr::V4(peer) = peer else {
        return false;
    };
    let Some(rows) = rows::<MIB_UDPROW_OWNER_PID>(true) else {
        return false;
    };
    let owners: Vec<_> = rows
        .iter()
        .filter(|r| {
            port(r.dwLocalPort) == peer.port()
                && (r.dwLocalAddr == 0 || r.dwLocalAddr == u32::from_ne_bytes(peer.ip().octets()))
        })
        .map(|r| r.dwOwningPid)
        .collect();
    !owners.is_empty() && owners.into_iter().all(own)
}

/// A duplicated job handle outlives concurrent UDP observation and cannot be
/// closed/reused while a membership check holds the mutex. This adds an
/// observation guard only; forwarding still uses its existing owner boundary.
#[derive(Default)]
pub struct RegistrationJob(std::sync::Mutex<Option<OwnedHandle>>);
impl RegistrationJob {
    pub fn bind(&self, job: windows_sys::Win32::Foundation::HANDLE) -> std::io::Result<()> {
        use windows_sys::Win32::Foundation::{DuplicateHandle, DUPLICATE_SAME_ACCESS};
        let mut duplicate = std::ptr::null_mut();
        let current = unsafe { GetCurrentProcess() };
        if unsafe { DuplicateHandle(current, job, current, &mut duplicate, 0, 0, DUPLICATE_SAME_ACCESS) } == 0 {
            return Err(std::io::Error::last_os_error());
        }
        let owned = unsafe { OwnedHandle::from_raw_handle(duplicate.cast()) };
        *self.0.lock().map_err(|_| std::io::Error::other("registration job unavailable"))? = Some(owned);
        Ok(())
    }
    pub fn process(&self, process: windows_sys::Win32::Foundation::HANDLE) -> bool {
        let Ok(job) = self.0.lock() else { return false; };
        let Some(job) = job.as_ref() else { return false; };
        let mut included = 0;
        unsafe { IsProcessInJob(process, job.as_raw_handle().cast(), &mut included) != 0 && included != 0
            && crate::identity::same_process_user(process).unwrap_or(false) }
    }
    pub fn udp(&self, peer: SocketAddr) -> bool {
        let SocketAddr::V4(peer) = peer else { return false; };
        let Some(table) = rows::<MIB_UDPROW_OWNER_PID>(true) else { return false; };
        let owners: Vec<_> = table.iter().filter(|r| port(r.dwLocalPort) == peer.port()
            && (r.dwLocalAddr == 0 || r.dwLocalAddr == u32::from_ne_bytes(peer.ip().octets())))
            .map(|r| r.dwOwningPid).collect();
        !owners.is_empty() && owners.into_iter().all(|pid| {
            if !own(pid) { return false; }
            let process = unsafe { OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid) };
            if process.is_null() { return false; }
            let process = unsafe { OwnedHandle::from_raw_handle(process.cast()) };
            self.process(process.as_raw_handle().cast())
        })
    }
    pub fn clear(&self) { if let Ok(mut job) = self.0.lock() { *job = None; } }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn registration_observation_requires_the_exact_engine_job_and_living_handle() {
        use std::os::windows::process::CommandExt;
        use windows_sys::Win32::System::JobObjects::{CreateJobObjectW, AssignProcessToJobObject};
        let job = unsafe { CreateJobObjectW(std::ptr::null(), std::ptr::null()) };
        assert!(!job.is_null());
        let job = unsafe { OwnedHandle::from_raw_handle(job.cast()) };
        // A literal system helper is created suspended and never resumed: no
        // engine, shell command, user UI or network traffic executes.
        let system = std::path::PathBuf::from(std::env::var_os("SystemRoot").unwrap()).join("System32/cmd.exe");
        struct Suspended(std::process::Child);
        impl Drop for Suspended { fn drop(&mut self) { let _=self.0.kill(); let _=self.0.wait(); } }
        let mut child = Suspended(std::process::Command::new(system).args(["/d", "/c", "exit", "0"])
            .creation_flags(0x08000004).spawn().unwrap());
        assert_ne!(unsafe { AssignProcessToJobObject(job.as_raw_handle().cast(), child.0.as_raw_handle().cast()) }, 0);
        let guard = RegistrationJob::default(); guard.bind(job.as_raw_handle().cast()).unwrap();
        assert!(guard.process(child.0.as_raw_handle().cast()));
        assert!(!guard.process(unsafe { GetCurrentProcess() }));
        let udp = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
        assert!(!guard.udp(udp.local_addr().unwrap()));
        drop(job); // The duplicate remains valid during observation.
        assert!(guard.process(child.0.as_raw_handle().cast()));
        guard.clear(); assert!(!guard.process(child.0.as_raw_handle().cast()));
        child.0.kill().unwrap(); child.0.wait().unwrap();
    }
    #[test]
    fn actual_loopback_client_is_authorized_by_its_owner_and_session() {
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let client = std::net::TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        let (_accepted, peer) = listener.accept().unwrap();
        let mut session = 0;
        assert_ne!(
            unsafe { ProcessIdToSessionId(GetCurrentProcessId(), &mut session) },
            0
        );
        assert_eq!(tcp(listener.local_addr().unwrap(), peer), session != 0);
        let udp_socket = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
        assert_eq!(udp(udp_socket.local_addr().unwrap()), session != 0);
        assert!(!tcp(
            listener.local_addr().unwrap(),
            SocketAddr::from(([127, 0, 0, 1], 0))
        ));
        drop(client);
    }
}
