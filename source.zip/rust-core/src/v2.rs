//! Durable immutable save snapshots, fresh CAS and short display metadata cache.
use crate::{
    Config,
    engine::{atomic, checked, hash},
    metadata::{Cache, Meta, fresh},
    safe,
};
use anyhow::{Result, ensure};
use opendal::Operator;
use serde::{Deserialize, Serialize};
use std::{
    fs::{self, File},
    io::{Read, Write},
    path::PathBuf,
    sync::Mutex,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
#[derive(Clone, Serialize, Deserialize)]
pub struct Record {
    pub path: String,
    pub ready: bool,
    pub snapshot: String,
    pub sha256: String,
    pub bytes: u64,
    pub base: Option<Meta>,
    pub scope: String,
    pub generation: String,
    #[serde(default)]
    pub cloud_base: Option<crate::replace::Identity>,
}
#[derive(Serialize, Deserialize)]
struct Base {
    meta: Option<Meta>,
    #[serde(default)]
    cloud: Option<crate::replace::Identity>,
}
pub fn file_hash(p: &std::path::Path) -> Result<String> {
    use sha2::{Digest, Sha256};
    let mut f = File::open(p)?;
    let mut h = Sha256::new();
    let mut b = vec![0; 1024 * 1024];
    loop {
        let n = f.read(&mut b)?;
        if n == 0 {
            break;
        }
        h.update(&b[..n])
    }
    Ok(hex::encode(h.finalize()))
}
pub fn nonce() -> String {
    format!(
        "{}-{}",
        std::process::id(),
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    )
}
pub struct Engine {
    pub cfg: Config,
    pub op: Operator,
    pub lock: Mutex<()>,
    pub cache: Cache,
    pub hidden: Mutex<std::collections::HashSet<String>>,
    scope: String,
    recovery_lock: tokio::sync::Mutex<()>,
}
impl Engine {
    pub fn new(cfg: Config, op: Operator) -> Result<Self> {
        ensure!(!cfg.work.as_os_str().is_empty(), "private cache required");
        for d in ["data", "bases", "journal", "snapshots", "conflicts"] {
            fs::create_dir_all(cfg.work.join(d))?
        }
        let scope = hash(
            serde_json::to_string(&(
                cfg.provider.clone(),
                cfg.root.clone(),
                cfg.get("connection_id"),
                cfg.get("endpoint"),
                cfg.get("bucket"),
            ))?
            .as_bytes(),
        );
        let guard = cfg.work.join("scope-v2.txt");
        if guard.exists() {
            ensure!(fs::read_to_string(&guard)? == scope, "cache scope mismatch")
        } else {
            atomic(&guard, scope.as_bytes())?
        }
        let hidden = cfg.work.join("hidden.json");
        let names = if hidden.exists() {
            serde_json::from_slice(&fs::read(hidden)?)?
        } else {
            std::collections::HashSet::new()
        };
        Ok(Self {
            cfg,
            op,
            lock: Mutex::new(()),
            cache: Cache::new(Duration::from_secs(2), 4096),
            hidden: Mutex::new(names),
            scope,
            recovery_lock: tokio::sync::Mutex::new(()),
        })
    }
    pub fn local(&self, p: &str) -> Result<PathBuf> {
        Ok(self.cfg.work.join("data").join(checked(p)?))
    }
    pub fn journal(&self, p: &str) -> PathBuf {
        self.cfg
            .work
            .join("journal")
            .join(format!("{}.json", hash(p.as_bytes())))
    }
    fn basefile(&self, p: &str) -> PathBuf {
        self.cfg
            .work
            .join("bases")
            .join(format!("{}.json", hash(p.as_bytes())))
    }
    pub fn remember(&self, p: &str, meta: Option<Meta>) -> Result<()> {
        atomic(
            &self.basefile(p),
            &serde_json::to_vec(&Base { meta, cloud: None })?,
        )
    }
    pub fn base(&self, p: &str) -> Result<Option<Meta>> {
        let f = self.basefile(p);
        if f.exists() {
            Ok(serde_json::from_slice::<Base>(&fs::read(f)?)?.meta)
        } else {
            Ok(None)
        }
    }
    pub fn hide(&self, p: &str, yes: bool) -> Result<()> {
        let mut names = self.hidden.lock().unwrap();
        if yes {
            names.insert(p.into());
        } else {
            names.remove(p);
        }
        atomic(
            &self.cfg.work.join("hidden.json"),
            &serde_json::to_vec(&*names)?,
        )?;
        self.cache.invalidate(p);
        Ok(())
    }
    pub async fn hydrate(&self, p: &str) -> Result<()> {
        let local = self.local(p)?;
        if local.exists() {
            return Ok(());
        }
        let m = fresh(&self.op, p)
            .await?
            .ok_or_else(|| anyhow::anyhow!("not found"))?;
        ensure!(!m.dir, "cannot hydrate directory");
        let mut identity = if matches!(self.cfg.provider.as_str(), "drive" | "onedrive") {
            crate::replace::identity(&self.cfg, p).await?
        } else {
            None
        };
        self.remember(p, Some(m.clone()))?;
        if let Some(d) = local.parent() {
            fs::create_dir_all(d)?
        }
        let temp = local.with_extension("hydrating");
        if let Some(ref mut tag) = identity {
            tag.sha256 = crate::replace::stream_id(&self.cfg, &tag.id, Some(&temp)).await?;
            ensure!(
                fs::metadata(&temp)?.len() == m.size,
                "short guarded hydration"
            );
        } else {
            let mut f = File::create(&temp)?;
            let reader = self
                .op
                .reader(p)
                .await
                .map_err(|e| anyhow::anyhow!("hydrate {:?}", e.kind()))?;
            let mut offset = 0;
            while offset < m.size {
                let end = (offset + 8 * 1024 * 1024).min(m.size);
                let b = reader
                    .read(offset..end)
                    .await
                    .map_err(|e| anyhow::anyhow!("hydrate range {:?}", e.kind()))?
                    .to_vec();
                ensure!(b.len() as u64 == end - offset, "short hydration");
                f.write_all(&b)?;
                offset = end
            }
            f.sync_all()?;
            drop(f);
        }
        let after = fresh(&self.op, p).await?;
        ensure!(after == Some(m), "remote changed during hydration");
        if let Some(ref mut tag) = identity {
            let after = crate::replace::identity(&self.cfg, p)
                .await?
                .ok_or_else(|| anyhow::anyhow!("hydration identity lost"))?;
            ensure!(
                tag.id == after.id && tag.etag == after.etag,
                "remote changed during guarded hydration"
            );
            tag.sha256 = file_hash(&temp)?;
            atomic(
                &self.basefile(p),
                &serde_json::to_vec(&Base {
                    meta: self.base(p)?,
                    cloud: identity,
                })?,
            )?;
        }
        fs::rename(temp, local)?;
        Ok(())
    }
    pub fn mark(&self, p: &str, ready: bool) -> Result<()> {
        let previous = self.journal(p);
        let old = if previous.exists() {
            Some(serde_json::from_slice::<Record>(&fs::read(&previous)?)?)
        } else {
            None
        };
        let generation = nonce();
        let local = self.local(p)?;
        let (snapshot, sha256, bytes) = if ready {
            let snap = format!("{}-{}.bin", hash(p.as_bytes()), generation);
            let dest = self.cfg.work.join("snapshots").join(&snap);
            fs::copy(&local, &dest)?;
            File::options().write(true).open(&dest)?.sync_all()?;
            (snap, file_hash(&dest)?, dest.metadata()?.len())
        } else if let Some(r) = old.as_ref().filter(|r| !r.snapshot.is_empty()) {
            // Opening an already saved document for writing must hold, but not
            // discard, its last immutable completed-close snapshot.
            (r.snapshot.clone(), r.sha256.clone(), r.bytes)
        } else {
            (String::new(), String::new(), 0)
        };
        let cloud_base = if let Some(ref r) = old {
            r.cloud_base.clone()
        } else {
            let file = self.basefile(p);
            if file.exists() {
                serde_json::from_slice::<Base>(&fs::read(file)?)?.cloud
            } else {
                None
            }
        };
        let base = old.map(|r| r.base).unwrap_or(self.base(p)?);
        let record = Record {
            path: p.into(),
            ready,
            snapshot,
            sha256,
            bytes,
            base,
            scope: self.scope.clone(),
            generation,
            cloud_base,
        };
        atomic(&previous, &serde_json::to_vec(&record)?)?;
        self.cache.invalidate(p);
        Ok(())
    }
    pub fn close_unchanged(&self, p: &str) -> Result<()> {
        let file = self.journal(p);
        if !file.exists() {
            return Ok(());
        }
        let mut r: Record = serde_json::from_slice(&fs::read(&file)?)?;
        if !r.ready
            && r.snapshot.is_empty()
            && r.cloud_base.as_ref().is_some_and(|g| !g.sha256.is_empty())
            && file_hash(&self.local(p)?)? == r.cloud_base.as_ref().unwrap().sha256
        {
            fs::remove_file(file)?;
            return Ok(());
        }
        if !r.ready
            && !r.snapshot.is_empty()
            && file_hash(&self.local(p)?)? == r.sha256
            && file_hash(&self.cfg.work.join("snapshots").join(&r.snapshot))? == r.sha256
        {
            r.ready = true;
            atomic(&file, &serde_json::to_vec(&r)?)?;
        }
        Ok(())
    }
    pub async fn recover(&self) -> Result<serde_json::Value> {
        let _recovery = self.recovery_lock.lock().await;
        if self.cfg.work.join("offline").exists() {
            return Ok(serde_json::json!({"offline":true}));
        }
        let mut sent = 0;
        let mut conflicts = 0;
        let mut held = 0;
        let entries = fs::read_dir(self.cfg.work.join("journal"))?
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().and_then(|s| s.to_str()) == Some("json"))
            .collect::<Vec<_>>();
        for path in entries {
            let r = {
                let _g = self.lock.lock().unwrap();
                if !path.exists() {
                    continue;
                }
                serde_json::from_slice::<Record>(&fs::read(&path)?)?
            };
            ensure!(r.scope == self.scope, "journal scope mismatch");
            if !r.ready || safe::transient(&r.path) || self.hidden.lock().unwrap().contains(&r.path)
            {
                held += 1;
                continue;
            }
            let snap = self.cfg.work.join("snapshots").join(&r.snapshot);
            ensure!(
                snap.metadata()?.len() == r.bytes && file_hash(&snap)? == r.sha256,
                "corrupt immutable snapshot"
            );
            let now = fresh(&self.op, &r.path).await?;
            let mut conflict = now != r.base;
            let managed_replacement = r.cloud_base.is_some()
                && self
                    .cfg
                    .work
                    .join("uploads")
                    .join(&r.snapshot)
                    .join("replace.dpapi")
                    .exists();
            // A response could have been lost after a successful commit; verify content.
            if conflict && !managed_replacement && now.as_ref().map(|m| m.size) == Some(r.bytes) {
                let digest = if matches!(self.cfg.provider.as_str(), "drive" | "onedrive") {
                    crate::replace::verify_path(&self.cfg, &r.path).await
                } else {
                    crate::cloud::remote_hash(&self.op, &r.path).await
                };
                if let Ok(digest) = digest
                    && digest == r.sha256
                {
                    let cloud = self.verified_identity(&r).await?;
                    self.finish(&r, now, false, cloud)?;
                    sent += 1;
                    continue;
                }
            }
            if r.bytes > 32 * 1024 * 1024
                && r.base.is_none()
                && self.cfg.provider == "onedrive"
                && self
                    .cfg
                    .work
                    .join("uploads")
                    .join(&r.snapshot)
                    .join("session.dpapi")
                    .exists()
            {
                // Adapter validates the protected reservation identity/revision.
                conflict = false;
            }
            if managed_replacement {
                conflict = false; // protected adapter reconciles its own commit phases
            }
            if !conflict {
                let saved = if r.bytes > 32 * 1024 * 1024
                    || (matches!(self.cfg.provider.as_str(), "drive" | "onedrive")
                        && (r.cloud_base.is_some() || self.cfg.provider == "drive"))
                {
                    // Large replacement requires atomic commit CAS; create-only
                    // adapters fail closed rather than overwrite an old version.
                    if (r.base.is_some() && r.cloud_base.is_none())
                        || !matches!(self.cfg.provider.as_str(), "drive" | "onedrive" | "s3")
                    {
                        held += 1;
                        continue;
                    }
                    let mut cfg = self.cfg.clone();
                    cfg.work = self.cfg.work.join("uploads").join(&r.snapshot);
                    cfg.options.insert("path".into(), r.path.clone());
                    cfg.options
                        .insert("source".into(), snap.to_string_lossy().into_owned());
                    if let Some(ref base) = r.cloud_base {
                        cfg.options
                            .insert("base_identity".into(), serde_json::to_string(base)?);
                    }
                    let outcome = if r.cloud_base.is_some() {
                        crate::replace::upload(&cfg).await
                    } else {
                        crate::stream::upload(&cfg).await
                    };
                    match outcome {
                        Ok(v) if v["completed"] == true => {
                            atomic(
                                &cfg.work.join("upload-result.json"),
                                &serde_json::to_vec(&v)?,
                            )?;
                            Ok(())
                        }
                        Ok(_) => {
                            held += 1;
                            continue;
                        }
                        Err(e) => Err(e),
                    }
                } else {
                    safe::put(
                        &self.cfg,
                        &self.op,
                        &r.path,
                        r.base.as_ref(),
                        fs::read(&snap)?,
                    )
                    .await
                };
                match saved {
                    Ok(()) => {}
                    Err(e) => {
                        let s = e.to_string();
                        if s.contains("ConditionNotMatch")
                            || s.contains("AlreadyExists")
                            || s.contains("HTTP 412")
                            || s.contains("HTTP 409")
                        {
                            conflict = true
                        } else if s.contains("unsupported") {
                            held += 1;
                            continue;
                        } else {
                            return Err(e);
                        }
                    }
                }
            }
            if conflict {
                let local = self.cfg.work.join("conflicts").join(format!(
                    "{}-{}-{}",
                    hash(r.path.as_bytes()),
                    &r.sha256[..12],
                    r.path.rsplit('/').next().unwrap()
                ));
                if !local.exists() {
                    fs::copy(&snap, &local)?;
                    File::options().write(true).open(&local)?.sync_all()?
                }
                atomic(&local.with_extension("json"), &serde_json::to_vec(&r)?)?;
                self.finish(&r, now, true, None)?;
                conflicts += 1;
                continue;
            }
            let cloud = self.verified_identity(&r).await?;
            if cloud.is_none() {
                ensure!(
                    crate::cloud::remote_hash(&self.op, &r.path).await? == r.sha256,
                    "postcommit hash mismatch"
                );
            }
            let next = fresh(&self.op, &r.path).await?;
            self.finish(&r, next, false, cloud)?;
            sent += 1;
        }
        Ok(serde_json::json!({"uploaded":sent,"conflicts":conflicts,"held":held}))
    }
    async fn verified_identity(&self, r: &Record) -> Result<Option<crate::replace::Identity>> {
        if !matches!(self.cfg.provider.as_str(), "drive" | "onedrive") {
            return Ok(None);
        }
        let mut cfg = self.cfg.clone();
        cfg.options.insert("path".into(), r.path.clone());
        let v = crate::replace::capture(&cfg).await?;
        ensure!(
            v.sha256 == r.sha256,
            "verified commit changed before base advance; retained"
        );
        Ok(Some(v))
    }
    fn finish(
        &self,
        r: &Record,
        next: Option<Meta>,
        conflict: bool,
        cloud: Option<crate::replace::Identity>,
    ) -> Result<()> {
        let _g = self.lock.lock().unwrap();
        let j = self.journal(&r.path);
        if j.exists() {
            let mut current: Record = serde_json::from_slice(&fs::read(&j)?)?;
            if current.generation == r.generation {
                fs::remove_file(j)?
            } else if !conflict && current.base == r.base {
                current.base = next.clone();
                current.cloud_base = cloud.clone();
                atomic(&j, &serde_json::to_vec(&current)?)?
            }
        }
        if !conflict {
            atomic(
                &self.basefile(&r.path),
                &serde_json::to_vec(&Base { meta: next, cloud })?,
            )?
        }
        self.cache.invalidate(&r.path);
        Ok(())
    }
}
