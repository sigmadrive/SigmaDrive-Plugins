//! A private wake hint, never a grant, heartbeat or transport credential.
//! Every remote change is followed by the ordinary authenticated state request.
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use std::{future::Future, time::Duration};

pub const HOLD_MS: u64 = 15_000;
pub const HTTP_SECONDS: u64 = 20;
pub const CANCEL_POLL_MS: u64 = 100;

#[derive(Clone)]
pub struct Ticket {
    cursor: String,
    identity: Value,
    auth_epoch: u64,
    desk_epoch: u64,
}
fn cursor(v: &Value) -> Option<&str> {
    v.as_str().filter(|s| s.len() == 32
        && s.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)))
}
fn exact(v: &Value, names: &[&str]) -> bool {
    v.as_object().is_some_and(|o| o.len() == names.len()
        && names.iter().all(|k| o.contains_key(*k)))
}
impl Ticket {
    pub fn observe(remote: &Value, identity: &Value, auth_epoch: u64, desk_epoch: u64) -> Option<Self> {
        let n = remote.get("notification")?;
        if !exact(n, &["version", "cursor", "wait_ms"]) || n["version"].as_u64() != Some(1)
            || n["wait_ms"].as_u64() != Some(HOLD_MS)
            || !["node", "pin", "member"].iter().all(|k|
                identity[*k].as_str().is_some_and(|s| !s.is_empty()) && remote["self"][*k] == identity[*k]) {
            return None;
        }
        Some(Self {cursor: cursor(&n["cursor"] )?.to_owned(), identity: identity.clone(), auth_epoch, desk_epoch})
    }
    pub fn matches(&self, identity: &Value, auth_epoch: u64, desk_epoch: u64) -> bool {
        self.identity == *identity && self.auth_epoch == auth_epoch && self.desk_epoch == desk_epoch
    }
    pub fn body(&self) -> Value { json!({"version":1,"cursor":self.cursor,"wait_ms":HOLD_MS}) }
    pub fn same_cursor(&self, other: &Self) -> bool {
        self.cursor == other.cursor && self.identity == other.identity
            && self.auth_epoch == other.auth_epoch && self.desk_epoch == other.desk_epoch
    }
    pub fn accept(&self, response: &Value) -> Result<bool> {
        ensure!(exact(response, &["version", "cursor", "changed"])
            && response["version"].as_u64() == Some(1), "SigmaDesk notification response denied");
        let next = cursor(&response["cursor"]).ok_or_else(||anyhow::anyhow!("SigmaDesk notification cursor denied"))?;
        let changed = response["changed"].as_bool().ok_or_else(||anyhow::anyhow!("SigmaDesk notification response denied"))?;
        ensure!(changed == (next != self.cursor), "SigmaDesk notification progress denied");
        Ok(changed)
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum Outcome { Changed, Timeout, LocalWake, Canceled }

// One owned HTTP future per wait. Dropping this future cancels its response
// stream; no detached task, credentials or background retry is retained.
pub async fn drive<F, C, CF>(request: F, ticket: &Ticket, wake: &tokio::sync::Notify,
    mut current: C) -> Result<Outcome>
where F: Future<Output=Result<Value>>, C: FnMut() -> CF, CF: Future<Output=bool> {
    if !current().await {return Ok(Outcome::Canceled)}
    let request=tokio::time::timeout(Duration::from_secs(HTTP_SECONDS), request);
    tokio::pin!(request);
    let mut check=tokio::time::interval(Duration::from_millis(CANCEL_POLL_MS));
    check.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    check.tick().await;
    loop {
        tokio::select! {
            biased;
            _ = check.tick() => {if !current().await {return Ok(Outcome::Canceled)}},
            _ = wake.notified() => return Ok(Outcome::LocalWake),
            result = &mut request => {
                let value=result.map_err(|_|anyhow::anyhow!("SigmaDesk notification deadline"))??;
                // A response can complete between two cancellation ticks. Do
                // not publish even a hint from an already retired local context.
                if !current().await {return Ok(Outcome::Canceled)}
                return Ok(if ticket.accept(&value)? {Outcome::Changed} else {Outcome::Timeout});
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, atomic::{AtomicBool, AtomicUsize, Ordering}};
    fn ticket() -> Ticket {
        Ticket::observe(&json!({"self":{"node":"node","pin":"pin","member":"member"},
            "notification":{"version":1,"cursor":"a".repeat(32),"wait_ms":HOLD_MS}}),
            &json!({"node":"node","pin":"pin","member":"member"}), 7, 9).unwrap()
    }
    #[test]
    fn capability_is_exact_bound_private_and_optional() {
        let t=ticket();
        assert!(t.matches(&t.identity,7,9));
        assert!(!t.matches(&t.identity,8,9));assert!(!t.matches(&t.identity,7,10));
        assert!(!t.matches(&json!({"node":"other","pin":"pin","member":"member"}),7,9));
        let base=json!({"self":t.identity,"notification":t.body()});
        for changed in [Value::Null,json!({"version":2,"cursor":"a".repeat(32),"wait_ms":HOLD_MS}),
            json!({"version":1,"cursor":"A".repeat(32),"wait_ms":HOLD_MS}),
            json!({"version":1,"cursor":"a".repeat(32),"wait_ms":30_000}),
            json!({"version":1,"cursor":"a".repeat(32),"wait_ms":HOLD_MS,"token":"secret"})] {
            let mut remote=base.clone();remote["notification"]=changed;
            assert!(Ticket::observe(&remote,&t.identity,7,9).is_none());
        }
        let mut wrong=base;wrong["self"]["member"]=json!("other");
        assert!(Ticket::observe(&wrong,&t.identity,7,9).is_none());
        assert_eq!(t.body().as_object().unwrap().len(),3);
        assert!(!t.body().to_string().contains("member"));
    }
    #[test]
    fn reply_is_only_a_progress_checked_hint() {
        let t=ticket();
        assert!(t.accept(&json!({"version":1,"cursor":"b".repeat(32),"changed":true})).unwrap());
        assert!(!t.accept(&json!({"version":1,"cursor":"a".repeat(32),"changed":false})).unwrap());
        for bad in [json!({"version":1,"cursor":"a".repeat(32),"changed":true}),
            json!({"version":1,"cursor":"b".repeat(32),"changed":false}),
            json!({"version":1,"cursor":"b".repeat(32),"changed":true,"decision":{}}),
            json!({"version":1,"cursor":"bad","changed":true}),
            json!({"version":1,"cursor":"b".repeat(32),"changed":1})] {
            assert!(t.accept(&bad).is_err());
        }
    }
    #[tokio::test]
    async fn immediate_signal_does_not_wait_for_legacy_timer() {
        let t=ticket();let wake=tokio::sync::Notify::new();let start=std::time::Instant::now();
        let outcome=drive(async {Ok(json!({"version":1,"cursor":"b".repeat(32),"changed":true}))},
            &t,&wake,||async{true}).await.unwrap();
        assert_eq!(outcome,Outcome::Changed);assert!(start.elapsed()<Duration::from_secs(1));
    }
    struct Dropped(Arc<AtomicUsize>);
    impl Drop for Dropped {fn drop(&mut self){self.0.fetch_add(1,Ordering::AcqRel);}}
    #[tokio::test]
    async fn local_context_change_drops_pending_http_without_starting_any_engine() {
        let t=ticket();let wake=tokio::sync::Notify::new();
        let live=Arc::new(AtomicBool::new(true));let drops=Arc::new(AtomicUsize::new(0));
        let guard=Dropped(drops.clone());let request=async move{let _guard=guard;std::future::pending::<Result<Value>>().await};
        let flag=live.clone();let reset=async move {tokio::time::sleep(Duration::from_millis(10)).await;flag.store(false,Ordering::Release);};
        let (_,result)=tokio::join!(reset,drive(request,&t,&wake,||{let live=live.clone();async move{live.load(Ordering::Acquire)}}));
        assert_eq!(result.unwrap(),Outcome::Canceled);assert_eq!(drops.load(Ordering::Acquire),1);
    }
    #[tokio::test]
    async fn local_wake_and_wait_failure_never_become_a_grant() {
        let t=ticket();let wake=tokio::sync::Notify::new();wake.notify_one();
        let value=drive(std::future::pending(),&t,&wake,||async{true}).await.unwrap();
        assert_eq!(value,Outcome::LocalWake);
        assert!(drive(async{anyhow::bail!("offline")},&t,&wake,||async{true}).await.is_err());
        assert_eq!(drive(std::future::pending(),&t,&wake,||async{false}).await.unwrap(),Outcome::Canceled);
    }
    #[tokio::test]
    async fn a_valid_late_reply_cannot_wake_a_replaced_context() {
        let t=ticket();let wake=tokio::sync::Notify::new();
        let live=Arc::new(AtomicBool::new(true));let remote_live=live.clone();
        let request=async move{
            remote_live.store(false,Ordering::Release);
            Ok(json!({"version":1,"cursor":"b".repeat(32),"changed":true}))
        };
        let result=drive(request,&t,&wake,||{let live=live.clone();async move{live.load(Ordering::Acquire)}}).await.unwrap();
        assert_eq!(result,Outcome::Canceled);
    }
}
