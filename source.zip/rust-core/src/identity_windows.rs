// Derived from Sigma-Drive/app/src-tauri/src/sys_windows.rs; per-user IPC identity verification.
use std::{
    io,
    os::windows::io::{AsRawHandle, FromRawHandle, OwnedHandle},
    ptr::null_mut,
};
use windows_sys::Win32::{
    Foundation::{HANDLE, LocalFree},
    Security::{
        Authorization::ConvertSidToStringSidW, EqualSid, GetTokenInformation, PSID, TOKEN_QUERY,
        TOKEN_USER, TokenUser,
    },
    System::Threading::{GetCurrentProcess, OpenProcessToken},
};
pub fn same_process_user(handle: HANDLE) -> io::Result<bool> {
    Ok(ProcessUser::of(handle)?.sid_string()? == current_sid()?)
}
pub fn current_sid() -> io::Result<String> {
    ProcessUser::of(unsafe { GetCurrentProcess() })?.sid_string()
}

pub const PRIVATE_STATE_DIRECTORY: &str = "SigmaDriveRustCore";
pub const PRIVATE_INSTALL_DIRECTORY: &str = "SigmaDriveRust";

fn private_local_relative(relative: &std::path::Path) -> bool {
    use std::path::Component;
    let parts: Vec<_> = relative.components().collect();
    if parts.iter().any(|p| !matches!(p, Component::Normal(_))) {
        return false;
    }
    parts
        .first()
        .is_some_and(|p| p.as_os_str() == PRIVATE_STATE_DIRECTORY)
        || (parts.len() >= 2
            && parts[0].as_os_str() == "Programs"
            && parts[1].as_os_str() == PRIVATE_INSTALL_DIRECTORY)
}

/// Elevated Windows accounts can create files owned by BUILTIN/Administrators.
/// Normalize that one owner only inside the token's real LocalAppData; never
/// adopt another user's SID, a junction, or a path chosen through environment.
pub fn protect_own_local_directory(path: &std::path::Path) -> io::Result<()> {
    use std::{
        os::windows::{ffi::OsStrExt, fs::MetadataExt},
        path::PathBuf,
    };
    use windows_sys::Win32::{
        Security::{
            Authorization::{GetNamedSecurityInfoW, SE_FILE_OBJECT, SetNamedSecurityInfoW},
            CreateWellKnownSid, OWNER_SECURITY_INFORMATION, WinBuiltinAdministratorsSid,
        },
        System::Com::CoTaskMemFree,
        UI::Shell::{FOLDERID_LocalAppData, SHGetKnownFolderPath},
    };
    let mut raw = null_mut();
    if unsafe { SHGetKnownFolderPath(&FOLDERID_LocalAppData, 0, null_mut(), &mut raw) } < 0
        || raw.is_null()
    {
        return Err(io::Error::other("Known Folder unavailable"));
    }
    use std::os::windows::ffi::OsStringExt;
    let len = (0..).take_while(|i| unsafe { *raw.add(*i) } != 0).count();
    let home = PathBuf::from(std::ffi::OsString::from_wide(unsafe {
        std::slice::from_raw_parts(raw, len)
    }));
    unsafe { CoTaskMemFree(raw.cast()) };
    if !path.is_absolute()
        || path
            .components()
            .any(|c| matches!(c, std::path::Component::ParentDir))
        || !path.starts_with(&home)
    {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "outside current user's LocalAppData",
        ));
    }
    let relative = path.strip_prefix(&home).map_err(io::Error::other)?;
    if !private_local_relative(relative) {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "not a SigmaDrive private directory",
        ));
    }
    let mut check = home.clone();
    for part in relative.components() {
        check.push(part);
        if std::fs::symlink_metadata(&check)?.file_attributes() & 0x400 != 0 {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "private directory link denied",
            ));
        }
    }
    // Resolve the whole chain as well; lexical prefix alone is not a boundary.
    if !path.canonicalize()?.starts_with(home.canonicalize()?) {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "foreign private directory",
        ));
    }
    let name: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();
    let mut owner = null_mut();
    let mut descriptor = null_mut();
    let result = unsafe {
        GetNamedSecurityInfoW(
            name.as_ptr(),
            SE_FILE_OBJECT,
            OWNER_SECURITY_INFORMATION,
            &mut owner,
            null_mut(),
            null_mut(),
            null_mut(),
            &mut descriptor,
        )
    };
    if result != 0 {
        return Err(io::Error::from_raw_os_error(result as i32));
    }
    let me = ProcessUser::of(unsafe { GetCurrentProcess() })?;
    let mut admins = [0u64; 16];
    let mut size = 128;
    let is_admins = unsafe {
        CreateWellKnownSid(
            WinBuiltinAdministratorsSid,
            null_mut(),
            admins.as_mut_ptr().cast(),
            &mut size,
        )
    } != 0
        && unsafe { EqualSid(owner, admins.as_ptr() as PSID) } != 0;
    let mine = unsafe { EqualSid(owner, me.sid()) } != 0;
    unsafe { LocalFree(descriptor) };
    if !mine {
        if !is_admins {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "foreign user data owner",
            ));
        }
        // This call needs WRITE_OWNER already granted by Windows. Never enable
        // privileges, take a foreign SID's directory, or change any policy.
        let result = unsafe {
            SetNamedSecurityInfoW(
                name.as_ptr(),
                SE_FILE_OBJECT,
                OWNER_SECURITY_INFORMATION,
                me.sid(),
                null_mut(),
                null_mut(),
                null_mut(),
            )
        };
        if result != 0 {
            return Err(io::Error::from_raw_os_error(result as i32));
        }
    }
    protect_directory(path)
}

// App data is private even when a user's profile inherited a permissive ACL.
// This is not a boundary against an administrator taking ownership.
pub fn protect_directory(path: &std::path::Path) -> io::Result<()> {
    use std::os::windows::ffi::OsStrExt;
    use windows_sys::Win32::Security::{
        Authorization::{
            ConvertStringSecurityDescriptorToSecurityDescriptorW, GetNamedSecurityInfoW,
            SE_FILE_OBJECT, SetNamedSecurityInfoW,
        },
        DACL_SECURITY_INFORMATION, GetSecurityDescriptorDacl, OWNER_SECURITY_INFORMATION,
        PROTECTED_DACL_SECURITY_INFORMATION,
    };
    let name: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();
    let mut owner = null_mut();
    let mut existing = null_mut();
    let err = unsafe {
        GetNamedSecurityInfoW(
            name.as_ptr(),
            SE_FILE_OBJECT,
            OWNER_SECURITY_INFORMATION,
            &mut owner,
            null_mut(),
            null_mut(),
            null_mut(),
            &mut existing,
        )
    };
    if err != 0 {
        return Err(io::Error::from_raw_os_error(err as i32));
    }
    let me = ProcessUser::of(unsafe { GetCurrentProcess() })?;
    let owned = unsafe { EqualSid(owner, me.sid()) } != 0;
    unsafe { LocalFree(existing) };
    if !owned {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "foreign user data owner",
        ));
    }
    let sddl: Vec<u16> = format!("D:P(A;OICI;FA;;;{})", me.sid_string()?)
        .encode_utf16()
        .chain(Some(0))
        .collect();
    let mut sd = null_mut();
    if unsafe {
        ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl.as_ptr(), 1, &mut sd, null_mut())
    } == 0
    {
        return Err(io::Error::last_os_error());
    }
    let mut present = 0;
    let mut defaulted = 0;
    let mut acl = null_mut();
    if unsafe { GetSecurityDescriptorDacl(sd, &mut present, &mut acl, &mut defaulted) } == 0
        || present == 0
        || acl.is_null()
    {
        unsafe { LocalFree(sd) };
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "private DACL unavailable",
        ));
    }
    let result = unsafe {
        SetNamedSecurityInfoW(
            name.as_ptr(),
            SE_FILE_OBJECT,
            DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
            null_mut(),
            null_mut(),
            acl,
            null_mut(),
        )
    };
    unsafe { LocalFree(sd) };
    if result != 0 {
        return Err(io::Error::from_raw_os_error(result as i32));
    }
    Ok(())
}
/// The user a process runs as: its token's TOKEN_USER, with the SID it
/// points to (u64s keep it aligned).
struct ProcessUser(Vec<u64>);

impl ProcessUser {
    fn of(process: HANDLE) -> io::Result<Self> {
        let mut token: HANDLE = null_mut();
        if unsafe { OpenProcessToken(process, TOKEN_QUERY, &mut token) } == 0 {
            return Err(io::Error::last_os_error());
        }
        let token = unsafe { OwnedHandle::from_raw_handle(token) };
        let mut len = 0u32;
        unsafe { GetTokenInformation(token.as_raw_handle(), TokenUser, null_mut(), 0, &mut len) };
        let mut buf = vec![0u64; (len as usize).div_ceil(8)];
        if unsafe {
            GetTokenInformation(
                token.as_raw_handle(),
                TokenUser,
                buf.as_mut_ptr().cast(),
                len,
                &mut len,
            )
        } == 0
        {
            return Err(io::Error::last_os_error());
        }
        Ok(Self(buf))
    }

    fn sid(&self) -> PSID {
        unsafe { (*self.0.as_ptr().cast::<TOKEN_USER>()).User.Sid }
    }

    fn sid_string(&self) -> io::Result<String> {
        let mut s = null_mut();
        if unsafe { ConvertSidToStringSidW(self.sid(), &mut s) } == 0 {
            return Err(io::Error::last_os_error());
        }
        let len = (0..).take_while(|&i| unsafe { *s.add(i) } != 0).count();
        let out = String::from_utf16_lossy(unsafe { std::slice::from_raw_parts(s, len) });
        unsafe { LocalFree(s.cast()) };
        Ok(out)
    }
}

#[cfg(test)]
mod privacy_tests {
    use super::*;
    #[test]
    fn rust_install_root_and_children_are_allowed_but_legacy_and_neighbors_are_not() {
        use std::path::Path;
        // These are the actual bootstrap paths, including the two-component root
        // checked before any download. Never weaken the boundary to all Programs.
        for name in [
            "Programs/SigmaDriveRust",
            "Programs/SigmaDriveRust/versions/0.3.2",
            "Programs/SigmaDriveRust/cache-v2",
            "SigmaDriveRustCore",
            "SigmaDriveRustCore/transfers",
        ] {
            assert!(private_local_relative(Path::new(name)), "{name}");
        }
        for name in [
            "",
            "Programs",
            "Programs/OtherApp",
            "Programs/SigmaDriveRustOther",
            "Programs/SigmaDriveFlutterPilot",
            "Programs/SigmaDriveFlutterPilot/versions",
            "SigmaDriveRustCoreOther",
            "Programs/SigmaDriveRust/../OtherApp",
            "C:/Windows",
            "../SigmaDriveRustCore",
        ] {
            assert!(!private_local_relative(Path::new(name)), "{name}");
        }
    }
    #[test]
    fn owner_normalization_cannot_adopt_an_unrelated_directory() {
        // No ownership mutation is attempted outside our exact Known Folder roots.
        let unrelated = std::env::temp_dir();
        assert!(protect_own_local_directory(&unrelated).is_err());
        assert!(protect_own_local_directory(std::path::Path::new(r"C:\Windows")).is_err());
        assert!(protect_own_local_directory(std::path::Path::new("relative")).is_err());
    }
    #[test]
    fn private_directory_rejects_anonymous_windows_token() {
        use windows_sys::Win32::{
            Security::{ImpersonateAnonymousToken, RevertToSelf},
            System::Threading::GetCurrentThread,
        };
        let root = std::env::temp_dir().join(format!(
            "SigmaFlutter-private-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&root).unwrap();
        protect_directory(&root).unwrap();
        let marker = root.join("private-cloud-configuration.txt");
        std::fs::write(&marker, b"fixture only, not a real account").unwrap();
        assert!(std::fs::read(&marker).is_ok());
        let anonymous = std::thread::spawn(move || {
            if unsafe { ImpersonateAnonymousToken(GetCurrentThread()) } == 0 {
                return Err(io::Error::last_os_error());
            }
            let denied = std::fs::read(&marker).is_err();
            let reverted = unsafe { RevertToSelf() };
            if reverted == 0 {
                return Err(io::Error::last_os_error());
            }
            Ok(denied)
        })
        .join()
        .unwrap()
        .unwrap();
        assert!(
            anonymous,
            "another Windows identity accessed private cloud configuration"
        );
        std::fs::remove_dir_all(root).unwrap();
    }
}
