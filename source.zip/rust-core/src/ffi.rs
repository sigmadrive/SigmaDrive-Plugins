//! Single Flutter/core boundary; no IPC address or downstream daemon routing.
use serde::Deserialize;
use serde_json::{Value, json};
use std::ffi::{CString, c_char};
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Request {
    abi: u32,
    rpc: String,
    #[serde(default = "object")]
    body: Value,
}
fn object() -> Value {
    json!({})
}
pub fn call_json(bytes: &[u8]) -> String {
    let out = std::panic::catch_unwind(|| -> anyhow::Result<Value> {
        anyhow::ensure!(bytes.len() <= 1024 * 1024, "core request exceeds 1 MiB");
        let r: Request = serde_json::from_slice(bytes)?;
        anyhow::ensure!(
            r.abi == 2,
            "Rust core ABI 2 required; legacy bridge ABI rejected"
        );
        crate::call(&r.rpc, r.body)
    });
    match out {
        Ok(Ok(data)) => json!({"ok":true,"data":data}),
        Ok(Err(e)) => json!({"ok":false,"error":e.to_string()}),
        Err(_) => json!({"ok":false,"error":"Rust core request failed"}),
    }
    .to_string()
}
#[unsafe(no_mangle)]
pub extern "C" fn sigma_core_abi() -> u32 {
    2
}
#[unsafe(no_mangle)]
pub extern "C" fn sigma_core_can_exit() -> u32 {
    u32::from(crate::can_exit())
}
#[unsafe(no_mangle)]
pub extern "C" fn sigma_core_update_exit_ready() -> u32 {
    u32::from(crate::update_exit_ready())
}
/// Invoked before Flutter/core initialization in a separate, short-lived copy
/// of the signed app. No account state, mounts or network services are started.
#[cfg(windows)]
#[unsafe(no_mangle)]
pub extern "C" fn sigma_core_update_worker() -> u32 {
    let result = std::panic::catch_unwind(|| -> anyhow::Result<()> {
        let args = std::env::args().collect::<Vec<_>>();
        anyhow::ensure!(
            args.len() == 5 && args[1] == "--sigma-update-worker",
            "invalid update worker arguments"
        );
        let root = sigmadrive_distribution::install::root()?;
        anyhow::ensure!(
            sigmadrive_distribution::install::executable(&root)? == std::env::current_exe()?,
            "unverified update worker"
        );
        sigmadrive_distribution::install::wait_client_exit_ready(
            &root,
            args[2].parse()?,
            args[3].parse()?,
            Some(&args[4]),
        )?;
        // Failure must restore availability using the retained current pointer.
        let applied = sigmadrive_distribution::install::apply_staged(&root);
        sigmadrive_distribution::install::launch_checked(&root, false)?;
        applied?;
        Ok(())
    });
    match result {
        Ok(Ok(())) => 0,
        _ => 1,
    }
}
/// # Safety
/// ptr must reference len readable bytes. Call from a Flutter background isolate.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn sigma_core_call(ptr: *const u8, len: usize) -> *mut c_char {
    let response = if ptr.is_null() || len > 1024 * 1024 {
        json!({"ok":false,"error":"invalid core input buffer"}).to_string()
    } else {
        call_json(unsafe { std::slice::from_raw_parts(ptr, len) })
    };
    CString::new(response)
        .expect("JSON cannot contain literal NUL")
        .into_raw()
}
/// # Safety
/// Free each pointer returned by sigma_core_call exactly once; null is allowed.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn sigma_core_free(ptr: *mut c_char) {
    if !ptr.is_null() {
        drop(unsafe { CString::from_raw(ptr) });
    }
}
