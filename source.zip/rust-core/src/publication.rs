//! Background policy refresh is not part of the file request/byte path.
use crate::{
    leases,
    permit::{PublicationPolicy, PublicationVerifier},
    relay::{Failure, RelayTransport},
};
use anyhow::{Result, ensure};
use serde_json::json;
use sha2::{Digest, Sha256};
use std::{
    collections::HashSet,
    sync::{Arc, Mutex},
    time::Duration,
};
use tokio::sync::watch;

pub struct Authority {
    share: String,
    verifier: Mutex<PublicationVerifier>,
    connections: Arc<leases::Registry>,
    state: Mutex<&'static str>,
    stop: watch::Sender<bool>,
}
impl Authority {
    pub async fn ready(&self) -> Result<()> {
        let until = tokio::time::Instant::now() + Duration::from_secs(5);
        loop {
            let state = *self
                .state
                .lock()
                .map_err(|_| anyhow::anyhow!("publication state unavailable"))?;
            if state == "active" {
                return Ok(());
            }
            ensure!(
                !matches!(state, "denied" | "invalid_policy" | "stopped"),
                "publication denied"
            );
            ensure!(
                tokio::time::Instant::now() < until,
                "publication authority not ready"
            );
            tokio::time::sleep(Duration::from_millis(25)).await;
        }
    }
    /// Caller must load these pins from explicit LOCAL device approvals. Server
    /// discovery/policy never fills either local set.
    pub fn start(
        share: String,
        publisher: String,
        pin: String,
        reads: HashSet<String>,
        writes: HashSet<String>,
        transport: Arc<RelayTransport>,
        connections: Arc<leases::Registry>,
    ) -> Result<Arc<Self>> {
        let verifier = PublicationVerifier::new(share.clone(), publisher, pin, reads, writes)?;
        let (stop, mut receiver) = watch::channel(false);
        let authority = Arc::new(Self {
            share,
            verifier: Mutex::new(verifier),
            connections,
            state: Mutex::new("loading"),
            stop,
        });
        // A weak reference permits Drop to signal cancellation; no self-owning task.
        let weak = Arc::downgrade(&authority);
        tokio::spawn(async move {
            loop {
                let Some(authority) = weak.upgrade() else {
                    break;
                };
                let share = authority.share.clone();
                drop(authority);
                let body = json!({"share":share});
                let result = tokio::select! {
                    biased;
                    _=receiver.wait_for(|s|*s)=>break,
                    result=transport.s3_control("publication",&body)=>result,
                };
                let Some(authority) = weak.upgrade() else {
                    break;
                };
                let terminal = match result {
                    Ok((body, sent)) => {
                        let result = serde_json::from_value::<PublicationPolicy>(body)
                            .map_err(anyhow::Error::from)
                            .and_then(|policy| {
                                let reads = policy.approved_pins.clone();
                                let writes = policy.write_pins.clone();
                                let mut verifier = authority.verifier.lock().map_err(|_| {
                                    anyhow::anyhow!("publication state unavailable")
                                })?;
                                let version = policy.version;
                                let changed = verifier.version().is_some_and(|old| old != version);
                                verifier.update(policy, sent)?;
                                if changed {
                                    authority.connections.revoke(&authority.share, None);
                                }
                                authority.connections.apply_policy(
                                    &authority.share,
                                    &reads,
                                    &writes,
                                );
                                Ok(())
                            });
                        if result.is_err() {
                            authority.invalidate("invalid_policy");
                            true
                        } else {
                            if let Ok(mut state) = authority.state.lock() {
                                *state = "active";
                            }
                            false
                        }
                    }
                    Err(error)
                        if error.downcast_ref::<Failure>().is_some_and(|f| {
                            matches!(
                                f,
                                Failure::Denied
                                    | Failure::UpdateRequired
                                    | Failure::InvalidResponse
                            )
                        }) =>
                    {
                        authority.invalidate("denied");
                        true
                    }
                    Err(error) => {
                        // No refresh on a transport error. Existing monotonic deadlines
                        // and Registry's 250ms expiry loop remain unchanged.
                        if let Ok(mut state) = authority.state.lock() {
                            *state = if error.downcast_ref::<Failure>() == Some(&Failure::Capacity)
                            {
                                "capacity"
                            } else {
                                "offline"
                            };
                        }
                        false
                    }
                };
                drop(authority);
                if terminal {
                    break;
                }
                tokio::select! {biased;_=receiver.wait_for(|s|*s)=>break,_=tokio::time::sleep(Duration::from_secs(5))=>{}}
            }
        });
        Ok(authority)
    }
    pub fn admit(
        &self,
        token: &str,
        capability: &str,
        actual_tls_pin: &str,
        peer_node: &str,
        write: bool,
    ) -> Result<leases::Guard> {
        let until = self
            .verifier
            .lock()
            .map_err(|_| anyhow::anyhow!("publication state unavailable"))?
            .authorize(token, capability, actual_tls_pin, peer_node, write)?;
        let binding = hex::encode(Sha256::digest(token.as_bytes()));
        self.connections
            .refresh_scope(&self.share, actual_tls_pin, write, until, &binding);
        self.connections
            .begin_bound(&self.share, actual_tls_pin, until, write, &binding)
    }
    pub fn renew(
        &self,
        guard: &leases::Guard,
        token: &str,
        capability: &str,
        actual_tls_pin: &str,
        peer_node: &str,
        write: bool,
    ) -> Result<()> {
        let until = self
            .verifier
            .lock()
            .map_err(|_| anyhow::anyhow!("publication state unavailable"))?
            .authorize(token, capability, actual_tls_pin, peer_node, write)?;
        // Registry also checks that this guard is still live, preventing resurrection.
        ensure!(
            self.connections
                .scope_matches(guard, &self.share, actual_tls_pin, write)
                && self
                    .connections
                    .bound(guard, &hex::encode(Sha256::digest(token.as_bytes()))),
            "connection scope mismatch"
        );
        self.connections.refresh(guard, until)
    }
    pub fn revoke_local(&self, pin: &str) {
        if let Ok(mut verifier) = self.verifier.lock() {
            verifier.revoke_local(pin);
        }
        self.connections.revoke(&self.share, Some(pin));
    }
    fn invalidate(&self, state: &'static str) {
        if let Ok(mut verifier) = self.verifier.lock() {
            verifier.invalidate();
        }
        if let Ok(mut current) = self.state.lock() {
            *current = state;
        }
        self.connections.revoke(&self.share, None);
    }
    pub fn stop(&self) {
        self.stop.send_replace(true);
        self.invalidate("stopped");
    }
    pub fn local_status(&self) -> serde_json::Value {
        json!({"state":self.state.lock().map(|s|*s).unwrap_or("unavailable"),"active_requests":self.connections.active_for(&self.share),"resources_released":self.connections.active_for(&self.share)==0})
    }
}
impl Drop for Authority {
    fn drop(&mut self) {
        self.stop();
    }
}
