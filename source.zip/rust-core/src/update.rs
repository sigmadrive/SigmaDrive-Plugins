//! Background acquisition and safe next-launch activation. The loaded core
//! never replaces its executable/DLL, terminates a peer, or changes legacy Z.
use crate::state::Core;
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use std::{
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};
#[derive(Default)]
pub struct Updater {
    pub draining: AtomicBool,
    fetching: AtomicBool,
    apply_when_ready: AtomicBool,
    exit: AtomicBool,
    state: Mutex<Value>,
}

fn state(core: &Core) -> Value {
    let mut v = core
        .update
        .state
        .lock()
        .map(|v| v.clone())
        .unwrap_or(json!({"state":"unavailable"}));
    if !v.is_object() {
        v = json!({"state":"idle"});
    }
    v["id"] = json!("client");
    v["name"] = json!("SigmaDrive Rust + Flutter");
    v["version"] = json!(crate::VERSION);
    v["exit_requested"] = json!(core.update.exit.load(Ordering::Acquire));
    v
}
pub fn exit_requested(core: &Core) -> bool {
    core.update.exit.load(Ordering::Acquire)
}
fn checking_state() -> Value {
    json!({"state":"checking","stage":"checking","message":"서명된 업데이트 정보를 확인하고 있습니다."})
}
fn merge_status(state: &mut Value, patch: Value) {
    if !state.is_object() { *state = json!({}); }
    if let Some(fields) = patch.as_object() {
        for (key, value) in fields { state[key] = value.clone(); }
    }
}
#[cfg(windows)]
fn progress_status(state: &mut Value, p: &sigmadrive_distribution::download::Progress) {
    merge_status(state, json!({"state":"downloading","progress":p.percent,
        "stage":p.stage,"message":p.message,"received_bytes":p.received_bytes,
        "reused_chunks":p.reused_chunks,"downloaded_chunks":p.downloaded_chunks,"total_chunks":p.total_chunks}));
}
#[cfg(windows)]
fn managed() -> Result<std::path::PathBuf> {
    let root = sigmadrive_distribution::install::root()?;
    ensure!(
        sigmadrive_distribution::install::executable(&root)? == std::env::current_exe()?,
        "automatic update requires a verified Rust installation"
    );
    Ok(root)
}
pub fn start(core: Arc<Core>) {
    let manual = core.clone();
    tokio::spawn(async move {
        loop {
            if manual.update.apply_when_ready.load(Ordering::Acquire)
                && state(&manual)["state"] == "ready"
            {
                manual
                    .update
                    .apply_when_ready
                    .store(false, Ordering::Release);
                if let Err(e) = manage(manual.clone(), json!({"action":"apply"})).await
                    && let Ok(mut s) = manual.update.state.lock()
                {
                    s["error"] = json!(e.to_string());
                }
            }
            tokio::time::sleep(Duration::from_secs(2)).await;
        }
    });
    tokio::spawn(async move {
        tokio::time::sleep(Duration::from_secs(30)).await;
        loop {
            let _ = fetch(core.clone());
            tokio::time::sleep(Duration::from_secs(6 * 3600)).await;
        }
    });
}
fn fetch(core: Arc<Core>) -> Result<()> {
    #[cfg(not(windows))]
    {
        let _ = core;
        anyhow::bail!("Rust updater is not yet implemented on this OS");
    }
    #[cfg(windows)]
    {
        let root = managed()?;
        ensure!(
            !core.update.draining.load(Ordering::Acquire),
            "safe restart is preparing"
        );
        if core.update.fetching.swap(true, Ordering::AcqRel) {
            return Ok(());
        }
        let updater = core.update.clone();
        if let Ok(mut s) = updater.state.lock() {
            *s = checking_state();
        }
        std::thread::spawn(move || {
            let result = (|| -> Result<Value> {
                let cancel = AtomicBool::new(false);
                let catalog = sigmadrive_distribution::download::catalog_selection(&cancel)
                    .map_err(anyhow::Error::msg)?;
                if let Ok(mut state) = updater.state.lock() {
                    merge_status(&mut state, json!({"latest_version":catalog.release.version,
                        "catalog_source":catalog.source,"catalog_sequence":catalog.release.sequence}));
                }
                let result = sigmadrive_distribution::install::prepare_with_progress(
                    &root,
                    &catalog.raw,
                    &cancel,
                    &mut |p| {
                        if let Ok(mut state) = updater.state.lock() {
                            progress_status(&mut state, p);
                        }
                    },
                )?;
                Ok(result)
            })();
            if result.as_ref().is_err() || result.as_ref().is_ok_and(|v| v["state"] != "ready") {
                updater.apply_when_ready.store(false, Ordering::Release);
            }
            if let Ok(mut s) = updater.state.lock() {
                match result {
                    Ok(v) => {
                        if v["state"] == "up_to_date" {
                            merge_status(&mut s, json!({"stage":"up_to_date","message":"현재 실행 버전이 최신 버전입니다."}));
                        }
                        merge_status(&mut s, v);
                    },
                    Err(e) => merge_status(&mut s,
                        json!({"state":"failed","error":e.to_string(),"message":"업데이트 준비에 실패하여 현재 버전을 유지합니다.","current_version_preserved":true})),
                }
            }
            updater.fetching.store(false, Ordering::Release);
        });
        Ok(())
    }
}
pub async fn manage(core: Arc<Core>, body: Value) -> Result<Value> {
    match body["action"].as_str().unwrap_or("status") {
        "status" => {
            let v = state(&core);
            Ok(json!({"packages":[v],"state":v["state"],"exit_requested":v["exit_requested"]}))
        }
        "check" | "start" | "download" | "check_apply" => {
            core.update
                .apply_when_ready
                .store(body["action"] == "check_apply", Ordering::Release);
            if let Err(e) = fetch(core.clone()) {
                core.update.apply_when_ready.store(false, Ordering::Release);
                return Err(e);
            }
            Ok(json!({"state":"checking"}))
        }
        "install" | "apply" | "restart" => {
            #[cfg(not(windows))]
            anyhow::bail!("Rust updater unavailable on this OS");
            #[cfg(windows)]
            {
                let root = managed()?;
                ensure!(
                    root.join("staged.json").is_file(),
                    "no verified update is ready"
                );
                ensure!(
                    core.flows.lock().await.is_empty(),
                    "finish or cancel active sign-in first"
                );
                ensure!(
                    !core.update.draining.swap(true, Ordering::AcqRel),
                    "safe restart is already preparing"
                );
                if let Ok(p) = core.publisher.lock()
                    && let Some(p) = p.as_ref()
                {
                    p.drain();
                }
                let task = core.clone();
                let prepared = state(&core);
                tokio::spawn(async move {
                    let result = prepare_restart(task.clone(), root).await;
                    if let Err(e) = result {
                        task.update.draining.store(false, Ordering::Release);
                        if let Ok(mut s) = task.update.state.lock() {
                            *s = prepared;
                            s["state"] = json!("ready");
                            s["error"] = json!(e.to_string());
                            s["current_version_preserved"] = json!(true);
                        }
                        crate::sharing::stop_publications(&task);
                    }
                });
                if let Ok(mut s) = core.update.state.lock() {
                    merge_status(&mut s, json!({"state":"waiting_for_checkpoint","stage":"waiting_for_checkpoint","message":"전송 체크포인트와 수신 요청 종료를 기다린 뒤 재시작합니다."}));
                }
                Ok(json!({"state":"waiting_for_checkpoint"}))
            }
        }
        _ => anyhow::bail!("unsupported update action"),
    }
}
#[cfg(windows)]
async fn prepare_restart(core: Arc<Core>, root: std::path::PathBuf) -> Result<()> {
    core.desk.clear_http();
    core.desk.stop_all();
    let jobs = core
        .data
        .read()
        .await
        .jobs
        .values()
        .filter(|j| {
            matches!(
                j["state"].as_str(),
                Some("running" | "queued" | "uploading" | "downloading" | "waiting_for_connection")
            )
        })
        .filter_map(|j| j["id"].as_str().map(str::to_owned))
        .collect::<Vec<_>>();
    // Admission barrier: pre-drain Dokany opens have registered their handles;
    // subsequent opens observe draining and cannot create new dirty records.
    {
        let _barrier = core
            .mount_admission
            .lock()
            .map_err(|_| anyhow::anyhow!("mount admission unavailable"))?;
    }
    let mut unmounted = Vec::<String>::new();
    let result = async {
        for id in &jobs {
            crate::jobs::manage(
                core.clone(),
                json!({"action":"pause","id":id,"_update_drain":true}),
            )
            .await?;
        }
        let deadline = tokio::time::Instant::now() + Duration::from_secs(120);
        loop {
            ensure!(
                tokio::time::Instant::now() < deadline,
                "safe restart deferred; an active transfer has not reached a checkpoint"
            );
            if core.transfers.lock().is_ok_and(|t| t.is_empty())
                && core.leases.active() == 0
                && core.mount_handles.load(Ordering::Acquire) == 0
                && core.desk.idle()
            {
                break;
            }
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
        crate::sharing::stop_publications(&core);
        let drives = core
            .mounts
            .lock()
            .map_err(|_| anyhow::anyhow!("mount state failed"))?
            .keys()
            .cloned()
            .collect::<Vec<_>>();
        for id in &drives {
            ensure!(
                crate::storage::pending_disk(&core, id).await? == 0,
                "update deferred: drive has unsaved content"
            );
        }
        for id in drives {
            crate::storage::unmount(core.clone(), &id, true).await?;
            unmounted.push(id);
        }
        restore_update_jobs(&core, &jobs).await?;
        use std::os::windows::process::CommandExt;
        // Use the signed current app in worker mode, so updater fixes travel
        // with the package instead of being pinned to the first bootstrap.
        let helper = sigmadrive_distribution::install::executable(&root)?;
        let token = sigmadrive_distribution::install::process_stamp(std::process::id())?;
        let ready_token = uuid::Uuid::new_v4().simple().to_string();
        let ready = sigmadrive_distribution::install::handoff_path(&root, &ready_token)?;
        std::fs::create_dir_all(ready.parent().unwrap())?;
        let mut child = std::process::Command::new(helper)
            .arg("--sigma-update-worker")
            .arg(std::process::id().to_string())
            .arg(token.to_string())
            .arg(&ready_token)
            .creation_flags(0x08000000)
            .spawn()?;
        // The worker verifies the complete signed file inventory before its
        // acknowledgement. First-use scanning can exceed 30 seconds; keep the
        // current app alive throughout this bounded wait.
        let deadline = tokio::time::Instant::now() + Duration::from_secs(120);
        loop {
            if ready.is_file() {
                let ack: Value = serde_json::from_slice(&std::fs::read(&ready)?)?;
                ensure!(
                    ack["pid"] == std::process::id() && ack["creation"] == token,
                    "update handoff identity mismatch"
                );
                let _ = std::fs::remove_file(&ready);
                break;
            }
            ensure!(
                child.try_wait()?.is_none(),
                "update worker failed before acquiring app handle"
            );
            ensure!(
                tokio::time::Instant::now() < deadline,
                "업데이트 작업 준비가 지연되어 현재 앱을 유지합니다. 잠시 후 다시 시도하거나 작업을 마친 뒤 앱을 종료하고 다시 실행하세요."
            );
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
        core.update.exit.store(true, Ordering::Release);
        if let Ok(mut s) = core.update.state.lock() {
            merge_status(&mut s, json!({"state":"restart_ready","stage":"restart_ready","exit_requested":true,"message":"검증된 업데이트를 적용하기 위해 재시작합니다."}));
        }
        Ok(())
    }
    .await;
    if result.is_err() {
        core.update.draining.store(false, Ordering::Release);
        // Restore only our own temporary changes. An explicit user pause or
        // cancellation always wins over the update checkpoint intent.
        let _ = restore_update_jobs(&core, &jobs).await;
        for id in unmounted {
            let _ = crate::storage::mount(core.clone(), &id).await;
        }
    }
    result
}
#[cfg(windows)]
async fn restore_update_jobs(core: &Core, jobs: &[String]) -> Result<()> {
    let _control = core.job_control.lock().await;
    for id in jobs {
        if core.data.read().await.jobs.get(id).is_some_and(|j| {
            j["state"] == "paused"
                && j["requested_state"] == "paused"
                && j["pause_reason"] == "update"
        }) {
            crate::jobs::patch(core,id,json!({"state":"queued","requested_state":"running","resume_on_restart":true,"pause_reason":null,"reason":"safe_update_checkpoint"})).await?;
        }
    }
    Ok(())
}
pub fn acknowledge() -> Result<Value> {
    #[cfg(windows)]
    if let Some(token) = std::env::var_os("SIGMA_RUST_READY_TOKEN") {
        let token = token.to_string_lossy();
        ensure!(
            token.len() == 32 && token.bytes().all(|b| b.is_ascii_hexdigit()),
            "invalid launch readiness token"
        );
        let root = sigmadrive_distribution::install::root()?;
        let directory = root.join("health");
        std::fs::create_dir_all(&directory)?;
        sigmadrive_distribution::install::atomic(
            &directory.join(format!("{token}.json")),
            &serde_json::to_vec(
                &json!({"token":token,"pid":std::process::id(),"version":crate::VERSION,"ui_ready":true}),
            )?,
        )?;
    }
    Ok(json!({"ready":true}))
}

#[cfg(test)]
mod progress_tests {
    use super::*;
    #[test]
    fn a_new_attempt_has_unknown_target_and_counters_instead_of_stale_results() {
        let previous = json!({"state":"failed","latest_version":"0.3.17","received_bytes":99,"error":"old failure"});
        let next = checking_state();
        assert_ne!(previous, next);
        for key in ["latest_version", "received_bytes", "reused_chunks", "downloaded_chunks", "error"] {
            assert!(next.get(key).is_none(), "{key} must remain unknown until observed");
        }
        assert_eq!(next["state"], "checking");
    }
    #[cfg(windows)]
    #[test]
    fn target_and_actual_counters_survive_every_preparation_stage() {
        let mut state = checking_state();
        merge_status(&mut state, json!({"latest_version":"0.3.18","catalog_sequence":19,"catalog_source":"cdn.jsdelivr.net"}));
        let mut p = sigmadrive_distribution::download::Progress { percent: 1, stage: "chunks", message: "synthetic",
            received_bytes: 13_297_729, reused_chunks: 92, downloaded_chunks: 79, total_chunks: 172 };
        progress_status(&mut state, &p);
        assert_eq!(state["downloaded_chunks"], 79);
        p.downloaded_chunks = 80;
        for stage in ["chunks", "package_verify", "extract", "candidate_verify", "stage_publish", "seed_save", "ready"] {
            p.stage = stage;
            progress_status(&mut state, &p);
            assert_eq!(state["latest_version"], "0.3.18");
            assert_eq!(state["catalog_sequence"], 19);
            assert_eq!(state["catalog_source"], "cdn.jsdelivr.net");
            assert_eq!(state["received_bytes"], 13_297_729);
            assert_eq!(state["reused_chunks"], 92);
            assert_eq!(state["downloaded_chunks"], 80);
            assert_eq!(state["stage"], stage);
        }
    }
    #[test]
    fn failure_ready_and_restart_keep_the_same_attempt_metadata() {
        for transition in ["failed", "ready", "waiting_for_checkpoint", "restart_ready"] {
            let mut state = json!({"latest_version":"0.3.18","catalog_sequence":19,"received_bytes":13_297_729,
                "reused_chunks":92,"downloaded_chunks":80,"stage":"candidate_verify"});
            merge_status(&mut state, json!({"state":transition}));
            assert_eq!(state["state"], transition);
            assert_eq!(state["latest_version"], "0.3.18");
            assert_eq!(state["catalog_sequence"], 19);
            assert_eq!(state["received_bytes"], 13_297_729);
            assert_eq!(state["reused_chunks"], 92);
            assert_eq!(state["downloaded_chunks"], 80);
        }
    }
}
