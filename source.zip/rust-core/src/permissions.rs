//! Explicit local peer trust is persisted separately from server discovery.
use crate::state::Core;
use anyhow::{Result, ensure};
use serde_json::{Value, json};

pub async fn decision(core: &Core, body: &Value) -> Result<Value> {
    let _decision = core.permission_control.lock().await;
    let action = body["action"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("decision action required"))?;
    let request = body["access_request_id"]
        .as_str()
        .filter(|s| !s.is_empty())
        .ok_or_else(|| anyhow::anyhow!("access request ID required"))?;
    ensure!(request.len() <= 128, "invalid access request ID");
    if action == "revoke-access" {
        // Local cancellation precedes any possibly delayed network call.
        let mut data = core.data.write().await;
        let mut next = data.clone();
        let approval = next
            .peer_approvals
            .get_mut(request)
            .ok_or_else(|| anyhow::anyhow!("local device approval is not registered"))?;
        let share = approval["share"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("approval share missing"))?
            .to_owned();
        let pin = approval["peer_pin"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("approval fingerprint missing"))?
            .to_owned();
        approval["active"] = json!(false);
        approval["state"] = json!("revoked_pending_server");
        core.leases.block_local(&share, &pin)?;
        let saved = core.persist(&next);
        *data = next;
        drop(data);
        saved?;
        let result = crate::authority::call(
            core,
            "POST",
            "/v1/access-requests/decision",
            Some(json!({"id":request,"status":"revoked","peer_pin":pin})),
        )
        .await?;
        mark(core, request, false, "revoked").await?;
        return Ok(result);
    }
    ensure!(
        matches!(action, "approve-access" | "reject-access"),
        "invalid access decision"
    );
    let available = crate::authority::call(core, "GET", "/v1/access-requests", None).await?;
    let rows = available
        .as_array()
        .or_else(|| available["requests"].as_array())
        .ok_or_else(|| anyhow::anyhow!("invalid access request list"))?;
    let target = rows
        .iter()
        .find(|r| r["id"] == request)
        .ok_or_else(|| anyhow::anyhow!("access request not visible to this device"))?;
    let node = core.data.read().await.node.clone();
    ensure!(
        target["publisher"] == node && target["status"] == "pending",
        "only the publisher can decide a pending request"
    );
    let pin = body["peer_pin"].as_str().unwrap_or("");
    if action == "approve-access" {
        ensure!(
            body["peer_verified"] == true
                && crate::permit::valid_pin(pin)
                && body["peer_node"] == target["subscriber"],
            "confirm the exact recipient node and fingerprint first"
        );
        ensure!(
            target["share"].as_str().is_some_and(|s| !s.is_empty()),
            "request share missing"
        );
        let mut data = core.data.write().await;
        let mut next = data.clone();
        next.peer_approvals.insert(request.into(),json!({"share":target["share"],"peer_node":target["subscriber"],"peer_pin":pin,"active":false,"state":"pending_server","role":"publisher","write_approved":body["write_approved"]==true}));
        core.persist(&next)?;
        *data = next;
    }
    let result=crate::authority::call(core,"POST","/v1/access-requests/decision",Some(json!({"id":request,"status":if action=="approve-access"{"approved"}else{"rejected"},"peer_pin":pin}))).await?;
    if action == "approve-access" {
        mark(core, request, true, "approved").await?;
        core.leases
            .allow_local(target["share"].as_str().unwrap(), pin)?;
    }
    Ok(result)
}
async fn mark(core: &Core, id: &str, active: bool, state: &str) -> Result<()> {
    let mut data = core.data.write().await;
    let mut next = data.clone();
    let record = next
        .peer_approvals
        .get_mut(id)
        .ok_or_else(|| anyhow::anyhow!("local approval no longer exists"))?;
    record["active"] = json!(active);
    record["state"] = json!(state);
    core.persist(&next)?;
    *data = next;
    Ok(())
}

/// Retry a durable local revocation after control-plane recovery. No grant is
/// enabled locally while this notification is pending.
pub async fn flush_revocations(core: &Core) -> Result<()> {
    let Ok(_decision) = core.permission_control.try_lock() else {
        return Ok(());
    };
    let pending = core
        .data
        .read()
        .await
        .peer_approvals
        .iter()
        .filter(|(_, a)| a["state"] == "revoked_pending_server")
        .map(|(id, a)| (id.clone(), a["peer_pin"].clone()))
        .collect::<Vec<_>>();
    for (id, pin) in pending {
        crate::authority::call(
            core,
            "POST",
            "/v1/access-requests/decision",
            Some(json!({"id":id,"status":"revoked","peer_pin":pin})),
        )
        .await?;
        mark(core, &id, false, "revoked").await?;
    }
    Ok(())
}
