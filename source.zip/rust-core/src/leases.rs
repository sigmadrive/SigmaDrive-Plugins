//! PC-local connection lifetime. A revoked/expired lease cancels its owner task;
//! resources are counted released only after that task drops its guard.
use anyhow::{Result, ensure};
use std::{
    collections::{HashMap, HashSet},
    sync::{
        Arc, Mutex, Weak,
        atomic::{AtomicU64, Ordering},
    },
    time::Instant,
};
use tokio::sync::watch;

struct Entry {
    binding: String,
    share: String,
    pin: String,
    write: bool,
    until: Instant,
    signal: watch::Sender<bool>,
}
#[derive(Default)]
pub struct Registry {
    entries: Mutex<HashMap<u64, Entry>>,
    blocked: Mutex<HashSet<(String, String)>>,
    next: AtomicU64,
}
pub struct Guard {
    id: u64,
    registry: Weak<Registry>,
    pub cancel: watch::Receiver<bool>,
}
impl Guard {
    pub fn live(&self) -> bool {
        self.registry.upgrade().is_some_and(|r| {
            r.entries.lock().is_ok_and(|e| {
                e.get(&self.id)
                    .is_some_and(|e| e.until > Instant::now() && !*e.signal.borrow())
            })
        })
    }
}
impl Drop for Guard {
    fn drop(&mut self) {
        if let Some(registry) = self.registry.upgrade()
            && let Ok(mut entries) = registry.entries.lock()
        {
            entries.remove(&self.id);
        }
    }
}
impl Registry {
    /// A newly verified proof refreshes only its exact permission scope. A read
    /// proof must never extend an active write request.
    pub fn refresh_scope(
        &self,
        share: &str,
        pin: &str,
        write: bool,
        until: Instant,
        binding: &str,
    ) {
        if let Ok(mut entries) = self.entries.lock() {
            for e in entries.values_mut() {
                if e.share == share
                    && e.pin == pin
                    && e.write == write
                    && e.binding == binding
                    && !*e.signal.borrow()
                    && e.until > Instant::now()
                {
                    e.until = until;
                }
            }
        }
    }
    pub fn scope_matches(&self, guard: &Guard, share: &str, pin: &str, write: bool) -> bool {
        guard
            .registry
            .upgrade()
            .is_some_and(|r| std::ptr::eq(r.as_ref(), self))
            && self.entries.lock().is_ok_and(|entries| {
                entries
                    .get(&guard.id)
                    .is_some_and(|e| e.share == share && e.pin == pin && e.write == write)
            })
    }
    pub fn begin(
        self: &Arc<Self>,
        share: &str,
        pin: &str,
        until: Instant,
        write: bool,
    ) -> Result<Guard> {
        self.begin_bound(share, pin, until, write, "")
    }
    pub fn bound(&self, guard: &Guard, binding: &str) -> bool {
        self.entries
            .lock()
            .is_ok_and(|e| e.get(&guard.id).is_some_and(|e| e.binding == binding))
    }
    pub fn begin_bound(
        self: &Arc<Self>,
        share: &str,
        pin: &str,
        until: Instant,
        write: bool,
        binding: &str,
    ) -> Result<Guard> {
        let blocked = self
            .blocked
            .lock()
            .map_err(|_| anyhow::anyhow!("local revocation registry unavailable"))?;
        ensure!(
            !blocked.contains(&(share.to_owned(), pin.to_owned())),
            "peer locally revoked"
        );
        ensure!(
            !share.is_empty() && crate::permit::valid_pin(pin) && until > Instant::now(),
            "valid peer authorization lease required"
        );
        let mut entries = self
            .entries
            .lock()
            .map_err(|_| anyhow::anyhow!("connection registry unavailable"))?;
        ensure!(entries.len() < 64, "peer connection capacity exceeded");
        let id = self.next.fetch_add(1, Ordering::Relaxed);
        let (signal, cancel) = watch::channel(false);
        entries.insert(
            id,
            Entry {
                binding: binding.into(),
                share: share.into(),
                pin: pin.into(),
                write,
                until,
                signal,
            },
        );
        drop(blocked);
        Ok(Guard {
            id,
            registry: Arc::downgrade(self),
            cancel,
        })
    }
    pub fn refresh(&self, guard: &Guard, until: Instant) -> Result<()> {
        ensure!(
            guard
                .registry
                .upgrade()
                .is_some_and(|r| std::ptr::eq(r.as_ref(), self)),
            "connection belongs to another registry"
        );
        let mut entries = self
            .entries
            .lock()
            .map_err(|_| anyhow::anyhow!("connection registry unavailable"))?;
        let entry = entries
            .get_mut(&guard.id)
            .ok_or_else(|| anyhow::anyhow!("connection already released"))?;
        ensure!(
            !*entry.signal.borrow() && entry.until > Instant::now() && until > Instant::now(),
            "revoked/expired connection cannot be resurrected"
        );
        entry.until = until;
        Ok(())
    }
    pub fn revoke(&self, share: &str, pin: Option<&str>) {
        if let Ok(mut entries) = self.entries.lock() {
            for entry in entries.values_mut() {
                if entry.share == share && pin.is_none_or(|p| p == entry.pin) {
                    entry.until = Instant::now();
                    entry.signal.send_replace(true);
                }
            }
        }
    }
    pub fn block_local(&self, share: &str, pin: &str) -> Result<()> {
        let mut blocked = self
            .blocked
            .lock()
            .map_err(|_| anyhow::anyhow!("local revocation registry unavailable"))?;
        blocked.insert((share.into(), pin.into()));
        self.revoke(share, Some(pin));
        Ok(())
    }
    pub fn allow_local(&self, share: &str, pin: &str) -> Result<()> {
        self.blocked
            .lock()
            .map_err(|_| anyhow::anyhow!("local revocation registry unavailable"))?
            .remove(&(share.into(), pin.into()));
        Ok(())
    }
    pub fn expire(&self) {
        if let Ok(mut entries) = self.entries.lock() {
            for entry in entries.values_mut() {
                if entry.until <= Instant::now() {
                    entry.signal.send_replace(true);
                }
            }
        }
    }
    pub fn apply_policy(&self, share: &str, reads: &[String], writes: &[String]) {
        if let Ok(mut entries) = self.entries.lock() {
            for entry in entries.values_mut() {
                if entry.share == share
                    && (!reads.contains(&entry.pin)
                        || (entry.write && !writes.contains(&entry.pin)))
                {
                    entry.until = Instant::now();
                    entry.signal.send_replace(true);
                }
            }
        }
    }
    pub fn active(&self) -> usize {
        self.entries.lock().map(|e| e.len()).unwrap_or(usize::MAX)
    }
    pub fn active_for(&self, share: &str) -> usize {
        self.entries
            .lock()
            .map(|e| e.values().filter(|e| e.share == share).count())
            .unwrap_or(usize::MAX)
    }
}
/// The caller's entire socket/HTTP/file future is owned by `operation`. Cancellation
/// drops it before this function returns and before Guard releases the active count.
pub async fn run<T>(
    mut guard: Guard,
    operation: impl std::future::Future<Output = Result<T>>,
) -> Result<T> {
    ensure!(!*guard.cancel.borrow(), "connection authorization revoked");
    tokio::pin!(operation);
    tokio::select! {
        biased;
        _=guard.cancel.wait_for(|revoked|*revoked)=>Err(anyhow::anyhow!("connection authorization revoked or expired")),
        result=&mut operation=>result,
    }
}

#[cfg(test)]
mod scoped_tests {
    use super::*;
    use std::time::Duration;
    #[test]
    fn read_or_different_token_cannot_extend_write_authority() {
        let registry = Arc::new(Registry::default());
        let expires = Instant::now() + Duration::from_secs(30);
        let guard = registry
            .begin_bound("share-a", &"a".repeat(64), expires, true, "token-a")
            .unwrap();
        registry.refresh_scope(
            "share-a",
            &"a".repeat(64),
            false,
            Instant::now() + Duration::from_secs(60),
            "token-a",
        );
        registry.refresh_scope(
            "share-a",
            &"a".repeat(64),
            true,
            Instant::now() + Duration::from_secs(60),
            "token-b",
        );
        assert_eq!(
            registry
                .entries
                .lock()
                .unwrap()
                .get(&guard.id)
                .unwrap()
                .until,
            expires
        );
        registry
            .entries
            .lock()
            .unwrap()
            .get_mut(&guard.id)
            .unwrap()
            .until = Instant::now();
        assert!(!guard.live());
        assert_eq!(registry.active(), 1);
        drop(guard);
        assert_eq!(registry.active(), 0);
    }
    #[test]
    fn revocation_does_not_cross_a_share_boundary() {
        let registry = Arc::new(Registry::default());
        let until = Instant::now() + Duration::from_secs(60);
        let a = registry
            .begin_bound("share-a", &"b".repeat(64), until, false, "a")
            .unwrap();
        let b = registry
            .begin_bound("share-b", &"b".repeat(64), until, false, "b")
            .unwrap();
        registry.block_local("share-a", &"b".repeat(64)).unwrap();
        assert!(!a.live());
        assert!(b.live());
        assert_eq!(registry.active(), 2);
        assert!(
            registry
                .begin_bound("share-a", &"b".repeat(64), until, false, "fresh-token")
                .is_err()
        );
        drop(a);
        drop(b);
        assert_eq!(registry.active(), 0);
    }
}
