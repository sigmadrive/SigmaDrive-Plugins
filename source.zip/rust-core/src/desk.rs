//! Flutter calls this Rust controller directly. The authority only sees device,
//! consent and lease state; native media/input stays in the isolated Rust engine.
#[cfg(windows)]
use crate::desk_windows::Engine;
use crate::{
    desk_lease::{self, Lease},
    state::{Core, now},
};
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use std::{
    collections::{HashMap, VecDeque},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering},
    },
    time::{Duration, Instant},
};

#[derive(Default)]
pub struct Runtime {
    #[cfg(windows)]
    pub(crate) assets: crate::desk_windows::AssetCache,
    ready: AtomicBool,
    component_view: Mutex<Value>,
    view: Mutex<Value>,
    active: Mutex<HashMap<String, Active>>,
    ended: Mutex<crate::desk_retirement::Ledger>,
    terminal_receipts: AtomicBool,
    epoch: AtomicU64,
    poll: tokio::sync::Mutex<()>,
    wake: Arc<tokio::sync::Notify>,
    readiness_capability: Mutex<crate::desk_readiness::Capability>,
    notification: Mutex<Option<crate::desk_notify::Ticket>>,
    notification_changed: tokio::sync::Notify,
    notification_stop: tokio::sync::Notify,
    closing: Mutex<Vec<Arc<std::sync::atomic::AtomicUsize>>>,
    diagnostics: Mutex<VecDeque<Value>>,
    #[cfg(windows)]
    transport_history: Mutex<VecDeque<(Arc<crate::desk_transport_trace::Trace>,Arc<AtomicUsize>)>>,
    starting: AtomicUsize,
    startup_cancel: Mutex<HashMap<String,StartupRecord>>,
    http: crate::desk_http::Pool,
}
struct Active {
    lease: Lease,
    role: String,
    desktop: String,
    identity: Value,
    auth_epoch: u64,
    transport_until: Instant,
    readiness: Arc<Mutex<Option<crate::desk_readiness::Binding>>>,
    streaming: Option<Arc<Mutex<crate::desk_streaming::Session>>>,
    #[cfg(windows)]
    engine: Engine,
}
#[derive(Clone)]
struct StartupBinding {
    context: crate::desk_retirement::Context,
    role: String,
    lease: crate::desk_retirement::LeaseBound,
}
struct StartupRecord {
    cancel: std::sync::Weak<AtomicBool>,
    binding: Option<StartupBinding>,
}
impl Runtime {
    pub(crate) fn clear_http(&self) {
        self.http.clear();
        self.clear_notification();
    }
    fn clear_notification(&self) {
        if let Ok(mut ticket)=self.notification.lock() {*ticket=None;}
        self.notification_stop.notify_waiters();
    }
    pub(crate) fn record(&self, event: &'static str, id: &str, role: &str,
        code: &'static str, elapsed: Duration, exit_code: Option<u32>) {
        if let Ok(mut history) = self.diagnostics.lock() {
            // Only fixed event/reason codes and bounded public session IDs enter
            // this PC-local history. Never copy an authority body or raw error.
            let row = json!({"at":now(),"event":event,
                "session":if desk_lease::valid_id(id){id}else{""},
                "role":if matches!(role,"host"|"viewer"){role}else{""},
                "code":code,"elapsed_ms":elapsed.as_millis().min(u64::MAX as u128) as u64,
                "exit_code":exit_code});
            if history.back().is_some_and(|old| old["event"]==row["event"]
                && old["session"]==row["session"] && old["code"]==row["code"]) { return; }
            if history.len() == 64 { history.pop_front(); }
            history.push_back(row);
        }
    }
    fn record_readiness(&self, id: &str, epoch: u64, lease: &Lease,
        binding: &mut crate::desk_readiness::Binding) {
        let now = Instant::now();
        let current = self.epoch.load(Ordering::Acquire) == epoch
            && lease.binding["session_id"] == id;
        for timing in binding.take_local_timings(lease, now, current) {
            self.record("registration_readiness", id, "host", timing.code.as_str(), timing.elapsed, None);
        }
    }
    pub fn stop_all(&self) {
        #[cfg(windows)]
        self.assets.clear();
        self.stop_sessions();
        // A profile/identity/consent boundary discards the previous local trace.
        #[cfg(windows)]
        if let Ok(mut history)=self.transport_history.lock(){history.clear();}
    }
    fn stop_sessions(&self) {
        if let Ok(starting)=self.startup_cancel.lock(){for c in starting.values().filter_map(|s|s.cancel.upgrade()){c.store(true,Ordering::Release);}}
        self.epoch.fetch_add(1, Ordering::AcqRel);
        self.clear_notification();
        if let Ok(mut active) = self.active.lock() {
            if let Ok(mut ended) = self.ended.lock() {
                for (id,a) in active.iter(){Self::retire_active(&mut ended,id,a); }
            }
            for a in active.values() {
                self.track_release(a);
            }
            active.clear();
        }
    }
    pub fn idle(&self) -> bool {
        #[cfg(windows)]
        if self.assets.busy() {return false;}
        self.starting.load(Ordering::Acquire) == 0
            && self.active.lock().is_ok_and(|a| a.is_empty())
            && self
                .closing
                .lock()
                .is_ok_and(|c| c.iter().all(|n| n.load(Ordering::Acquire) == 0))
    }
    fn track_release(&self, a: &Active) {
        #[cfg(windows)]
        if let Ok(mut closing) = self.closing.lock() {
            closing.retain(|n|n.load(Ordering::Acquire)>0);
            if !closing.iter().any(|n|Arc::ptr_eq(n,&a.engine.proxy.tasks)){closing.push(a.engine.proxy.tasks.clone());}
            if let Ok(mut history)=self.transport_history.lock(){
                if !history.iter().any(|(t,_)|Arc::ptr_eq(t,&a.engine.proxy.observations)){
                    if history.len()==8{history.pop_front();}
                    history.push_back((a.engine.proxy.observations.clone(),a.engine.proxy.tasks.clone()));
                }
            }
        }
        #[cfg(not(windows))]
        let _ = a;
    }
    fn track_transport_tasks(&self,tasks:&Arc<AtomicUsize>)->Result<()> {
        let mut closing=self.closing.lock().map_err(|_|anyhow::anyhow!("SigmaDesk transport release tracking unavailable"))?;
        closing.retain(|n|n.load(Ordering::Acquire)>0);
        if !closing.iter().any(|n|Arc::ptr_eq(n,tasks)){closing.push(tasks.clone());}Ok(())
    }
    #[cfg(windows)]
    pub(crate) fn track_start_proxy(&self,proxy:&crate::desk_transport::Proxy)->Result<()> {
        // Includes failures before Active publication; Proxy::drop starts an
        // asynchronous drain, whose counter must reach zero before compaction.
        self.track_transport_tasks(&proxy.tasks)
    }
    fn retire_active(ledger:&mut crate::desk_retirement::Ledger,id:&str,a:&Active){
        ledger.retire(id,crate::desk_retirement::Context::new(&a.identity,&a.desktop,a.auth_epoch).ok(),Some(&a.role),
            Some(crate::desk_retirement::LeaseBound{sequence:a.lease.sequence,expires:a.lease.expires,until:a.lease.until,browser:a.lease.browser}),Instant::now());
    }
    fn stop(&self,id:&str){self.stop_bound(id,None,None);}
    fn stop_bound(&self,id:&str,context:Option<crate::desk_retirement::Context>,role:Option<&str>){
        let starting=self.startup_cancel.lock().ok().and_then(|starts|starts.get(id).and_then(|s|{
            let cancel=s.cancel.upgrade()?;cancel.store(true,Ordering::Release);s.binding.clone()
        }));
        if let Ok(mut active)=self.active.lock() && let Some(a)=active.remove(id){
            self.track_release(&a);
            if let Ok(mut ended)=self.ended.lock(){Self::retire_active(&mut ended,id,&a);}return;
        }
        if let Ok(mut ended)=self.ended.lock(){
            if let Some(binding)=starting {
                ended.retire(id,Some(binding.context.clone()),Some(&binding.role),Some(binding.lease),Instant::now());
                ended.bind_retired(id,&binding.context,&binding.role,binding.lease,Instant::now());
            } else {ended.retire(id,context,role,None,Instant::now());}
        }
    }
    fn register_start(&self,id:&str,cancel:&Arc<AtomicBool>,binding:Option<StartupBinding>)->Result<()> {
        {
            let mut starts=self.startup_cancel.lock().map_err(|_|anyhow::anyhow!("SigmaDesk startup cancellation unavailable"))?;
            starts.retain(|_,s|s.cancel.strong_count()>0);
            ensure!(starts.len()<128&&!starts.contains_key(id),"SigmaDesk startup cancellation capacity");
            starts.insert(id.into(),StartupRecord{cancel:Arc::downgrade(cancel),binding:binding.clone()});
        }
        if let Some(binding)=binding && let Ok(mut ended)=self.ended.lock(){ended.bind_retired(id,&binding.context,&binding.role,binding.lease,Instant::now());}
        if self.retired(id)? {cancel.store(true,Ordering::Release);anyhow::bail!("SigmaDesk session ended locally during startup");}
        Ok(())
    }
    fn renew_start_binding(&self,id:&str,context:&crate::desk_retirement::Context,role:&str,lease:&Lease)->Result<()> {
        let (binding,cancelled)={
            let mut starts=self.startup_cancel.lock().map_err(|_|anyhow::anyhow!("SigmaDesk startup cancellation unavailable"))?;
            let record=starts.get_mut(id).ok_or_else(||anyhow::anyhow!("SigmaDesk startup binding missing"))?;
            let binding=record.binding.as_mut().ok_or_else(||anyhow::anyhow!("SigmaDesk startup binding unavailable"))?;
            ensure!(&binding.context==context&&binding.role==role&&binding.lease.browser==lease.browser,
                "SigmaDesk startup retirement context changed");
            ensure!(lease.sequence>binding.lease.sequence&&lease.expires>=binding.lease.expires,
                "SigmaDesk startup retirement lease rolled back");
            // A slower verified response can have a shorter conservative local
            // deadline. Keep the longest prior deadline as a cleanup floor.
            let until=if lease.expires==binding.lease.expires {binding.lease.until}
                else {lease.until.max(binding.lease.until)};
            binding.lease=crate::desk_retirement::LeaseBound{sequence:lease.sequence,expires:lease.expires,
                until,browser:lease.browser};
            (binding.clone(),record.cancel.upgrade().is_none_or(|c|c.load(Ordering::Acquire)))
        };
        // A cancellation that won the race may already have created a tombstone.
        // Advance its verified floor and invalidate any older in-flight proof.
        if let Ok(mut ended)=self.ended.lock(){ended.bind_retired(id,&binding.context,&binding.role,binding.lease,Instant::now());}
        ensure!(!cancelled,"SigmaDesk session ended locally during startup");Ok(())
    }
    fn retired(&self,id:&str)->Result<bool>{
        Ok(self.ended.lock().map_err(|_|anyhow::anyhow!("SigmaDesk session history unavailable"))?.blocked(id))
    }
    fn known_retired(&self,id:&str)->Result<bool>{
        Ok(self.ended.lock().map_err(|_|anyhow::anyhow!("SigmaDesk session history unavailable"))?.contains(id))
    }
    fn admission_blocked(&self,id:&str)->Result<bool> {
        let active=self.active.lock().map_err(|_|anyhow::anyhow!("SigmaDesk state unavailable"))?;
        let ended=self.ended.lock().map_err(|_|anyhow::anyhow!("SigmaDesk session history unavailable"))?;
        Ok(ended.admission_blocked(id,active.contains_key(id)))
    }
    fn publish_active<T>(&self,id:&str,epoch:u64,cancel:&AtomicBool,until:Instant,
        publish:impl FnOnce(&mut HashMap<String,Active>)->T)->Result<T> {
        // Use the same active -> ended lock order as stop_bound. A targeted
        // cancellation must either prevent publication or remove it afterward.
        let mut active=self.active.lock().map_err(|_|anyhow::anyhow!("SigmaDesk state unavailable"))?;
        startup_allowed_for(self,epoch,cancel,id)?;
        ensure!(until>Instant::now(),"SigmaDesk lease expired during startup");
        Ok(publish(&mut active))
    }
    pub(crate) fn snapshot(&self) -> Value {
        let mut v = self.view.lock().map(|v| v.clone()).unwrap_or(json!({}));
        if !v.is_object() {
            v = json!({});
        }
        let sessions=self.active.lock().map(|a|a.iter().map(|(id,a)|{
            #[cfg(windows)]let (processes,connections)=(a.engine.processes(),a.engine.proxy.connections.load(Ordering::Acquire));
            #[cfg(not(windows))]let (processes,connections)=(0,0);
            #[cfg(windows)]let (relay_streams,relay_opened)=(a.engine.proxy.active_relay.load(Ordering::Acquire),a.engine.proxy.relay_opened.load(Ordering::Acquire));
            #[cfg(not(windows))]let (relay_streams,relay_opened)=(0,0);
            json!({"phase":if relay_streams>0{"active"}else if relay_opened>0{"reconnecting"}else{"starting"},"session":{"session_id":id},"role":a.role,"scope":if a.lease.control{"control"}else{"view"},"processes":processes,"connections":connections,"relay_streams":relay_streams,"relay_opened":relay_opened,"resources_released":false})
        }).collect::<Vec<_>>()).unwrap_or_default();
        let closing = self
            .closing
            .lock()
            .map(|mut c| {
                c.retain(|n| n.load(Ordering::Acquire) > 0);
                c.len()
            })
            .unwrap_or(1);
        #[cfg(windows)]
        {
            let active=self.active.lock().map(|a|a.values().map(|a|a.engine.proxy.observations.snapshot()).collect::<Vec<_>>()).unwrap_or_default();
            let recent=self.transport_history.lock().map(|h|h.iter().map(|(t,n)|{let tasks=n.load(Ordering::Acquire);json!({"observations":t.snapshot(),"pending_transport_tasks":tasks,"transport_tasks_ended":tasks==0})}).collect::<Vec<_>>()).unwrap_or_default();
            v["transport_observations"]=json!({"schema":1,"storage":"pc_memory_only","identity_exported":false,"active":active,"recent":recent});
        }
        v["retirement"] = self.ended.lock().map(|h|h.summary()).unwrap_or(json!({"backpressure":true}));
        v["retirement"]["authority_supported"] = json!(self.terminal_receipts.load(Ordering::Acquire));
        v["sessions"] = json!(sessions);
        v["diagnostics"] = json!(self.diagnostics.lock().map(|h|h.iter().cloned().collect::<Vec<_>>()).unwrap_or_default());
        v["component_progress"] = self
            .component_view
            .lock()
            .map(|v| v.clone())
            .unwrap_or(Value::Null);
        let starting=self.starting.load(Ordering::Acquire);
        v["runtime"] = json!({"phase":if !sessions.is_empty(){"active"}else if starting>0{"starting"}else if closing>0{"stopping"}else{"stopped"},"processes":sessions.iter().filter_map(|s|s["processes"].as_u64()).sum::<u64>(),"resources_released":sessions.is_empty()&&closing==0&&starting==0});
        v
    }
}
fn safe_rows(v: &Value, fields: &[&str]) -> Vec<Value> {
    v.as_array()
        .into_iter()
        .flatten()
        .take(128)
        .map(|v| {
            let mut row = json!({});
            for field in fields {
                if let Some(value) = v.get(*field).filter(|value| {
                    value.is_boolean()
                        || value.is_u64()
                        || value.is_i64()
                        || value
                            .as_str()
                            .is_some_and(|s| s.len() <= 512 && !s.chars().any(char::is_control))
                }) {
                    row[*field] = value.clone();
                }
            }
            row
        })
        .collect()
}
fn tls_identity(identity: &Value) -> crate::desk_http::TlsIdentity<'_> {
    crate::desk_http::TlsIdentity {
        certificate: identity["certificate"].as_str().unwrap_or(""),
        key: identity["key"].as_str().unwrap_or(""),
        ca: identity["ca"].as_str(),
    }
}
#[cfg(windows)]
fn http_context<'a>(sid:&'a str,boundary:&'a str,current:&'a Value,auth_epoch:u64)
    ->Result<crate::desk_http::Context<'a>> {
    let required=|field:&str| current[field].as_str()
        .ok_or_else(||anyhow::anyhow!("SigmaDesk HTTP identity context unavailable"));
    Ok(crate::desk_http::Context {sid,desktop:boundary,member:required("bound_member")?,
        node:required("node")?,pin:required("pin")?,tls:tls_identity(current),
        credential:required("credential")?,control_url:required("control_url")?,
        authority_url:desk_lease::AUTHORITY,auth_epoch})
}
#[cfg(windows)]
async fn validate_http_response(core:&Core,expected:&Value,lease:&crate::desk_http::ClientLease,status:u16)->Result<()> {
    ensure!(core.desk.http.is_current(lease.ticket)
        && !core.update.draining.load(Ordering::Acquire),"SigmaDesk HTTP context changed");
    let (sid,boundary)=tokio::task::spawn_blocking(||
        Ok::<_,anyhow::Error>((crate::identity::current_sid()?,desktop()?)))
        .await.map_err(|_|anyhow::anyhow!("SigmaDesk HTTP Windows context unavailable"))??;
    // Pure lookup: an old response must not clear a newly authenticated pool.
    let (current,_)=checked_identity(core).await
        .map_err(|_|anyhow::anyhow!("SigmaDesk HTTP context changed"))?;
    ensure!(current==*expected && !core.update.draining.load(Ordering::Acquire),
        "SigmaDesk HTTP context changed");
    let context=http_context(&sid,&boundary,&current,core.auth_epoch.load(Ordering::Acquire))?;
    core.desk.http.accept_response(lease,&context,status)
}
#[cfg(windows)]
async fn request_client(core: &Core, expected_identity: &Value) -> Result<(crate::desk_http::ClientLease, u64)> {
    // Disabled presence may still report its state, but must not retain the
    // feature's pooled client. This preserves the pre-pool unpooled behavior.
    let cache_enabled = core.data.read().await.settings["sigmadesk.enabled.v1"] == true;
    if !cache_enabled { core.desk.clear_http(); }
    let ticket = core.desk.http.ticket()?;
    let auth_epoch = core.auth_epoch.load(Ordering::Acquire);
    let (sid, boundary) = tokio::task::spawn_blocking(|| {
        Ok::<_, anyhow::Error>((crate::identity::current_sid()?, desktop()?))
    }).await.map_err(|_| anyhow::anyhow!("SigmaDesk HTTP Windows context unavailable"))??;
    // Resolve from live in-memory authority state after the OS lookup; never
    // trust a cached desktop, a shadow credential file or mtime equivalence.
    let (current, _) = checked_identity(core).await?;
    ensure!(current == *expected_identity, "SigmaDesk HTTP identity changed");
    ensure!(!core.update.draining.load(Ordering::Acquire)
        && core.auth_epoch.load(Ordering::Acquire) == auth_epoch,
        "SigmaDesk HTTP context changed");
    let context = http_context(&sid,&boundary,&current,auth_epoch)?;
    let http = if cache_enabled {
        core.desk.http.client(ticket, &context)?
    } else {
        core.desk.http.uncached_client(ticket,&context)?
    };
    if !(core.desk.http.is_current(http.ticket)
        && core.auth_epoch.load(Ordering::Acquire) == auth_epoch
        && !core.update.draining.load(Ordering::Acquire)) {
        core.desk.http.clear_if_current(http.ticket);
        anyhow::bail!("SigmaDesk HTTP context changed");
    }
    Ok((http, auth_epoch))
}
#[derive(Debug)]
struct AuthorityStatus(u16);
impl std::fmt::Display for AuthorityStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "SigmaDesk authority rejected request (HTTP {})", self.0)
    }
}
impl std::error::Error for AuthorityStatus {}
struct ReadinessFailure { session: String, message: String }
impl std::fmt::Debug for ReadinessFailure {
    fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result{f.write_str(&self.message)}
}
impl std::fmt::Display for ReadinessFailure {
    fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result{f.write_str(&self.message)}
}
impl std::error::Error for ReadinessFailure {}
fn scoped_readiness(session: &str, error: anyhow::Error) -> anyhow::Error {
    if error.is::<ReadinessFailure>() || !desk_lease::valid_id(session) { return error; }
    ReadinessFailure { session: session.into(), message: error.to_string() }.into()
}
enum FailureScope<'a> { Assignment(&'a str), All, None }
fn failure_scope(error: &anyhow::Error) -> FailureScope<'_> {
    if let Some(failure)=error.downcast_ref::<ReadinessFailure>() { return FailureScope::Assignment(&failure.session); }
    let message=error.to_string();
    if message.contains("HTTP 403") || message.contains("HTTP 401") || message.contains("active member/device")
        || message.contains("SigmaDesk registration readiness") { FailureScope::All } else { FailureScope::None }
}
fn runtime_lease_live(previous: &Lease, renewed: &Lease, session: &str, now: Instant) -> Result<()> {
    if previous.until <= now || renewed.until <= now {
        return Err(scoped_readiness(session,
            anyhow::anyhow!("SigmaDesk registration readiness runtime lease expired")));
    }
    Ok(())
}
fn apply_runtime_lease(previous: &mut Lease, renewed: Lease, session: &str, now: Instant) -> Result<()> {
    runtime_lease_live(previous, &renewed, session, now)?;
    *previous = renewed;
    Ok(())
}
async fn request(core: &Core, identity: &Value, path: &str, body: Value) -> Result<(Value, Instant, i64)> {
    control_request(core, identity, path, body, false).await
}
async fn control_request(core: &Core, identity: &Value, path: &str, body: Value,
    notification: bool) -> Result<(Value, Instant, i64)> {
    ensure!(
        (notification && path == "wait") || (!notification && matches!(
            path,
            "state" | "request" | "connect" | "approve" | "reject" | "revoke" | "cancel" | "terminal-status"
        )),
        "SigmaDesk authority path denied"
    );
    if !(identity["state"] == "enrolled" && identity["control_url"] == "https://team.sigmadrive.net") {
        anyhow::bail!("registered production device required");
    }
    // Keep sent before client/context acquisition, as before. The conservative
    // signed-lease clock anchor and HTTP connect5/total8 deadlines are unchanged.
    let sent = Instant::now();
    #[cfg(windows)]
    let (lease, auth_epoch) = request_client(core, identity).await?;
    #[cfg(windows)]
    ensure!(core.desk.http.is_current(lease.ticket)
        && core.auth_epoch.load(Ordering::Acquire) == auth_epoch
        && !core.update.draining.load(Ordering::Acquire),
        "SigmaDesk HTTP context changed");
    #[cfg(windows)]
    let http = lease.client.clone();
    #[cfg(not(windows))]
    let http = crate::desk_http::build_client(&tls_identity(identity))?;
    let builder = http
        .post(format!("{}/v1/desk/{path}", desk_lease::AUTHORITY))
        .bearer_auth(
            identity["credential"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("SigmaDesk device credential missing"))?,
        )
        .json(&body);
    // Only the hint endpoint may hold a request. Ordinary state/grant requests
    // retain their original8s total/5s connect deadline and lease clock anchor.
    let builder=if notification {builder.timeout(Duration::from_secs(crate::desk_notify::HTTP_SECONDS))}
        else {builder};
    let response = builder
        .send()
        .await
        .map_err(|_| anyhow::anyhow!("SigmaDesk authority unavailable"))?;
    #[cfg(windows)]
    validate_http_response(core,identity,&lease,response.status().as_u16()).await?;
    if response.status() != 200 {
        return Err(AuthorityStatus(response.status().as_u16()).into());
    }
    let server = response
        .headers()
        .get("date")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| jiff::fmt::rfc2822::parse(v).ok())
        .map(|t| t.timestamp().as_millisecond() + 1000)
        .unwrap_or(0);
    use futures_util::StreamExt;
    let mut bytes = vec![];
    let mut stream = response.bytes_stream();
    while let Some(c) = stream.next().await {
        let c = c.map_err(|_| anyhow::anyhow!("SigmaDesk response unavailable"))?;
        ensure!(
            bytes.len() + c.len() <= if notification {1024} else if path=="terminal-status"{8192}else{1024 * 1024},
            "SigmaDesk response limit"
        );
        bytes.extend_from_slice(&c);
    }
    #[cfg(windows)]
    validate_http_response(core,identity,&lease,200).await?;
    let value = if bytes.is_empty() {
        json!({})
    } else {
        desk_lease::unique(&bytes)?
    };
    #[cfg(windows)]
    validate_http_response(core,identity,&lease,200).await?;
    Ok((value, sent, server))
}
async fn identity(core: &Core) -> Result<(Value, Value)> {
    let result = checked_identity(core).await;
    if result.is_err() { core.desk.clear_http(); }
    result
}
async fn checked_identity(core: &Core) -> Result<(Value, Value)> {
    let d = core.data.read().await;
    let i = d
        .share_identity
        .as_ref()
        .ok_or_else(|| anyhow::anyhow!("회원 로그인·개인 프로필·공유 장치 등록이 필요합니다."))?;
    ensure!(
        i["state"] == "enrolled"
            && d.member
                .as_ref()
                .is_some_and(|m| m["memberId"] == i["bound_member"]
                    && m["expiresAt"].as_u64().unwrap_or(0) > now())
            && d.online.as_ref().is_some_and(|p| p.enabled),
        "active member/device required for SigmaDesk"
    );
    Ok((
        i.clone(),
        json!({"node":i["node"],"pin":i["pin"],"member":i["bound_member"]}),
    ))
}
async fn state_request(core: &Core, identity: &Value, local: &Value, body: Value) -> Result<(Value, Instant, i64)> {
    let advertised = body["readiness_version"].as_u64() == Some(1);
    let phase = body["phase"].as_str().unwrap_or("").to_owned();
    let session = body["session"].as_str().unwrap_or("").to_owned();
    let result = request(core, identity, "state", body).await;
    if let Err(error) = &result {
        let status = error.downcast_ref::<AuthorityStatus>().map(|s| s.0);
        match crate::desk_readiness::Capability::recovery(status, advertised, &phase, &session,
            core.desk.starting.load(Ordering::Acquire) != 0) {
            crate::desk_readiness::Recovery::ReprobeIdle => {
                if let Ok(mut capability) = core.desk.readiness_capability.lock() { capability.reset(local); }
                // No retry of credentials/permissions or a live assignment. The
                // next idle poll discovers capability using the original fields.
            },
            crate::desk_readiness::Recovery::EndSession => return Err(scoped_readiness(&session,
                anyhow::anyhow!("SigmaDesk registration readiness authority protocol changed; new session required"))),
            crate::desk_readiness::Recovery::None => {},
        }
    }
    result
}
#[cfg(windows)]
fn installed() -> bool {
    crate::desk_windows::engine_files().is_ok()
}
#[cfg(not(windows))]
fn installed() -> bool {
    false
}
#[cfg(windows)]
async fn install_engine(core: Arc<Core>) -> Result<()> {
    let task = core.clone();
    tokio::task::spawn_blocking(move || {
        let _operation = crate::state::Operation::begin(task.clone());
        let result = crate::desk_assets::install(&task.update.draining, &mut |percent, message| {
            if let Ok(mut view) = task.desk.component_view.lock() {
                *view = json!({"state":"preparing","percent":percent,"message":message});
            }
        });
        task.desk.ready.store(result.is_ok(), Ordering::Release);
        if let Ok(mut view)=task.desk.component_view.lock() {
            *view=match &result {Ok(())=>json!({"state":"ready","percent":100,"message":"SigmaDesk 엔진 검증을 완료했습니다."}),Err(error)=>json!({"state":"failed","message":error.to_string()})};
        }
        result
    })
    .await??;
    core.desk.wake.notify_one();
    Ok(())
}
#[cfg(not(windows))]
async fn install_engine(_core: Arc<Core>) -> Result<()> {
    anyhow::bail!("SigmaDesk OS adapter not available")
}
pub async fn manage(core: Arc<Core>, body: Value) -> Result<Value> {
    let action = body["action"].as_str().unwrap_or("desk-status");
    if action == "component-install" {
        ensure!(body["id"] == "remote-rustdesk", "unknown Rust component");
        ensure!(
            core.desk.idle(),
            "SigmaDesk is running; end its session before updating the engine"
        );
        #[cfg(windows)]
        core.desk.assets.clear();
        install_engine(core.clone()).await?;
        ensure!(
            installed(),
            "SigmaDesk engine missing or changed; update the signed app package"
        );
        let mut d = core.data.write().await;
        let mut next = d.clone();
        next.settings["sigmadesk.installed.v1"] = json!(true);
        core.persist(&next)?;
        *d = next;
    } else if let Some(key) = match action {
        "desk-enable" | "desk-disable" => Some("sigmadesk.enabled.v1"),
        "desk-own-enable" | "desk-own-disable" => Some("sigmadesk.allow-owned.v1"),
        "desk-browser-enable" | "desk-browser-disable" => Some("sigmadesk.browser-enabled.v1"),
        _ => None,
    } {
        let enabled = action.ends_with("enable");
        if enabled {
            ensure!(
                installed() && core.data.read().await.settings["sigmadesk.installed.v1"] == true,
                "먼저 SigmaDesk 플러그인을 검증·설치하세요."
            );
        }
        let mut d = core.data.write().await;
        let mut next = d.clone();
        next.settings[key] = json!(enabled);
        core.persist(&next)?;
        *d = next;
        drop(d);
        core.desk.epoch.fetch_add(1, Ordering::AcqRel);
        #[cfg(windows)]
        core.desk.assets.clear();
        if !enabled {
            core.desk.clear_http();
            core.desk.stop_all();
        }
    } else if !matches!(action, "desk-status" | "component-status") {
        let path = action
            .strip_prefix("desk-")
            .ok_or_else(|| anyhow::anyhow!("unsupported SigmaDesk action"))?;
        let (identity, local) = identity(&core).await?;
        let id = body["id"].as_str().unwrap_or("");
        ensure!(
            !id.is_empty() && id.len() <= 128 && !id.chars().any(char::is_control),
            "SigmaDesk target required"
        );
        let payload = if matches!(path, "request" | "connect") {
            ensure!(
                core.data.read().await.settings["sigmadesk.installed.v1"] == true
                    && core.desk.ready.load(Ordering::Acquire),
                "먼저 SigmaDesk 플러그인을 검증·설치하세요."
            );
            ensure!(
                body["name"] == "view" || body["name"] == "control",
                "SigmaDesk view/control scope required"
            );
            json!({"host":id,"scope":body["name"]})
        } else {
            ensure!(desk_lease::valid_id(id), "invalid SigmaDesk session ID");
            if matches!(path, "revoke" | "cancel" | "reject") {
                let role=match path {"cancel"=>Some("viewer"),"reject"=>Some("host"),_=>None};
                let context=crate::desk_retirement::Context::new(&local,&desktop()?,core.auth_epoch.load(Ordering::Acquire)).ok();
                core.desk.stop_bound(id,context,role);
            }
            json!({"id":id})
        };
        let sent = Instant::now();
        let result = request(&core, &identity, path, payload).await;
        core.desk.record(match path {"connect"=>"connect_result","request"=>"request_result",
            "revoke"=>"revoke_result","cancel"=>"cancel_result",_=>"permission_result"},
            id,"",result.as_ref().err().map(failure_code).unwrap_or("ok"),sent.elapsed(),None);
        result?;
    }
    core.desk.wake.notify_one();
    if action == "desk-status" && core.desk.view.lock().is_ok_and(|v| v.is_null()) {
        let _ = poll(core.clone()).await;
    }
    let settings = core.data.read().await.settings.clone();
    let mut state = core.desk.snapshot();
    state["enabled"] = json!(settings["sigmadesk.enabled.v1"] == true);
    state["allow_owned"] = json!(settings["sigmadesk.allow-owned.v1"] == true);
    state["browser_enabled"] = json!(settings["sigmadesk.browser-enabled.v1"] == true);
    state["browser_compatible"] = json!(true);
    let component = component(&core).await;
    Ok(
        json!({"desk_json":serde_json::to_string(&state)?,"components":[component],"device_names":{}}),
    )
}
pub async fn component(core: &Core) -> Value {
    let installed = core.data.read().await.settings["sigmadesk.installed.v1"] == true;
    #[cfg(windows)]
    let bytes = crate::desk_windows::engine_bytes();
    #[cfg(not(windows))]
    let bytes = 0;
    #[cfg(windows)]
    let version = crate::desk_assets::version().unwrap_or("unknown");
    #[cfg(not(windows))]
    let version = "unknown";
    let progress = core
        .desk
        .component_view
        .lock()
        .map(|v| v.clone())
        .unwrap_or(Value::Null);
    #[cfg(windows)]
    let asset_failed=core.desk.assets.failed();
    #[cfg(not(windows))]
    let asset_failed=false;
    json!({"id":"remote-rustdesk","version":version,"state":if bytes==0{"unavailable"}else if installed && asset_failed{"failed"}else if installed && core.desk.ready.load(Ordering::Acquire){"installed"}else if installed{"preparing"}else{"available"},"bytes":bytes,"running":!core.desk.idle(),"repository_configured":bytes>0,"engine":"rust","go":false,"progress":progress})
}
pub fn start(core: Arc<Core>) {
    let assets = core.clone();
    crate::runtime().spawn(async move {
        if assets.data.read().await.settings["sigmadesk.installed.v1"] == true {
            let _ = install_engine(assets.clone()).await;
        }
    });
    let poll_core = core.clone();
    crate::runtime().spawn(async move{loop{let _=poll(poll_core.clone()).await;tokio::select!{_=poll_core.desk.wake.notified()=>{},_=tokio::time::sleep(Duration::from_secs(3))=>{}}}});
    let retirement_core=core.clone();
    crate::runtime().spawn(async move {loop{
        if let Err(error)=retirement_maintenance(&retirement_core).await{
            retirement_core.desk.record("retirement_maintenance","","",failure_code(&error),Duration::ZERO,None);
        }
        tokio::time::sleep(Duration::from_secs(3)).await;
    }});
    let notify_core=core.clone();
    crate::runtime().spawn(async move { notification_loop(notify_core).await; });
    #[cfg(windows)]
    {
        let prepare_core=core.clone();
        crate::runtime().spawn(async move {
            loop {
                let epoch=prepare_core.desk.epoch.load(Ordering::Acquire);
                if let Ok(context)=asset_context(&prepare_core,true).await {
                    let current=prepare_core.clone();
                    if current.desk.epoch.load(Ordering::Acquire)==epoch
                        && current.desk.assets.select(context.clone()).is_ok_and(|ready|!ready)
                        && current.desk.assets.needs_preparation(&context) {
                        let _=tokio::task::spawn_blocking(move || {
                            let started=Instant::now();
                            let result=current.desk.assets.prepare(&context,&|| {
                                ensure!(!current.update.draining.load(Ordering::Acquire)
                                    && current.desk.epoch.load(Ordering::Acquire)==epoch,
                                    "SigmaDesk asset preparation canceled");Ok(())
                            });
                            current.desk.record("engine_assets_prepared","","",
                                if result.is_ok(){"ok"}else{"failed"},started.elapsed(),None);
                            if result.is_err() && current.desk.assets.failed()
                                && let Ok(mut view)=current.desk.component_view.lock() {
                                *view=json!({"state":"failed","message":"SigmaDesk 엔진 사전 검증에 실패했습니다. 플러그인을 다시 검증·설치하세요."});
                            }
                        }).await;
                    }
                } else {prepare_core.desk.assets.clear();}
                tokio::time::sleep(Duration::from_secs(3)).await;
            }
        });
    }
    crate::runtime().spawn(async move {
        loop {
            let expected = identity(&core).await.ok().map(|(_, i)| i);
            if let Ok(mut active) = core.desk.active.lock() {
                active.retain(|id, a| {
                    #[cfg(windows)]
                    let running = a.engine.processes() > 0;
                    #[cfg(not(windows))]
                    let running = false;
                    #[cfg(windows)]
                    if a.engine.proxy.active_relay.load(Ordering::Acquire) > 0 {
                        a.transport_until = Instant::now() + Duration::from_secs(30);
                    }
                    let keep = a.lease.until > Instant::now()
                        && expected.as_ref() == Some(&a.identity)
                        && running
                        && a.transport_until > Instant::now();
                    if !keep {
                        let reason = if a.lease.until <= Instant::now() {"lease_expired"}
                            else if expected.as_ref()!=Some(&a.identity) {"identity_changed"}
                            else if !running {"engine_exited"} else {"transport_timeout"};
                        #[cfg(windows)] let exit_code=a.engine.exit_code();
                        #[cfg(not(windows))] let exit_code=None;
                        core.desk.record("watchdog_stop",id,&a.role,reason,Duration::ZERO,exit_code);
                        core.desk.track_release(a);
                        if let Ok(mut ended)=core.desk.ended.lock(){Runtime::retire_active(&mut ended,id,a);}
                    }
                    keep
                });
            }
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
    });
}
#[cfg(windows)]
async fn asset_context(core:&Core,receiving:bool)->Result<crate::desk_windows::AssetContext> {
    ensure!(!core.update.draining.load(Ordering::Acquire),"SigmaDesk update is draining");
    let (_,local)=identity(core).await?;
    let d=core.data.read().await;
    ensure!(d.settings["sigmadesk.installed.v1"]==true && core.desk.ready.load(Ordering::Acquire)
        && (!receiving || d.settings["sigmadesk.enabled.v1"]==true),"SigmaDesk assets are disabled");
    let profile=d.online.as_ref().filter(|p|p.enabled)
        .ok_or_else(||anyhow::anyhow!("SigmaDesk asset profile unavailable"))?.profile.clone();
    crate::desk_windows::AssetContext::current(&local,desktop()?,profile,core.root.clone(),
        core.auth_epoch.load(Ordering::Acquire))
}
#[cfg(windows)]
fn desktop() -> Result<String> {
    crate::desk_windows::desktop()
}
#[cfg(not(windows))]
fn desktop() -> Result<String> {
    anyhow::bail!("SigmaDesk OS adapter not available")
}
async fn poll(core: Arc<Core>) -> Result<()> {
    let _single = core.desk.poll.lock().await;
    let result = poll_inner(&core).await;
    if let Err(e) = &result {
        core.desk.clear_notification();
        core.desk.record("poll_failed","","",failure_code(e),Duration::ZERO,None);
        if let Ok(mut view) = core.desk.view.lock() {
            if !view.is_object() {
                *view = json!({});
            }
            view["error"] = json!(e.to_string());
        }
        match failure_scope(e) {
            FailureScope::Assignment(id)=>core.desk.stop(id),
            FailureScope::All=>core.desk.stop_all(), FailureScope::None=>{},
        }
    }
    result
}

async fn notification_current(core: &Core, ticket: &crate::desk_notify::Ticket) -> bool {
    if core.update.draining.load(Ordering::Acquire) || !core.desk.ready.load(Ordering::Acquire)
        || !core.desk.idle() {return false}
    let data=core.data.read().await;
    let Some(i)=data.share_identity.as_ref() else{return false};
    if data.settings["sigmadesk.enabled.v1"]!=true || data.settings["sigmadesk.installed.v1"]!=true
        || !data.online.as_ref().is_some_and(|p|p.enabled)
        || !data.member.as_ref().is_some_and(|m|m["memberId"]==i["bound_member"]
            && m["expiresAt"].as_u64().unwrap_or(0)>now()) {return false}
    let local=json!({"node":i["node"],"pin":i["pin"],"member":i["bound_member"]});
    ticket.matches(&local,core.auth_epoch.load(Ordering::Acquire),core.desk.epoch.load(Ordering::Acquire))
        && core.desk.notification.lock().is_ok_and(|current|
            current.as_ref().is_some_and(|current|current.same_cursor(ticket)))
}
async fn notification_loop(core: Arc<Core>) {
    let mut consumed:Option<crate::desk_notify::Ticket>=None;
    loop {
        // Install the listener before reading the capability, so a state update
        // between that read and the wait cannot be lost. This is local only.
        let changed=core.desk.notification_changed.notified();
        tokio::pin!(changed);changed.as_mut().enable();
        let ticket=core.desk.notification.lock().ok().and_then(|n|n.clone());
        let eligible=match &ticket {
            Some(ticket)=>!consumed.as_ref().is_some_and(|old|old.same_cursor(ticket))
                && notification_current(&core,ticket).await,
            None=>false,
        };
        if !eligible {
            tokio::select! {_=&mut changed=>{},_=tokio::time::sleep(Duration::from_secs(3))=>{}}
            continue;
        }
        let ticket=ticket.unwrap();
        let started=Instant::now();
        let result=async {
            let (identity,_)=checked_identity(&core).await?;
            let request=async {Ok(control_request(&core,&identity,"wait",ticket.body(),true).await?.0)};
            crate::desk_notify::drive(request,&ticket,&core.desk.notification_stop,
                ||notification_current(&core,&ticket)).await
        }.await;
        match result {
            Ok(crate::desk_notify::Outcome::Changed)=>{
                // A hint wakes the unchanged state/permission path exactly once.
                // Wait for that path to publish a NEW cursor before waiting again.
                consumed=Some(ticket);
                core.desk.record("notification_wait","","","changed",Duration::ZERO,None);
                core.desk.wake.notify_one();
            },
            Ok(crate::desk_notify::Outcome::Timeout)=>{
                // A misconfigured intermediary returning immediate unchanged
                // replies must not turn a bounded wait into a busy request loop.
                if started.elapsed()<Duration::from_secs(1) {
                    tokio::select! {_=core.desk.notification_stop.notified()=>{},
                        _=tokio::time::sleep(Duration::from_secs(3))=>{}}
                }
            },
            Ok(_)=>{},
            Err(error)=>{
                core.desk.record("notification_wait","","",failure_code(&error),Duration::ZERO,None);
                // Existing state polling remains the fallback and handles all
                // lease/auth failures. A failed hint can never end or grant media.
                tokio::select! {_=core.desk.notification_stop.notified()=>{},
                    _=tokio::time::sleep(Duration::from_secs(3))=>{}}
            },
        }
    }
}
async fn retirement_maintenance(core:&Arc<Core>)->Result<()> {
    if !core.desk.terminal_receipts.load(Ordering::Acquire)||!core.desk.idle(){return Ok(())}
    let (identity,local)=identity(core).await?;
    let auth_epoch=core.auth_epoch.load(Ordering::Acquire);let epoch=core.desk.epoch.load(Ordering::Acquire);
    let context=crate::desk_retirement::Context::new(&local,&desktop()?,auth_epoch)?;
    let ticket=core.desk.ended.lock().map_err(|_|anyhow::anyhow!("SigmaDesk retirement unavailable"))?.ticket(&context,Instant::now());
    let Some(ticket)=ticket else{return Ok(())};
    // Network is outside the poll lock. No media, active lease renewal or input waits on this request.
    let (response,_,clock)=request(core,&identity,"terminal-status",ticket.body()).await?;
    let proof=crate::desk_retirement::verify(&response,&ticket,clock)?;
    let Ok(_poll)=core.desk.poll.try_lock()else{return Ok(())};
    let (_,fresh)=self::identity(core).await?;
    let current=crate::desk_retirement::Context::new(&fresh,&desktop()?,core.auth_epoch.load(Ordering::Acquire))?;
    if auth_epoch!=core.auth_epoch.load(Ordering::Acquire)||epoch!=core.desk.epoch.load(Ordering::Acquire)||!core.desk.idle(){return Ok(())}
    if core.desk.ended.lock().map_err(|_|anyhow::anyhow!("SigmaDesk retirement unavailable"))?.compact(&ticket,proof,&current,Instant::now(),true){
        core.desk.epoch.fetch_add(1,Ordering::AcqRel);core.desk.clear_notification();
        core.desk.record("retirement_compacted","","","confirmed_terminal",Duration::ZERO,None);
    }
    Ok(())
}
pub(crate) fn startup_allowed(runtime: &Runtime, epoch: u64, cancel: &AtomicBool) -> Result<()> {
    ensure!(!cancel.load(Ordering::Acquire) && runtime.epoch.load(Ordering::Acquire)==epoch,
        "SigmaDesk state changed during startup");
    Ok(())
}
pub(crate) fn startup_allowed_for(runtime:&Runtime,epoch:u64,cancel:&AtomicBool,id:&str)->Result<()> {
    startup_allowed(runtime,epoch,cancel)?;
    ensure!(!runtime.known_retired(id)?,"SigmaDesk session ended locally during startup");Ok(())
}
struct StartupCancel(Arc<AtomicBool>);
impl Drop for StartupCancel {
    fn drop(&mut self) { self.0.store(true,Ordering::Release); }
}
#[cfg(windows)]
struct StartupWork(Arc<Core>);
#[cfg(windows)]
impl Drop for StartupWork {
    fn drop(&mut self) { self.0.desk.starting.fetch_sub(1,Ordering::AcqRel); }
}
// Slow filesystem/loader work must never hold up the authority presence lease.
// Revalidate once more after completion before exposing the prepared resource.
async fn complete_startup<T,S:Clone,F:std::future::Future<Output=Result<S>>>(
    mut work: tokio::task::JoinHandle<Result<T>>, period: Duration, state:&mut S,
    mut heartbeat: impl FnMut(S) -> F) -> Result<T> {
    loop {
        tokio::select! {
            result=&mut work => {
                let value=result??;
                *state=heartbeat(state.clone()).await?;
                return Ok(value);
            },
            _=tokio::time::sleep(period) => *state=heartbeat(state.clone()).await?,
        }
    }
}
fn failure_code(error: &anyhow::Error) -> &'static str {
    let message=error.to_string();
    for (needle,code) in [
        ("retirement history pending","retirement_pending"),
        ("HTTP 400","authority_400"),("HTTP 401","authority_401"),
        ("HTTP 403","authority_403"),("HTTP 409","authority_409"),
        ("authority unavailable","authority_unavailable"),
        ("lease lifetime","lease_lifetime"),("lease expired","lease_expired"),
        ("rolled back","lease_rollback"),("ended locally","session_ended_locally"),
        ("21117","relay_port_conflict"),("desktop","desktop_boundary"),
        ("hash mismatch","engine_hash"),("size mismatch","engine_size"),
        ("asset","engine_inventory"),("credential","transport_credential"),
        ("state changed during startup","startup_state_changed"),
    ] { if message.contains(needle) { return code; } }
    "operation_failed"
}
async fn poll_inner(core: &Arc<Core>) -> Result<()> {
    if core.update.draining.load(Ordering::Acquire) {
        core.desk.clear_http();
        core.desk.stop_all();
        return Ok(());
    }
    let (identity, local) = identity(core).await?;
    let epoch = core.desk.epoch.load(Ordering::Acquire);
    let notification_auth_epoch=core.auth_epoch.load(Ordering::Acquire);
    let settings = core.data.read().await.settings.clone();
    let is_installed =
        settings["sigmadesk.installed.v1"] == true && core.desk.ready.load(Ordering::Acquire);
    let enabled = is_installed && settings["sigmadesk.enabled.v1"] == true;
    let browser = enabled && settings["sigmadesk.browser-enabled.v1"] == true;
    let active = core
        .desk
        .active
        .lock()
        .map(|a| a.keys().next().cloned())
        .unwrap_or(None);
    let phase = if active.is_some() {
        "active"
    } else {
        "stopped"
    };
    let device = core.settings().await;
    let mut body=json!({"enabled":enabled,"allow_owned":enabled&&settings["sigmadesk.allow-owned.v1"]==true,"browser_enabled":browser,"browser_lease_version":1,"lease_version":2,"name":device["device_name"],"phase":phase,"session":active.unwrap_or_default()});
    if let Ok(capability)=core.desk.readiness_capability.lock(){capability.advertise(&mut body,&local);}
    #[cfg(windows)]
    {
        let active=core.desk.active.lock().map_err(|_|anyhow::anyhow!("SigmaDesk state unavailable"))?;
        if let Some(a)=active.get(body["session"].as_str().unwrap_or("")) {
            if a.role=="host" {
                ensure!(a.identity==local&&a.desktop==desktop().map_err(|_|anyhow::anyhow!("SigmaDesk registration readiness desktop unavailable"))?&&core.desk.epoch.load(Ordering::Acquire)==epoch,
                    "SigmaDesk registration readiness context changed");
                let report_id=a.lease.binding["session_id"].as_str().unwrap_or("");
                if let Some(binding)=a.readiness.lock().map_err(|_|scoped_readiness(report_id,anyhow::anyhow!("SigmaDesk registration readiness unavailable")))?.as_mut(){
                    if binding.ack_mode(){
                        let now=Instant::now();
                        let observed=a.engine.registration_observation(now).ok_or_else(||scoped_readiness(report_id,anyhow::anyhow!("SigmaDesk registration readiness observer missing")))?;
                        binding.evidence(&mut body,observed,phase,&a.lease,now).map_err(|e|scoped_readiness(report_id,e))?;
                        if let Some(streaming)=a.streaming.as_ref() {
                            streaming.lock().map_err(|_|scoped_readiness(report_id,anyhow::anyhow!("SigmaDesk streaming state unavailable")))?
                                .append(&mut body,&local,a.engine.streaming_manifest_pin(),binding,&a.lease,now)
                                .map_err(|e|scoped_readiness(report_id,e))?;
                        }
                        core.desk.record_readiness(report_id,epoch,&a.lease,binding);
                    }
                }
            }
        }
    }
    let (remote,sent,clock)=state_request(core,&identity,&local,body).await?;
    ensure!(epoch==core.desk.epoch.load(Ordering::Acquire),
        "SigmaDesk preference changed during request");
    let matches_identity = remote["self"]["node"] == local["node"]
        && remote["self"]["pin"] == local["pin"]
        && remote["self"]["member"] == local["member"];
    if !matches_identity {
        core.desk.stop_all();
    }
    ensure!(
        matches_identity,
        "SigmaDesk returned another member/device identity"
    );
    ensure!(epoch==core.desk.epoch.load(Ordering::Acquire),
        "SigmaDesk preference changed during request");
    core.desk.terminal_receipts.store(remote["terminal_receipt_version"].as_u64()==Some(1),Ordering::Release);
    if let Ok(mut capability)=core.desk.readiness_capability.lock(){capability.observe(&remote,&local);}
    if let Ok(mut notification)=core.desk.notification.lock() {
        *notification=crate::desk_notify::Ticket::observe(&remote,&local,notification_auth_epoch,epoch);
    }
    core.desk.notification_changed.notify_waiters();
    let mut view = json!({"node":local["node"],"member":local["member"],"devices":safe_rows(&remote["devices"],&["node","name","member","enabled","online","allow_owned","browser_enabled"]),"requests":safe_rows(&remote["requests"],&["id","host","peer","scope","status","host_name","peer_name","participant_kind","origin","same_member","created","expires"]),"engine":"rust","go":false});
    if !is_installed {
        view["message"] =
            json!("SigmaDesk 플러그인을 검증·설치하면 원격 접속을 사용할 수 있습니다.");
    }
    {
        let mut current_view=core.desk.view.lock()
            .map_err(|_|anyhow::anyhow!("SigmaDesk state lock failed"))?;
        ensure!(epoch==core.desk.epoch.load(Ordering::Acquire),
            "SigmaDesk preference changed during request");
        *current_view=view;
    }
    let decision = remote
        .get("browser_decision")
        .filter(|v| v.is_object())
        .or_else(|| remote.get("decision").filter(|v| v.is_object()));
    let Some(decision) = decision else {
        if let Ok(active)=core.desk.active.lock() {
            for (id,a) in active.iter() {core.desk.record("authority_stop",id,&a.role,"no_decision",Duration::ZERO,None);}
        }
        // An idle authority poll ends sessions, not consent-bound immutable
        // assets prepared for the next connection. Disable/logout/drain still
        // use stop_all and invalidate preparation immediately.
        if core.desk.active.lock().is_ok_and(|a|!a.is_empty()) {core.desk.stop_sessions();}
        return Ok(());
    };
    let browser_session = decision["binding"]["kind"] == "browser";
    let host = browser_session || decision["role"] == "host";
    ensure!(
        is_installed && (!host || enabled) && (!browser_session || browser),
        "SigmaDesk host consent is disabled"
    );
    let desktop = match desktop() {
        Ok(value) => value,
        Err(error) => {
            core.desk.stop_all();
            return Err(error);
        }
    };
    let id = decision["binding"]["session_id"]
        .as_str()
        .unwrap_or("")
        .to_owned();
    if core.desk.admission_blocked(&id)? {
        ensure!(core.desk.known_retired(&id)?,"SigmaDesk retirement history pending; retry after terminal confirmation");
        ensure!(desk_lease::valid_id(&id), "invalid SigmaDesk session ID");
        core.desk.stop(&id);
        // phase=stopped with an empty session does not retire an authority grant.
        // Explicitly retire this participant's grant; failed requests are retried
        // on the next poll without restarting the local engine.
        let result=request(core, &identity, "revoke", json!({"id":id})).await;
        core.desk.record("automatic_revoke",&id,if host{"host"}else{"viewer"},
            result.as_ref().err().map(failure_code).unwrap_or("ok"),Duration::ZERO,None);
        result?;
        anyhow::bail!("SigmaDesk session ended locally; a new approval is required");
    }
    let verification = {
        let active = core
            .desk
            .active
            .lock()
            .map_err(|_| anyhow::anyhow!("SigmaDesk state unavailable"))?;
        desk_lease::verify(
            decision,
            &local,
            &desktop,
            sent,
            clock,
            active.get(&id).map(|a| &a.lease),
        )
    };
    let mut lease = match verification {
        Ok(lease) => lease,
        Err(error) => {
            core.desk.stop_all();
            return Err(error);
        }
    };
    {
        let mut active = core
            .desk
            .active
            .lock()
            .map_err(|_| anyhow::anyhow!("SigmaDesk state unavailable"))?;
        if let Some(old) = active.get_mut(&id) {
            if old.desktop != desktop {
                drop(active);
                core.desk.stop_all();
                anyhow::bail!("SigmaDesk Windows desktop changed");
            }
            #[cfg(windows)]
            if !old.engine.proxy.matches_token(remote["transport_token"].as_str().unwrap_or("")) {
                return Err(scoped_readiness(&id,anyhow::anyhow!("SigmaDesk registration readiness transport changed")));
            }
            if host {
                // A late renewed lease must not resync metadata belonging to an
                // already expired engine, even if the watchdog awaits this lock.
                runtime_lease_live(&old.lease,&lease,&id,Instant::now())?;
                let mut readiness=old.readiness.lock().map_err(|_|scoped_readiness(&id,anyhow::anyhow!("SigmaDesk registration readiness unavailable")))?;
                if let Some(binding)=readiness.as_mut(){binding.observe(&remote,&lease,remote["transport_token"].as_str().unwrap_or("")).map_err(|e|scoped_readiness(&id,e))?;}
                else if remote["readiness_version"].as_u64()==Some(1){
                    let adopted=crate::desk_readiness::Binding::create(&remote,&lease,remote["transport_token"].as_str().unwrap_or(""),1).map_err(|e|scoped_readiness(&id,e))?;
                    if adopted.as_ref().is_some_and(|b|b.ack_mode()) { return Err(scoped_readiness(&id,anyhow::anyhow!("SigmaDesk registration readiness cannot upgrade a running session"))); }
                    *readiness=adopted;
                }
                if let Some(streaming)=old.streaming.as_ref() {
                    streaming.lock().map_err(|_|scoped_readiness(&id,anyhow::anyhow!("SigmaDesk streaming state unavailable")))?
                        .observe_verified(&remote,&local).map_err(|e|scoped_readiness(&id,e))?;
                }
            }
            apply_runtime_lease(&mut old.lease,lease,&id,Instant::now())?;
            if host {
                if let Ok(mut readiness)=old.readiness.lock() {
                    if let Some(binding)=readiness.as_mut() {
                        core.desk.record_readiness(&id,epoch,&old.lease,binding);
                    }
                }
            }
            return Ok(());
        }
        ensure!(
            active.is_empty(),
            "SigmaDesk is busy; this server uses single-session negotiation"
        );
    }
    #[cfg(windows)]
    {
        let token = remote["transport_token"].as_str().unwrap_or("").to_owned();
        let streaming=if browser_session {Some(Arc::new(Mutex::new(
            crate::desk_streaming::Session::from_verified_assignment(&remote,&local)
                .map_err(|e|scoped_readiness(&id,e))?)))}else{None};
        let proposed_registration=if host {
            let expected=if browser_session{desk_lease::rdid(&decision["binding"]["host_rdid"])?}else{desk_lease::rdid(&decision["hostRdid"])?};
            Some(Arc::new(crate::desk_registration::Registration::new(expected.into()).with_wake(core.desk.wake.clone())))
        }else{None};
        let readiness=if host{match crate::desk_readiness::Binding::create(&remote,&lease,&token,
            proposed_registration.as_ref().map(|r|r.observation(Instant::now()).generation).unwrap_or(1)){
                Ok(value)=>value,Err(error)=>{core.desk.stop(&id);return Err(scoped_readiness(&id,error));}
            }}else{None};
        let registration=if readiness.as_ref().is_some_and(|r|r.ack_mode()){proposed_registration}else{None};
        let readiness=Arc::new(Mutex::new(readiness));
        let started=Instant::now();
        let role=if host {"host"}else{"viewer"};
        core.desk.record("engine_start",&id,role,"begin",Duration::ZERO,None);
        if host {
            if let Ok(mut readiness)=readiness.lock() {
                if let Some(binding)=readiness.as_mut() {
                    core.desk.record_readiness(&id,epoch,&lease,binding);
                } else if core.desk.epoch.load(Ordering::Acquire)==epoch && lease.until>Instant::now() {
                    core.desk.record("registration_readiness",&id,"host","mode_legacy",Duration::ZERO,None);
                }
            }
        }
        let cancelled=Arc::new(AtomicBool::new(false));
        let _cancel_on_exit=StartupCancel(cancelled.clone());
        core.desk.register_start(&id,&cancelled,Some(StartupBinding{
            context:crate::desk_retirement::Context::new(&local,&desktop,notification_auth_epoch)?,role:role.into(),
            lease:crate::desk_retirement::LeaseBound{sequence:lease.sequence,expires:lease.expires,until:lease.until,browser:lease.browser},
        }))?;
        let task_core=core.clone();
        let assignment=decision.clone();
        let self_identity=remote["self"].clone();
        let task_desktop=desktop.clone();
        let asset_context=asset_context(core,false).await?;
        if host {core.desk.assets.select(asset_context.clone())?;}
        let control=lease.control;
        let worker_registration=registration.clone();
        core.desk.starting.fetch_add(1,Ordering::AcqRel);
        let work_guard=StartupWork(task_core.clone());
        let publication_cancel=cancelled.clone();
        let work=tokio::task::spawn_blocking(move || {
            let _work_guard=work_guard;
            crate::runtime().block_on(async {
                let engine=Engine::start(&assignment,&self_identity,&task_desktop,control,token,
                    &task_core.desk,epoch,&cancelled,worker_registration,asset_context).await?;
                startup_allowed_for(&task_core.desk,epoch,&cancelled,assignment["binding"]["session_id"].as_str().unwrap_or(""))?;
                Ok(engine)
            })
        });
        let local_ref=&local;
        let desktop_ref=&desktop;
        let id_ref=&id;
        let readiness_ref=&readiness;
        let registration_ref=&registration;
        let streaming_ref=&streaming;
        let result=complete_startup(work,Duration::from_secs(3),&mut lease,|old|async move {
            ensure!(core.desk.epoch.load(Ordering::Acquire)==epoch
                && !core.update.draining.load(Ordering::Acquire) && old.until>Instant::now(),
                "SigmaDesk state changed during startup");
            ensure!(started.elapsed()<Duration::from_secs(180),"SigmaDesk engine startup timeout");
            let (current_identity,current_local)=self::identity(core).await?;
            ensure!(current_local==*local_ref,"SigmaDesk startup identity changed");
            let prefs=core.data.read().await.settings.clone();
            ensure!(prefs["sigmadesk.installed.v1"]==true
                && (!host || prefs["sigmadesk.enabled.v1"]==true)
                && (!browser_session || prefs["sigmadesk.browser-enabled.v1"]==true),
                "SigmaDesk host consent is disabled");
            let device=core.settings().await;
            let enabled=prefs["sigmadesk.enabled.v1"]==true;
            let mut body=json!({"enabled":enabled,
                "allow_owned":enabled&&prefs["sigmadesk.allow-owned.v1"]==true,
                "browser_enabled":enabled&&prefs["sigmadesk.browser-enabled.v1"]==true,
                "browser_lease_version":1,"lease_version":2,"name":device["device_name"],
                "phase":"starting","session":id_ref});
            if let Ok(capability)=core.desk.readiness_capability.lock(){capability.advertise(&mut body,&current_local);}
            if let Some(binding)=readiness_ref.lock().map_err(|_|anyhow::anyhow!("SigmaDesk registration readiness unavailable"))?.as_mut(){
                if binding.ack_mode(){
                    let now=Instant::now();
                    let observed=registration_ref.as_ref().ok_or_else(||anyhow::anyhow!("SigmaDesk registration readiness observer missing"))?.observation(now);
                    binding.evidence(&mut body,observed,"starting",&old,now)?;
                    core.desk.record_readiness(id_ref,epoch,&old,binding);
                }
            }
            let (fresh,sent,clock)=state_request(core,&current_identity,&current_local,body).await?;
            ensure!(old.until>Instant::now() && fresh["self"]["node"]==local_ref["node"]
                && fresh["self"]["pin"]==local_ref["pin"] && fresh["self"]["member"]==local_ref["member"],
                "SigmaDesk startup identity or lease expired");
            let next=if browser_session {&fresh["browser_decision"]}else{&fresh["decision"]};
            ensure!(next.is_object(),"SigmaDesk startup assignment withdrawn");
            let renewed=desk_lease::verify(next,local_ref,desktop_ref,sent,clock,Some(&old))?;
            ensure!(next["role"]==decision["role"]
                && ["password","salt","hostRdid","peerRdid"].iter().all(|key|next[*key]==decision[*key]),
                "SigmaDesk startup assignment changed");
            ensure!(core.desk.epoch.load(Ordering::Acquire)==epoch && self::desktop()?==*desktop_ref,
                "SigmaDesk state changed during startup");
            if let Some(binding)=readiness_ref.lock().map_err(|_|anyhow::anyhow!("SigmaDesk registration readiness unavailable"))?.as_mut(){
                binding.observe(&fresh,&renewed,fresh["transport_token"].as_str().unwrap_or(""))?;
                core.desk.record_readiness(id_ref,epoch,&renewed,binding);
            }
            if let Some(streaming)=streaming_ref.as_ref() {
                streaming.lock().map_err(|_|anyhow::anyhow!("SigmaDesk streaming state unavailable"))?
                    .observe_verified(&fresh,local_ref)?;
            }
            if let Ok(mut capability)=core.desk.readiness_capability.lock(){capability.observe(&fresh,local_ref);}
            core.desk.renew_start_binding(id_ref,&crate::desk_retirement::Context::new(local_ref,desktop_ref,notification_auth_epoch)?,role,&renewed)?;
            core.desk.record("startup_heartbeat",id_ref,role,"ok",started.elapsed(),None);
            Ok(renewed)
        }).await;
        core.desk.record("engine_start_result",&id,role,
            result.as_ref().err().map(failure_code).unwrap_or("ok"),started.elapsed(),None);
        let engine=result.map_err(|e|if e.to_string().contains("SigmaDesk registration readiness"){scoped_readiness(&id,e)}else{e})?;
        if epoch != core.desk.epoch.load(Ordering::Acquire) || lease.until <= Instant::now() {
            core.desk.record("startup_rejected",&id,role,"startup_state_changed",started.elapsed(),engine.exit_code());
        }
        core.desk.publish_active(&id.clone(),epoch,&publication_cancel,lease.until,|active|{
            active.insert(
                id,
                Active {
                    lease,
                    role: if host { "host" } else { "viewer" }.into(),
                    desktop,
                    identity: local,
                    auth_epoch: notification_auth_epoch,
                    transport_until: Instant::now() + Duration::from_secs(120),
                    readiness,
                    streaming,
                    engine,
                },
            );
        })?;
        core.desk.wake.notify_one();
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn targeted_local_cancel_stops_only_that_late_startup_and_cannot_be_replayed(){
        let runtime=Runtime::default();let id="a".repeat(32);let other="b".repeat(32);
        let canceled=Arc::new(AtomicBool::new(false));let unaffected=Arc::new(AtomicBool::new(false));
        runtime.register_start(&id,&canceled,None).unwrap();runtime.register_start(&other,&unaffected,None).unwrap();
        runtime.stop(&id);assert!(canceled.load(Ordering::Acquire));assert!(!unaffected.load(Ordering::Acquire));
        assert!(startup_allowed_for(&runtime,0,&canceled,&id).is_err());
        assert!(startup_allowed_for(&runtime,0,&unaffected,&other).is_ok());
        assert!(runtime.register_start(&id,&Arc::new(AtomicBool::new(false)),None).is_err());
    }
    #[test]
    fn cancel_before_publication_never_runs_the_publish_closure(){
        let runtime=Runtime::default();let id="c".repeat(32);
        let cancel=Arc::new(AtomicBool::new(false));runtime.register_start(&id,&cancel,None).unwrap();
        runtime.stop(&id);let mut published=false;
        assert!(runtime.publish_active(&id,0,&cancel,Instant::now()+Duration::from_secs(60),|_|{published=true;}).is_err());
        assert!(!published);assert!(runtime.known_retired(&id).unwrap());
    }
    #[test]
    fn cancellation_after_publication_check_waits_for_the_same_active_lock(){
        let runtime=Arc::new(Runtime::default());let id="d".repeat(32);
        let cancel=Arc::new(AtomicBool::new(false));runtime.register_start(&id,&cancel,None).unwrap();
        let entered=Arc::new(std::sync::Barrier::new(2));let release=Arc::new(std::sync::Barrier::new(2));
        let completed=Arc::new(AtomicBool::new(false));
        let worker={let runtime=runtime.clone();let id=id.clone();let cancel=cancel.clone();let entered=entered.clone();let release=release.clone();
            std::thread::spawn(move||runtime.publish_active(&id,0,&cancel,Instant::now()+Duration::from_secs(60),|_|{entered.wait();release.wait();}).unwrap())};
        entered.wait();assert!(runtime.active.try_lock().is_err());
        let stopper={let runtime=runtime.clone();let id=id.clone();let completed=completed.clone();std::thread::spawn(move||{runtime.stop(&id);completed.store(true,Ordering::Release);})};
        let deadline=Instant::now()+Duration::from_secs(5);
        while !cancel.load(Ordering::Acquire)&&Instant::now()<deadline{std::thread::yield_now();}
        assert!(cancel.load(Ordering::Acquire));assert!(!completed.load(Ordering::Acquire));
        release.wait();worker.join().unwrap();stopper.join().unwrap();
        assert!(completed.load(Ordering::Acquire));assert!(runtime.known_retired(&id).unwrap());
    }
    #[test]
    fn startup_revoke_retains_verified_role_and_binding_for_terminal_confirmation(){
        let runtime=Runtime::default();let now=Instant::now();
        let context=crate::desk_retirement::Context::new(&json!({"member":"m","node":"n","pin":"p"}),"desktop",0).unwrap();
        for before_registration in [false,true]{
            let id=if before_registration{"a".repeat(32)}else{"b".repeat(32)};
            let cancel=Arc::new(AtomicBool::new(false));
            let binding=StartupBinding{context:context.clone(),role:"host".into(),
                lease:crate::desk_retirement::LeaseBound{sequence:2,expires:150000,until:now+Duration::from_secs(60),browser:false}};
            if before_registration{runtime.stop_bound(&id,Some(context.clone()),None);}
            let result=runtime.register_start(&id,&cancel,Some(binding));
            if before_registration{assert!(result.is_err());}else{result.unwrap();runtime.stop_bound(&id,None,None);}
            assert!(cancel.load(Ordering::Acquire));
            let ticket=runtime.ended.lock().unwrap().ticket(&context,now+Duration::from_secs(181)).unwrap();
            assert_eq!(ticket.body()["id"],id);assert_eq!(ticket.body()["role"],"host");
        }
    }
    #[test]
    fn failed_unpublished_startup_remains_busy_until_transport_drain_finishes(){
        let runtime=Runtime::default();let tasks=Arc::new(AtomicUsize::new(2));
        runtime.track_transport_tasks(&tasks).unwrap();runtime.track_transport_tasks(&tasks).unwrap();
        assert_eq!(runtime.closing.lock().unwrap().len(),1);assert!(!runtime.idle());
        tasks.store(0,Ordering::Release);assert!(runtime.idle());
        let next=Arc::new(AtomicUsize::new(1));runtime.track_transport_tasks(&next).unwrap();
        assert_eq!(runtime.closing.lock().unwrap().len(),1);assert!(!runtime.idle());
        next.store(0,Ordering::Release);assert!(runtime.idle());
    }
    #[test]
    fn verified_startup_renewal_updates_terminal_floor_even_if_cancel_won_the_race(){
        let runtime=Runtime::default();let now=Instant::now();let id="c".repeat(32);
        let context=crate::desk_retirement::Context::new(&json!({"member":"m","node":"n","pin":"p"}),"desktop",0).unwrap();
        let cancel=Arc::new(AtomicBool::new(false));
        runtime.register_start(&id,&cancel,Some(StartupBinding{context:context.clone(),role:"host".into(),
            lease:crate::desk_retirement::LeaseBound{sequence:1,expires:100000,until:now+Duration::from_secs(30),browser:false}})).unwrap();
        let next=Lease{binding:json!({"session_id":id}),sequence:2,expires:110000,until:now+Duration::from_secs(40),browser:false,control:false};
        runtime.renew_start_binding(&id,&context,"host",&next).unwrap();
        assert!(runtime.renew_start_binding(&id,&context,"host",&next).is_err());
        runtime.stop_bound(&id,None,None);
        let final_lease=Lease{sequence:3,expires:120000,until:now+Duration::from_secs(35),..next};
        assert!(runtime.renew_start_binding(&id,&context,"host",&final_lease).is_err());
        let starts=runtime.startup_cancel.lock().unwrap();let recorded=starts[&id].binding.as_ref().unwrap();
        assert_eq!(recorded.lease.sequence,3);assert_eq!(recorded.lease.expires,120000);
        assert_eq!(recorded.lease.until,now+Duration::from_secs(40));drop(starts);
        assert!(runtime.ended.lock().unwrap().ticket(&context,now+Duration::from_secs(181)).is_some());
        assert!(runtime.known_retired(&id).unwrap());
    }
    #[test]
    fn capped_startup_lease_can_advance_sequence_without_extending_the_approval_expiry(){
        let runtime=Runtime::default();let now=Instant::now();let id="d".repeat(32);
        let context=crate::desk_retirement::Context::new(&json!({"member":"m","node":"n","pin":"p"}),"desktop",0).unwrap();
        let cancel=Arc::new(AtomicBool::new(false));
        runtime.register_start(&id,&cancel,Some(StartupBinding{context:context.clone(),role:"host".into(),
            lease:crate::desk_retirement::LeaseBound{sequence:1,expires:100000,until:now+Duration::from_secs(30),browser:false}})).unwrap();
        let capped=Lease{binding:json!({"session_id":id}),sequence:2,expires:100000,until:now+Duration::from_secs(29),browser:false,control:false};
        runtime.renew_start_binding(&id,&context,"host",&capped).unwrap();
        assert!(!cancel.load(Ordering::Acquire));
        assert!(runtime.renew_start_binding(&id,&context,"host",&capped).is_err());
        let same_expiry_longer_local=Lease{sequence:3,until:now+Duration::from_secs(40),..capped};
        runtime.renew_start_binding(&id,&context,"host",&same_expiry_longer_local).unwrap();
        let rollback=Lease{sequence:4,expires:99999,..same_expiry_longer_local};
        assert!(runtime.renew_start_binding(&id,&context,"host",&rollback).is_err());
        let starts=runtime.startup_cancel.lock().unwrap();let b=starts[&id].binding.as_ref().unwrap();
        assert_eq!(b.lease.sequence,3);assert_eq!(b.lease.expires,100000);assert_eq!(b.lease.until,now+Duration::from_secs(30));
    }
    #[cfg(windows)]
    #[test]
    fn local_transport_history_exposes_task_state_but_discards_previous_profile_on_stop_all() {
        let runtime=Runtime::default();
        let trace=Arc::new(crate::desk_transport_trace::Trace::default());
        let tasks=Arc::new(AtomicUsize::new(1));
        drop(trace.open(crate::desk_transport_trace::Route::Relay));
        runtime.transport_history.lock().unwrap().push_back((trace,tasks.clone()));
        let s=runtime.snapshot();let last=&s["transport_observations"]["recent"][0];
        assert_eq!(last["pending_transport_tasks"],1);assert_eq!(last["transport_tasks_ended"],false);
        tasks.store(0,Ordering::Release);
        assert_eq!(runtime.snapshot()["transport_observations"]["recent"][0]["transport_tasks_ended"],true);
        runtime.stop_all();
        assert!(runtime.snapshot()["transport_observations"]["recent"].as_array().unwrap().is_empty());
    }
    fn diagnostic_binding(id: &str, lease: &Lease) -> crate::desk_readiness::Binding {
        crate::desk_readiness::Binding::create(&json!({"readiness_version":1,
            "readiness":{"version":1,"mode":"udp-ack-v1","session":id,
                "nonce":"a".repeat(64),"lease_sequence":lease.sequence,
                "generation":0,"accepted_revision":0,"freshness_ms":30000,
                "result":"waiting","ready":false}}),lease,&"b".repeat(64),7).unwrap().unwrap()
    }
    #[test]
    fn readiness_diagnostics_log_only_fixed_codes_for_the_current_runtime() {
        let runtime=Runtime::default();
        let id="0123456789abcdef0123456789abcdef";
        let lease=Lease{binding:json!({"session_id":id}),sequence:1,
            until:Instant::now()+Duration::from_secs(60),expires:0,control:true,browser:true};
        let mut binding=diagnostic_binding(id,&lease);
        runtime.record_readiness(id,0,&lease,&mut binding);
        let output=runtime.snapshot();
        let rows=output["diagnostics"].as_array().unwrap();
        assert_eq!(rows.len(),1);
        assert_eq!(rows[0]["event"],"registration_readiness");
        assert_eq!(rows[0]["code"],"mode_ack");
        assert_eq!(rows[0]["elapsed_ms"],0);
        assert_eq!(rows[0].as_object().unwrap().len(),7);
        for key in ["nonce","token","generation","lease","member","node","pid","address"] {
            assert!(rows[0].get(key).is_none(),"{key}");
        }
        assert!(!output.to_string().contains(&"a".repeat(64)));
        assert!(!output.to_string().contains(&"b".repeat(64)));
        runtime.record_readiness(id,0,&lease,&mut binding);
        assert_eq!(runtime.snapshot()["diagnostics"].as_array().unwrap().len(),1);
    }
    #[test]
    fn readiness_diagnostics_discard_old_epoch_and_wrong_assignment_callbacks() {
        let runtime=Runtime::default();
        let id="0123456789abcdef0123456789abcdef";
        let lease=Lease{binding:json!({"session_id":id}),sequence:1,
            until:Instant::now()+Duration::from_secs(60),expires:0,control:true,browser:true};
        let mut retired=diagnostic_binding(id,&lease);
        runtime.stop_all();
        runtime.record_readiness(id,0,&lease,&mut retired);
        runtime.record_readiness(id,1,&lease,&mut retired);
        assert!(runtime.snapshot()["diagnostics"].as_array().unwrap().is_empty());
        let mut other=diagnostic_binding(id,&lease);
        runtime.record_readiness("fedcba9876543210fedcba9876543210",1,&lease,&mut other);
        runtime.record_readiness(id,1,&lease,&mut other);
        assert!(runtime.snapshot()["diagnostics"].as_array().unwrap().is_empty());
    }
    #[test]
    fn a_late_signed_renewal_cannot_reactivate_an_expired_runtime_or_retire_another_assignment() {
        let sent=Instant::now();let id="0123456789abcdef0123456789abcdef";let other="fedcba9876543210fedcba9876543210";
        let original=Lease{binding:json!({"session_id":id}),sequence:1,until:sent+Duration::from_millis(10),expires:0,control:true,browser:true};
        let renewed=Lease{sequence:2,until:sent+Duration::from_secs(60),..original.clone()};
        let unrelated=Lease{binding:json!({"session_id":other}),sequence:40,..renewed.clone()};
        let mut leases=HashMap::from([(id.to_owned(),original.clone()),(other.to_owned(),unrelated.clone())]);
        assert!(original.until>sent); // Valid when the control request was sent.
        let received=sent+Duration::from_millis(11);assert!(renewed.until>received);
        let error=apply_runtime_lease(leases.get_mut(id).unwrap(),renewed.clone(),id,received).unwrap_err();
        assert_eq!(leases[id].sequence,1);assert_eq!(leases[id].until,original.until);
        assert_eq!(leases[other].sequence,40);assert_eq!(leases[other].until,unrelated.until);
        let runtime=Runtime::default();match failure_scope(&error){FailureScope::Assignment(failed)=>runtime.stop(failed),_=>panic!("late renewal lost its assignment scope")};
        assert!(runtime.retired(id).unwrap());assert!(!runtime.retired(other).unwrap());
        assert!(!error.to_string().contains(id));
        let mut boundary=original.clone();assert!(apply_runtime_lease(&mut boundary,renewed.clone(),id,original.until).is_err());
        let mut normal=original.clone();apply_runtime_lease(&mut normal,renewed.clone(),id,sent+Duration::from_millis(5)).unwrap();assert_eq!(normal.sequence,2);
        let mut previous=original;let expired=Lease{until:sent+Duration::from_millis(4),..renewed};
        assert!(apply_runtime_lease(&mut previous,expired,id,sent+Duration::from_millis(5)).is_err());assert_eq!(previous.sequence,1);
    }
    #[test]
    fn readiness_failures_retire_only_the_known_assignment_without_exposing_its_id() {
        let id="0123456789abcdef0123456789abcdef";
        let other="fedcba9876543210fedcba9876543210";
        let error=scoped_readiness(id,anyhow::anyhow!("SigmaDesk registration readiness evidence rejected"));
        let runtime=Runtime::default();
        match failure_scope(&error){FailureScope::Assignment(session)=>runtime.stop(session),_=>panic!("assignment scope lost")}
        assert!(runtime.retired(id).unwrap());assert!(!runtime.retired(other).unwrap());
        assert!(!format!("{error:?}").contains(id));assert!(!error.to_string().contains(id));
        assert!(matches!(failure_scope(&AuthorityStatus(401).into()),FailureScope::All));
        assert!(matches!(failure_scope(&AuthorityStatus(403).into()),FailureScope::All));
        assert!(matches!(failure_scope(&AuthorityStatus(400).into()),FailureScope::None));
    }
    #[tokio::test]
    async fn slow_startup_keeps_heartbeats_and_checks_latest_authority_before_returning() {
        let done=Arc::new(tokio::sync::Notify::new());
        let worker_done=done.clone();
        let worker=tokio::spawn(async move {worker_done.notified().await;Ok(7)});
        let mut checks=0;
        let done_ref=&done;
        let value=complete_startup(worker,Duration::from_millis(2),&mut checks,|old|async move {
            let checks=old+1;
            if checks==3 {done_ref.notify_one();}
            Ok(checks)
        }).await.unwrap();
        assert_eq!(value,7);
        assert_eq!(checks,4); // Three during preparation and one after it finishes.
    }
    #[tokio::test]
    async fn authority_withdrawal_drops_a_completed_engine_instead_of_publishing_it() {
        struct OwnedResource(Arc<AtomicUsize>);
        impl Drop for OwnedResource {
            fn drop(&mut self){self.0.fetch_sub(1,Ordering::AcqRel);}
        }
        let live=Arc::new(AtomicUsize::new(1));
        let owned=OwnedResource(live.clone());
        let worker=tokio::spawn(async move {Ok(owned)});
        let result=complete_startup(worker,Duration::from_secs(10),&mut (),|()|async {
            anyhow::bail!("SigmaDesk startup assignment withdrawn")
        }).await;
        assert!(result.is_err());
        assert_eq!(live.load(Ordering::Acquire),0);
    }
    #[test]
    fn revoked_epoch_or_cancelled_startup_cannot_launch_a_late_engine() {
        let runtime=Runtime::default();
        let cancelled=Arc::new(AtomicBool::new(false));
        let guard=StartupCancel(cancelled.clone());
        assert!(startup_allowed(&runtime,0,&cancelled).is_ok());
        runtime.stop_all();
        assert!(startup_allowed(&runtime,0,&cancelled).is_err());
        assert!(startup_allowed(&runtime,1,&cancelled).is_ok());
        drop(guard);
        assert!(startup_allowed(&runtime,1,&cancelled).is_err());
    }
    #[test]
    fn connection_failure_history_survives_fresh_status_without_raw_credentials() {
        let runtime=Runtime::default();
        let error=anyhow::anyhow!("credential=must-not-appear; relay port 21117 is already in use");
        runtime.record("engine_start_result","aabbccddeeff00112233445566778899","host",failure_code(&error),Duration::from_millis(12),None);
        *runtime.view.lock().unwrap()=json!({"devices":[]});
        let output=runtime.snapshot();
        assert_eq!(output["diagnostics"][0]["code"],"relay_port_conflict");
        assert_eq!(output["diagnostics"][0]["elapsed_ms"],12);
        assert!(!output.to_string().contains("must-not-appear"));
    }
    #[test]
    fn connection_failure_history_is_bounded_and_rejects_untrusted_identifiers() {
        let runtime=Runtime::default();
        for n in 0..80 {runtime.record("watchdog_stop",&format!("{n:032x}"),"host","engine_exited",Duration::ZERO,Some(78));}
        let output=runtime.snapshot();
        assert_eq!(output["diagnostics"].as_array().unwrap().len(),64);
        runtime.record("poll_failed","token=private","private role","operation_failed",Duration::ZERO,None);
        let output=runtime.snapshot();
        assert_eq!(output["diagnostics"].as_array().unwrap().last().unwrap()["session"],"");
        assert!(!output.to_string().contains("private"));
    }
    #[test]
    fn ended_sessions_cannot_restart_and_history_limit_fails_closed() {
        let runtime = Runtime::default();
        assert!(!runtime.retired(&"f".repeat(32)).unwrap());
        runtime.stop(&"e".repeat(32));
        assert!(runtime.retired(&"e".repeat(32)).unwrap());
        assert!(!runtime.retired("new").unwrap());
        for i in 0..128 {
            runtime.stop(&format!("{i:032x}"));
        }
        assert!(runtime.retired(&"d".repeat(32)).unwrap());
        assert!(runtime.idle());
    }
    #[test]
    fn flutter_snapshot_omits_authority_credentials_and_nested_payloads() {
        let rows = safe_rows(
            &json!([{"node":"pc-public","name":"QA","password":"secret","lease":{"payload":"secret"},"transport_token":"secret","online":true}]),
            &["node", "name", "online"],
        );
        assert_eq!(
            rows,
            vec![json!({"node":"pc-public","name":"QA","online":true})]
        );
        assert!(
            safe_rows(&json!([{"name":{"password":"secret"}}]), &["name"])[0]
                .get("name")
                .is_none()
        );
        let runtime = Runtime::default();
        assert!(runtime.idle());
        assert_eq!(runtime.snapshot()["runtime"]["resources_released"], true);
    }
}
