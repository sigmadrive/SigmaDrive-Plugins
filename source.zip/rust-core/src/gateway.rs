//! S3 multiplexing over outbound, end-to-end pinned mTLS relay streams.
//! No local TCP listener, anonymous S3, data telemetry or permission RPC per file.
use crate::{
    peer_tls::LocalPins, publication::Authority, relay::RelayTransport, share_fs::Root, state::Core,
};
use anyhow::{Result, ensure};
use hmac::{Hmac, Mac};
use http_body_util::BodyExt;
use hyper::{Request, Response, body::Incoming};
use hyper_util::rt::TokioIo;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::{HashMap, HashSet},
    sync::{
        Arc, Mutex, RwLock,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};
use tokio::sync::{Semaphore, watch};

pub struct Published {
    pub root: Arc<Root>,
    pub authority: Arc<Authority>,
    pins: HashMap<String, String>,
    secret: zeroize::Zeroizing<Vec<u8>>,
    fingerprint: String,
    labels: RwLock<Value>,
}
pub struct Publisher {
    accept_stop: watch::Sender<bool>,
    pub transport: Arc<RelayTransport>,
    identity: String,
    shares: RwLock<HashMap<String, Arc<Published>>>,
    pins: LocalPins,
    stop: watch::Sender<bool>,
    state: Mutex<&'static str>,
}
impl Published {
    fn credentials(&self, pin: &str) -> Result<(String, String)> {
        let mut access = Hmac::<Sha256>::new_from_slice(&self.secret)?;
        access.update(b"SigmaDrive/S3/access/1\0");
        access.update(pin.as_bytes());
        let mut secret = Hmac::<Sha256>::new_from_slice(&self.secret)?;
        secret.update(b"SigmaDrive/S3/secret/1\0");
        secret.update(pin.as_bytes());
        Ok((
            hex::encode(access.finalize().into_bytes()),
            hex::encode(secret.finalize().into_bytes()),
        ))
    }
}
impl Publisher {
    fn new(identity: &Value) -> Result<Arc<Self>> {
        let (stop, _) = watch::channel(false);
        let (accept_stop, _) = watch::channel(false);
        let value = Arc::new(Self {
            accept_stop,
            transport: Arc::new(RelayTransport::from_identity(identity)?),
            identity: identity["pin"].to_string() + identity["credential"].as_str().unwrap_or(""),
            shares: RwLock::new(HashMap::new()),
            pins: Arc::new(RwLock::new(HashSet::new())),
            stop,
            state: Mutex::new("starting"),
        });
        Ok(value)
    }
    fn listen(self: &Arc<Self>) {
        let weak = Arc::downgrade(self);
        let mut stop = self.accept_stop.subscribe();
        tokio::spawn(async move {
            let slots = Arc::new(Semaphore::new(8));
            loop {
                let Some(p) = weak.upgrade() else { break };
                let permit = tokio::select! {biased;_=stop.wait_for(|s|*s)=>break,p=slots.clone().acquire_owned()=>{let Ok(p)=p else{break};p}};
                let transport = p.transport.clone();
                let pins = p.pins.clone();
                drop(p);
                let accepted = tokio::select! {biased;_=stop.wait_for(|s|*s)=>break,r=transport.accept(pins)=>r};
                let Some(p) = weak.upgrade() else { break };
                match accepted {
                    Ok(peer) => {
                        if let Ok(mut state) = p.state.lock() {
                            *state = "listening";
                        }
                        let weak = Arc::downgrade(&p);
                        let stop = p.stop.subscribe();
                        tokio::spawn(async move {
                            let _slot = permit;
                            let _ = serve(weak, peer, stop).await;
                        });
                    }
                    Err(_) => {
                        if let Ok(mut state) = p.state.lock() {
                            *state = "reconnecting";
                        }
                        drop(permit);
                        drop(p);
                        tokio::select! {biased;_=stop.wait_for(|s|*s)=>break,_=tokio::time::sleep(Duration::from_secs(2))=>{}}
                    }
                }
            }
        });
    }
    pub fn stop(&self) {
        self.accept_stop.send_replace(true);
        self.stop.send_replace(true);
        if let Ok(shares) = self.shares.read() {
            for s in shares.values() {
                s.authority.stop();
            }
        }
    }
    pub fn drain(&self) {
        self.accept_stop.send_replace(true);
    }
    pub fn status(&self) -> Value {
        json!({"state":self.state.lock().map(|s|*s).unwrap_or("unavailable"),"shares":self.shares.read().map(|s|s.len()).unwrap_or(0)})
    }
    pub fn share_status(&self, id: &str) -> Value {
        self.shares
            .read()
            .ok()
            .and_then(|s| s.get(id).map(|p| p.authority.local_status()))
            .unwrap_or(json!({"state":"stopped","active_requests":0,"resources_released":true}))
    }
    pub fn remove(&self, id: &str) {
        if let Ok(mut shares) = self.shares.write()
            && let Some(s) = shares.remove(id)
        {
            s.authority.stop();
        }
        self.refresh_pins();
    }
    fn refresh_pins(&self) {
        if let (Ok(shares), Ok(mut pins)) = (self.shares.read(), self.pins.write()) {
            *pins = shares
                .values()
                .flat_map(|s| s.pins.keys().cloned())
                .collect();
        }
    }
}
impl Drop for Publisher {
    fn drop(&mut self) {
        self.stop();
    }
}

pub async fn reconcile(core: &Arc<Core>) -> Result<()> {
    if core.update.draining.load(Ordering::Acquire) {
        return Ok(());
    }
    let _control = core.share_control.lock().await;
    let (identity, shares, approvals, member) = {
        let d = core.data.read().await;
        (
            d.share_identity.clone(),
            d.shares.clone(),
            d.peer_approvals.clone(),
            d.member.clone(),
        )
    };
    if !shares.values().any(|s| s["enabled"] == true) {
        crate::sharing::stop_publications(core);
        return Ok(());
    }
    if crate::profile::readiness(core).await.is_err() {
        crate::sharing::stop_all(core).await;
        anyhow::bail!("profile verification required");
    }
    let identity = identity.ok_or_else(|| anyhow::anyhow!("device registration required"))?;
    if !(identity["state"] == "enrolled"
        && member.as_ref().is_some_and(|m| {
            m["memberId"] == identity["bound_member"]
                && m["expiresAt"].as_u64().unwrap_or(0) > crate::state::now()
        }))
    {
        crate::sharing::stop_all(core).await;
    }
    ensure!(
        identity["state"] == "enrolled"
            && member
                .as_ref()
                .is_some_and(|m| m["memberId"] == identity["bound_member"]
                    && m["expiresAt"].as_u64().unwrap_or(0) > crate::state::now()),
        "valid member and enrolled node required"
    );
    let publisher = {
        let mut p = core
            .publisher
            .lock()
            .map_err(|_| anyhow::anyhow!("publisher lock failed"))?;
        let fingerprint =
            identity["pin"].to_string() + identity["credential"].as_str().unwrap_or("");
        if p.as_ref().is_some_and(|p| p.identity != fingerprint)
            && let Some(old) = p.take()
        {
            old.stop();
        }
        if p.is_none() {
            *p = Some(Publisher::new(&identity)?);
        }
        p.as_ref().unwrap().clone()
    };
    let old = publisher
        .shares
        .read()
        .map_err(|_| anyhow::anyhow!("publication state failed"))?
        .keys()
        .cloned()
        .collect::<Vec<_>>();
    for id in old {
        if !shares.get(&id).is_some_and(|s| s["enabled"] == true) {
            publisher.remove(&id);
        }
    }
    let device_name = core.settings().await["device_name"].clone();
    for (id, share) in shares.into_iter().filter(|(_, s)| s["enabled"] == true) {
        let mut bindings = approvals
            .values()
            .filter(|a| a["share"] == id && a["role"] == "publisher" && a["active"] == true)
            .cloned()
            .collect::<Vec<_>>();
        bindings.sort_by_key(|a| a.to_string());
        let mut policy = share.clone();
        policy.as_object_mut().unwrap().remove("name");
        let labels = json!({"name":share["name"],"device_name":device_name});
        let fingerprint = hex::encode(Sha256::digest(serde_json::to_vec(&json!([
            policy, bindings
        ]))?));
        if let Ok(existing) = publisher.shares.read()
            && let Some(p) = existing.get(&id).filter(|p| p.fingerprint == fingerprint)
        {
            if let Ok(mut value) = p.labels.write() {
                *value = labels;
            }
            continue;
        }
        // A local policy edit cancels old requests before contacting the server.
        publisher.remove(&id);
        let root = Root::open(
            std::path::Path::new(share["folder"].as_str().unwrap_or("")),
            share["s3_bucket"].as_str().unwrap_or(""),
        )?;
        crate::authority::call(core,"POST","/v1/shares",Some(json!({"id":id,"name":id,"protocol":"s3","team_wide":false,"grants":share["grants"],"write_grants":share["write_grants"]}))).await?;
        {
            let current = core.data.read().await;
            if current.shares.get(&id) != Some(&share)
                || !current.online.as_ref().is_some_and(|p| p.enabled)
                || !current.member.as_ref().is_some_and(|m| {
                    m["memberId"] == identity["bound_member"]
                        && m["expiresAt"].as_u64().unwrap_or(0) > crate::state::now()
                })
            {
                continue;
            }
        }
        let mut pins = HashMap::new();
        let mut writes = HashSet::new();
        for b in bindings {
            let pin = b["peer_pin"]
                .as_str()
                .filter(|s| crate::permit::valid_pin(s))
                .ok_or_else(|| anyhow::anyhow!("local approval pin invalid"))?;
            let node = b["peer_node"]
                .as_str()
                .filter(|s| !s.is_empty())
                .ok_or_else(|| anyhow::anyhow!("local approval node invalid"))?;
            pins.insert(pin.to_owned(), node.to_owned());
            if b["write_approved"] == true {
                writes.insert(pin.to_owned());
            }
        }
        let authority = Authority::start(
            id.clone(),
            identity["node"].as_str().unwrap_or("").into(),
            identity["pin"].as_str().unwrap_or("").into(),
            pins.keys().cloned().collect(),
            writes,
            publisher.transport.clone(),
            core.leases.clone(),
        )?;
        let secret =
            zeroize::Zeroizing::new(hex::decode(share["_s3_secret"].as_str().unwrap_or(""))?);
        ensure!(secret.len() == 32, "publication secret missing");
        authority.ready().await?;
        let entry = Arc::new(Published {
            root: Arc::new(root),
            authority,
            pins,
            secret,
            fingerprint,
            labels: RwLock::new(labels),
        });
        publisher
            .shares
            .write()
            .map_err(|_| anyhow::anyhow!("publication state failed"))?
            .insert(id, entry);
        publisher.refresh_pins();
    }
    // A single task owns the standby. Multiple buckets share it.
    let mut state = publisher
        .state
        .lock()
        .map_err(|_| anyhow::anyhow!("publisher state failed"))?;
    if *state == "starting" {
        *state = "connecting";
        drop(state);
        publisher.listen();
    }
    Ok(())
}

struct StopFlag(Arc<AtomicBool>);
impl Drop for StopFlag {
    fn drop(&mut self) {
        self.0.store(true, Ordering::Release);
    }
}
type Guards = Arc<Mutex<Vec<crate::leases::Guard>>>;
type Scope = Arc<Mutex<Option<(String, String)>>>;
async fn serve(
    publisher: std::sync::Weak<Publisher>,
    peer: crate::relay::AcceptedPeer,
    mut stop: watch::Receiver<bool>,
) -> Result<()> {
    let stopped = Arc::new(AtomicBool::new(false));
    let _flag = StopFlag(stopped.clone());
    let guards: Guards = Arc::new(Mutex::new(Vec::new()));
    let active = guards.clone();
    let scope: Scope = Arc::new(Mutex::new(None));
    let signal = stopped.clone();
    let pin = peer.pin;
    let service = hyper::service::service_fn(move |req| {
        let publisher = publisher.clone();
        let pin = pin.clone();
        let guards = active.clone();
        let signal = signal.clone();
        let scope = scope.clone();
        async move {
            Ok::<_, std::convert::Infallible>(
                match handle(publisher, req, &pin, guards, signal, scope).await {
                    Ok(r) => r,
                    Err(_) => response(403, b"permission denied".to_vec()),
                },
            )
        }
    });
    let connection = hyper::server::conn::http1::Builder::new()
        .keep_alive(true)
        .max_buf_size(32 * 1024)
        .serve_connection(TokioIo::new(peer.stream), service);
    tokio::pin!(connection);
    let mut idle = tokio::time::interval(Duration::from_millis(100));
    let started = std::time::Instant::now();
    loop {
        tokio::select! {biased;
            _=stop.wait_for(|s|*s)=>break,
        _=idle.tick()=>{if guards.lock().map(|g|g.iter().any(|g|*g.cancel.borrow())||(g.is_empty()&&started.elapsed()>Duration::from_secs(10))).unwrap_or(true){break;}},
            r=&mut connection=>{r?;return Ok(());},
        }
    }
    anyhow::bail!("peer connection stopped")
}
fn response(status: u16, bytes: Vec<u8>) -> Response<s3s::Body> {
    let mut r = Response::new(s3s::Body::from(bytes));
    *r.status_mut() = http::StatusCode::from_u16(status).unwrap();
    r.headers_mut()
        .insert("x-sigma-protocol", http::HeaderValue::from_static("1"));
    r.headers_mut()
        .insert("x-sigma-protocol-min", http::HeaderValue::from_static("1"));
    r.headers_mut()
        .insert("x-sigma-protocol-max", http::HeaderValue::from_static("1"));
    r.headers_mut()
        .insert("cache-control", http::HeaderValue::from_static("no-store"));
    r
}
fn header<'a>(r: &'a Request<Incoming>, key: &str) -> Result<&'a str> {
    ensure!(
        r.headers().get_all(key).iter().count() == 1,
        "missing/duplicate header"
    );
    Ok(r.headers()[key].to_str()?)
}
async fn handle(
    publisher: std::sync::Weak<Publisher>,
    request: Request<Incoming>,
    pin: &str,
    guards: Guards,
    stopped: Arc<AtomicBool>,
    scope: Scope,
) -> Result<Response<s3s::Body>> {
    let publisher = publisher
        .upgrade()
        .ok_or_else(|| anyhow::anyhow!("publisher stopped"))?;
    let share = header(&request, "x-sigma-s3-share")?.to_owned();
    let entry = publisher
        .shares
        .read()
        .map_err(|_| anyhow::anyhow!("publication state failed"))?
        .get(&share)
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("publication inactive"))?;
    let node = entry
        .pins
        .get(pin)
        .ok_or_else(|| anyhow::anyhow!("peer not locally approved"))?;
    let token = header(&request, "x-sigma-s3-permit")?;
    let capability = header(&request, "x-sigma-s3-capability")?;
    {
        let binding = (share.clone(), hex::encode(Sha256::digest(token.as_bytes())));
        let mut scope = scope
            .lock()
            .map_err(|_| anyhow::anyhow!("connection scope unavailable"))?;
        ensure!(
            scope.as_ref().is_none_or(|s| s == &binding),
            "connection cannot change share/session identity"
        );
        *scope = Some(binding);
    }
    ensure!(
        token.len() <= 8192 && capability.len() <= 8192,
        "authority header bound"
    );
    let write = !matches!(*request.method(), http::Method::GET | http::Method::HEAD);
    let read = entry.authority.admit(token, capability, pin, node, false)?;
    let write_guard = entry
        .authority
        .admit(token, capability, pin, node, true)
        .ok();
    ensure!(!write || write_guard.is_some(), "write authority required");
    let writable = write_guard.is_some();
    {
        let mut g = guards
            .lock()
            .map_err(|_| anyhow::anyhow!("guard lock failed"))?;
        ensure!(
            g.iter().all(crate::leases::Guard::live),
            "connection authorization ended"
        );
        if g.is_empty() {
            g.push(read);
        }
        if g.len() == 1
            && let Some(w) = write_guard
        {
            g.push(w);
        }
    }
    let min = request
        .headers()
        .get("x-sigma-protocol-min")
        .map(|v| v.to_str()?.parse::<u32>().map_err(anyhow::Error::from))
        .transpose()?
        .unwrap_or(1);
    let max = request
        .headers()
        .get("x-sigma-protocol-max")
        .map(|v| v.to_str()?.parse::<u32>().map_err(anyhow::Error::from))
        .transpose()?
        .unwrap_or(1);
    if crate::relay::negotiate(min, max).is_err() {
        return Ok(response(426, b"peer update required".to_vec()));
    }
    ensure!(
        request.uri().scheme().is_none() && request.uri().authority().is_none(),
        "absolute request denied"
    );
    let (access, secret) = entry.credentials(pin)?;
    if request.uri().path() == "/_sigma/s3/authority" {
        ensure!(
            request.method() == http::Method::HEAD && request.uri().query().is_none(),
            "invalid authority probe"
        );
        return Ok(response(200, vec![]));
    }
    if request.uri().path() == "/_sigma/s3/credentials" {
        ensure!(
            request.method() == http::Method::GET && request.uri().query().is_none(),
            "invalid credentials probe"
        );
        return Ok(response(
            200,
            serde_json::to_vec(
                &json!({"accessKey":access,"secretKey":secret,"bucket":entry.root.bucket,"write":writable,"name":entry.labels.read().ok().map(|v|v["name"].clone()),"device_name":entry.labels.read().ok().map(|v|v["device_name"].clone())}),
            )?,
        ));
    }
    ensure!(
        !request
            .uri()
            .query()
            .unwrap_or("")
            .to_ascii_lowercase()
            .contains("x-amz-"),
        "presigned requests not supported"
    );
    ensure!(
        !request.headers().contains_key("x-amz-security-token")
            && !request.headers().contains_key("transfer-encoding"),
        "streamed/token requests denied"
    );
    let len = request
        .headers()
        .get("content-length")
        .map(|v| v.to_str()?.parse::<u64>().map_err(anyhow::Error::from))
        .transpose()?
        .unwrap_or(0);
    ensure!(len <= 8 * 1024 * 1024, "S3 request exceeds part bound");
    let authorization = header(&request, "authorization")?.to_ascii_lowercase();
    ensure!(
        authorization.starts_with("aws4-hmac-sha256 ")
            && authorization.contains("/us-east-1/s3/aws4_request"),
        "SigV4 region/service required"
    );
    let signed = authorization
        .split("signedheaders=")
        .nth(1)
        .and_then(|s| s.split(',').next())
        .ok_or_else(|| anyhow::anyhow!("signed headers missing"))?;
    let signed = signed.split(';').collect::<HashSet<_>>();
    for name in ["host", "x-amz-date", "x-amz-content-sha256"] {
        ensure!(signed.contains(name), "required signed header missing");
    }
    for name in ["range", "if-match", "if-none-match", "content-type"] {
        ensure!(
            !request.headers().contains_key(name) || signed.contains(name),
            "unsigned semantic header"
        );
    }
    let date = header(&request, "x-amz-date")?;
    let parsed = jiff::Timestamp::strptime("%Y%m%dT%H%M%S%z", date.replace('Z', "+0000"))?;
    ensure!(
        (parsed.as_millisecond() - crate::state::now() as i64).unsigned_abs() <= 300000,
        "SigV4 request date outside allowed window"
    );
    let payload = header(&request, "x-amz-content-sha256")?.to_owned();
    ensure!(
        payload.len() == 64 && payload.bytes().all(|b| b.is_ascii_hexdigit()),
        "hashed payload required"
    );
    let (parts, mut body) = request.into_parts();
    let mut bytes = Vec::new();
    while let Some(frame) = body.frame().await {
        ensure!(!stopped.load(Ordering::Acquire), "connection stopped");
        let frame = frame?;
        let data = frame
            .into_data()
            .map_err(|_| anyhow::anyhow!("trailers denied"))?;
        ensure!(
            bytes.len() + data.len() <= len as usize,
            "request body overflow"
        );
        bytes.extend_from_slice(&data);
    }
    ensure!(
        bytes.len() == len as usize && hex::encode(Sha256::digest(&bytes)) == payload,
        "request body hash mismatch"
    );
    let store = crate::s3_store::Store {
        root: entry.root.clone(),
        pin: pin.into(),
        access: access.clone(),
        writable,
        stopped,
        lease_owner: guards,
    };
    let mut builder = s3s::service::S3ServiceBuilder::new(store);
    builder.set_auth(s3s::auth::SimpleAuth::from_single(access, secret));
    let service = builder.build();
    let mut response = service
        .call(Request::from_parts(parts, s3s::Body::from(bytes)))
        .await?;
    response
        .headers_mut()
        .insert("x-sigma-protocol", http::HeaderValue::from_static("1"));
    Ok(response)
}
