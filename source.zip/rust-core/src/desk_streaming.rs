//! Optional streaming compatibility assertion for the existing Rust HOST flow.
//! No new bridge/runtime, public diagnostics or persistent capability cache.
//! Exact reviewed engine fingerprints gate the HOST compatibility assertion.
//! The authority still decides whether a supported session may use streaming.
use anyhow::{Result, ensure};
use serde_json::Value;

pub const REVIEWED_STREAMING_ENGINE: Option<&str> = Some("28205dc1721a823b6dc8529424ca93a825f5881b63ac47d68dff2c3b359fe088");
pub const REVIEWED_FAST_REGISTRATION_ENGINE: Option<&str> = Some("28205dc1721a823b6dc8529424ca93a825f5881b63ac47d68dff2c3b359fe088");
pub const MODE: &str = "bounded-stream-v1";

fn exact_pin(pin: &str) -> bool {
    pin.len()==64 && pin.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))
}
pub fn fast_registration_allowed(actual: &str) -> bool {
    reviewed_pin_matches(REVIEWED_FAST_REGISTRATION_ENGINE, actual)
}
fn reviewed_pin_matches(expected: Option<&str>, actual: &str) -> bool {
    expected.is_some_and(|expected|exact_pin(expected)&&expected==actual)
}

pub struct Session {
    identity: Value,
    supported: bool,
    published: bool,
    expected_engine: Option<String>,
}
impl Session {
    /// Call only after exact self identity and signed HOST assignment validation.
    /// A session that began on a legacy authority cannot upgrade in place.
    pub fn from_verified_assignment(remote: &Value, identity: &Value) -> Result<Self> {
        Self::with_expected(remote, identity, REVIEWED_STREAMING_ENGINE)
    }
    fn with_expected(remote: &Value, identity: &Value, reviewed: Option<&str>) -> Result<Self> {
        ensure!(same_identity(remote,identity),"SigmaDesk streaming identity changed");
        ensure!(reviewed.is_none_or(exact_pin),"SigmaDesk reviewed streaming engine invalid");
        Ok(Self { identity:identity.clone(),
            supported:remote["browser_streaming_capability_version"].as_u64()==Some(1),
            published:false,expected_engine:reviewed.map(str::to_owned) })
    }
    /// Existing readiness Binding::observe has already verified nonce, generation,
    /// token and current HOST lease. Lost support never restores on a late response.
    pub fn observe_verified(&mut self, remote: &Value, identity: &Value) -> Result<()> {
        ensure!(identity==&self.identity && same_identity(remote,identity),
            "SigmaDesk streaming identity changed");
        if remote["browser_streaming_capability_version"].as_u64()!=Some(1) {
            ensure!(!self.published,"SigmaDesk streaming authority protocol changed");
            self.supported=false;
        }
        Ok(())
    }
    /// Caller owns the current Active runtime lock and rechecks identity, desktop,
    /// cancellation epoch and HOST lease. Pin comes only from the running Engine,
    /// which owns full verified asset handles and its live kill-on-close Job.
    pub fn append(&mut self, body:&mut Value, identity:&Value,
        runtime_pin:Option<&str>, binding:&crate::desk_readiness::Binding,
        lease:&crate::desk_lease::Lease, now:std::time::Instant) -> Result<()> {
        ensure!(identity==&self.identity,"SigmaDesk streaming identity changed");
        ensure!(["streaming_capability_version","streaming_capability_mode",
            "streaming_engine_manifest_sha256"].iter().all(|key|body.get(*key).is_none()),
            "SigmaDesk streaming capability must use a fresh state body");
        let Some(expected)=self.expected_engine.as_deref() else {return Ok(())};
        if !self.supported {return Ok(())}
        ensure!(runtime_pin.is_some_and(|actual|reviewed_pin_matches(Some(expected),actual)),
            "SigmaDesk streaming engine runtime unavailable");
        self.published |= binding.append_streaming(body,lease,expected,now)?;
        Ok(())
    }
}
fn same_identity(remote:&Value, identity:&Value)->bool {
    ["node","pin","member"].iter().all(|key|
        identity[*key].is_string() && !identity[*key].as_str().unwrap_or("").is_empty()
        && remote["self"][*key]==identity[*key])
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    fn identity()->Value {json!({"node":"synthetic-node","pin":"synthetic-cert","member":"synthetic-member"})}
    fn remote(v:Value)->Value {json!({"self":identity(),"browser_streaming_capability_version":v})}
    fn fixture()->(crate::desk_readiness::Binding,crate::desk_lease::Lease,Value,std::time::Instant) {
        use crate::{desk_readiness::Binding,desk_registration::Observation,desk_lease::Lease};
        let now=std::time::Instant::now();let id="0123456789abcdef0123456789abcdef";
        let lease=Lease{binding:json!({"session_id":id,"kind":"browser"}),sequence:1,until:now+std::time::Duration::from_secs(60),expires:0,control:true,browser:true};
        let mut r=remote(json!(1));r["readiness_version"]=json!(1);
        r["readiness"]=json!({"version":1,"mode":"udp-ack-v1","session":id,"nonce":"a".repeat(64),"lease_sequence":1,"generation":0,"accepted_revision":0,"freshness_ms":30000,"result":"waiting","ready":false});
        let mut b=Binding::create(&r,&lease,&"b".repeat(64),7).unwrap().unwrap();
        let mut body=json!({"phase":"starting","session":id});
        b.evidence(&mut body,Observation{generation:7,revision:1,ready:false,age_ms:0},"starting",&lease,now).unwrap();
        r["readiness"]["generation"]=json!(7);r["readiness"]["accepted_revision"]=json!(1);r["readiness"]["result"]=json!("accepted");
        b.observe(&r,&lease,&"b".repeat(64)).unwrap();
        body["phase"]=json!("active");
        b.evidence(&mut body,Observation{generation:7,revision:2,ready:true,age_ms:0},"active",&lease,now).unwrap();
        (b,lease,body,now)
    }
    #[test] fn reviewed_release_policies_match_the_embedded_engine_and_reject_old_pins() {
        use sha2::{Digest, Sha256};
        let expected=hex::encode(Sha256::digest(include_str!("../public/sigmadesk-files.json").as_bytes()));
        assert_eq!(REVIEWED_STREAMING_ENGINE,Some(expected.as_str()));
        assert_eq!(REVIEWED_FAST_REGISTRATION_ENGINE,Some(expected.as_str()));
        assert!(fast_registration_allowed(&expected));
        let mut changed=expected.clone().into_bytes();changed[0]=if changed[0]==b'0'{b'1'}else{b'0'};
        for rejected in [String::from_utf8(changed).unwrap(),
            "f58ce0d67a132c549226898e8fc383b46eba8286ecb34f0c36c7213362a0ca95".into(),
            "7a2c973bf552c59fec340eb706b4d2ae76cf6886cce62f8741a6cdcf250582b1".into()] {
            assert!(!fast_registration_allowed(&rejected));
            assert!(!reviewed_pin_matches(REVIEWED_STREAMING_ENGINE,&rejected));
        }
    }
    #[test] fn no_version_or_certificate_substitute_for_engine_pin() {
        for actual in ["0.3.21","synthetic-cert","",&"A".repeat(64),&"a".repeat(63)] {
            assert!(!reviewed_pin_matches(Some(&"a".repeat(64)),actual));
        }
        assert!(reviewed_pin_matches(Some(&"a".repeat(64)),&"a".repeat(64)));
    }
    #[test] fn response_first_is_exact_and_legacy_session_never_upgrades() {
        for v in [Value::Null,json!("1"),json!(1.0),json!(2)] {
            let mut s=Session::with_expected(&remote(v),&identity(),Some(&"a".repeat(64))).unwrap();
            assert!(!s.supported);
            s.observe_verified(&remote(json!(1)),&identity()).unwrap();
            assert!(!s.supported);
        }
    }
    #[test] fn support_disappearance_is_sticky_before_first_publication() {
        let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"a".repeat(64))).unwrap();
        s.observe_verified(&remote(Value::Null),&identity()).unwrap();
        s.observe_verified(&remote(json!(1)),&identity()).unwrap();
        assert!(!s.supported);
    }
    #[test] fn changed_identity_and_published_support_loss_fail_closed() {
        let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"a".repeat(64))).unwrap();
        let mut changed=identity();changed["node"]=json!("other-node");
        assert!(s.observe_verified(&remote(json!(1)),&changed).is_err());
        s.published=true;
        assert!(s.observe_verified(&remote(Value::Null),&identity()).is_err());
    }
    #[test] fn malformed_reviewed_pin_never_constructs_a_live_policy() {
        assert!(Session::with_expected(&remote(json!(1)),&identity(),Some("0.3.21")).is_err());
    }
    #[test] fn explicit_disabled_policy_cannot_publish_even_on_verified_runtime_and_ready_proof() {
        let (b,l,mut body,t)=fixture();
        let mut s=Session::with_expected(&remote(json!(1)),&identity(),None).unwrap();
        s.append(&mut body,&identity(),Some(&"a".repeat(64)),&b,&l,t).unwrap();
        assert!(!s.published);assert!(body.get("streaming_capability_version").is_none());
    }
    #[test] fn release_assignment_publishes_only_the_exact_live_engine_pin() {
        let (b,l,body,t)=fixture();let pin=REVIEWED_STREAMING_ENGINE.unwrap();
        let mut s=Session::from_verified_assignment(&remote(json!(1)),&identity()).unwrap();
        let mut current=body.clone();s.append(&mut current,&identity(),Some(pin),&b,&l,t).unwrap();
        assert!(s.published);assert_eq!(current["streaming_engine_manifest_sha256"],pin);
        for actual in [None,Some("f58ce0d67a132c549226898e8fc383b46eba8286ecb34f0c36c7213362a0ca95")] {
            let mut s=Session::from_verified_assignment(&remote(json!(1)),&identity()).unwrap();
            let mut changed=body.clone();assert!(s.append(&mut changed,&identity(),actual,&b,&l,t).is_err());
            assert!(!s.published);assert!(changed.get("streaming_capability_version").is_none());
        }
    }
    #[test] fn active_reviewed_runtime_appends_only_three_exact_fields() {
        let (b,l,mut body,t)=fixture();let before=body.as_object().unwrap().len();
        let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
        s.append(&mut body,&identity(),Some(&"c".repeat(64)),&b,&l,t).unwrap();
        assert_eq!(body.as_object().unwrap().len(),before+3);assert!(s.published);
        assert_eq!(body["streaming_capability_version"],1);assert_eq!(body["streaming_capability_mode"],MODE);
        assert_eq!(body["streaming_engine_manifest_sha256"],"c".repeat(64));
        assert_eq!(body["readiness_generation"],7);assert_eq!(body["readiness_nonce"],"a".repeat(64));
    }
    #[test] fn missing_or_wrong_verified_runtime_pin_never_publishes() {
        let (b,l,body,t)=fixture();
        for pin in [None,Some("0.3.21"),Some(&"b".repeat(64))] {
            let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
            let mut body=body.clone();assert!(s.append(&mut body,&identity(),pin,&b,&l,t).is_err());
            assert!(!s.published);assert!(body.get("streaming_capability_version").is_none());
        }
    }
    #[test] fn stale_or_other_readiness_binding_never_publishes() {
        let (b,l,body,t)=fixture();
        for (key,value) in [("session",json!("other-session")),("readiness_nonce",json!("b".repeat(64))),
            ("readiness_generation",json!(8)),("readiness_lease_sequence",json!(2)),
            ("readiness_mode",json!("legacy-timer")),("readiness_version",json!("1")),
            ("readiness_revision",json!(3)),("readiness_revision",json!(0)),("readiness_ready",Value::Null)] {
            let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
            let mut changed=body.clone();changed[key]=value;
            assert!(s.append(&mut changed,&identity(),Some(&"c".repeat(64)),&b,&l,t).is_err(),"{key}");
            assert!(changed.get("streaming_capability_version").is_none());
        }
        let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
        assert!(s.append(&mut body.clone(),&identity(),Some(&"c".repeat(64)),&b,&l,l.until).is_err());
    }
    #[test] fn no_cap_from_initial_not_ready_starting_or_aged_proof() {
        let (b,l,body,t)=fixture();
        for (key,value) in [("phase",json!("starting")),("readiness_ready",json!(false)),
            ("readiness_revision",json!(1)),("readiness_age_ms",json!(30000)),("readiness_age_ms",json!("0"))] {
            let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
            let mut changed=body.clone();changed[key]=value;
            s.append(&mut changed,&identity(),Some(&"c".repeat(64)),&b,&l,t).unwrap();
            assert!(!s.published);assert!(changed.get("streaming_capability_version").is_none());
        }
    }
    #[test] fn legacy_first_assignment_never_publishes_after_later_support_response() {
        let (b,l,mut body,t)=fixture();
        let mut s=Session::with_expected(&remote(Value::Null),&identity(),Some(&"c".repeat(64))).unwrap();
        s.observe_verified(&remote(json!(1)),&identity()).unwrap();
        s.append(&mut body,&identity(),Some(&"c".repeat(64)),&b,&l,t).unwrap();
        assert!(body.get("streaming_capability_version").is_none());
    }

    #[test] fn native_host_lease_cannot_assert_browser_streaming() {
        let (b,mut l,mut body,t)=fixture(); l.browser=false; l.binding["kind"]=json!("native");
        let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
        assert!(s.append(&mut body,&identity(),Some(&"c".repeat(64)),&b,&l,t).is_err());
        assert!(body.get("streaming_capability_version").is_none());
    }

    #[test] fn browser_flag_and_signed_kind_must_both_match_before_assertion() {
        for (browser,kind) in [(false,json!("browser")),(true,json!("native")),(true,Value::Null)] {
            let (b,mut l,mut body,t)=fixture();l.browser=browser;l.binding["kind"]=kind;
            let mut s=Session::with_expected(&remote(json!(1)),&identity(),Some(&"c".repeat(64))).unwrap();
            assert!(s.append(&mut body,&identity(),Some(&"c".repeat(64)),&b,&l,t).is_err());
            assert!(body.get("streaming_capability_version").is_none());
        }
    }
}
