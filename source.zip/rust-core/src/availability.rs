//! Volatile local observations of the authenticated data path. No probes, paths,
//! transfer counters or observations are sent to the directory service.
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    sync::Mutex,
    time::{Duration, Instant},
};

#[derive(Clone, Copy)]
pub enum Contact {
    Verified,
    Unreachable,
    Denied,
}
#[derive(Default)]
pub struct Registry(Mutex<Observations>);
type Observations = HashMap<(String, String, String), (Contact, Instant)>;
impl Registry {
    pub fn record(&self, share: &str, node: &str, pin: &str, state: Contact) {
        if let Ok(mut records) = self.0.lock() {
            // Only bounded per-share state, never object-level history.
            if records.len() >= 128 {
                records.retain(|_, (_, at)| at.elapsed() < Duration::from_secs(60));
            }
            if records.len() < 128 || records.contains_key(&(share.into(), node.into(), pin.into()))
            {
                records.insert(
                    (share.into(), node.into(), pin.into()),
                    (state, Instant::now()),
                );
            }
        }
    }
    pub fn status(
        &self,
        share: &str,
        node: &str,
        pin: &str,
        directory: &Value,
        active: bool,
    ) -> Value {
        let observation = self
            .0
            .lock()
            .ok()
            .and_then(|r| r.get(&(share.into(), node.into(), pin.into())).copied());
        describe(observation, directory, active, Instant::now())
    }
}
fn describe(
    observation: Option<(Contact, Instant)>,
    directory: &Value,
    active: bool,
    now: Instant,
) -> Value {
    let fresh =
        observation.filter(|(_, at)| now.saturating_duration_since(*at) < Duration::from_secs(60));
    let state = if !active {
        "approval_required"
    } else {
        match fresh {
            Some((Contact::Verified, _)) => "verified",
            Some((Contact::Unreachable, _)) => "unreachable",
            Some((Contact::Denied, _)) => "access_denied",
            None => "unverified",
        }
    };
    json!({"state":state,"source":if fresh.is_some()&&active{"local_authenticated_connection"}else{"not_verified"},
        "directory_online":directory.as_bool(),"recent_seconds":fresh.filter(|_|active).map(|(_,at)|now.saturating_duration_since(at).as_secs())})
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn directory_false_is_not_proof_of_relay_failure() {
        let now = Instant::now();
        assert_eq!(
            describe(None, &json!(false), true, now)["state"],
            "unverified"
        );
        assert_eq!(
            describe(Some((Contact::Verified, now)), &json!(false), true, now)["state"],
            "verified"
        );
        assert_eq!(
            describe(
                Some((Contact::Verified, now)),
                &json!(true),
                true,
                now + Duration::from_secs(61)
            )["state"],
            "unverified"
        );
    }
    #[test]
    fn contact_is_bound_to_exact_share_device_pin_and_revocation() {
        let r = Registry::default();
        r.record("s", "n", "p", Contact::Verified);
        assert_eq!(
            r.status("other", "n", "p", &Value::Null, true)["state"],
            "unverified"
        );
        assert_eq!(
            r.status("s", "other", "p", &Value::Null, true)["state"],
            "unverified"
        );
        assert_eq!(
            r.status("s", "n", "other", &Value::Null, true)["state"],
            "unverified"
        );
        assert_eq!(
            r.status("s", "n", "p", &Value::Null, false)["state"],
            "approval_required"
        );
        r.record("s", "n", "p", Contact::Denied);
        assert_eq!(
            r.status("s", "n", "p", &json!(true), true)["state"],
            "access_denied"
        );
        r.record("s", "n", "p", Contact::Unreachable);
        assert_eq!(
            r.status("s", "n", "p", &json!(true), true)["state"],
            "unreachable"
        );
    }
}
