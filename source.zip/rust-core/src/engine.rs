use crate::Config;
#[cfg(test)]
use anyhow::bail;
use anyhow::{Result, ensure};
use opendal::Operator;
use serde::{Deserialize, Serialize};
use serde_json::json;
use sha2::{Digest, Sha256};
#[cfg(test)]
use std::{fs::File, path::PathBuf};
use std::{
    fs::{self, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::Path,
};
#[cfg(test)]
use tokio::sync::Mutex;

pub fn hash(b: &[u8]) -> String {
    hex::encode(Sha256::digest(b))
}
#[cfg(test)]
pub fn corpus(n: usize) -> Vec<u8> {
    let mut s = 0x9e3779b97f4a7c15u64;
    (0..n)
        .map(|_| {
            s ^= s << 13;
            s ^= s >> 7;
            s ^= s << 17;
            s as u8
        })
        .collect()
}
pub fn checked(path: &str) -> Result<String> {
    let p = path.replace('\\', "/");
    let p = p.trim_matches('/');
    ensure!(
        !p.split('/')
            .any(|s| s == ".." || s == "." || s.contains(':')),
        "unsafe path"
    );
    for part in p.split('/').filter(|s| !s.is_empty()) {
        ensure!(
            !part.ends_with([' ', '.'])
                && !part
                    .chars()
                    .any(|c| c.is_control() || "<>\"|?*".contains(c)),
            "path is not safe for a Windows cache"
        );
        let name = part.split('.').next().unwrap_or("").to_ascii_uppercase();
        ensure!(
            !matches!(name.as_str(), "CON" | "PRN" | "AUX" | "NUL")
                && !(name.len() == 4
                    && (name.starts_with("COM") || name.starts_with("LPT"))
                    && matches!(name.as_bytes()[3], b'1'..=b'9')),
            "reserved Windows file name"
        );
    }
    Ok(p.to_owned())
}
#[cfg(test)]
#[derive(Serialize, Deserialize, Clone)]
pub struct Record {
    pub path: String,
    pub ready: bool,
    pub bytes: u64,
    pub sha256: String,
    pub scope: String,
}
#[cfg(test)]
pub struct Engine {
    pub cfg: Config,
    pub op: Operator,
    pub lock: Mutex<()>,
}
#[cfg(test)]
impl Engine {
    pub fn new(cfg: Config, op: Operator) -> Result<Self> {
        ensure!(
            !cfg.work.as_os_str().is_empty(),
            "private work dir required"
        );
        fs::create_dir_all(cfg.work.join("data"))?;
        fs::create_dir_all(cfg.work.join("journal"))?;
        let scope = hash(
            format!(
                "{}:{}:{}:{}:{}",
                cfg.provider,
                cfg.root,
                cfg.get("connection_id"),
                cfg.get("bucket"),
                cfg.get("endpoint")
            )
            .as_bytes(),
        );
        let guard = cfg.work.join("scope.txt");
        if guard.exists() {
            ensure!(fs::read_to_string(&guard)? == scope, "cache scope mismatch")
        } else {
            let mut f = File::create(guard)?;
            f.write_all(scope.as_bytes())?;
            f.sync_all()?;
        }
        Ok(Self {
            cfg,
            op,
            lock: Mutex::new(()),
        })
    }
    pub fn data(&self, p: &str) -> Result<PathBuf> {
        Ok(self.cfg.work.join("data").join(checked(p)?))
    }
    pub fn mark(&self, p: &str, ready: bool) -> Result<()> {
        let path = checked(p)?;
        let content = if ready {
            fs::read(self.data(p)?)?
        } else {
            Vec::new()
        };
        let r = Record {
            path: path.clone(),
            ready,
            bytes: content.len() as u64,
            sha256: hash(&content),
            scope: fs::read_to_string(self.cfg.work.join("scope.txt"))?,
        };
        let out = self
            .cfg
            .work
            .join("journal")
            .join(format!("{}.json", hash(path.as_bytes())));
        atomic(&out, &serde_json::to_vec(&r)?)?;
        Ok(())
    }
    pub async fn recover(&self) -> Result<serde_json::Value> {
        let _guard = self.lock.lock().await;
        let mut uploaded = 0;
        let mut held = 0;
        if self.cfg.work.join("offline").exists() {
            return Ok(json!({"uploaded":0,"offline":true}));
        }
        for entry in fs::read_dir(self.cfg.work.join("journal"))? {
            let entry = entry?;
            if entry.path().extension().and_then(|s| s.to_str()) != Some("json") {
                continue;
            };
            let r: Record = serde_json::from_slice(&fs::read(entry.path())?)?;
            ensure!(
                r.scope == fs::read_to_string(self.cfg.work.join("scope.txt"))?,
                "record scope mismatch"
            );
            if !r.ready {
                held += 1;
                continue;
            }
            let b = fs::read(self.data(&r.path)?)?;
            ensure!(
                b.len() as u64 == r.bytes && hash(&b) == r.sha256,
                "dirty cache checksum mismatch"
            );
            match self.op.read(&r.path).await {
                Ok(v) => {
                    if hash(&v.to_vec()) == r.sha256 {
                        fs::remove_file(entry.path())?;
                        uploaded += 1;
                        continue;
                    } else {
                        held += 1;
                        continue;
                    }
                }
                Err(e) if e.kind() == opendal::ErrorKind::NotFound => {}
                Err(_) => {
                    held += 1;
                    continue;
                }
            }
            // New unique paths only. Concurrent replacement/Office semantics are not claimed.
            let temp = format!("poc-staging-{}.bin", r.sha256);
            self.op
                .write(&temp, b.clone())
                .await
                .map_err(|e| anyhow::anyhow!("upload {:?}", e.kind()))?;
            let check = self
                .op
                .read(&temp)
                .await
                .map_err(|e| anyhow::anyhow!("verify {:?}", e.kind()))?;
            ensure!(
                hash(&check.to_vec()) == r.sha256,
                "remote staging hash mismatch"
            );
            if self.op.info().capability().rename {
                self.op
                    .rename(&temp, &r.path)
                    .await
                    .map_err(|e| anyhow::anyhow!("commit rename {:?}", e.kind()))?;
            } else if self.op.info().capability().copy {
                self.op
                    .copy(&temp, &r.path)
                    .await
                    .map_err(|e| anyhow::anyhow!("commit copy {:?}", e.kind()))?;
                self.op
                    .delete(&temp)
                    .await
                    .map_err(|e| anyhow::anyhow!("staging cleanup {:?}", e.kind()))?;
            } else {
                bail!("backend lacks staging commit")
            }
            let check = self
                .op
                .read(&r.path)
                .await
                .map_err(|e| anyhow::anyhow!("commit verify {:?}", e.kind()))?;
            ensure!(hash(&check.to_vec()) == r.sha256, "committed hash mismatch");
            fs::remove_file(entry.path())?;
            uploaded += 1;
        }
        Ok(json!({"uploaded":uploaded,"held":held,"offline":false}))
    }
}
pub fn atomic(path: &Path, b: &[u8]) -> Result<()> {
    crate::identity::atomic(path, b)
}

#[derive(Serialize, Deserialize)]
struct Download {
    size: u64,
    etag: String,
    scope: String,
    expected_sha256: String,
    hashes: Vec<String>,
}
fn revision(meta: &opendal::Metadata, cfg: &Config) -> Result<String> {
    if let Some(etag) = meta.etag() {
        return Ok(format!("etag:{etag}"));
    }
    // Google Drive's current OpenDAL service exposes length/time but no
    // ETag/version/hash. Never silently equate size+mtime with identity.
    let expected = cfg.get("expected_sha256");
    ensure!(
        expected.len() == 64 && expected.bytes().all(|b| b.is_ascii_hexdigit()),
        "stable ETag or trusted external SHA256 required for resume"
    );
    Ok(format!("external-sha256:{expected}"))
}
pub async fn download(cfg: &Config, op: &Operator) -> Result<serde_json::Value> {
    fs::create_dir_all(&cfg.work)?;
    let name = cfg.get("path");
    let google = if cfg.provider == "drive" {
        Some(
            crate::replace::identity(cfg, name)
                .await?
                .ok_or_else(|| anyhow::anyhow!("Google source missing"))?,
        )
    } else {
        None
    };
    let (size, etag) = if let Some(identity) = &google {
        (
            identity.size,
            format!("gdrive:{}:{}", identity.id, identity.etag),
        )
    } else {
        let meta = op
            .stat(name)
            .await
            .map_err(|e| anyhow::anyhow!("download stat {:?}", e.kind()))?;
        (meta.content_length(), revision(&meta, cfg)?)
    };
    let scope = hash(
        format!(
            "{}:{}:{}:{}:{}:{}",
            cfg.provider,
            cfg.root,
            cfg.get("connection_id"),
            cfg.get("bucket"),
            cfg.get("endpoint"),
            name
        )
        .as_bytes(),
    );
    let cp = cfg.work.join("download.json");
    let part = cfg.work.join("download.part");
    let mut c = if cp.exists() {
        serde_json::from_slice::<Download>(&fs::read(&cp)?)?
    } else {
        Download {
            size,
            etag: etag.clone(),
            scope: scope.clone(),
            expected_sha256: cfg.get("expected_sha256").to_string(),
            hashes: vec![],
        }
    };
    ensure!(
        c.size == size
            && c.etag == etag
            && c.scope == scope
            && c.expected_sha256 == cfg.get("expected_sha256"),
        "remote revision changed: partial held"
    );
    let mut f = OpenOptions::new()
        .create(true)
        .truncate(false)
        .read(true)
        .write(true)
        .open(&part)?;
    let chunk = cfg
        .get("chunk_bytes")
        .parse::<u64>()
        .unwrap_or(1024 * 1024)
        .clamp(1024 * 1024, 8 * 1024 * 1024);
    let mut offset = 0;
    for h in &c.hashes {
        ensure!(offset < c.size, "checkpoint contains excess chunks");
        let n = chunk.min(c.size - offset);
        let mut b = vec![0; n as usize];
        f.read_exact(&mut b)?;
        ensure!(hash(&b) == *h, "partial chunk corrupt");
        offset += n
    }
    f.set_len(offset)?;
    f.seek(SeekFrom::Start(offset))?;
    let start = offset;
    let stop = cfg.get("stop_after_chunks").parse::<usize>().unwrap_or(0);
    while offset < c.size {
        let end = (offset + chunk).min(c.size);
        let b = if let Some(identity) = &google {
            crate::replace::drive_range(cfg, identity, offset, end).await?
        } else {
            op.read_with(name)
                .range(offset..end)
                .await
                .map_err(|e| anyhow::anyhow!("download range {:?}", e.kind()))?
                .to_vec()
        };
        ensure!(b.len() as u64 == end - offset, "short range");
        f.write_all(&b)?;
        f.sync_all()?;
        c.hashes.push(hash(&b));
        atomic(&cp, &serde_json::to_vec(&c)?)?;
        offset = end;
        let delay = cfg.get("delay_ms").parse::<u64>().unwrap_or(0);
        if delay > 0 {
            tokio::time::sleep(std::time::Duration::from_millis(delay)).await;
        }
        if stop > 0 && c.hashes.len() >= stop {
            break;
        }
    }
    if let Some(original) = &google {
        let after = crate::replace::identity(cfg, name)
            .await?
            .ok_or_else(|| anyhow::anyhow!("Google source removed during read"))?;
        ensure!(
            after.id == original.id && after.etag == original.etag && after.size == original.size,
            "Google revision changed during read; partial held"
        );
    } else {
        let after = op
            .stat(name)
            .await
            .map_err(|e| anyhow::anyhow!("download revalidate {:?}", e.kind()))?;
        ensure!(
            revision(&after, cfg)? == c.etag && after.content_length() == c.size,
            "remote revision changed during read"
        );
    }
    let done = offset == c.size;
    drop(f);
    let digest = if done {
        Some(crate::v2::file_hash(&part)?)
    } else {
        None
    };
    if done && !c.expected_sha256.is_empty() {
        ensure!(
            digest.as_deref() == Some(c.expected_sha256.as_str()),
            "trusted final SHA256 mismatch; partial held"
        );
    }
    Ok(
        json!({"completed":done,"resumed_from":start,"received_bytes":offset-start,"total_bytes":c.size,"sha256":digest,"checkpoint_chunks":c.hashes.len(),"revision_source":if google.is_some(){"Google frozen ID + conditional ETag"}else if c.etag.starts_with("external-"){"trusted external SHA256"}else{"backend ETag"}}),
    )
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn no_path_escape() {
        for p in ["../a", "a/../b", "a:b", "a/./b"] {
            assert!(checked(p).is_err())
        }
        assert_eq!(checked("\\hello\\한글.txt").unwrap(), "hello/한글.txt")
    }
    #[test]
    fn deterministic_fixture() {
        assert_eq!(hash(&corpus(1024)), hash(&corpus(1024)));
        assert_ne!(hash(&corpus(1024)), hash(&corpus(1025)))
    }
    fn fixture(name: &str) -> Config {
        let base = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join(".local/unit")
            .join(format!(
                "{}-{}-{}",
                name,
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ));
        let remote = base.join("remote");
        fs::create_dir_all(&remote).unwrap();
        Config {
            provider: "fs".to_string(),
            root: "SigmaDrive-OpenDAL-PoC-unit".to_string(),
            options: std::collections::HashMap::from([(
                "local_root".to_string(),
                remote.to_string_lossy().to_string(),
            )]),
            work: base.join("cache"),
            mode: String::new(),
            mount: String::new(),
        }
    }
    #[tokio::test]
    async fn crash_replay_holds_incomplete_and_replays_closed() {
        let cfg = fixture("replay");
        let op = cfg.operator().unwrap();
        let e = Engine::new(cfg.clone(), op.clone()).unwrap();
        fs::write(e.data("incomplete.bin").unwrap(), b"partial").unwrap();
        e.mark("incomplete.bin", false).unwrap();
        fs::write(e.data("closed.bin").unwrap(), b"closed durable file").unwrap();
        e.mark("closed.bin", true).unwrap();
        drop(e);
        let e = Engine::new(cfg, op.clone()).unwrap();
        let r = e.recover().await.unwrap();
        assert_eq!(r["uploaded"], 1);
        assert_eq!(r["held"], 1);
        assert_eq!(
            op.read("closed.bin").await.unwrap().to_vec(),
            b"closed durable file"
        );
        assert!(op.stat("incomplete.bin").await.is_err());
    }
    #[tokio::test]
    async fn changed_remote_and_corrupt_cache_are_preserved() {
        let cfg = fixture("conflict");
        let op = cfg.operator().unwrap();
        let e = Engine::new(cfg, op.clone()).unwrap();
        fs::write(e.data("conflict.bin").unwrap(), b"local").unwrap();
        e.mark("conflict.bin", true).unwrap();
        op.write("conflict.bin", "remote edit").await.unwrap();
        let r = e.recover().await.unwrap();
        assert_eq!(r["held"], 1);
        assert_eq!(
            op.read("conflict.bin").await.unwrap().to_vec(),
            b"remote edit"
        );
        fs::write(e.data("bad.bin").unwrap(), b"before").unwrap();
        e.mark("bad.bin", true).unwrap();
        fs::write(e.data("bad.bin").unwrap(), b"after corruption").unwrap();
        assert!(e.recover().await.is_err());
        assert!(op.stat("bad.bin").await.is_err());
    }
    #[test]
    fn cache_rejects_other_scope() {
        let cfg = fixture("scope");
        let e = Engine::new(cfg.clone(), cfg.operator().unwrap()).unwrap();
        drop(e);
        let mut other = cfg;
        other.root.push_str("-other-account");
        assert!(Engine::new(other.clone(), other.operator().unwrap()).is_err());
    }
    #[tokio::test]
    async fn download_rejects_corrupt_partial_scope_and_changed_content() {
        let mut cfg = fixture("download");
        let op = cfg.operator().unwrap();
        let data = corpus(4 * 1024 * 1024);
        op.write("file.bin", data.clone()).await.unwrap();
        cfg.options.insert("path".into(), "file.bin".into());
        cfg.options.insert("expected_sha256".into(), hash(&data));
        cfg.options.insert("stop_after_chunks".into(), "2".into());
        let a = download(&cfg, &op).await.unwrap();
        assert_eq!(a["received_bytes"], 2 * 1024 * 1024);
        assert_eq!(a["completed"], false);
        let mut other = cfg.clone();
        other.root.push_str("-other");
        assert!(download(&other, &op).await.is_err());
        let part = cfg.work.join("download.part");
        let mut f = OpenOptions::new().write(true).open(&part).unwrap();
        f.write_all(b"X").unwrap();
        drop(f);
        assert!(download(&cfg, &op).await.is_err());
        fs::write(&part, &data[..2 * 1024 * 1024]).unwrap();
        cfg.options.remove("stop_after_chunks");
        let mut changed = data.clone();
        changed[3 * 1024 * 1024] ^= 255;
        op.write("file.bin", changed).await.unwrap();
        assert!(download(&cfg, &op).await.is_err());
        assert!(part.exists());
    }
}
