//! Registered-device control plane. No file names, paths or transfer telemetry.
use crate::state::{Core, now};
use anyhow::{Result, bail, ensure};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{sync::Arc, time::Duration};

pub async fn enroll(core: Arc<Core>) -> Result<Value> {
    let _control = core.share_control.lock().await;
    crate::profile::readiness(&core).await?;
    let member = core
        .data
        .read()
        .await
        .member
        .clone()
        .ok_or_else(|| anyhow::anyhow!("member login required"))?;
    ensure!(
        member["expiresAt"].as_u64().unwrap_or(0) > now(),
        "membership expired; renewal required"
    );
    let endpoint = member["endpoint"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("member authority missing"))?;
    let credential = member["credential"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("member credential missing"))?;
    let existing = core.data.read().await.share_identity.clone();
    let mut identity = if let Some(i) = existing {
        i
    } else {
        let key = rcgen::KeyPair::generate_for(&rcgen::PKCS_ED25519)?;
        let mut params = rcgen::CertificateParams::new(vec!["localhost".to_owned()])?;
        params
            .distinguished_name
            .push(rcgen::DnType::CommonName, "SigmaDrive.Share node");
        params.not_before = time::OffsetDateTime::now_utc() - time::Duration::minutes(1);
        params.not_after = time::OffsetDateTime::now_utc() + time::Duration::days(365);
        params.key_usages = vec![rcgen::KeyUsagePurpose::DigitalSignature];
        params.extended_key_usages = vec![
            rcgen::ExtendedKeyUsagePurpose::ClientAuth,
            rcgen::ExtendedKeyUsagePurpose::ServerAuth,
        ];
        let cert = params.self_signed(&key)?;
        let i = json!({"certificate":cert.pem(),"key":key.serialize_pem(),"pin":hex::encode(Sha256::digest(cert.der().as_ref())),"bound_member":member["memberId"],"state":"pending"});
        let mut data = core.data.write().await;
        let mut next = data.clone();
        next.share_identity = Some(i.clone());
        core.persist(&next)?;
        *data = next;
        i
    };
    ensure!(
        identity["bound_member"] == member["memberId"],
        "device identity belongs to a different member"
    );
    if identity["credential"]
        .as_str()
        .is_some_and(|s| !s.is_empty())
    {
        report(&core).await?;
        let profile = call_with(&identity, "GET", "/v1/node", None).await?;
        ensure!(
            profile["id"] == identity["node"]
                && profile["user"] == member["memberId"]
                && profile["pin"] == identity["pin"],
            "saved device identity no longer matches"
        );
        identity["state"] = json!("enrolled");
        let mut data = core.data.write().await;
        let mut next = data.clone();
        next.share_identity = Some(identity.clone());
        core.persist(&next)?;
        *data = next;
        return Ok(
            json!({"node":identity["node"],"pin":identity["pin"],"enrolled":true,"connected":true}),
        );
    }
    let result = crate::auth::member_request(
        endpoint,
        reqwest::Method::POST,
        "share/enroll",
        credential,
        Some(json!({"pin":identity["pin"]})),
    )
    .await?;
    ensure!(
        result["memberId"] == member["memberId"]
            && result["node"].as_str().is_some_and(|s| !s.is_empty())
            && result["credential"].as_str().is_some_and(|s| !s.is_empty()),
        "invalid enrolled member/device response"
    );
    ensure!(
        result["controlURL"] == "https://team.sigmadrive.net",
        "unexpected control origin; registration not activated"
    );
    let config =
        crate::auth::member_request(endpoint, reqwest::Method::GET, "config", "", None).await?;
    identity["credential"] = result["credential"].clone();
    identity["control_url"] = result["controlURL"].clone();
    identity["node"] = result["node"].clone();
    identity["ca"] = config["shareCA"].clone();
    // The response rotates a device token. Persist before any further network I/O.
    {
        let mut data = core.data.write().await;
        let mut next = data.clone();
        next.node = result["node"].as_str().unwrap().into();
        next.share_identity = Some(identity.clone());
        core.persist(&next)?;
        *data = next;
    }
    report(&core).await?;
    // Verify actual TLS proof and returned member binding before marking enrolled.
    let profile = call_with(&identity, "GET", "/v1/node", None).await?;
    ensure!(
        profile["id"] == result["node"]
            && profile["user"] == member["memberId"]
            && profile["pin"] == identity["pin"],
        "device binding verification failed"
    );
    identity["state"] = json!("enrolled");
    let mut data = core.data.write().await;
    let mut next = data.clone();
    next.node = result["node"].as_str().unwrap().into();
    next.share_identity = Some(identity.clone());
    core.persist(&next)?;
    *data = next;
    Ok(json!({"node":result["node"],"pin":identity["pin"],"enrolled":true,"connected":false}))
}
pub async fn report(core: &Core) -> Result<()> {
    let mut readiness = crate::profile::readiness(core).await;
    let data = core.data.read().await;
    if !data.online.as_ref().is_some_and(|p| p.enabled) {
        readiness = Err(anyhow::anyhow!("profile paused"));
    }
    let Some(identity) = data
        .share_identity
        .as_ref()
        .filter(|i| i["node"].as_str().is_some_and(|s| !s.is_empty()))
    else {
        return Ok(());
    };
    let member = data
        .member
        .as_ref()
        .ok_or_else(|| anyhow::anyhow!("member login required"))?;
    if !(member["expiresAt"].as_u64().unwrap_or(0) > now()
        && identity["bound_member"] == member["memberId"])
    {
        drop(data);
        crate::sharing::stop_all(core).await;
        anyhow::bail!("membership expired or device owner mismatch");
    }
    ensure!(
        member["expiresAt"].as_u64().unwrap_or(0) > now()
            && identity["bound_member"] == member["memberId"],
        "membership expired or device owner mismatch"
    );
    let endpoint = member["endpoint"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("member authority missing"))?
        .to_owned();
    let credential = member["credential"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("member credential missing"))?
        .to_owned();
    let shares=data.shares.values().map(|s|json!({"id":s["id"],"protocol":"s3","state":if readiness.is_ok()&&s["enabled"]==true{"ready"}else{"paused"},"port":0,"members":[]})).collect::<Vec<_>>();
    ensure!(shares.len() <= 64, "member report share limit reached");
    let body = json!({"node":identity["node"],"readiness":if readiness.is_ok(){"ready"}else{"profile_unavailable"},"profileProvider":readiness.as_ref().map(String::as_str).unwrap_or(""),"shares":shares});
    drop(data);
    if readiness.is_err() {
        crate::sharing::stop_all(core).await;
    }
    crate::auth::member_request(
        &endpoint,
        reqwest::Method::POST,
        "share/report",
        &credential,
        Some(body),
    )
    .await?;
    Ok(())
}
pub async fn call(core: &Core, method: &str, path: &str, body: Option<Value>) -> Result<Value> {
    let identity = core
        .data
        .read()
        .await
        .share_identity
        .clone()
        .ok_or_else(|| anyhow::anyhow!("registered Rust device required"))?;
    let revocation = method == "DELETE"
        || (path == "/v1/access-requests/decision"
            && body.as_ref().is_some_and(|b| {
                matches!(
                    b["status"].as_str(),
                    Some("revoked" | "rejected" | "cancelled")
                )
            }));
    if !revocation {
        let data = core.data.read().await;
        ensure!(
            data.member
                .as_ref()
                .is_some_and(|m| m["memberId"] == identity["bound_member"]
                    && m["expiresAt"].as_u64().unwrap_or(0) > now())
                && data.online.as_ref().is_some_and(|p| p.enabled),
            "active member and profile required"
        );
    }
    ensure!(
        identity["state"] == "enrolled",
        "device enrollment incomplete"
    );
    call_with(&identity, method, path, body).await
}
async fn call_with(
    identity: &Value,
    method: &str,
    path: &str,
    body: Option<Value>,
) -> Result<Value> {
    ensure!(
        matches!(
            path,
            "/v1/node"
                | "/v1/members"
                | "/v1/shares"
                | "/v1/access-requests"
                | "/v1/access-requests/decision"
                | "/v1/node/presence"
                | "/v1/sessions"
                | "/v1/sessions/check"
                | "/v1/member-invites"
                | "/v1/member-invites/accept"
        ) || (method == "DELETE"
            && path
                .strip_prefix("/v1/shares/")
                .is_some_and(|s| s.starts_with("share-")
                    && s.len() <= 128
                    && s.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-'))),
        "control path is not permitted"
    );
    let certificate = identity["certificate"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("device certificate missing"))?;
    let key = identity["key"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("device key missing"))?;
    let pem = zeroize::Zeroizing::new(format!("{certificate}\n{key}"));
    let mut client = reqwest::Client::builder()
        .identity(reqwest::Identity::from_pem(pem.as_bytes())?)
        .redirect(reqwest::redirect::Policy::none())
        .tls_version_min(reqwest::tls::Version::TLS_1_3)
        .timeout(Duration::from_secs(10));
    if let Some(ca) = identity["ca"].as_str().filter(|s| !s.is_empty()) {
        ensure!(
            ca.len() <= 65536 && !ca.contains("PRIVATE KEY"),
            "invalid public authority CA"
        );
        for cert in reqwest::Certificate::from_pem_bundle(ca.as_bytes())? {
            client = client.add_root_certificate(cert);
        }
    }
    ensure!(
        identity["control_url"] == "https://team.sigmadrive.net",
        "control origin not permitted"
    );
    let mut request = client
        .build()?
        .request(
            reqwest::Method::from_bytes(method.as_bytes())?,
            format!("https://team.sigmadrive.net{path}"),
        )
        .bearer_auth(
            identity["credential"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("device credential missing"))?,
        );
    if let Some(body) = body {
        request = request.json(&body);
    }
    let response = request
        .send()
        .await
        .map_err(|_| anyhow::anyhow!("share control unavailable"))?;
    match response.status().as_u16() {
        200 => (),
        401 | 403 => bail!("share permission denied or expired"),
        503 => bail!("publisher offline"),
        429 => bail!("relay capacity exceeded"),
        s => bail!("control HTTP {s}"),
    }
    use futures_util::StreamExt;
    let mut stream = response.bytes_stream();
    let mut bytes = Vec::new();
    while let Some(c) = stream.next().await {
        let c = c.map_err(|_| anyhow::anyhow!("control response unavailable"))?;
        ensure!(
            bytes.len() + c.len() <= 4 * 1024 * 1024,
            "control response exceeds limit"
        );
        bytes.extend_from_slice(&c);
    }
    if bytes.is_empty() {
        Ok(json!({}))
    } else {
        Ok(serde_json::from_slice(&bytes)?)
    }
}
