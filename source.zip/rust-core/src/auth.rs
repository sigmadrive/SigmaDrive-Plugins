//! Native OAuth code/PKCE and refresh. Tokens never leave this core.
use crate::state::{Connection, Core, id, now};
use anyhow::{Result, bail, ensure};
use base64::Engine as _;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::TcpListener,
    sync::Mutex,
};

pub struct Flow {
    pub canceled: Arc<AtomicBool>,
    pub result: Arc<Mutex<Option<std::result::Result<Value, String>>>>,
}
fn client() -> Result<reqwest::Client> {
    Ok(reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .tls_version_min(reqwest::tls::Version::TLS_1_3)
        .timeout(Duration::from_secs(30))
        .build()?)
}
fn endpoints(provider: &str) -> Result<(&'static str, &'static str)> {
    match provider {
        "drive" => Ok((
            "https://accounts.google.com/o/oauth2/v2/auth",
            "https://oauth2.googleapis.com/token",
        )),
        "onedrive" => Ok((
            "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
            "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        )),
        _ => bail!("unsupported OAuth provider"),
    }
}
pub async fn member_request(
    endpoint: &str,
    method: reqwest::Method,
    path: &str,
    credential: &str,
    body: Option<Value>,
) -> Result<Value> {
    let u = reqwest::Url::parse(endpoint)?;
    ensure!(
        u.scheme() == "https"
            && u.username().is_empty()
            && u.password().is_none()
            && u.query().is_none()
            && u.fragment().is_none()
            && matches!(
                u.host_str(),
                Some("console.sigmadrive.net" | "www.sigmadrive.net")
            )
            && u.port_or_known_default() == Some(443)
            && (u.path() == "/" || u.path().is_empty()),
        "invalid membership authority endpoint"
    );
    ensure!(
        matches!(
            path,
            "config"
                | "challenge"
                | "session"
                | "session/renew"
                | "logout"
                | "share/enroll"
                | "share/report"
                | "me"
        ),
        "invalid member operation"
    );
    let mut r = client()?.request(
        method,
        format!(
            "{}/sigma-api/v1/member/{path}",
            endpoint.trim_end_matches('/')
        ),
    );
    if !credential.is_empty() {
        if path == "share/report" {
            r = r.timeout(Duration::from_secs(5));
        }
        r = r.bearer_auth(credential);
    }
    if let Some(body) = body {
        ensure!(
            serde_json::to_vec(&body)?.len() <= 8192,
            "membership request exceeds server bound"
        );
        r = r.json(&body);
    }
    let response = r
        .send()
        .await
        .map_err(|_| anyhow::anyhow!("member_unavailable"))?;
    ensure!(
        response.status().is_success(),
        "membership authority HTTP {}",
        response.status().as_u16()
    );
    bounded(response).await
}
async fn bounded(response: reqwest::Response) -> Result<Value> {
    use futures_util::StreamExt;
    let mut stream = response.bytes_stream();
    let mut bytes = Vec::new();
    while let Some(chunk) = stream.next().await {
        let chunk = chunk.map_err(|_| anyhow::anyhow!("provider response failed"))?;
        ensure!(
            bytes.len() + chunk.len() <= 1024 * 1024,
            "provider response bound exceeded"
        );
        bytes.extend_from_slice(&chunk);
    }
    Ok(serde_json::from_slice(&bytes)?)
}
pub async fn start(core: Arc<Core>, body: Value) -> Result<Value> {
    let epoch = core.auth_epoch.load(Ordering::Acquire);
    let catalog = body["catalog_id"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("catalog ID required"))?;
    let (provider, profile) = match catalog {
        "drive" => ("drive", false),
        "onedrive" => ("onedrive", false),
        "profile-google" => ("drive", true),
        "profile-onedrive" => ("onedrive", true),
        _ => bail!("OAuth provider unavailable"),
    };
    let mut values: HashMap<String, String> =
        serde_json::from_value(body.get("values").cloned().unwrap_or(json!({})))?;
    let replacement = if let Some(id) = body["connection"]["id"].as_str().filter(|s| !s.is_empty())
    {
        let old = core.connection(id).await?;
        ensure!(
            old.provider == provider && (old.preset == "profile") == profile,
            "reconnect provider/profile mismatch"
        );
        for k in ["client_id", "client_secret"] {
            if let Some(v) = old.secrets.get(k) {
                values.insert(k.into(), v.clone());
            }
        }
        Some(old)
    } else {
        None
    };
    if let Some(source) = values.remove("source_connection") {
        let c = core.connection(&source).await?;
        ensure!(
            c.provider == provider,
            "registration source provider mismatch"
        );
        for k in ["client_id", "client_secret"] {
            if let Some(v) = c.secrets.get(k) {
                values.entry(k.into()).or_insert_with(|| v.clone());
            }
        }
    }
    let client_id = values
        .get("client_id")
        .filter(|v| !v.is_empty())
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("OAuth app client ID required"))?;
    ensure!(
        provider != "onedrive" || values.get("client_secret").is_none_or(|s| s.is_empty()),
        "Microsoft desktop sign-in requires a public client without a secret"
    );
    let (auth_url, token_url) = endpoints(provider)?;
    let listener = TcpListener::bind("127.0.0.1:53682").await.map_err(|_| {
        anyhow::anyhow!("OAuth callback port is in use; finish or cancel the other login")
    })?;
    let redirect = "http://localhost:53682/";
    let verifier = format!(
        "{}{}",
        uuid::Uuid::new_v4().simple(),
        uuid::Uuid::new_v4().simple()
    );
    let challenge = base64::engine::general_purpose::URL_SAFE_NO_PAD
        .encode(Sha256::digest(verifier.as_bytes()));
    let state = id("oauth");
    let flowid = id("signin");
    let scope = match (provider, profile) {
        ("drive", false) => "https://www.googleapis.com/auth/drive",
        ("drive", true) => "openid https://www.googleapis.com/auth/drive.appdata",
        ("onedrive", false) => "Files.ReadWrite offline_access",
        _ => "openid Files.ReadWrite.AppFolder offline_access",
    };
    let mut url = reqwest::Url::parse(auth_url)?;
    url.query_pairs_mut().extend_pairs([
        ("client_id", client_id.as_str()),
        ("response_type", "code"),
        ("redirect_uri", redirect),
        ("scope", scope),
        ("state", state.as_str()),
        ("code_challenge", challenge.as_str()),
        ("code_challenge_method", "S256"),
        (
            "prompt",
            if provider == "drive" {
                "consent select_account"
            } else {
                "select_account"
            },
        ),
    ]);
    if provider == "drive" {
        url.query_pairs_mut().append_pair("access_type", "offline");
    }
    let endpoint = values.remove("member_server").unwrap_or_default();
    let terms = values.remove("member_terms").unwrap_or_default();
    let member_challenge = if !endpoint.is_empty() {
        ensure!(
            profile,
            "membership requires separate profile authorization"
        );
        let cfg = member_request(&endpoint, reqwest::Method::GET, "config", "", None).await?;
        ensure!(
            !terms.is_empty() && cfg["termsVersion"].as_str() == Some(&terms),
            "review current membership terms"
        );
        let proof=member_request(&endpoint,reqwest::Method::POST,"challenge","",Some(json!({"provider":if provider=="drive"{"google"}else{"microsoft"},"clientId":client_id}))).await?;
        url.query_pairs_mut().append_pair(
            "nonce",
            proof["nonce"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("missing identity nonce"))?,
        );
        Some(proof)
    } else {
        None
    };
    let result = Arc::new(Mutex::new(None));
    let canceled = Arc::new(AtomicBool::new(false));
    core.flows.lock().await.insert(
        flowid.clone(),
        Flow {
            canceled: canceled.clone(),
            result: result.clone(),
        },
    );
    let name = body["connection"]["name"]
        .as_str()
        .unwrap_or(if provider == "drive" {
            "Google Drive"
        } else {
            "OneDrive"
        })
        .to_owned();
    let provider = provider.to_string();
    tokio::spawn(async move {
        let outcome:Result<Value>=async {
            let deadline=tokio::time::Instant::now()+Duration::from_secs(600);
            let code=loop {
                ensure!(!canceled.load(Ordering::Acquire),"login canceled");
                ensure!(tokio::time::Instant::now()<deadline,"login expired");
                let Ok(Ok((mut socket,peer)))=tokio::time::timeout(Duration::from_millis(200),listener.accept()).await else{continue};
                ensure!(peer.ip().is_loopback(),"non-loopback callback denied");
                let mut buf=Vec::new();
                tokio::time::timeout(Duration::from_secs(5),async {
                    while !buf.windows(4).any(|s|s==b"\r\n\r\n") {
                        let mut piece=[0u8;2048]; let n=socket.read(&mut piece).await?;
                        ensure!(n>0 && buf.len()+n<=16384,"invalid OAuth callback headers");
                        buf.extend_from_slice(&piece[..n]);
                    }
                    Ok::<(),anyhow::Error>(())
                }).await??;
                let req=std::str::from_utf8(&buf)?;
                let target=req.lines().next().and_then(|line|line.strip_prefix("GET ")).and_then(|line|line.strip_suffix(" HTTP/1.1"));
                let parsed=target.and_then(|p|reqwest::Url::parse(&format!("http://localhost:53682{p}")).ok());
                let params:HashMap<String,String>=parsed.as_ref().map(|u|u.query_pairs().into_owned().collect()).unwrap_or_default();
                let valid=parsed.as_ref().is_some_and(|u|u.path()=="/")&&params.get("state")==Some(&state);
                let page=if valid{"인증 응답을 받았습니다. SigmaDrive 앱으로 돌아가 최종 연결 결과를 확인해 주세요. 이 페이지는 연결 성공을 보장하지 않습니다."}else{"Invalid authentication response."};
                let response=format!("HTTP/1.1 {}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n{}",if valid{"200 OK"}else{"400 Bad Request"},page.len(),page);
                socket.write_all(response.as_bytes()).await?;
                if !valid {continue;}
                ensure!(!params.contains_key("error"),"authentication declined");
                break params.get("code").cloned().ok_or_else(||anyhow::anyhow!("authorization code missing"))?;
            };
            let mut form=vec![("client_id",client_id.as_str()),("grant_type","authorization_code"),("code",code.as_str()),("redirect_uri",redirect),("code_verifier",verifier.as_str())];
            if let Some(s)=values.get("client_secret"){form.push(("client_secret",s));}
            let response=client()?.post(token_url).form(&form).send().await.map_err(|_|anyhow::anyhow!("token exchange unavailable"))?;
            ensure!(response.status().is_success(),"token exchange rejected HTTP {}",response.status().as_u16());
            let mut token=bounded(response).await?;
            ensure!(token["access_token"].as_str().is_some_and(|s|!s.is_empty()),"provider returned no access credential");
            token["expires_at"]=json!(now()+token["expires_in"].as_u64().unwrap_or(3600)*1000);
            let mut conn=Connection{id:id("connection"),name,provider:provider.clone(),preset:if profile{"profile"}else{""}.into(),options:HashMap::new(),secrets:values};
            conn.secrets.insert("client_id".into(),client_id);
            conn.secrets.insert("oauth_token".into(),token.to_string());
            if profile {conn.options.insert("sigma_profile_only".into(),"true".into());}
            verify_identity(&mut conn,&token).await?;
            if let Some(old)=replacement.as_ref(){
                let owner=if provider=="drive"{"storage_owner"}else{"drive_id"};
                ensure!(old.options.get(owner).is_none_or(|v|conn.options.get(owner)==Some(v)),"sign in as the existing cloud storage owner");
                conn.id=old.id.clone();
            }
            let mut member=if let Some(challenge)=member_challenge {
                let mut m=member_request(&endpoint,reqwest::Method::POST,"session","",Some(json!({"challengeId":challenge["id"],"idToken":token["id_token"],"acceptance":terms}))).await?;
                m["connection"]=json!(conn.id);m["endpoint"]=json!(endpoint);Some(m)
            }else{None};
            ensure!(!canceled.load(Ordering::Acquire),"login canceled before credential commit");
            ensure!(core.auth_epoch.load(Ordering::Acquire)==epoch,"sign-in superseded by logout");
            let mut data=core.data.write().await;let mut next=data.clone();
            ensure!(core.auth_epoch.load(Ordering::Acquire)==epoch,"sign-in superseded by logout");
            if let Some(old)=replacement.as_ref(){ensure!(data.connections.get(&old.id).is_some_and(|c|c.provider==old.provider&&c.preset==old.preset&&c.options==old.options),"connection changed or was removed during sign-in");}
            if let Some(ref m)=member {
                if let Some(old)=data.member.as_ref(){ensure!(old["memberId"]==m["memberId"],"this local profile belongs to another SigmaDrive member; use a separate profile");}
                if let Some(identity)=data.share_identity.as_ref(){ensure!(identity["bound_member"]==m["memberId"],"registered device belongs to another SigmaDrive member");}
            }
            if profile && let Some(online)=data.online.as_ref() {
                let previous=data.connections.get(&online.connection).ok_or_else(||anyhow::anyhow!("profile connection missing"))?;
                let owner=if provider=="drive"{"storage_owner"}else{"drive_id"};
                ensure!(previous.provider==conn.provider&&previous.preset=="profile"&&previous.options.get(owner)==conn.options.get(owner)&&previous.secrets.get("client_id")==conn.secrets.get("client_id"),"sign in to the account and app that own this personal profile");
                conn.id=previous.id.clone();if let Some(m)=member.as_mut(){m["connection"]=json!(conn.id);}
            }
            let public=conn.public();
            next.connections.insert(conn.id.clone(),conn);if member.is_some(){next.member=member;}
            core.persist(&next)?;*data=next;Ok(public)
        }.await;
        *result.lock().await = Some(outcome.map_err(|e| e.to_string()));
    });
    Ok(json!({"id":flowid,"url":url.as_str()}))
}
pub async fn finish(core: &Core, id: &str) -> Result<Value> {
    let result = core
        .flows
        .lock()
        .await
        .get(id)
        .map(|f| f.result.clone())
        .ok_or_else(|| anyhow::anyhow!("login not active"))?;
    for _ in 0..6100 {
        if let Some(value) = result.lock().await.take() {
            core.flows.lock().await.remove(id);
            return value.map_err(anyhow::Error::msg);
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
    bail!("authentication wait expired")
}
pub async fn cancel(core: &Core, id: &str) -> Result<Value> {
    if let Some(flow) = core.flows.lock().await.get(id) {
        flow.canceled.store(true, Ordering::Release);
    }
    Ok(json!({}))
}
async fn verify_identity(c: &mut Connection, token: &Value) -> Result<()> {
    let access = token["access_token"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("access token missing"))?;
    let url = if c.provider == "drive" {
        "https://www.googleapis.com/drive/v3/about?fields=user(permissionId)"
    } else {
        "https://graph.microsoft.com/v1.0/me/drive?$select=id,driveType,owner"
    };
    let r = client()?
        .get(url)
        .bearer_auth(access)
        .send()
        .await
        .map_err(|_| anyhow::anyhow!("provider identity check unavailable"))?;
    ensure!(
        r.status().is_success(),
        "provider file access unavailable HTTP {}",
        r.status().as_u16()
    );
    let v = bounded(r).await?;
    let (key, value) = if c.provider == "drive" {
        ("storage_owner", v["user"]["permissionId"].as_str())
    } else {
        ("drive_id", v["id"].as_str())
    };
    c.options.insert(
        key.into(),
        value
            .filter(|s| !s.is_empty())
            .ok_or_else(|| anyhow::anyhow!("provider identity missing"))?
            .into(),
    );
    Ok(())
}
pub async fn fresh(core: &Core, id: &str) -> Result<Connection> {
    let lock = {
        core.credential_locks
            .lock()
            .map_err(|_| anyhow::anyhow!("credential lock failed"))?
            .entry(id.into())
            .or_insert_with(|| Arc::new(Mutex::new(())))
            .clone()
    };
    let _renewal = lock.lock().await;
    let mut c = core.connection(id).await?;
    if !matches!(c.provider.as_str(), "drive" | "onedrive") {
        return Ok(c);
    }
    let mut token: Value = serde_json::from_str(
        c.secrets
            .get("oauth_token")
            .ok_or_else(|| anyhow::anyhow!("provider login required"))?,
    )?;
    let old_credential = c.secrets.get("oauth_token").cloned();
    if token["expires_at"].as_u64().unwrap_or(0) > now() + 120000 {
        return Ok(c);
    }
    let (_, url) = endpoints(&c.provider)?;
    let refresh = token["refresh_token"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("provider reauthorization required"))?;
    let mut form = vec![
        (
            "client_id",
            c.secrets
                .get("client_id")
                .ok_or_else(|| anyhow::anyhow!("registration missing"))?
                .as_str(),
        ),
        ("grant_type", "refresh_token"),
        ("refresh_token", refresh),
    ];
    if let Some(s) = c.secrets.get("client_secret") {
        form.push(("client_secret", s));
    }
    let r = client()?
        .post(url)
        .form(&form)
        .send()
        .await
        .map_err(|_| anyhow::Error::new(crate::provider_http::Unavailable))?;
    ensure!(
        r.status().is_success(),
        "provider renewal HTTP {}",
        r.status().as_u16()
    );
    let mut next = bounded(r).await?;
    ensure!(
        next["access_token"].as_str().is_some_and(|s| !s.is_empty()),
        "renewal credential missing"
    );
    if next["refresh_token"].is_null() {
        next["refresh_token"] = token["refresh_token"].take();
    }
    next["expires_at"] = json!(now() + next["expires_in"].as_u64().unwrap_or(3600) * 1000);
    c.secrets.insert("oauth_token".into(), next.to_string());
    let mut data = core.data.write().await;
    if let Some(current) = data.connections.get(id)
        && current.secrets.get("oauth_token") != old_credential.as_ref()
    {
        return Ok(current.clone());
    }
    ensure!(
        data.connections.contains_key(id),
        "connection removed during renewal"
    );
    let mut next_data = data.clone();
    next_data.connections.insert(c.id.clone(), c.clone());
    core.persist(&next_data)?;
    *data = next_data;
    Ok(c)
}

pub async fn renew_member(core: &Core) -> Result<()> {
    let saved = core.data.read().await.member.clone();
    let Some(member) = saved else {
        return Ok(());
    };
    if member["expiresAt"].as_u64().unwrap_or(0) > now() + 12 * 3600 * 1000 {
        return Ok(());
    }
    let endpoint = member["endpoint"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("membership origin missing"))?;
    let credential = member["credential"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("membership credential missing"))?;
    let response = member_request(
        endpoint,
        reqwest::Method::POST,
        "session/renew",
        credential,
        Some(json!({})),
    )
    .await?;
    let server = response["serverTime"].as_u64().unwrap_or(0);
    let expires = response["expiresAt"].as_u64().unwrap_or(0);
    ensure!(
        response["memberId"] == member["memberId"]
            && response["provider"] == member["provider"]
            && server > 0
            && expires > server
            && expires - server <= 24 * 3600 * 1000
            && expires > now(),
        "invalid membership renewal response"
    );
    let mut data = core.data.write().await;
    let mut next = data.clone();
    let current = next
        .member
        .as_mut()
        .ok_or_else(|| anyhow::anyhow!("membership removed during renewal"))?;
    ensure!(
        current["memberId"] == member["memberId"] && current["credential"] == member["credential"],
        "membership changed during renewal"
    );
    current["expiresAt"] = json!(expires.max(current["expiresAt"].as_u64().unwrap_or(0)));
    current["renewedAt"] = json!(now());
    current["contracts"] = response["contracts"].clone();
    core.persist(&next)?;
    *data = next;
    Ok(())
}
