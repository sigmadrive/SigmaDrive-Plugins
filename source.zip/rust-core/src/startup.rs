//! Login startup belongs to the current Windows user, never a machine service.
use serde_json::{Value, json};
#[cfg(windows)]
fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}
#[cfg(windows)]
fn launcher() -> Result<std::path::PathBuf, String> {
    let installed = sigmadrive_distribution::install::root().map_err(|e| e.to_string())?;
    let expected =
        sigmadrive_distribution::install::executable(&installed).map_err(|e| e.to_string())?;
    if std::env::current_exe().map_err(|e| e.to_string())? == expected
        && installed.join("SigmaDrive.exe").is_file()
    {
        return Ok(installed.join("SigmaDrive.exe"));
    }
    let exe = std::env::current_exe().map_err(|_| "설치 경로를 확인하지 못했습니다.")?;
    let parent = exe.parent().ok_or("설치 경로 없음")?;
    let root = if parent.file_name().is_some_and(|n| n == "client") {
        parent.parent().ok_or("설치 경로 없음")?
    } else {
        parent
    };
    let target = root.join("sigmadrive_flutter.exe");
    if !root.join("rust-core-manifest.json").is_file() || !target.is_file() {
        return Err("Rust 코어 설치 검증을 통과한 앱에서만 자동 시작을 변경할 수 있습니다.".into());
    }
    Ok(target)
}
pub fn command(path: &std::path::Path) -> Result<String, String> {
    let p = path.to_str().ok_or("Invalid startup path")?;
    if !path.is_absolute() || p.contains(['"', '\0', '\n', '\r']) {
        return Err("Invalid startup path".into());
    }
    Ok(format!("\"{p}\" --startup"))
}
pub fn perform(enabled: Option<bool>) -> Result<Value, String> {
    #[cfg(not(windows))]
    {
        let _ = enabled;
        Ok(json!({"supported":false}))
    }
    #[cfg(windows)]
    {
        use windows_sys::Win32::{
            Foundation::{ERROR_FILE_NOT_FOUND, ERROR_SUCCESS},
            System::Registry::*,
        };
        let target = match launcher() {
            Ok(p) => p,
            Err(e) => {
                if enabled.is_some() {
                    return Err(e);
                }
                return Ok(json!({"supported":false,"reason":e}));
            }
        };
        let path = wide(r"Software\Microsoft\Windows\CurrentVersion\Run");
        let name = wide("SigmaDriveRustCore");
        let mut key = std::ptr::null_mut();
        if unsafe {
            RegCreateKeyExW(
                HKEY_CURRENT_USER,
                path.as_ptr(),
                0,
                std::ptr::null(),
                0,
                KEY_QUERY_VALUE | KEY_SET_VALUE,
                std::ptr::null(),
                &mut key,
                std::ptr::null_mut(),
            )
        } != ERROR_SUCCESS
        {
            return Err("자동 시작 설정에 접근하지 못했습니다.".into());
        }
        struct Key(HKEY);
        impl Drop for Key {
            fn drop(&mut self) {
                unsafe { RegCloseKey(self.0) };
            }
        }
        let _guard = Key(key);
        let expected = command(&target)?;
        if let Some(on) = enabled {
            let result = if on {
                let data = wide(&expected);
                unsafe {
                    RegSetValueExW(
                        key,
                        name.as_ptr(),
                        0,
                        REG_SZ,
                        data.as_ptr().cast(),
                        (data.len() * 2) as u32,
                    )
                }
            } else {
                unsafe { RegDeleteValueW(key, name.as_ptr()) }
            };
            if result != ERROR_SUCCESS && !(result == ERROR_FILE_NOT_FOUND && !on) {
                return Err("자동 시작 설정을 저장하지 못했습니다.".into());
            }
        }
        let mut kind = 0;
        let mut bytes = vec![0u16; 4096];
        let mut length = (bytes.len() * 2) as u32;
        let result = unsafe {
            RegQueryValueExW(
                key,
                name.as_ptr(),
                std::ptr::null(),
                &mut kind,
                bytes.as_mut_ptr().cast(),
                &mut length,
            )
        };
        let registered = result == ERROR_SUCCESS
            && kind == REG_SZ
            && length.is_multiple_of(2)
            && length as usize <= bytes.len() * 2;
        let actual = if registered {
            String::from_utf16_lossy(&bytes[..length as usize / 2])
                .trim_end_matches('\0')
                .to_string()
        } else {
            String::new()
        };
        Ok(
            json!({"supported":true,"enabled":actual==expected,"scope":"current-windows-user","after":"windows-sign-in","launcher":target}),
        )
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn startup_command_quotes_spaces_and_never_uses_shell() {
        let p = std::env::temp_dir().join("app with spaces/SigmaDriveFlutter.exe");
        assert_eq!(
            command(&p).unwrap(),
            format!("\"{}\" --startup", p.display())
        );
        assert!(command(std::path::Path::new("relative.exe")).is_err());
        assert!(command(&std::env::temp_dir().join("bad\".exe")).is_err());
    }
}
