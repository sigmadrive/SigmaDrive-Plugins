//! Optional engine delivery is pinned by the signed client, uses the same
//! immutable CDN chunks/fixed fallback, and never changes a running engine.
use anyhow::{Result, ensure};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::os::windows::fs::OpenOptionsExt;
use std::{
    fs::OpenOptions,
    io::{Read, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
};
pub const MANIFEST: &str = include_str!("../public/sigmadesk-files.json");
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub schema: u32,
    pub entry: String,
    pub files: Vec<Asset>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Asset {
    pub path: String,
    pub bytes: u64,
    pub sha256: String,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Delivery {
    version: String,
    commit: String,
    sha256: String,
    length: u64,
    manifest_sha256: String,
    chunks: Vec<Chunk>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Chunk {
    sha256: String,
    size: u64,
    wire_sha256: String,
    wire_size: u64,
}
/// Display only the version carried by the signed client's embedded delivery,
/// bound to its exact engine inventory. No remote metadata is used here.
pub fn version() -> Result<&'static str> {
    static VERSION: std::sync::OnceLock<Option<String>> = std::sync::OnceLock::new();
    VERSION.get_or_init(|| delivery_version(
        include_str!("../public/sigmadesk-delivery.json"), MANIFEST).ok())
        .as_deref().ok_or_else(|| anyhow::anyhow!("SigmaDesk embedded delivery version invalid"))
}
fn delivery_version(delivery: &str, manifest: &str) -> Result<String> {
    let d: Delivery = serde_json::from_str(delivery)?;
    ensure!(
        d.manifest_sha256 == hex::encode(Sha256::digest(manifest.as_bytes())),
        "SigmaDesk delivery manifest identity changed"
    );
    let plain = d.version.strip_suffix("-rust")
        .ok_or_else(|| anyhow::anyhow!("SigmaDesk delivery version invalid"))?;
    let parts: Vec<_> = plain.split('.').collect();
    ensure!(
        parts.len() == 3 && parts.iter().all(|part|
            !part.is_empty() && part.len() <= 10
                && part.bytes().all(|b| b.is_ascii_digit())
                && (*part == "0" || !part.starts_with('0'))
                && part.parse::<u32>().is_ok()),
        "SigmaDesk delivery version invalid"
    );
    Ok(d.version)
}
pub fn manifest() -> Result<Manifest> {
    let m: Manifest = serde_json::from_str(MANIFEST)?;
    ensure!(
        m.schema == 1 && m.entry == "rustdesk.exe" && !m.files.is_empty() && m.files.len() <= 8192,
        "SigmaDesk Flutter engine is not published yet"
    );
    let mut names = std::collections::HashSet::new();
    for a in &m.files {
        ensure!(
            !a.path.is_empty()
                && a.path.split('/').all(|p| !p.is_empty()
                    && p != "."
                    && p != ".."
                    && !p.contains(['\\', ':'])
                    && !p.ends_with([' ', '.']))
                && !a.path.ends_with(".sigma-part")
                && names.insert(a.path.to_ascii_lowercase()),
            "SigmaDesk asset path denied"
        );
    }
    ensure!(
        names.contains("rustdesk.exe")
            && names.contains("librustdesk.dll")
            && names.contains("flutter_windows.dll"),
        "SigmaDesk Flutter engine incomplete"
    );
    Ok(m)
}
pub fn bytes() -> u64 {
    manifest()
        .map(|m| m.files.iter().map(|a| a.bytes).sum())
        .unwrap_or(0)
}
pub fn root() -> Result<PathBuf> {
    Ok(sigmadrive_distribution::install::root()?
        .join("components")
        .join("sigmadesk")
        .join(hex::encode(Sha256::digest(MANIFEST.as_bytes()))))
}
fn private(path: &Path) -> Result<()> {
    sigmadrive_distribution::download::safe(path).map_err(anyhow::Error::msg)?;
    std::fs::create_dir_all(path)?;
    Ok(sigmadrive_distribution::identity::protect_own_local_directory(path)?)
}
pub fn install(cancel: &AtomicBool, notify: &mut dyn FnMut(u32, &str)) -> Result<()> {
    let m = manifest()?;
    let d: Delivery = serde_json::from_str(include_str!("../public/sigmadesk-delivery.json"))?;
    ensure!(
        d.manifest_sha256 == hex::encode(Sha256::digest(MANIFEST.as_bytes()))
            && d.length > 0
            && d.length <= 256 * 1024 * 1024
            && d.commit.len() == 40
            && d.commit.bytes().all(|b| b.is_ascii_hexdigit()),
        "SigmaDesk delivery identity denied"
    );
    let r = sigmadrive_distribution::trust::Release {
        filename: format!("sigmadesk-{}.component", d.manifest_sha256),
        version: d.version,
        sequence: 1,
        manifest_hash: d.manifest_sha256,
        verification: "signed-client-pinned-sigmadesk",
        hash: d.sha256,
        size: d.length,
        commit: d.commit,
        chunks: d
            .chunks
            .into_iter()
            .map(|c| sigmadrive_distribution::trust::Chunk {
                hash: c.sha256,
                size: c.size,
                wire: Some((c.wire_sha256, c.wire_size)),
            })
            .collect(),
    };
    let dest = root()?;
    if dest.exists() {
        crate::desk_windows::engine_files()?;
        return Ok(());
    }
    let parent = dest
        .parent()
        .ok_or_else(|| anyhow::anyhow!("component directory unavailable"))?;
    private(parent)?;
    let cache = parent.join("download-cache");
    private(&cache)?;
    let prepared = sigmadrive_distribution::download::prepare(&r, &cache, cancel, None, notify)
        .map_err(anyhow::Error::msg)?;
    let mut archive = OpenOptions::new()
        .read(true)
        .share_mode(1)
        .open(&prepared.path)?;
    let mut magic = [0; 8];
    archive.read_exact(&mut magic)?;
    ensure!(&magic == b"SDDESK1\n", "SigmaDesk component format denied");
    let mut length = [0; 4];
    archive.read_exact(&mut length)?;
    let length = u32::from_le_bytes(length) as usize;
    ensure!(
        length == MANIFEST.len() && length <= 2 * 1024 * 1024,
        "SigmaDesk component manifest denied"
    );
    let mut header = vec![0; length];
    archive.read_exact(&mut header)?;
    ensure!(
        header == MANIFEST.as_bytes(),
        "SigmaDesk component manifest mismatch"
    );
    let staging = parent.join(format!("pending-{}", r.manifest_hash));
    private(&staging)?;
    for asset in &m.files {
        ensure!(
            !cancel.load(Ordering::Acquire),
            "SigmaDesk installation cancelled for safe restart"
        );
        let file = staging.join(&asset.path);
        sigmadrive_distribution::download::safe(&file).map_err(anyhow::Error::msg)?;
        std::fs::create_dir_all(
            file.parent()
                .ok_or_else(|| anyhow::anyhow!("component parent unavailable"))?,
        )?;
        let temp = PathBuf::from(format!("{}.sigma-part", file.to_string_lossy()));
        sigmadrive_distribution::download::safe(&temp).map_err(anyhow::Error::msg)?;
        // This exact temporary member is inside the private, pinned component staging tree.
        if temp.exists() {
            ensure!(temp.is_file(), "non-file component temporary member");
            std::fs::remove_file(&temp)?;
        }
        let existing = file.exists();
        if existing {
            sigmadrive_distribution::download::verified(&file, asset.bytes, &asset.sha256)
                .map_err(anyhow::Error::msg)?;
        }
        let mut output = if existing {
            None
        } else {
            Some(
                OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(&temp)?,
            )
        };
        let mut left = asset.bytes;
        let mut hash = Sha256::new();
        let mut buffer = [0; 65536];
        while left > 0 {
            ensure!(
                !cancel.load(Ordering::Acquire),
                "SigmaDesk installation cancelled for safe restart"
            );
            let n = left.min(buffer.len() as u64) as usize;
            archive.read_exact(&mut buffer[..n])?;
            hash.update(&buffer[..n]);
            if let Some(f) = output.as_mut() {
                f.write_all(&buffer[..n])?;
            }
            left -= n as u64;
        }
        ensure!(
            hex::encode(hash.finalize()) == asset.sha256,
            "SigmaDesk component checksum failed"
        );
        if let Some(f) = output {
            f.sync_all()?;
            drop(f);
            std::fs::rename(temp, file)?;
        }
    }
    let mut extra = [0];
    ensure!(
        archive.read(&mut extra)? == 0,
        "trailing SigmaDesk component content"
    );
    crate::desk_windows::engine_files_at(&staging)?;
    ensure!(
        !cancel.load(Ordering::Acquire),
        "SigmaDesk installation cancelled for safe restart"
    );
    std::fs::rename(staging, dest)?;
    notify(100, "SigmaDesk 엔진 검증·설치를 완료했습니다.");
    Ok(())
}

#[cfg(test)]
mod version_tests {
    use super::*;
    use serde_json::{Value, json};

    fn delivery() -> Value {
        serde_json::from_str(include_str!("../public/sigmadesk-delivery.json")).unwrap()
    }
    #[test]
    fn engine_version_comes_from_the_matching_embedded_delivery() {
        for value in ["0.3.1-rust", "0.3.2-rust", "1.23.456-rust"] {
            let mut d = delivery(); d["version"] = json!(value);
            assert_eq!(delivery_version(&d.to_string(), MANIFEST).unwrap(), value);
        }
        assert_eq!(version().unwrap(), delivery()["version"].as_str().unwrap());
        let mut d = delivery(); d["manifest_sha256"] = json!("0".repeat(64));
        assert!(delivery_version(&d.to_string(), MANIFEST).is_err());
        assert!(delivery_version(&delivery().to_string(), "changed inventory").is_err());
    }
    #[test]
    fn engine_version_rejects_malformed_types_or_non_exact_release_labels() {
        for value in [Value::Null, json!(2), json!(true), json!({"version":"0.3.2-rust"}),
            json!("0.3.2"), json!("0.3.2-RUST"), json!("v0.3.2-rust"),
            json!("0.3.2.1-rust"), json!("0.03.2-rust"), json!("0.-1.2-rust"),
            json!("0.3.4294967296-rust"), json!("0.3.2-rust\n"), json!(" 0.3.2-rust")] {
            let mut d = delivery(); d["version"] = value;
            assert!(delivery_version(&d.to_string(), MANIFEST).is_err());
        }
        let mut d = delivery(); d.as_object_mut().unwrap().remove("version");
        assert!(delivery_version(&d.to_string(), MANIFEST).is_err());
    }
}
