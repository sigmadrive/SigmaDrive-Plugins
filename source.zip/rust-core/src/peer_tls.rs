//! Certificate pins are explicit local trust, followed by TLS proof of possession.
//! The outer relay's public PKI identity never substitutes for the peer identity.
use anyhow::{Result, ensure};
use rustls::{
    ClientConfig, DigitallySignedStruct, Error, ServerConfig, SignatureScheme,
    client::danger::{HandshakeSignatureValid, ServerCertVerified, ServerCertVerifier},
    pki_types::{CertificateDer, PrivateKeyDer, ServerName, UnixTime, pem::PemObject},
    server::danger::{ClientCertVerified, ClientCertVerifier},
};
use sha2::{Digest, Sha256};
use std::{
    collections::HashSet,
    sync::{Arc, RwLock},
};

pub type LocalPins = Arc<RwLock<HashSet<String>>>;
#[derive(Debug)]
struct PinnedPeer {
    pins: LocalPins,
    server: bool,
}
impl PinnedPeer {
    fn check(
        &self,
        leaf: &CertificateDer<'_>,
        chain: &[CertificateDer<'_>],
        now: UnixTime,
    ) -> std::result::Result<(), Error> {
        let deny = || Error::General("peer identity not approved or certificate invalid".into());
        if !chain.is_empty() || leaf.len() > 65536 {
            return Err(deny());
        }
        let pin = hex::encode(Sha256::digest(leaf.as_ref()));
        if !self.pins.read().map_err(|_| deny())?.contains(&pin) {
            return Err(deny());
        }
        let (rest, cert) =
            x509_parser::parse_x509_certificate(leaf.as_ref()).map_err(|_| deny())?;
        let at = x509_parser::time::ASN1Time::from_timestamp(
            now.as_secs().try_into().map_err(|_| deny())?,
        )
        .map_err(|_| deny())?;
        if !rest.is_empty() || !cert.validity().is_valid_at(at) {
            return Err(deny());
        }
        let usage = cert.key_usage().map_err(|_| deny())?.ok_or_else(deny)?;
        let extended = cert
            .extended_key_usage()
            .map_err(|_| deny())?
            .ok_or_else(deny)?;
        if !usage.value.digital_signature()
            || (self.server && !extended.value.server_auth)
            || (!self.server && !extended.value.client_auth)
        {
            return Err(deny());
        }
        Ok(())
    }
    fn signature(
        &self,
        message: &[u8],
        cert: &CertificateDer<'_>,
        dss: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        rustls::crypto::verify_tls13_signature(
            message,
            cert,
            dss,
            &rustls::crypto::ring::default_provider().signature_verification_algorithms,
        )
    }
    fn schemes(&self) -> Vec<SignatureScheme> {
        rustls::crypto::ring::default_provider()
            .signature_verification_algorithms
            .supported_schemes()
    }
}
impl ServerCertVerifier for PinnedPeer {
    fn verify_server_cert(
        &self,
        leaf: &CertificateDer<'_>,
        chain: &[CertificateDer<'_>],
        _: &ServerName<'_>,
        _: &[u8],
        now: UnixTime,
    ) -> std::result::Result<ServerCertVerified, Error> {
        self.check(leaf, chain, now)?;
        Ok(ServerCertVerified::assertion())
    }
    fn verify_tls12_signature(
        &self,
        _: &[u8],
        _: &CertificateDer<'_>,
        _: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        Err(Error::General("peer TLS 1.3 required".into()))
    }
    fn verify_tls13_signature(
        &self,
        m: &[u8],
        c: &CertificateDer<'_>,
        s: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        self.signature(m, c, s)
    }
    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        self.schemes()
    }
}
impl ClientCertVerifier for PinnedPeer {
    fn root_hint_subjects(&self) -> &[rustls::DistinguishedName] {
        &[]
    }
    fn verify_client_cert(
        &self,
        leaf: &CertificateDer<'_>,
        chain: &[CertificateDer<'_>],
        now: UnixTime,
    ) -> std::result::Result<ClientCertVerified, Error> {
        self.check(leaf, chain, now)?;
        Ok(ClientCertVerified::assertion())
    }
    fn verify_tls12_signature(
        &self,
        _: &[u8],
        _: &CertificateDer<'_>,
        _: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        Err(Error::General("peer TLS 1.3 required".into()))
    }
    fn verify_tls13_signature(
        &self,
        m: &[u8],
        c: &CertificateDer<'_>,
        s: &DigitallySignedStruct,
    ) -> std::result::Result<HandshakeSignatureValid, Error> {
        self.signature(m, c, s)
    }
    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        self.schemes()
    }
}
pub struct PeerIdentity {
    cert: Vec<CertificateDer<'static>>,
    key: PrivateKeyDer<'static>,
}
impl PeerIdentity {
    pub fn from_pem(certificate: &str, key: &str) -> Result<Self> {
        ensure!(
            certificate.len() <= 65536 && key.len() <= 16384,
            "invalid identity size"
        );
        let cert = CertificateDer::pem_slice_iter(certificate.as_bytes())
            .collect::<std::result::Result<Vec<_>, _>>()?;
        ensure!(cert.len() == 1, "one pinned device certificate required");
        let key = PrivateKeyDer::from_pem_slice(key.as_bytes())?;
        Ok(Self { cert, key })
    }
    pub fn client(&self, pin: &str) -> Result<Arc<ClientConfig>> {
        ensure!(crate::permit::valid_pin(pin), "invalid local publisher pin");
        let pins = Arc::new(RwLock::new(HashSet::from([pin.to_owned()])));
        let mut config =
            ClientConfig::builder_with_provider(Arc::new(rustls::crypto::ring::default_provider()))
                .with_protocol_versions(&[&rustls::version::TLS13])?
                .dangerous()
                .with_custom_certificate_verifier(Arc::new(PinnedPeer { pins, server: true }))
                .with_client_auth_cert(self.cert.clone(), self.key.clone_key())?;
        config.alpn_protocols = vec![b"http/1.1".to_vec()];
        config.resumption = rustls::client::Resumption::disabled();
        Ok(Arc::new(config))
    }
    pub fn server(&self, pins: LocalPins) -> Result<Arc<ServerConfig>> {
        let mut config =
            ServerConfig::builder_with_provider(Arc::new(rustls::crypto::ring::default_provider()))
                .with_protocol_versions(&[&rustls::version::TLS13])?
                .with_client_cert_verifier(Arc::new(PinnedPeer {
                    pins,
                    server: false,
                }))
                .with_single_cert(self.cert.clone(), self.key.clone_key())?;
        config.alpn_protocols = vec![b"http/1.1".to_vec()];
        // Re-check current local pins for every connection; do not resume revoked identities.
        config.send_tls13_tickets = 0;
        config.session_storage = Arc::new(rustls::server::NoServerSessionStorage {});
        Ok(Arc::new(config))
    }
}
