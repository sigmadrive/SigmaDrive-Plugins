//! Fixed, signed upstream dependency. Driver installation is a user action;
//! neither background recovery nor automatic updates invoke elevation.
use anyhow::{Result, ensure};
use serde_json::{Value, json};
pub fn status() -> Value {
    #[cfg(windows)]
    {
        let version = dokan::get_driver_version();
        json!({"supported":true,"driver":"Dokany","installed":version>=200,"version":version,"restart_may_be_required":true})
    }
    #[cfg(not(windows))]
    {
        json!({"supported":false,"installed":false})
    }
}
pub fn install() -> Result<Value> {
    #[cfg(windows)]
    {
        use sha2::{Digest, Sha256};
        use std::os::windows::ffi::OsStrExt;
        use windows_sys::Win32::UI::Shell::ShellExecuteW;
        let dir = std::env::current_exe()?
            .parent()
            .ok_or_else(|| anyhow::anyhow!("application directory missing"))?
            .to_path_buf();
        let path = dir.join("prerequisites/Dokan_x64.msi");
        let bytes = std::fs::read(&path)?;
        ensure!(
            bytes.len() == 9269248
                && hex::encode(Sha256::digest(&bytes))
                    == "69ff8cb37bfec3a75921c85ffd1c6370b50a9ec4ecef2cf3a009d488dcbf5465",
            "driver package integrity check failed"
        );
        // Resolve the OS directory through Windows, never a mutable environment
        // variable when starting an elevated, user-approved system installer.
        use std::os::windows::ffi::OsStringExt;
        use windows_sys::Win32::{
            System::Com::CoTaskMemFree,
            UI::Shell::{FOLDERID_System, SHGetKnownFolderPath},
        };
        let mut system = std::ptr::null_mut();
        ensure!(
            unsafe { SHGetKnownFolderPath(&FOLDERID_System, 0, std::ptr::null_mut(), &mut system) }
                >= 0
                && !system.is_null(),
            "Windows system directory unavailable"
        );
        let len = (0..)
            .take_while(|i| unsafe { *system.add(*i) } != 0)
            .count();
        let executable = std::path::PathBuf::from(std::ffi::OsString::from_wide(unsafe {
            std::slice::from_raw_parts(system, len)
        }))
        .join("msiexec.exe");
        unsafe { CoTaskMemFree(system.cast()) };
        let wide = |s: &std::ffi::OsStr| s.encode_wide().chain(Some(0)).collect::<Vec<_>>();
        let exe = wide(executable.as_os_str());
        let arguments = wide(std::ffi::OsStr::new(&format!(
            "/i \"{}\" /passive /norestart",
            path.display()
        )));
        let verb = wide(std::ffi::OsStr::new("runas"));
        let result = unsafe {
            ShellExecuteW(
                std::ptr::null_mut(),
                verb.as_ptr(),
                exe.as_ptr(),
                arguments.as_ptr(),
                std::ptr::null(),
                1,
            )
        } as isize;
        ensure!(
            result > 32,
            "driver installation was cancelled or could not start"
        );
        Ok(json!({"state":"installer_started","restart_required":true}))
    }
    #[cfg(not(windows))]
    {
        anyhow::bail!("driver adapter unavailable on this OS")
    }
}
