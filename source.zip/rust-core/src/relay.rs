//! Outbound relay carries opaque inner peer TLS. No transfer telemetry is sent.
use crate::peer_tls::{LocalPins, PeerIdentity};
use anyhow::{Result, ensure};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::time::{Duration, Instant};
use tokio::io::AsyncReadExt;
use tokio_rustls::{TlsAcceptor, TlsConnector};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Failure {
    Denied,
    Offline,
    Capacity,
    UpdateRequired,
    InvalidResponse,
}
impl std::fmt::Display for Failure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Denied => "relay permission denied",
            Self::Offline => "relay offline",
            Self::Capacity => "relay capacity exceeded",
            Self::UpdateRequired => "peer update required",
            Self::InvalidResponse => "invalid relay response",
        })
    }
}
impl std::error::Error for Failure {}
pub struct RelayTransport {
    http: reqwest::Client,
    credential: zeroize::Zeroizing<String>,
    identity: PeerIdentity,
}
pub type ReceiverStream = tokio_rustls::client::TlsStream<reqwest::Upgraded>;
pub type PublisherStream = tokio_rustls::server::TlsStream<reqwest::Upgraded>;
pub struct AcceptedPeer {
    pub stream: PublisherStream,
    pub pin: String,
}
fn status(code: u16) -> Result<()> {
    match code {
        200 | 101 => Ok(()),
        401 | 403 => Err(Failure::Denied.into()),
        429 => Err(Failure::Capacity.into()),
        426 => Err(Failure::UpdateRequired.into()),
        408 | 502 | 503 | 504 => Err(Failure::Offline.into()),
        _ => Err(Failure::InvalidResponse.into()),
    }
}
async fn bounded_json(response: reqwest::Response, max: usize) -> Result<Value> {
    use futures_util::StreamExt;
    status(response.status().as_u16())?;
    ensure!(response.status() == 200, Failure::InvalidResponse);
    let mut bytes = Vec::new();
    let mut stream = response.bytes_stream();
    while let Some(chunk) = stream.next().await {
        let chunk = chunk.map_err(|_| Failure::Offline)?;
        ensure!(bytes.len() + chunk.len() <= max, Failure::InvalidResponse);
        bytes.extend_from_slice(&chunk);
    }
    if bytes.is_empty() {
        Ok(json!({}))
    } else {
        serde_json::from_slice(&bytes).map_err(|_| Failure::InvalidResponse.into())
    }
}
impl RelayTransport {
    pub fn from_identity(value: &Value) -> Result<Self> {
        ensure!(
            value["state"] == "enrolled" && value["control_url"] == "https://team.sigmadrive.net",
            "registered production device required"
        );
        let certificate = value["certificate"].as_str().ok_or(Failure::Denied)?;
        let key = value["key"].as_str().ok_or(Failure::Denied)?;
        let credential = value["credential"]
            .as_str()
            .ok_or(Failure::Denied)?
            .to_owned();
        ensure!(
            !credential.is_empty() && credential.len() <= 8192,
            Failure::Denied
        );
        let pem = zeroize::Zeroizing::new(format!("{certificate}\n{key}"));
        let mut builder = reqwest::Client::builder()
            .identity(reqwest::Identity::from_pem(pem.as_bytes())?)
            .redirect(reqwest::redirect::Policy::none())
            .no_proxy()
            .http1_only()
            .connect_timeout(Duration::from_secs(10))
            .tls_version_min(reqwest::tls::Version::TLS_1_3);
        if let Some(ca) = value["ca"].as_str().filter(|s| !s.is_empty()) {
            ensure!(
                ca.len() <= 65536 && !ca.contains("PRIVATE KEY"),
                "invalid relay public CA"
            );
            for cert in reqwest::Certificate::from_pem_bundle(ca.as_bytes())? {
                builder = builder.add_root_certificate(cert);
            }
        }
        Ok(Self {
            http: builder.build()?,
            credential: zeroize::Zeroizing::new(credential),
            identity: PeerIdentity::from_pem(certificate, key)?,
        })
    }
    pub async fn s3_control(&self, operation: &str, body: &Value) -> Result<(Value, Instant)> {
        let (body, sent, _) = self.s3_clock_control(operation, body).await?;
        Ok((body, sent))
    }
    pub async fn s3_clock_control(
        &self,
        operation: &str,
        body: &Value,
    ) -> Result<(Value, Instant, i64)> {
        ensure!(
            matches!(
                operation,
                "publication" | "session" | "check" | "renew" | "close"
            ),
            "unsupported S3 authority operation"
        );
        let sent = Instant::now();
        let response = self
            .http
            .post(format!(
                "https://directory.relay.sigmadrive.net/v1/relay/s3/{operation}"
            ))
            .bearer_auth(self.credential.as_str())
            .timeout(Duration::from_secs(3))
            .json(body)
            .send()
            .await
            .map_err(|_| Failure::Offline)?;
        let date = response
            .headers()
            .get("Date")
            .and_then(|v| v.to_str().ok())
            .ok_or(Failure::InvalidResponse)?;
        let clock =
            jiff::Timestamp::strptime("%a, %d %b %Y %H:%M:%S %z", date.replace(" GMT", " +0000"))
                .map_err(|_| Failure::InvalidResponse)?
                .as_millisecond();
        Ok((bounded_json(response, 4 * 1024 * 1024).await?, sent, clock))
    }
    pub async fn origin(&self, permit: Option<&str>) -> Result<String> {
        let mut request = self
            .http
            .get("https://directory.relay.sigmadrive.net/v1/relay/route")
            .bearer_auth(self.credential.as_str())
            .timeout(Duration::from_secs(10));
        if let Some(p) = permit {
            ensure!(!p.is_empty() && p.len() <= 8192, Failure::Denied);
            request = request.header("X-Sigma-Permit", p);
        }
        let response = request.send().await.map_err(|_| Failure::Offline)?;
        let route = bounded_json(response, 4096).await?;
        let url = route["url"].as_str().ok_or(Failure::InvalidResponse)?;
        let label = url
            .strip_prefix("https://u-")
            .and_then(|s| s.strip_suffix(".relay.sigmadrive.net"))
            .ok_or(Failure::InvalidResponse)?;
        ensure!(
            label.len() == 32
                && label
                    .bytes()
                    .all(|b| b.is_ascii_digit() || matches!(b, b'a'..=b'f')),
            Failure::InvalidResponse
        );
        Ok(url.to_owned())
    }
    async fn tunnel(&self, permit: Option<&str>) -> Result<reqwest::Upgraded> {
        let origin = self.origin(permit).await?;
        self.tunnel_at(permit, &origin).await
    }
    async fn tunnel_at(&self, permit: Option<&str>, origin: &str) -> Result<reqwest::Upgraded> {
        let label = origin
            .strip_prefix("https://u-")
            .and_then(|s| s.strip_suffix(".relay.sigmadrive.net"))
            .ok_or(Failure::InvalidResponse)?;
        ensure!(
            label.len() == 32
                && label
                    .bytes()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)),
            Failure::InvalidResponse
        );
        let mut request = self
            .http
            .get(format!(
                "{origin}/v1/relay/{}",
                if permit.is_some() {
                    "connect"
                } else {
                    "accept"
                }
            ))
            .bearer_auth(self.credential.as_str())
            .header("Connection", "Upgrade")
            .header("Upgrade", "sigma-tunnel-v1")
            .timeout(Duration::from_secs(10));
        if let Some(p) = permit {
            request = request.header("X-Sigma-Permit", p);
        }
        let response = request.send().await.map_err(|_| Failure::Offline)?;
        status(response.status().as_u16())?;
        ensure!(
            response.status() == 101
                && response
                    .headers()
                    .get("Upgrade")
                    .is_some_and(|v| v.as_bytes() == b"sigma-tunnel-v1")
                && response
                    .headers()
                    .get("Connection")
                    .and_then(|v| v.to_str().ok())
                    .is_some_and(|v| v
                        .split(',')
                        .any(|s| s.trim().eq_ignore_ascii_case("upgrade"))),
            Failure::InvalidResponse
        );
        // Hyper preserves bytes read ahead beyond the HTTP 101 boundary.
        response
            .upgrade()
            .await
            .map_err(|_| Failure::Offline.into())
    }
    /// The publisher pin is read from an existing explicit local approval.
    /// A control-plane discovery response alone cannot enroll an inner TLS peer.
    pub async fn connect(&self, permit: &str, local_publisher_pin: &str) -> Result<ReceiverStream> {
        let origin = self.origin(Some(permit)).await?;
        self.connect_at(permit, local_publisher_pin, &origin).await
    }
    pub async fn connect_at(
        &self,
        permit: &str,
        local_publisher_pin: &str,
        origin: &str,
    ) -> Result<ReceiverStream> {
        let config = self.identity.client(local_publisher_pin)?;
        let tunnel = self.tunnel_at(Some(permit), origin).await?;
        let name = rustls::pki_types::ServerName::try_from("localhost")?.to_owned();
        tokio::time::timeout(
            Duration::from_secs(10),
            TlsConnector::from(config).connect(name, tunnel),
        )
        .await
        .map_err(|_| Failure::Offline)?
        .map_err(|_| Failure::Denied.into())
    }
    /// Waiting for a subscriber is intentionally unbounded. The owning publication
    /// selects this future against its cancellation signal and maintains one standby.
    pub async fn accept(&self, local_subscriber_pins: LocalPins) -> Result<AcceptedPeer> {
        let config = self.identity.server(local_subscriber_pins)?;
        let mut tunnel = self.tunnel(None).await?;
        let mut ready = [0u8; 1];
        tunnel
            .read_exact(&mut ready)
            .await
            .map_err(|_| Failure::Offline)?;
        ensure!(ready[0] == 1, Failure::InvalidResponse);
        let stream = tokio::time::timeout(
            Duration::from_secs(10),
            TlsAcceptor::from(config).accept(tunnel),
        )
        .await
        .map_err(|_| Failure::Offline)?
        .map_err(|_| Failure::Denied)?;
        let peers = stream
            .get_ref()
            .1
            .peer_certificates()
            .ok_or(Failure::Denied)?;
        ensure!(peers.len() == 1, Failure::Denied);
        let pin = hex::encode(Sha256::digest(peers[0].as_ref()));
        Ok(AcceptedPeer { stream, pin })
    }
}

/// Protocol range negotiation stays separate from authorization. Never retry a
/// TLS/authentication failure using a weaker protocol or another endpoint.
pub fn negotiate(min: u32, max: u32) -> Result<u32> {
    ensure!(min > 0 && min <= max, Failure::UpdateRequired);
    ensure!(min <= 1, Failure::UpdateRequired);
    Ok(1)
}
