use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    fs::{File, OpenOptions},
    path::PathBuf,
    sync::Mutex,
    time::{SystemTime, UNIX_EPOCH},
};
use tokio::sync::RwLock;

pub fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}
pub fn id(prefix: &str) -> String {
    format!("{prefix}-{}", uuid::Uuid::new_v4().simple())
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Connection {
    pub id: String,
    pub name: String,
    pub provider: String,
    #[serde(default)]
    pub preset: String,
    #[serde(default)]
    pub options: HashMap<String, String>,
    #[serde(default)]
    pub secrets: HashMap<String, String>,
}
impl Connection {
    pub fn public(&self) -> Value {
        let needs_auth = if matches!(self.provider.as_str(), "drive" | "onedrive") {
            !self.secrets.contains_key("oauth_token")
        } else {
            self.provider == "s3"
                && (!self.secrets.contains_key("access_key_id")
                    || !self.secrets.contains_key("secret_access_key"))
        };
        json!({"id":self.id,"name":self.name,"provider":self.provider,"preset":self.preset,"options":self.options,"needs_auth":needs_auth,"engine":"rust"})
    }
}
#[derive(Clone, Serialize, Deserialize, Default)]
pub struct Data {
    pub schema: u32,
    pub owner: String,
    pub node: String,
    pub settings: Value,
    pub connections: HashMap<String, Connection>,
    pub drives: HashMap<String, Value>,
    pub shares: HashMap<String, Value>,
    pub jobs: HashMap<String, Value>,
    pub member: Option<Value>,
    #[serde(default)]
    pub share_identity: Option<Value>,
    #[serde(default)]
    pub peer_approvals: HashMap<String, Value>,
    #[serde(default)]
    pub online: Option<crate::profile::Online>,
}
pub struct Core {
    pub desk: crate::desk::Runtime,
    pub availability: std::sync::Arc<crate::availability::Registry>,
    pub mount_admission: Mutex<()>,
    pub mount_handles: std::sync::atomic::AtomicUsize,
    pub auth_epoch: std::sync::atomic::AtomicU64,
    pub update: std::sync::Arc<crate::update::Updater>,
    pub publisher: Mutex<Option<std::sync::Arc<crate::gateway::Publisher>>>,
    pub peer_sessions: Mutex<HashMap<String, std::sync::Weak<crate::peer_client::Session>>>,
    pub leases: std::sync::Arc<crate::leases::Registry>,
    pub operations: std::sync::atomic::AtomicUsize,
    pub permission_control: tokio::sync::Mutex<()>,
    pub job_control: tokio::sync::Mutex<()>,
    pub drive_control: tokio::sync::Mutex<()>,
    pub profile_control: tokio::sync::Mutex<()>,
    pub share_control: tokio::sync::Mutex<()>,
    pub profile_proof: Mutex<Option<(String, std::time::Instant)>>,
    pub root: PathBuf,
    pub started: u64,
    pub data: RwLock<Data>,
    pub flows: tokio::sync::Mutex<HashMap<String, crate::auth::Flow>>,
    pub credential_locks: Mutex<HashMap<String, std::sync::Arc<tokio::sync::Mutex<()>>>>,
    pub mounts: Mutex<HashMap<String, crate::storage::Mount>>,
    pub transfers: Mutex<HashMap<String, std::sync::Arc<std::sync::atomic::AtomicBool>>>,
    _owner_lock: File,
}
impl Core {
    pub fn open() -> Result<Self> {
        let root = crate::identity::root()?;
        let mut lock = OpenOptions::new();
        lock.create(true).truncate(false).read(true).write(true);
        #[cfg(windows)]
        {
            use std::os::windows::fs::OpenOptionsExt;
            lock.share_mode(0);
        }
        let owner_lock = lock.open(root.join("owner.lock"))?;
        #[cfg(windows)]
        let owner = crate::identity::current_sid()?;
        #[cfg(not(windows))]
        let owner = String::new();
        let file = root.join("state.dpapi");
        let mut data: Data = if file.exists() {
            ensure!(
                file.metadata()?.len() <= 16 * 1024 * 1024,
                "core state exceeds bound"
            );
            let plain = zeroize::Zeroizing::new(crate::identity::unseal(&std::fs::read(file)?)?);
            let d: Data = serde_json::from_slice(&plain)?;
            ensure!(
                d.schema == 1 && d.owner == owner,
                "state identity or schema mismatch"
            );
            d
        } else {
            Data {
                schema: 1,
                owner,
                node: id("pc"),
                settings: json!({"language":"ko","device_alias":""}),
                ..Data::default()
            }
        };
        // A process restart never reports an old active transfer as complete.
        for j in data.jobs.values_mut() {
            if matches!(j["state"].as_str(), Some("running" | "queued" | "pausing")) {
                j["state"] = json!(if j["requested_state"] == "running"
                    && j["resume_on_restart"] == true
                {
                    "queued"
                } else {
                    "paused"
                });
                j["reason"] = json!("core_restarted");
                j["resources_released"] = json!(true);
            }
        }
        for d in data.drives.values_mut() {
            d["mounted"] = json!(false);
            d["mount_point"] = json!("");
        }
        let plain = zeroize::Zeroizing::new(serde_json::to_vec(&data)?);
        crate::identity::atomic(&root.join("state.dpapi"), &crate::identity::seal(&plain)?)?;
        let leases = std::sync::Arc::new(crate::leases::Registry::default());
        for approval in data.peer_approvals.values() {
            if approval["active"] == false
                && matches!(
                    approval["state"].as_str(),
                    Some("revoked" | "revoked_pending_server")
                )
            {
                leases.block_local(
                    approval["share"]
                        .as_str()
                        .ok_or_else(|| anyhow::anyhow!("revocation share missing"))?,
                    approval["peer_pin"]
                        .as_str()
                        .ok_or_else(|| anyhow::anyhow!("revocation pin missing"))?,
                )?;
            }
        }
        let core = Self {
            desk: crate::desk::Runtime::default(),
            availability: std::sync::Arc::new(crate::availability::Registry::default()),
            mount_admission: Mutex::new(()),
            mount_handles: std::sync::atomic::AtomicUsize::new(0),
            auth_epoch: std::sync::atomic::AtomicU64::new(0),
            update: std::sync::Arc::new(crate::update::Updater::default()),
            leases,
            operations: std::sync::atomic::AtomicUsize::new(0),
            permission_control: tokio::sync::Mutex::new(()),
            job_control: tokio::sync::Mutex::new(()),
            drive_control: tokio::sync::Mutex::new(()),
            profile_control: tokio::sync::Mutex::new(()),
            share_control: tokio::sync::Mutex::new(()),
            profile_proof: Mutex::new(None),
            publisher: Mutex::new(None),
            peer_sessions: Mutex::new(HashMap::new()),
            root,
            started: now(),
            data: RwLock::new(data),
            flows: tokio::sync::Mutex::new(HashMap::new()),
            credential_locks: Mutex::new(HashMap::new()),
            mounts: Mutex::new(HashMap::new()),
            transfers: Mutex::new(HashMap::new()),
            _owner_lock: owner_lock,
        };
        Ok(core)
    }
    pub fn persist(&self, data: &Data) -> Result<()> {
        let plain = zeroize::Zeroizing::new(serde_json::to_vec(data)?);
        ensure!(
            plain.len() <= 12 * 1024 * 1024,
            "state capacity exceeded; preserve existing state"
        );
        let sealed = crate::identity::seal(&plain)?;
        crate::identity::atomic(&self.root.join("state.dpapi"), &sealed)
    }
    pub async fn connection(&self, id: &str) -> Result<Connection> {
        self.data
            .read()
            .await
            .connections
            .get(id)
            .cloned()
            .ok_or_else(|| anyhow::anyhow!("connection not registered in this Rust core"))
    }
    pub async fn settings(&self) -> Value {
        let mut s = self.data.read().await.settings.clone();
        let computer = std::env::var("COMPUTERNAME").unwrap_or_else(|_| "SigmaDrive".into());
        s["computer_name"] = json!(computer);
        s["device_name"] = json!(
            s["device_alias"]
                .as_str()
                .filter(|s| !s.trim().is_empty())
                .unwrap_or(&computer)
        );
        s
    }
}
pub struct Operation(std::sync::Arc<Core>);
impl Operation {
    pub fn begin(core: std::sync::Arc<Core>) -> Self {
        core.operations
            .fetch_add(1, std::sync::atomic::Ordering::AcqRel);
        Self(core)
    }
}
impl Drop for Operation {
    fn drop(&mut self) {
        self.0
            .operations
            .fetch_sub(1, std::sync::atomic::Ordering::AcqRel);
    }
}
