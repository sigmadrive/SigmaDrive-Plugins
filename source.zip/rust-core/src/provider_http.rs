//! One Rust credential owner for OpenDAL and provider-specific upload protocols.
use opendal::{Buffer, HttpBody, HttpTransport, HttpTransporter};
#[derive(Debug)]
pub struct Unavailable;
impl std::fmt::Display for Unavailable {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("cloud transport unavailable; saved state retained")
    }
}
impl std::error::Error for Unavailable {}
pub struct ProviderTransport {
    pub inner: HttpTransporter,
    pub connection: String,
    pub provider: String,
}
pub fn provider_host(provider: &str, host: &str) -> bool {
    match provider {
        "drive" => matches!(host, "www.googleapis.com" | "content.googleapis.com"),
        "onedrive" => host == "graph.microsoft.com",
        _ => false,
    }
}
impl HttpTransport for ProviderTransport {
    async fn fetch(
        &self,
        mut req: http::Request<Buffer>,
    ) -> opendal::Result<http::Response<HttpBody>> {
        if req.headers().contains_key(http::header::AUTHORIZATION)
            && provider_host(&self.provider, req.uri().host().unwrap_or(""))
        {
            let core = crate::core().map_err(|_| {
                opendal::Error::new(
                    opendal::ErrorKind::PermissionDenied,
                    "Rust credential store unavailable",
                )
            })?;
            let connection = crate::auth::fresh(&core, &self.connection)
                .await
                .map_err(|_| {
                    opendal::Error::new(
                        opendal::ErrorKind::PermissionDenied,
                        "provider credential unavailable; local data retained",
                    )
                })?;
            let token: serde_json::Value =
                serde_json::from_str(connection.secrets.get("oauth_token").ok_or_else(|| {
                    opendal::Error::new(
                        opendal::ErrorKind::PermissionDenied,
                        "provider credential missing",
                    )
                })?)
                .map_err(|_| {
                    opendal::Error::new(
                        opendal::ErrorKind::PermissionDenied,
                        "provider credential invalid",
                    )
                })?;
            let access = token["access_token"].as_str().ok_or_else(|| {
                opendal::Error::new(
                    opendal::ErrorKind::PermissionDenied,
                    "provider access credential missing",
                )
            })?;
            let mut value =
                http::HeaderValue::from_str(&format!("Bearer {access}")).map_err(|_| {
                    opendal::Error::new(
                        opendal::ErrorKind::PermissionDenied,
                        "invalid access credential",
                    )
                })?;
            value.set_sensitive(true);
            req.headers_mut().insert(http::header::AUTHORIZATION, value);
        }
        self.inner.fetch(req).await
    }
}
pub async fn send(builder: reqwest::RequestBuilder) -> anyhow::Result<reqwest::Response> {
    let (client, request) = builder.build_split();
    let mut request = request.map_err(|_| anyhow::anyhow!("invalid cloud request"))?;
    if let Some(id) = request.headers_mut().remove("X-Sigma-Local-Connection") {
        let id = id
            .to_str()
            .map_err(|_| anyhow::anyhow!("invalid local connection binding"))?;
        let core = crate::core()?;
        let connection = crate::auth::fresh(&core, id).await?;
        anyhow::ensure!(
            provider_host(&connection.provider, request.url().host_str().unwrap_or("")),
            "provider credential destination denied"
        );
        let token: serde_json::Value = serde_json::from_str(
            connection
                .secrets
                .get("oauth_token")
                .ok_or_else(|| anyhow::anyhow!("provider credential missing"))?,
        )?;
        let access = token["access_token"]
            .as_str()
            .ok_or_else(|| anyhow::anyhow!("provider access credential missing"))?;
        let mut header = reqwest::header::HeaderValue::from_str(&format!("Bearer {access}"))?;
        header.set_sensitive(true);
        request
            .headers_mut()
            .insert(reqwest::header::AUTHORIZATION, header);
    }
    client
        .execute(request)
        .await
        .map_err(|_| anyhow::Error::new(Unavailable))
}
