//! Local share configuration is not a claim of an enrolled/publishing relay.
use crate::state::{Core, id};
use anyhow::{Result, bail, ensure};
use serde_json::{Value, json};
use std::sync::Arc;
pub fn stop_publications(core: &Core) {
    if let Ok(mut runtime) = core.publisher.lock()
        && let Some(p) = runtime.take()
    {
        p.stop();
    }
}
pub async fn stop_all(core: &Core) {
    stop_publications(core);
    if let Ok(sessions) = core.peer_sessions.lock() {
        for session in sessions.values().filter_map(std::sync::Weak::upgrade) {
            session.stop();
        }
    }
    let data = core.data.read().await;
    for share in data.shares.keys() {
        core.leases.revoke(share, None);
    }
}
// Only locally persisted, explicitly approved identities may be reused. Values
// in the server's directory never establish device trust.
fn receiver_pin<'a>(approval: Option<&'a Value>, share: &str, publisher: &str) -> Option<&'a str> {
    let a = approval?;
    (a["active"] == true
        && a["state"] == "approved"
        && a["role"] == "receiver"
        && a["share"] == share
        && a["peer_node"] == publisher)
        .then(|| a["peer_pin"].as_str())
        .flatten()
        .filter(|pin| crate::permit::valid_pin(pin))
}
pub async fn manage(core: Arc<Core>, body: Value) -> Result<Value> {
    if body["action"]
        .as_str()
        .is_some_and(|a| a.starts_with("desk-") || a == "component-install")
    {
        return crate::desk::manage(core, body).await;
    }
    let desk_component = crate::desk::component(&core).await;
    match body["action"].as_str().unwrap_or("status") {
        "prepare-member" | "configure-member" => crate::authority::enroll(core).await,
        "request-access" => {
            crate::authority::call(
                &core,
                "POST",
                "/v1/access-requests",
                Some(json!({"share":body["id"]})),
            )
            .await
        }
        "approve-access" | "reject-access" | "revoke-access" => {
            let result = crate::permissions::decision(&core, &body).await?;
            crate::gateway::reconcile(&core).await?;
            Ok(result)
        }
        "start" | "stop" => {
            let sid = body["id"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("share ID required"))?;
            let enabled = body["action"] == "start";
            if !enabled
                && let Ok(p) = core.publisher.lock()
                && let Some(p) = p.as_ref()
            {
                p.remove(sid);
            }
            {
                let mut data = core.data.write().await;
                let mut next = data.clone();
                let share = next
                    .shares
                    .get_mut(sid)
                    .ok_or_else(|| anyhow::anyhow!("share not configured"))?;
                share["enabled"] = json!(enabled);
                let saved = core.persist(&next);
                if saved.is_ok() || !enabled {
                    *data = next;
                }
                saved?;
            }
            if enabled {
                crate::authority::report(&core).await?;
                crate::gateway::reconcile(&core).await?;
            } else {
                let _control = core.share_control.lock().await;
                crate::authority::call(&core, "DELETE", &format!("/v1/shares/{sid}"), None).await?;
            }
            Ok(json!({"id":sid,"enabled":enabled}))
        }
        "cancel-access" => {
            crate::authority::call(
                &core,
                "POST",
                "/v1/access-requests/decision",
                Some(json!({"id":body["access_request_id"],"status":"cancelled","peer_pin":""})),
            )
            .await
        }
        "invite-member" => {
            let invite = crate::authority::call(
                &core,
                "POST",
                "/v1/member-invites",
                Some(json!({"share":body["id"]})),
            )
            .await?;
            Ok(json!({"member_invite":invite["token"]}))
        }
        "accept-member-invite" => {
            crate::authority::call(
                &core,
                "POST",
                "/v1/member-invites/accept",
                Some(json!({"token":body["share_invite"]})),
            )
            .await
        }
        "receiver-trust" => {
            let sid = body["id"].as_str().unwrap_or("");
            let publisher = body["publisher"].as_str().unwrap_or("");
            ensure!(
                !sid.is_empty() && !publisher.is_empty(),
                "share and publisher required"
            );
            let d = core.data.read().await;
            let pin = receiver_pin(
                d.peer_approvals.get(&format!("receiver:{sid}")),
                sid,
                publisher,
            );
            Ok(json!({"trusted":pin.is_some(),"peer_pin":pin,"publisher":publisher,"share":sid}))
        }
        "resolve-name" => {
            let sid = body["id"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("share ID required"))?;
            let pin = body["peer_pin"].as_str().unwrap_or("");
            ensure!(
                crate::permit::valid_pin(pin),
                "publisher fingerprint must be confirmed locally"
            );
            let available = crate::authority::call(&core, "GET", "/v1/shares", None).await?;
            let remote = available
                .as_array()
                .or_else(|| available["shares"].as_array())
                .and_then(|a| a.iter().find(|r| r["id"] == sid))
                .ok_or_else(|| anyhow::anyhow!("share unavailable"))?;
            let mut d = core.data.write().await;
            let mut next = d.clone();
            let key = format!("receiver:{sid}");
            if body["peer_verified"] != true {
                ensure!(
                    receiver_pin(
                        next.peer_approvals.get(&key),
                        sid,
                        remote["publisher"].as_str().unwrap_or("")
                    ) == Some(pin),
                    "publisher trust missing, revoked or changed; confirm locally"
                );
            }
            if let Some(old) = next.peer_approvals.get(&key) {
                ensure!(
                    old["peer_pin"] == pin && old["peer_node"] == remote["publisher"],
                    "publisher identity changed; revoke old trust explicitly"
                );
            }
            if body["peer_verified"] == true {
                next.peer_approvals.insert(key,json!({"share":sid,"role":"receiver","peer_pin":pin,"peer_node":remote["publisher"],"active":true,"state":"approved"}));
            }
            core.persist(&next)?;
            *d = next;
            drop(d);
            let peer = crate::peer_client::open(&core, sid, pin).await?;
            let labels = peer.credentials().await?;
            let mut d = core.data.write().await;
            let mut next = d.clone();
            if let Some(a) = next.peer_approvals.get_mut(&format!("receiver:{sid}")) {
                for k in ["name", "device_name"] {
                    if let Some(label) = labels[k]
                        .as_str()
                        .filter(|s| s.len() <= 256 && !s.chars().any(char::is_control))
                    {
                        a[k] = json!(label);
                    }
                }
            }
            core.persist(&next)?;
            *d = next;
            let mut item = remote.clone();
            item["name"] = labels["name"].clone();
            item["publisher_name"] = labels["device_name"].clone();
            Ok(json!({"available":[item],"trusted":true}))
        }
        "status" | "component-status" => {
            let (node, identity, member, shares) = {
                let d = core.data.read().await;
                (
                    d.node.clone(),
                    d.share_identity.clone(),
                    d.member.clone(),
                    d.shares.values().map(public).collect::<Vec<_>>(),
                )
            };
            let registered = identity.as_ref().is_some_and(|i| i["state"] == "enrolled");
            let (available, requests, invites, control_error) = if registered {
                let (a, r, i) = tokio::join!(
                    crate::authority::call(&core, "GET", "/v1/shares", None),
                    crate::authority::call(&core, "GET", "/v1/access-requests", None),
                    crate::authority::call(&core, "GET", "/v1/member-invites", None)
                );
                let error = a.is_err() || r.is_err() || i.is_err();
                (
                    a.unwrap_or(json!([])),
                    r.unwrap_or(json!([])),
                    i.unwrap_or(json!([])),
                    error,
                )
            } else {
                (json!([]), json!([]), json!([]), false)
            };
            let mut available = available;
            let d = core.data.read().await;
            let mut names = serde_json::Map::new();
            if let Some(items) = available.as_array_mut() {
                for item in items {
                    let sid = item["id"].as_str().unwrap_or("").to_owned();
                    let publisher = item["publisher"].as_str().unwrap_or("").to_owned();
                    let pin = receiver_pin(
                        d.peer_approvals.get(&format!("receiver:{sid}")),
                        &sid,
                        &publisher,
                    );
                    item["connectivity"] = core.availability.status(
                        &sid,
                        &publisher,
                        pin.unwrap_or(""),
                        &item["online"],
                        pin.is_some() && item["active"] != false,
                    );
                    if let Some(a) = d
                        .peer_approvals
                        .get(&format!("receiver:{}", item["id"].as_str().unwrap_or("")))
                        .filter(|a| a["active"] == true && a["peer_node"] == item["publisher"])
                    {
                        if a["name"].is_string() {
                            item["name"] = a["name"].clone();
                        }
                        if a["device_name"].is_string() {
                            item["publisher_name"] = a["device_name"].clone();
                            names.insert(
                                item["publisher"].as_str().unwrap_or("").into(),
                                a["device_name"].clone(),
                            );
                        }
                    }
                }
            }
            drop(d);
            let runtime = core
                .publisher
                .lock()
                .map_err(|_| anyhow::anyhow!("publisher lock failed"))?;
            let local=shares.into_iter().map(|mut s|{let status=runtime.as_ref().map(|p|p.share_status(s["id"].as_str().unwrap_or(""))).unwrap_or(json!({"state":"stopped","active_requests":0,"resources_released":true}));s["runtime"]=status;s}).collect::<Vec<_>>();
            Ok(
                json!({"node":node,"configured":registered,"registered":registered,"connected":registered&&!control_error,"readiness":if control_error{"control_unavailable"}else if registered{"ready"}else{"registration_required"},"owner_member":member.as_ref().map(|m|m["memberId"].clone()),"local_pin":identity.as_ref().map(|i|i["pin"].clone()),"local":local,"published":local,"available":available,"device_names":names,"access_requests":requests,"member_invites":invites,"supported_protocols":["s3"],"components":[{"id":"sigma.s3","state":"builtin-rust"},desk_component],"relay":runtime.as_ref().map(|p|p.status()),"engine":"rust","legacy_fallback":false}),
            )
        }
        "save" => {
            let folder = body["folder"]
                .as_str()
                .ok_or_else(|| anyhow::anyhow!("folder required"))?;
            let path = std::path::Path::new(folder);
            ensure!(
                path.is_absolute() && path.is_dir(),
                "existing absolute folder required"
            );
            ensure!(
                !folder.to_ascii_lowercase().starts_with("z:"),
                "existing Z is outside new engine scope"
            );
            let bucket = body["s3_bucket"].as_str().unwrap_or("");
            ensure!(
                (3..=63).contains(&bucket.len())
                    && bucket
                        .bytes()
                        .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
                    && !bucket.starts_with('-')
                    && !bucket.ends_with('-'),
                "invalid bucket name"
            );
            let sid = body["id"]
                .as_str()
                .filter(|s| !s.is_empty())
                .map(str::to_owned)
                .unwrap_or_else(|| id("share"));
            ensure!(
                sid.starts_with("share-")
                    && sid.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-'),
                "invalid share ID"
            );
            let mut data = core.data.write().await;
            ensure!(
                body["protocol"].as_str().is_none_or(|p| p == "s3"),
                "Rust sharing currently requires S3 protocol"
            );
            ensure!(
                data.shares.len() < 64 || data.shares.contains_key(&sid),
                "share capacity reached"
            );
            let grants = body["grants"]
                .as_array()
                .ok_or_else(|| anyhow::anyhow!("explicit read member grants required"))?;
            let writes = body["write_grants"]
                .as_array()
                .ok_or_else(|| anyhow::anyhow!("explicit write grants required"))?;
            ensure!(
                grants.len() <= 256
                    && grants
                        .iter()
                        .all(|g| g.as_str().is_some_and(|s| !s.is_empty() && s.len() <= 128))
                    && writes.iter().all(|w| grants.contains(w)),
                "invalid member grants"
            );
            ensure!(
                !data
                    .shares
                    .iter()
                    .any(|(k, v)| k != &sid && v["s3_bucket"] == bucket),
                "bucket is already used on this node"
            );
            let old = data.shares.get(&sid);
            let mut share = json!({"name":body["name"],"folder":folder,"s3_bucket":bucket,"grants":grants,"write_grants":writes,"protocol":"s3","s3_relay":true,"enabled":old.is_some_and(|s|s["enabled"]==true),"_s3_secret":old.and_then(|s|s["_s3_secret"].as_str()).map(str::to_owned).unwrap_or_else(||format!("{}{}",uuid::Uuid::new_v4().simple(),uuid::Uuid::new_v4().simple()))});
            share["id"] = json!(sid);
            share["publisher"] = json!(data.node);
            share["publishing"] = json!(false);
            share["readiness"] = json!("configuration_only");
            let mut next = data.clone();
            next.shares.insert(sid.clone(), share.clone());
            core.persist(&next)?;
            *data = next;
            drop(data);
            if let Ok(p) = core.publisher.lock()
                && let Some(p) = p.as_ref()
            {
                p.remove(&sid);
            }
            if share["enabled"] == true {
                crate::gateway::reconcile(&core).await?;
            }
            Ok(public(&share))
        }
        // Never synthesize enrollment, identity, device approval or recipient credentials.
        _ => bail!(
            "Rust share authority/relay integration is incomplete; no Go fallback and no implicit permission grant"
        ),
    }
}
pub fn public(value: &Value) -> Value {
    let mut v = value.clone();
    if let Some(o) = v.as_object_mut() {
        o.remove("_s3_secret");
    }
    v
}

#[cfg(test)]
mod receiver_trust_tests {
    use super::*;
    #[test]
    fn persisted_trust_is_scoped_to_share_publisher_role_and_active_approval() {
        let pin = "ab".repeat(32);
        let a = json!({"share":"s1","peer_node":"p1","role":"receiver","active":true,"state":"approved","peer_pin":pin});
        assert_eq!(receiver_pin(Some(&a), "s1", "p1"), Some(pin.as_str()));
        assert_eq!(receiver_pin(Some(&a), "s2", "p1"), None);
        assert_eq!(receiver_pin(Some(&a), "s1", "p2"), None);
        for (field, value) in [
            ("active", json!(false)),
            ("state", json!("revoked")),
            ("role", json!("publisher")),
            ("peer_pin", json!("bad")),
        ] {
            let mut changed = a.clone();
            changed[field] = value;
            assert_eq!(receiver_pin(Some(&changed), "s1", "p1"), None);
        }
        assert_eq!(receiver_pin(None, "s1", "p1"), None);
    }
}
