//! One anonymous native-root TLS configuration per authorized Proxy lifetime.
//! No Sigma account/delegation credentials, sockets or cross-account cache.
use anyhow::{Result, ensure};
use rustls::{ClientConfig, RootCertStore};
use serde_json::{Value, json};
use std::{sync::{Arc, Mutex, atomic::{AtomicU64, Ordering}}, time::Instant};
use tokio::net::TcpStream;
use tokio_tungstenite::{Connector, MaybeTlsStream, WebSocketStream,
    client_async_tls_with_config,
    tungstenite::{handshake::client::{Request, Response}, protocol::WebSocketConfig}};

const CAP:usize=64;
const MAX_US:u64=60_000_000;
#[derive(Clone,Copy)]
#[repr(u8)]
pub(crate) enum Stage {RootLoad=1,DnsTcp=2,TlsAndUpgrade=3,DialTotal=4}
#[derive(Clone,Copy)]
#[repr(u8)]
pub(crate) enum Route {Registration=1,Id=2,Relay=3}
#[derive(Clone,Copy)]
#[repr(u8)]
pub(crate) enum Outcome {Ok=1,Error=2,Cancelled=3,Timeout=4}
#[derive(Clone,Copy)]
struct Row {stage:u8,outcome:u8,elapsed_us:u64,route:u8}
pub(crate) struct Metrics {enabled:bool,rows:Mutex<Vec<Row>>,dropped:AtomicU64}
impl Metrics {
    pub(crate) fn new(enabled:bool)->Self{Self{enabled,rows:Mutex::new(if enabled{Vec::with_capacity(CAP)}else{Vec::new()}),dropped:AtomicU64::new(0)}}
    fn lost(&self){let _=self.dropped.fetch_update(Ordering::Relaxed,Ordering::Relaxed,|n|Some(n.saturating_add(1).min(1_000_000_000)));}
    pub(crate) fn begin(self:&Arc<Self>,stage:Stage)->Span{self.begin_code(stage,0)}
    pub(crate) fn begin_route(self:&Arc<Self>,stage:Stage,route:Route)->Span{self.begin_code(stage,route as u8)}
    fn begin_code(self:&Arc<Self>,stage:Stage,route:u8)->Span{if self.enabled{Span{metrics:Some(self.clone()),stage,route,start:Some(Instant::now())}}else{Span{metrics:None,stage,route,start:None}}}
    fn record(&self,stage:Stage,outcome:Outcome,elapsed_us:u64,route:u8){
        if !self.enabled{return;}if elapsed_us>MAX_US{self.lost();return;}
        match self.rows.try_lock(){Ok(mut rows)if rows.len()<CAP=>rows.push(Row{stage:stage as u8,outcome:outcome as u8,elapsed_us,route}),_=>self.lost()}
    }
    pub(crate) fn snapshot(&self)->Value{
        if !self.enabled{return json!({"schema":1,"enabled":0,"capacity":CAP,"rows":[],"dropped":0});}
        match self.rows.try_lock(){Ok(rows)=>json!({"schema":1,"enabled":1,"capacity":CAP,"rows":rows.iter().map(|r|[r.stage as u64,r.outcome as u64,r.elapsed_us,r.route as u64]).collect::<Vec<_>>(),"dropped":self.dropped.load(Ordering::Relaxed)}),Err(_)=>json!({"schema":1,"enabled":1,"capacity":CAP,"rows":[],"dropped":self.dropped.load(Ordering::Relaxed),"unavailable":1})}
    }
}
pub(crate) struct Span {metrics:Option<Arc<Metrics>>,stage:Stage,route:u8,start:Option<Instant>}
impl Span {
    pub(crate) fn finish(mut self,outcome:Outcome){self.complete(outcome);}
    fn complete(&mut self,outcome:Outcome){if let (Some(m),Some(at))=(self.metrics.take(),self.start.take()){m.record(self.stage,outcome,u64::try_from(at.elapsed().as_micros()).unwrap_or(u64::MAX),self.route);}}
}
impl Drop for Span {fn drop(&mut self){self.complete(Outcome::Cancelled);}}

pub(crate) struct SessionTls {config:Arc<ClientConfig>,pub(crate) metrics:Arc<Metrics>}
impl SessionTls {
    // Engine::start already executes blocking filesystem/loader preparation on
    // its guarded spawn_blocking worker. Loading the OS roots stays there too.
    pub(crate) fn native(metrics:Arc<Metrics>)->Result<Self>{Self::with_loader(metrics,||{
        let loaded=rustls_native_certs::load_native_certs();
        ensure!(!loaded.certs.is_empty(),"SigmaDesk TLS trust unavailable");
        let mut roots=RootCertStore::empty();
        let (accepted,_)=roots.add_parsable_certificates(loaded.certs);
        ensure!(accepted>0,"SigmaDesk TLS trust unavailable");
        Ok(roots)
    })}
    fn with_loader(metrics:Arc<Metrics>,load:impl FnOnce()->Result<RootCertStore>)->Result<Self>{
        let span=metrics.begin(Stage::RootLoad);
        let result=(||{let roots=load()?;ensure!(!roots.is_empty(),"SigmaDesk TLS trust unavailable");
            // Select the same provider as Core::init and peer_tls without
            // depending on process-global initialization or Cargo feature union.
            let config=ClientConfig::builder_with_provider(Arc::new(rustls::crypto::ring::default_provider()))
                .with_safe_default_protocol_versions()
                .map_err(|_|anyhow::anyhow!("SigmaDesk TLS configuration unavailable"))?
                .with_root_certificates(roots).with_no_client_auth();
            Ok(Self{config:Arc::new(config),metrics})})();
        span.finish(if result.is_ok(){Outcome::Ok}else{Outcome::Error});result
    }
    pub(crate) async fn connect(&self,request:Request,config:WebSocketConfig,route:Route)->Result<(WebSocketStream<MaybeTlsStream<TcpStream>>,Response)>{
        ensure!(request.uri().scheme_str()==Some("wss"),"SigmaDesk TLS transport required");
        let domain=request.uri().host().ok_or_else(||anyhow::anyhow!("SigmaDesk TLS transport denied"))?;
        let port=request.uri().port_u16().unwrap_or(443);
        let tcp=self.metrics.begin_route(Stage::DnsTcp,route);
        let socket=TcpStream::connect(format!("{domain}:{port}")).await;
        tcp.finish(if socket.is_ok(){Outcome::Ok}else{Outcome::Error});
        let socket=socket.map_err(|_|anyhow::anyhow!("SigmaDesk transport unavailable"))?;
        socket.set_nodelay(true).map_err(|_|anyhow::anyhow!("SigmaDesk transport unavailable"))?;
        let handshake=self.metrics.begin_route(Stage::TlsAndUpgrade,route);
        let result=client_async_tls_with_config(request,socket,Some(config),Some(Connector::Rustls(self.config.clone()))).await;
        handshake.finish(if result.is_ok(){Outcome::Ok}else{Outcome::Error});
        result.map_err(|_|anyhow::anyhow!("SigmaDesk transport unavailable"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use futures_util::{SinkExt,StreamExt};
    use std::sync::atomic::AtomicUsize;
    use tokio::net::TcpListener;
    use tokio_rustls::TlsAcceptor;
    use tokio_tungstenite::{accept_hdr_async,tungstenite::{Message,client::IntoClientRequest,handshake::server::ErrorResponse}};
    fn config()->(RootCertStore,rustls::ServerConfig){
        let cert=rcgen::generate_simple_self_signed(vec!["localhost".into()]).unwrap();
        let mut roots=RootCertStore::empty();roots.add(cert.cert.der().clone()).unwrap();
        let server=rustls::ServerConfig::builder_with_provider(Arc::new(rustls::crypto::ring::default_provider()))
            .with_safe_default_protocol_versions().unwrap().with_no_client_auth().with_single_cert(vec![cert.cert.der().clone()],rustls::pki_types::PrivatePkcs8KeyDer::from(cert.key_pair.serialize_der()).into()).unwrap();(roots,server)
    }
    async fn fixture(server:rustls::ServerConfig,count:usize)->(u16,tokio::task::JoinHandle<Vec<String>>){
        let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let port=listener.local_addr().unwrap().port();let accept=TlsAcceptor::from(Arc::new(server));
        let task=tokio::spawn(async move {let mut paths=Vec::new();for _ in 0..count{let(socket,_)=listener.accept().await.unwrap();let Ok(tls)=accept.accept(socket).await else{continue};let path=Arc::new(Mutex::new(String::new()));let record=path.clone();let mut ws=accept_hdr_async(tls,move|req:&Request,res|->std::result::Result<_,ErrorResponse>{*record.lock().unwrap()=req.uri().path().to_owned();Ok(res)}).await.unwrap();let m=ws.next().await.unwrap().unwrap();ws.send(m).await.unwrap();ws.close(None).await.unwrap();paths.push(path.lock().unwrap().clone());}paths});(port,task)
    }
    #[tokio::test]
    async fn one_owner_loads_roots_once_and_reuses_exact_connector_for_three_actual_tls_routes(){
        let(roots,server)=config();let(port,task)=fixture(server,3).await;let calls=AtomicUsize::new(0);let metrics=Arc::new(Metrics::new(true));
        let owner=SessionTls::with_loader(metrics.clone(),||{calls.fetch_add(1,Ordering::Relaxed);Ok(roots)}).unwrap();let weak=Arc::downgrade(&owner.config);
        for(route,code)in [("udp",Route::Registration),("id",Route::Id),("relay",Route::Relay)]{let req=format!("wss://localhost:{port}/{route}").into_client_request().unwrap();let(mut ws,_)=owner.connect(req,WebSocketConfig::default(),code).await.unwrap();ws.send(Message::Binary(b"synthetic-test-only".to_vec().into())).await.unwrap();assert_eq!(ws.next().await.unwrap().unwrap(),Message::Binary(b"synthetic-test-only".to_vec().into()));}
        assert_eq!(calls.load(Ordering::Relaxed),1);assert_eq!(task.await.unwrap(),["/udp","/id","/relay"]);let rows=metrics.snapshot();assert_eq!(rows["rows"].as_array().unwrap().iter().filter(|r|r[0]==1).count(),1);assert_eq!(rows["rows"].as_array().unwrap().iter().filter(|r|r[0]==3&&r[1]==1).map(|r|r[3].as_u64().unwrap()).collect::<Vec<_>>(),[1,2,3]);drop(owner);assert!(weak.upgrade().is_none());
    }
    #[test]
    fn owners_never_share_config_and_drop_releases_config(){let(roots,_)=config();let a=SessionTls::with_loader(Arc::new(Metrics::new(false)),||Ok(roots.clone())).unwrap();let b=SessionTls::with_loader(Arc::new(Metrics::new(false)),||Ok(roots)).unwrap();assert!(!a.config.enable_early_data&&!b.config.enable_early_data);assert!(!Arc::ptr_eq(&a.config,&b.config));let weak=Arc::downgrade(&a.config);drop(a);assert!(weak.upgrade().is_none());assert_eq!(Arc::strong_count(&b.config),1);}
    #[test]
    fn root_failure_and_empty_store_fail_closed_with_no_connector(){let metrics=Arc::new(Metrics::new(true));assert!(SessionTls::with_loader(metrics.clone(),||anyhow::bail!("synthetic failure")).is_err());assert!(SessionTls::with_loader(metrics.clone(),||Ok(RootCertStore::empty())).is_err());let rows=metrics.snapshot();assert!(rows["rows"].as_array().unwrap().iter().all(|r|r[0]==1&&r[1]==2));}
    #[tokio::test]
    async fn wrong_ca_hostname_and_plain_transport_are_rejected(){
        let(roots,server)=config();let(_,other_server)=config();let(port,task)=fixture(other_server,1).await;let a=SessionTls::with_loader(Arc::new(Metrics::new(true)),||Ok(roots.clone())).unwrap();assert!(a.connect(format!("wss://localhost:{port}/id").into_client_request().unwrap(),WebSocketConfig::default(),Route::Id).await.is_err());task.await.unwrap();
        let(port,task)=fixture(server,1).await;assert!(a.connect(format!("wss://127.0.0.1:{port}/id").into_client_request().unwrap(),WebSocketConfig::default(),Route::Id).await.is_err());task.await.unwrap();
        assert!(a.connect("ws://localhost:9/id".into_client_request().unwrap(),WebSocketConfig::default(),Route::Id).await.is_err());
    }
    #[tokio::test]
    async fn pending_handshake_timeout_and_cancellation_drop_socket_without_a_completed_dial(){
        let(roots,_)=config();let a=SessionTls::with_loader(Arc::new(Metrics::new(true)),||Ok(roots)).unwrap();let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let port=listener.local_addr().unwrap().port();let(server_tx,server_rx)=tokio::sync::oneshot::channel();
        let server=tokio::spawn(async move {let(mut socket,_)=listener.accept().await.unwrap();server_tx.send(()).unwrap();let mut buf=vec![0;16384];use tokio::io::AsyncReadExt;loop{let n=socket.read(&mut buf).await.unwrap();if n==0{break;}}});
        let mut pending=Box::pin(a.connect(format!("wss://localhost:{port}/relay").into_client_request().unwrap(),WebSocketConfig::default(),Route::Relay));tokio::select!{r=&mut pending=>panic!("unexpected handshake completion: {}",r.is_ok()),_=server_rx=>{}}
        assert!(tokio::time::timeout(std::time::Duration::from_millis(20),&mut pending).await.is_err());drop(pending);tokio::time::timeout(std::time::Duration::from_secs(2),server).await.unwrap().unwrap();let rows=a.metrics.snapshot();assert!(rows["rows"].as_array().unwrap().iter().any(|r|r[0]==3&&r[1]==3));
    }
    #[test]
    fn observations_are_default_off_bounded_numeric_and_drop_on_contention(){let off=Arc::new(Metrics::new(false));off.begin(Stage::RootLoad).finish(Outcome::Ok);assert_eq!(off.snapshot()["rows"],json!([]));let on=Arc::new(Metrics::new(true));for _ in 0..70{on.begin(Stage::DialTotal).finish(Outcome::Timeout);}let snap=on.snapshot();assert_eq!(snap["rows"].as_array().unwrap().len(),CAP);assert_eq!(snap["dropped"],6);assert!(snap["rows"].as_array().unwrap().iter().all(|r|r.as_array().unwrap().iter().all(Value::is_u64)));let _guard=on.rows.lock().unwrap();on.begin(Stage::DnsTcp).finish(Outcome::Error);assert_eq!(on.dropped.load(Ordering::Relaxed),7);}
    #[test]
    fn real_windows_native_roots_initialize_one_verified_configuration(){let metrics=Arc::new(Metrics::new(true));let owner=SessionTls::native(metrics.clone()).unwrap();assert_eq!(Arc::strong_count(&owner.config),1);assert_eq!(metrics.snapshot()["rows"][0][0],1);assert_eq!(metrics.snapshot()["rows"][0][1],1);println!("LOCAL_NATIVE_ROOT_OBSERVATION {}",metrics.snapshot());}
    #[test]
    fn local_windows_native_root_workload_observation_is_bounded_and_not_remote_latency(){
        let mut baseline_us=Vec::new();for _ in 0..3{let m=Arc::new(Metrics::new(true));let owner=SessionTls::native(m.clone()).unwrap();baseline_us.push(m.snapshot()["rows"][0][2].as_u64().unwrap());drop(owner);}
        let m=Arc::new(Metrics::new(true));let owner=SessionTls::native(m.clone()).unwrap();let clone_started=Instant::now();let routes=[owner.config.clone(),owner.config.clone(),owner.config.clone()];let clone_us=clone_started.elapsed().as_micros() as u64;assert!(routes.iter().all(|v|Arc::ptr_eq(v,&owner.config)));assert_eq!(m.snapshot()["rows"].as_array().unwrap().len(),1);
        println!("LOCAL_NATIVE_ROOT_WORKLOAD {}",json!({"schema":1,"measurement_scope_code":1,"system_cold_established":0,"first_process_sample_index":0,"baseline_native_loads":3,"baseline_root_us":baseline_us,"candidate_native_loads":1,"candidate_root_us":m.snapshot()["rows"][0][2],"candidate_three_connector_clones_us":clone_us,"remote_startup_measured":0}));
    }
}
