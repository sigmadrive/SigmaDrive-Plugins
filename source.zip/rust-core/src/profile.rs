//! Portable credential-free profiles. Online SDP1 encryption is compatible with
//! the earlier format, but no old database, DPAPI blob or runtime key is imported.
use crate::state::{Connection, Core, Data, now};
use aes_gcm::{
    Aes256Gcm, KeyInit, Nonce,
    aead::{Aead, AeadCore, OsRng, Payload},
};
use anyhow::{Result, bail, ensure};
use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, HashMap, HashSet};

const MAX: usize = 2 * 1024 * 1024;
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Online {
    pub profile: String,
    pub owner: String,
    pub device: String,
    pub key: String,
    pub connection: String,
    pub member: String,
    pub enabled: bool,
    pub heads: Vec<String>,
    pub seen: Vec<String>,
    pub last_sync: u64,
    pub pending_name: String,
    pub pending: String,
    pub base: Value,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Revision {
    version: u32,
    profile: String,
    owner: String,
    device: String,
    parents: Vec<String>,
    at: u64,
    document: Value,
}
fn hexn(s: &str, n: usize) -> bool {
    s.len() == n
        && s.bytes()
            .all(|b| b.is_ascii_digit() || matches!(b, b'a'..=b'f'))
}
fn hash(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}
impl Online {
    fn prefix(&self) -> String {
        format!("sd-profile-{}-", self.profile)
    }
    fn aad(&self) -> String {
        format!(
            "SigmaDrive/online-profile/1/{}/{}",
            self.profile, self.owner
        )
    }
    fn cipher(&self) -> Result<Aes256Gcm> {
        let key = zeroize::Zeroizing::new(URL_SAFE_NO_PAD.decode(&self.key)?);
        ensure!(key.len() == 32, "invalid profile key");
        Aes256Gcm::new_from_slice(&key).map_err(|_| anyhow::anyhow!("invalid profile key"))
    }
    fn recovery(&self) -> String {
        format!("SDP1.{}.{}.{}", self.profile, self.owner, self.key)
    }
    fn encode(&self, document: Value) -> Result<(String, Vec<u8>)> {
        validate_document(&document)?;
        let plain = zeroize::Zeroizing::new(serde_json::to_vec(&Revision {
            version: 1,
            profile: self.profile.clone(),
            owner: self.owner.clone(),
            device: self.device.clone(),
            parents: self.heads.clone(),
            at: now(),
            document,
        })?);
        ensure!(plain.len() <= MAX / 2, "profile exceeds size bound");
        let nonce = Aes256Gcm::generate_nonce(&mut OsRng);
        let ciphertext = self
            .cipher()?
            .encrypt(
                &nonce,
                Payload {
                    msg: &plain,
                    aad: self.aad().as_bytes(),
                },
            )
            .map_err(|_| anyhow::anyhow!("profile encryption failed"))?;
        let mut bytes = nonce.to_vec();
        bytes.extend(ciphertext);
        Ok((format!("{}{}.bin", self.prefix(), hash(&bytes)), bytes))
    }
    fn decode(&self, name: &str, bytes: &[u8]) -> Result<Revision> {
        ensure!(
            bytes.len() >= 28
                && bytes.len() <= MAX
                && name == format!("{}{}.bin", self.prefix(), hash(bytes)),
            "profile revision checksum mismatch"
        );
        let plain = zeroize::Zeroizing::new(
            self.cipher()?
                .decrypt(
                    Nonce::from_slice(&bytes[..12]),
                    Payload {
                        msg: &bytes[12..],
                        aad: self.aad().as_bytes(),
                    },
                )
                .map_err(|_| anyhow::anyhow!("wrong recovery key or damaged profile"))?,
        );
        let r: Revision = serde_json::from_slice(&plain)?;
        ensure!(
            r.version == 1
                && r.profile == self.profile
                && r.owner == self.owner
                && hexn(&r.device, 32)
                && r.parents.len() <= 256,
            "profile owner or version mismatch"
        );
        validate_document(&r.document)?;
        Ok(r)
    }
}
fn options(provider: &str, key: &str) -> bool {
    match provider {
        "drive" => matches!(key, "root_folder_id" | "team_drive" | "scope"),
        "onedrive" => matches!(key, "drive_id" | "drive_type" | "region"),
        "s3" => matches!(key, "region" | "endpoint" | "bucket"),
        _ => false,
    }
}
fn validate_document(d: &Value) -> Result<()> {
    let obj = d
        .as_object()
        .ok_or_else(|| anyhow::anyhow!("profile document required"))?;
    ensure!(
        obj.keys().all(|k| matches!(
            k.as_str(),
            "version" | "name" | "language" | "connections" | "drives" | "shares"
        )) && d["version"] == 1,
        "unsupported profile document"
    );
    ensure!(
        d["name"].as_str().is_some_and(|s| s.len() <= 256),
        "profile name invalid"
    );
    let connections = d["connections"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("profile connections missing"))?;
    let drives = d["drives"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("profile disks missing"))?;
    ensure!(
        connections.len() <= 256 && drives.len() <= 256,
        "profile entry bound exceeded"
    );
    let mut ids = HashSet::new();
    for c in connections {
        let id = c["id"]
            .as_str()
            .filter(|s| !s.is_empty() && s.len() <= 128)
            .ok_or_else(|| anyhow::anyhow!("connection ID invalid"))?;
        ensure!(
            ids.insert(id) && c["preset"].as_str() != Some("profile"),
            "duplicate/profile-storage connection in portable profile"
        );
        ensure!(
            c.as_object().is_some_and(|m| m.keys().all(|k| matches!(
                k.as_str(),
                "id" | "name" | "provider" | "preset" | "options"
            ))),
            "secret/runtime field in portable connection"
        );
        let provider = c["provider"].as_str().unwrap_or("");
        ensure!(
            matches!(provider, "drive" | "onedrive" | "s3"),
            "provider migration required before import"
        );
        let opts = c["options"]
            .as_object()
            .ok_or_else(|| anyhow::anyhow!("connection options invalid"))?;
        for (key, value) in opts {
            ensure!(
                options(provider, key)
                    && value
                        .as_str()
                        .is_some_and(|s| s.len() <= 8192 && !s.contains('\0')),
                "unsafe portable option"
            );
            if key == "endpoint" {
                let u = reqwest::Url::parse(value.as_str().unwrap())?;
                ensure!(
                    u.scheme() == "https"
                        && u.username().is_empty()
                        && u.password().is_none()
                        && u.query().is_none()
                        && u.fragment().is_none(),
                    "unsafe profile endpoint"
                );
            }
        }
    }
    let mut drive_ids = HashSet::new();
    for drive in drives {
        ensure!(
            drive.as_object().is_some_and(|o| o
                .keys()
                .all(|k| matches!(k.as_str(), "id" | "name" | "mode" | "members" | "access"))),
            "runtime field in portable disk"
        );
        ensure!(
            drive["id"]
                .as_str()
                .is_some_and(|s| !s.is_empty() && s.len() <= 128 && drive_ids.insert(s)),
            "invalid disk ID"
        );
        let members = drive["members"]
            .as_array()
            .ok_or_else(|| anyhow::anyhow!("disk members missing"))?;
        ensure!(
            !members.is_empty() && members.len() <= 64,
            "disk member bound exceeded"
        );
        for member in members {
            ensure!(
                member["connection_id"]
                    .as_str()
                    .is_some_and(|id| ids.contains(id)),
                "disk connection missing"
            );
            ensure!(
                member.as_object().is_some_and(|o| o
                    .keys()
                    .all(|k| matches!(k.as_str(), "connection_id" | "remote_path" | "folder"))),
                "secret/runtime field in portable disk member"
            );
            crate::engine::checked(member["remote_path"].as_str().unwrap_or(""))?;
        }
    }
    if let Some(shares) = d["shares"].as_array() {
        ensure!(shares.len() <= 256, "share bound exceeded");
        for share in shares {
            ensure!(
                share.as_object().is_some_and(|o| o.keys().all(|k| matches!(
                    k.as_str(),
                    "id" | "name" | "protocol" | "members" | "bucket"
                ))),
                "local path or permission material in portable share"
            );
        }
    }
    Ok(())
}
fn export(data: &Data) -> Value {
    let mut cs = data
        .connections
        .values()
        .filter(|c| c.preset != "profile")
        .map(|c| {
            let options = c
                .options
                .iter()
                .filter(|(k, _)| options(&c.provider, k))
                .map(|(k, v)| (k.clone(), json!(v)))
                .collect::<serde_json::Map<_, _>>();
            json!({"id":c.id,"name":c.name,"provider":c.provider,"preset":"","options":options})
        })
        .collect::<Vec<_>>();
    cs.sort_by_key(|c| c["id"].as_str().unwrap_or("").to_owned());
    let mut ds=data.drives.values().map(|d|json!({"id":d["id"],"name":d["name"],"mode":d["mode"],"members":d["members"],"access":d["access_mode"]})).collect::<Vec<_>>();
    ds.sort_by_key(|d| d["id"].as_str().unwrap_or("").to_owned());
    json!({"version":1,"name":"SigmaDrive","language":data.settings["language"],"connections":cs,"drives":ds,"shares":[]})
}
async fn save(core: &Core, mut online: Online) -> Result<()> {
    let mut data = core.data.write().await;
    let mut next = data.clone();
    if data
        .online
        .as_ref()
        .is_some_and(|s| s.profile == online.profile && !s.enabled)
    {
        online.enabled = false;
    }
    next.online = Some(online);
    core.persist(&next)?;
    *data = next;
    Ok(())
}

type ProfileListing = Option<(String, BTreeMap<String, Vec<String>>)>;
struct Cloud {
    connection: String,
    provider: String,
    owner: String,
    folder: String,
    listing: tokio::sync::Mutex<ProfileListing>,
}
impl Cloud {
    async fn open(core: &Core, cid: &str) -> Result<Self> {
        let c = crate::auth::fresh(core, cid).await?;
        ensure!(
            c.preset == "profile",
            "separate profile-folder authorization required"
        );
        let client = c
            .secrets
            .get("client_id")
            .ok_or_else(|| anyhow::anyhow!("profile app registration missing"))?;
        let raw = match c.provider.as_str() {
            "drive" => format!(
                "google/{}/{}",
                client,
                c.options
                    .get("storage_owner")
                    .ok_or_else(|| anyhow::anyhow!("profile storage owner missing"))?
            ),
            "onedrive" => format!(
                "onedrive/{}/{}",
                client,
                c.options
                    .get("drive_id")
                    .ok_or_else(|| anyhow::anyhow!("profile drive owner missing"))?
            ),
            _ => bail!("profile provider unsupported"),
        };
        let mut cloud = Self {
            connection: cid.into(),
            provider: c.provider,
            owner: hash(raw.as_bytes()),
            folder: String::new(),
            listing: tokio::sync::Mutex::new(None),
        };
        if cloud.provider == "onedrive" {
            let v = cloud
                .json(
                    reqwest::Method::GET,
                    "https://graph.microsoft.com/v1.0/me/drive/special/approot".into(),
                    None,
                )
                .await?;
            cloud.folder = v["id"]
                .as_str()
                .filter(|s| !s.is_empty())
                .ok_or_else(|| anyhow::anyhow!("app folder missing"))?
                .into();
        }
        Ok(cloud)
    }
    fn request(&self, method: reqwest::Method, url: String) -> Result<reqwest::RequestBuilder> {
        Ok(reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .timeout(std::time::Duration::from_secs(30))
            .build()?
            .request(method, url)
            .header("X-Sigma-Local-Connection", &self.connection))
    }
    async fn json(
        &self,
        method: reqwest::Method,
        url: String,
        body: Option<Value>,
    ) -> Result<Value> {
        let mut request = self.request(method, url)?;
        if let Some(body) = body {
            request = request.json(&body);
        }
        let response = crate::provider_http::send(request).await?;
        ensure!(
            response.status().is_success(),
            "profile cloud HTTP {}",
            response.status().as_u16()
        );
        let bytes = bounded(response, MAX).await?;
        Ok(serde_json::from_slice(&bytes)?)
    }
    async fn list(&self, prefix: &str) -> Result<BTreeMap<String, Vec<String>>> {
        ensure!(
            prefix.starts_with("sd-profile-") && prefix.len() == 44,
            "invalid profile prefix"
        );
        let mut out = BTreeMap::<String, Vec<String>>::new();
        let mut next = String::new();
        for _ in 0..16 {
            let url = if self.provider == "drive" {
                let mut url = reqwest::Url::parse("https://www.googleapis.com/drive/v3/files")?;
                url.query_pairs_mut().extend_pairs([
                    ("spaces", "appDataFolder"),
                    (
                        "q",
                        format!("trashed = false and name contains '{prefix}'").as_str(),
                    ),
                    ("fields", "nextPageToken,files(id,name)"),
                    ("pageSize", "100"),
                ]);
                if !next.is_empty() {
                    url.query_pairs_mut().append_pair("pageToken", &next);
                }
                url.to_string()
            } else if next.is_empty() {
                format!(
                    "https://graph.microsoft.com/v1.0/me/drive/items/{}/children?$top=100&$select=id,name",
                    crate::safe::encoded(&self.folder)
                )
            } else {
                next.clone()
            };
            let page = self.json(reqwest::Method::GET, url, None).await?;
            for item in page[if self.provider == "drive" {
                "files"
            } else {
                "value"
            }]
            .as_array()
            .ok_or_else(|| anyhow::anyhow!("profile listing invalid"))?
            {
                let name = item["name"].as_str().unwrap_or("");
                if name.starts_with(prefix) {
                    ensure!(
                        name.len() == 112 && name.ends_with(".bin") && hexn(&name[44..108], 64),
                        "invalid immutable profile name"
                    );
                    let id = item["id"]
                        .as_str()
                        .ok_or_else(|| anyhow::anyhow!("profile item ID missing"))?;
                    out.entry(name.into()).or_default().push(id.into());
                    ensure!(out.len() <= 256, "profile history entry limit reached");
                }
            }
            next = page[if self.provider == "drive" {
                "nextPageToken"
            } else {
                "@odata.nextLink"
            }]
            .as_str()
            .unwrap_or("")
            .into();
            if next.is_empty() {
                return Ok(out);
            }
            if self.provider == "onedrive" {
                ensure!(
                    next.starts_with("https://graph.microsoft.com/v1.0/") && !next.contains('#'),
                    "invalid profile pagination origin"
                );
            }
        }
        bail!("profile pagination bound reached")
    }
    async fn read(&self, name: &str) -> Result<Vec<u8>> {
        let prefix = &name[..44];
        let all = {
            let mut cache = self.listing.lock().await;
            if cache.as_ref().is_none_or(|(p, _)| p != prefix) {
                *cache = Some((prefix.to_owned(), self.list(prefix).await?));
            }
            cache.as_ref().unwrap().1.clone()
        };
        let ids = all
            .get(name)
            .ok_or_else(|| anyhow::anyhow!("profile revision missing"))?;
        let mut found = None;
        for id in ids {
            let url = if self.provider == "drive" {
                format!(
                    "https://www.googleapis.com/drive/v3/files/{}?alt=media",
                    crate::safe::encoded(id)
                )
            } else {
                format!(
                    "https://graph.microsoft.com/v1.0/me/drive/items/{}/content",
                    crate::safe::encoded(id)
                )
            };
            let mut response =
                crate::provider_http::send(self.request(reqwest::Method::GET, url)?).await?;
            if self.provider == "onedrive" && matches!(response.status().as_u16(), 302 | 307) {
                let u = reqwest::Url::parse(
                    response
                        .headers()
                        .get("Location")
                        .and_then(|v| v.to_str().ok())
                        .ok_or_else(|| anyhow::anyhow!("profile download redirect missing"))?,
                )?;
                let host = u.host_str().unwrap_or("");
                ensure!(
                    u.scheme() == "https"
                        && u.username().is_empty()
                        && u.password().is_none()
                        && u.port_or_known_default() == Some(443)
                        && ["sharepoint.com", "microsoftpersonalcontent.com", "1drv.com"]
                            .iter()
                            .any(|d| host == *d || host.ends_with(&format!(".{d}"))),
                    "untrusted profile content endpoint"
                );
                response = reqwest::Client::builder()
                    .redirect(reqwest::redirect::Policy::none())
                    .timeout(std::time::Duration::from_secs(30))
                    .build()?
                    .get(u)
                    .send()
                    .await
                    .map_err(|_| anyhow::anyhow!("profile content unavailable"))?;
            }
            ensure!(
                response.status() == 200,
                "profile content HTTP {}",
                response.status().as_u16()
            );
            let bytes = bounded(response, MAX).await?;
            if let Some(old) = &found {
                ensure!(old == &bytes, "duplicate immutable revision conflict");
            }
            found = Some(bytes);
        }
        found.ok_or_else(|| anyhow::anyhow!("profile revision missing"))
    }
    async fn create(&self, name: &str, bytes: &[u8]) -> Result<()> {
        ensure!(
            bytes.len() <= MAX && name.len() == 112,
            "invalid profile object"
        );
        let all = self.list(&name[..44]).await?;
        *self.listing.lock().await = Some((name[..44].to_owned(), all.clone()));
        if all.contains_key(name) {
            ensure!(
                self.read(name).await? == bytes,
                "immutable revision changed"
            );
            return Ok(());
        }
        let request = if self.provider == "drive" {
            let boundary = format!("sigma-{}", uuid::Uuid::new_v4().simple());
            let meta = json!({"name":name,"parents":["appDataFolder"]});
            let mut body=format!("--{boundary}\r\nContent-Type: application/json\r\n\r\n{meta}\r\n--{boundary}\r\nContent-Type: application/octet-stream\r\n\r\n").into_bytes();
            body.extend_from_slice(bytes);
            body.extend_from_slice(format!("\r\n--{boundary}--\r\n").as_bytes());
            self.request(
                reqwest::Method::POST,
                "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id"
                    .into(),
            )?
            .header(
                "Content-Type",
                format!("multipart/related; boundary={boundary}"),
            )
            .body(body)
        } else {
            self.request(reqwest::Method::PUT,format!("https://graph.microsoft.com/v1.0/me/drive/items/{}:/{}:/content?@microsoft.graph.conflictBehavior=fail",crate::safe::encoded(&self.folder),name))?.header("If-None-Match","*").body(bytes.to_vec())
        };
        let response = crate::provider_http::send(request).await?;
        ensure!(
            response.status().is_success(),
            "profile upload HTTP {}; pending revision retained",
            response.status().as_u16()
        );
        *self.listing.lock().await = None;
        Ok(())
    }
}
async fn bounded(response: reqwest::Response, max: usize) -> Result<Vec<u8>> {
    use futures_util::StreamExt;
    let mut bytes = Vec::new();
    let mut stream = response.bytes_stream();
    while let Some(c) = stream.next().await {
        let c = c.map_err(|_| anyhow::anyhow!("profile response interrupted"))?;
        ensure!(
            bytes.len() + c.len() <= max,
            "profile response bound exceeded"
        );
        bytes.extend_from_slice(&c);
    }
    Ok(bytes)
}

async fn publish(core: &Core, remote: &Cloud, mut state: Online) -> Result<Online> {
    ensure!(state.owner == remote.owner, "profile account changed");
    if state.pending_name.is_empty() {
        let document = export(&*core.data.read().await);
        let (name, bytes) = state.encode(document)?;
        state.pending_name = name;
        state.pending = URL_SAFE_NO_PAD.encode(bytes);
        save(core, state.clone()).await?;
    }
    let bytes = URL_SAFE_NO_PAD.decode(&state.pending)?;
    remote.create(&state.pending_name, &bytes).await?;
    let actual = remote.read(&state.pending_name).await?;
    ensure!(actual == bytes, "profile upload verification failed");
    let revision = state.decode(&state.pending_name, &actual)?;
    state.heads = vec![state.pending_name.clone()];
    if !state.seen.contains(&state.pending_name) {
        state.seen.push(state.pending_name.clone());
    }
    state.base = revision.document;
    state.pending.clear();
    state.pending_name.clear();
    state.last_sync = now();
    save(core, state.clone()).await?;
    Ok(state)
}
async fn history(
    remote: &Cloud,
    state: &Online,
) -> Result<(Vec<String>, HashMap<String, Revision>)> {
    let names = remote.list(&state.prefix()).await?;
    ensure!(
        !names.is_empty(),
        "online profile missing; local settings retained"
    );
    let mut records = HashMap::new();
    let mut total = 0;
    for name in names.keys() {
        let bytes = remote.read(name).await?;
        total += bytes.len();
        ensure!(
            total <= 16 * 1024 * 1024,
            "profile history exceeds16MiB; revisions retained"
        );
        records.insert(name.clone(), state.decode(name, &bytes)?);
    }
    ensure!(
        state.seen.iter().all(|n| records.contains_key(n)),
        "previous profile revision missing; possible rollback"
    );
    let mut parents = HashSet::new();
    for (name, r) in &records {
        for p in &r.parents {
            ensure!(
                p != name && records.contains_key(p),
                "profile ancestry missing or cyclic"
            );
            parents.insert(p.clone());
        }
    }
    fn visit(
        name: &str,
        records: &HashMap<String, Revision>,
        colors: &mut HashMap<String, u8>,
    ) -> Result<()> {
        ensure!(colors.get(name) != Some(&1), "cyclic profile history");
        if colors.get(name) == Some(&2) {
            return Ok(());
        }
        colors.insert(name.into(), 1);
        for p in &records[name].parents {
            visit(p, records, colors)?;
        }
        colors.insert(name.into(), 2);
        Ok(())
    }
    let mut colors = HashMap::new();
    for name in records.keys() {
        visit(name, &records, &mut colors)?;
    }
    let mut heads = records
        .keys()
        .filter(|n| !parents.contains(*n))
        .cloned()
        .collect::<Vec<_>>();
    heads.sort();
    ensure!(!heads.is_empty(), "profile has no head");
    Ok((heads, records))
}
pub async fn presence(core: &Core) -> Result<String> {
    let data = core.data.read().await;
    let state = data
        .online
        .clone()
        .ok_or_else(|| anyhow::anyhow!("profile_required"))?;
    let member = data
        .member
        .as_ref()
        .ok_or_else(|| anyhow::anyhow!("login_required"))?;
    ensure!(
        state.enabled
            && state.member == member["memberId"].as_str().unwrap_or("")
            && state.connection == member["connection"].as_str().unwrap_or(""),
        "profile_account_mismatch"
    );
    drop(data);
    let remote = Cloud::open(core, &state.connection).await?;
    ensure!(
        remote.owner == state.owner && !state.heads.is_empty() && state.last_sync > 0,
        "profile owner or revision not confirmed"
    );
    let listed = remote.list(&state.prefix()).await?;
    ensure!(
        state.heads.iter().all(|n| listed.contains_key(n)),
        "confirmed profile revision missing"
    );
    Ok(if remote.provider == "drive" {
        "google"
    } else {
        "microsoft"
    }
    .into())
}
pub async fn readiness(core: &Core) -> Result<String> {
    let (fingerprint, provider) = {
        let data = core.data.read().await;
        let s = data
            .online
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("profile_required"))?;
        ensure!(s.enabled, "profile_paused");
        let provider = data
            .connections
            .get(&s.connection)
            .ok_or_else(|| anyhow::anyhow!("profile connection missing"))?
            .provider
            .clone();
        (
            hash(&serde_json::to_vec(&(
                &s.profile,
                &s.owner,
                &s.connection,
                &s.member,
                &s.heads,
            ))?),
            provider,
        )
    };
    if core.profile_proof.lock().is_ok_and(|proof| {
        proof.as_ref().is_some_and(|(key, at)| {
            key == &fingerprint && at.elapsed() < std::time::Duration::from_secs(30)
        })
    }) {
        return Ok(if provider == "drive" {
            "google"
        } else {
            "microsoft"
        }
        .into());
    }
    let attempt = tokio::time::timeout(std::time::Duration::from_secs(5), presence(core)).await;
    match attempt {
        Ok(Ok(provider)) => {
            *core
                .profile_proof
                .lock()
                .map_err(|_| anyhow::anyhow!("profile proof unavailable"))? =
                Some((fingerprint, std::time::Instant::now()));
            Ok(provider)
        }
        failure => {
            let transient = failure.is_err()
                || matches!(&failure,Ok(Err(e)) if e.is::<crate::provider_http::Unavailable>());
            let mut cache = core
                .profile_proof
                .lock()
                .map_err(|_| anyhow::anyhow!("profile proof unavailable"))?;
            if transient
                && cache.as_ref().is_some_and(|(key, at)| {
                    key == &fingerprint && at.elapsed() < std::time::Duration::from_secs(600)
                })
            {
                return Ok(if provider == "drive" {
                    "google"
                } else {
                    "microsoft"
                }
                .into());
            }
            *cache = None;
            bail!("profile verification unavailable or revoked")
        }
    }
}
pub async fn manage(core: &Core, body: &Value) -> Result<Value> {
    if body["action"] == "cloud_pause" {
        // Cancellation and durable disable precede waiting for a slow profile I/O.
        crate::sharing::stop_all(core).await;
        let mut d = core.data.write().await;
        let mut next = d.clone();
        let state = next
            .online
            .as_mut()
            .ok_or_else(|| anyhow::anyhow!("profile missing"))?;
        state.enabled = false;
        let saved = core.persist(&next);
        *d = next;
        if let Ok(mut proof) = core.profile_proof.lock() {
            *proof = None;
        }
        saved?;
        return Ok(json!({}));
    }
    let action = body["action"].as_str().unwrap_or("cloud_status");
    if action == "cloud_status" {
        let state = core.data.read().await.online.clone();
        return Ok(
            json!({"export_data":state.map(|s|json!({"enabled":s.enabled,"profile":s.profile,"connection":s.connection,"last_sync":s.last_sync,"pending":!s.pending_name.is_empty()})).unwrap_or(json!({"enabled":false})).to_string()}),
        );
    }
    let _control = core.profile_control.lock().await;
    if action == "cloud_key" {
        let data = core.data.read().await;
        let state = data
            .online
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("profile not connected"))?;
        return Ok(json!({"export_data":json!({"recovery":state.recovery()}).to_string()}));
    }
    if action == "cloud_resume" {
        let mut data = core.data.write().await;
        let mut next = data.clone();
        let online = next
            .online
            .as_mut()
            .ok_or_else(|| anyhow::anyhow!("profile missing"))?;
        online.enabled = true;
        core.persist(&next)?;
        *data = next;
        return Ok(json!({}));
    }
    let member = core
        .data
        .read()
        .await
        .member
        .clone()
        .ok_or_else(|| anyhow::anyhow!("member login required"))?;
    let cid = body["id"]
        .as_str()
        .filter(|s| !s.is_empty())
        .map(str::to_owned)
        .or_else(|| {
            core.data
                .try_read()
                .ok()
                .and_then(|d| d.online.as_ref().map(|s| s.connection.clone()))
        })
        .ok_or_else(|| anyhow::anyhow!("profile connection required"))?;
    ensure!(
        member["connection"] == cid && member["expiresAt"].as_u64().unwrap_or(0) > now(),
        "sign in as the profile owner first"
    );
    let remote = Cloud::open(core, &cid).await?;
    match action {
        "cloud_create" => {
            let old = core.data.read().await.online.clone();
            let state = if let Some(old) = old {
                ensure!(
                    old.connection == cid && !old.pending_name.is_empty(),
                    "profile already exists; sync or restore explicitly"
                );
                old
            } else {
                Online {
                    profile: uuid::Uuid::new_v4().simple().to_string(),
                    owner: remote.owner.clone(),
                    device: uuid::Uuid::new_v4().simple().to_string(),
                    key: URL_SAFE_NO_PAD.encode(Aes256Gcm::generate_key(&mut OsRng)),
                    connection: cid,
                    member: member["memberId"].as_str().unwrap_or("").into(),
                    enabled: true,
                    heads: vec![],
                    seen: vec![],
                    last_sync: 0,
                    pending_name: String::new(),
                    pending: String::new(),
                    base: Value::Null,
                }
            };
            let state = publish(core, &remote, state).await?;
            Ok(
                json!({"export_data":json!({"recovery":state.recovery(),"profile":state.profile}).to_string()}),
            )
        }
        "cloud_restore" => {
            ensure!(
                core.data.read().await.online.is_none(),
                "disconnect the current profile explicitly before restoring another"
            );
            let code = body["recovery"]
                .as_str()
                .or(body["password"].as_str())
                .ok_or_else(|| anyhow::anyhow!("recovery key required"))?;
            let p = code.trim().split('.').collect::<Vec<_>>();
            ensure!(
                p.len() == 4
                    && p[0] == "SDP1"
                    && hexn(p[1], 32)
                    && hexn(p[2], 64)
                    && p[2] == remote.owner
                    && URL_SAFE_NO_PAD.decode(p[3])?.len() == 32,
                "invalid recovery key or different cloud owner"
            );
            let mut state = Online {
                profile: p[1].into(),
                owner: p[2].into(),
                key: p[3].into(),
                device: uuid::Uuid::new_v4().simple().to_string(),
                connection: cid,
                member: member["memberId"].as_str().unwrap_or("").into(),
                enabled: true,
                heads: vec![],
                seen: vec![],
                last_sync: 0,
                pending_name: String::new(),
                pending: String::new(),
                base: Value::Null,
            };
            let (heads, records) = history(&remote, &state).await?;
            ensure!(
                heads.len() == 1,
                "multiple profile heads: resolve without overwriting either revision"
            );
            let document = &records[&heads[0]].document;
            let _drive_control = core.drive_control.lock().await;
            ensure!(
                core.mounts
                    .lock()
                    .map_err(|_| anyhow::anyhow!("mount lock unavailable"))?
                    .is_empty(),
                "unmount new-core disks before restoring configuration"
            );
            let mut data = core.data.write().await;
            let mut next = data.clone();
            for c in document["connections"].as_array().unwrap() {
                let id = c["id"].as_str().unwrap();
                let options: HashMap<String, String> =
                    serde_json::from_value(c["options"].clone())?;
                let keep = next.connections.get(id).is_some_and(|prior| {
                    prior.provider == c["provider"].as_str().unwrap()
                        && prior
                            .options
                            .iter()
                            .filter(|(k, _)| crate::profile::options(&prior.provider, k))
                            .all(|(k, v)| options.get(k) == Some(v))
                });
                if !keep {
                    next.connections.insert(
                        id.into(),
                        Connection {
                            id: id.into(),
                            name: c["name"].as_str().unwrap_or("Cloud").into(),
                            provider: c["provider"].as_str().unwrap().into(),
                            preset: String::new(),
                            options,
                            secrets: HashMap::new(),
                        },
                    );
                }
            }
            // Imported definitions have no local letter, automatic mount, folder path,
            // grants or credentials. Existing device-specific entries remain untouched.
            next.settings["restored_profile_drives"] = document["drives"].clone();
            next.settings["restored_profile_shares"] = document["shares"].clone();
            state.heads = heads;
            state.seen = records.keys().cloned().collect();
            state.base = document.clone();
            state.last_sync = now();
            next.online = Some(state);
            core.persist(&next)?;
            *data = next;
            Ok(
                json!({"export_data":json!({"restored":true,"requires_local_connections":true,"local_mounts_unchanged":true}).to_string()}),
            )
        }
        "cloud_sync" => {
            let mut state = core
                .data
                .read()
                .await
                .online
                .clone()
                .ok_or_else(|| anyhow::anyhow!("profile missing"))?;
            let (heads, records) = history(&remote, &state).await?;
            ensure!(
                heads.len() == 1 && heads == state.heads,
                "profile changed on another device; restore/resolve explicitly, both versions retained"
            );
            if !state.pending_name.is_empty()
                || export(&*core.data.read().await) != records[&heads[0]].document
            {
                state = publish(core, &remote, state).await?;
            }
            Ok(
                json!({"export_data":json!({"profile":state.profile,"last_sync":state.last_sync}).to_string()}),
            )
        }
        _ => bail!("unsupported online profile action"),
    }
}
