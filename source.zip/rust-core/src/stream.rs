//! S3 multipart checkpoint extension. OpenDAL supplies ordinary storage reads;
//! a Rust protocol adapter persists upload sessions unavailable through Writer.
use crate::{
    Config,
    engine::{atomic, hash},
    safe::encoded,
    v2::file_hash,
};
use anyhow::{Result, ensure};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::Sha256;
use std::{
    fs::{self, File},
    io::{Read, Seek, SeekFrom},
};
fn hm(k: &[u8], b: &str) -> Vec<u8> {
    let mut h = Hmac::<Sha256>::new_from_slice(k).unwrap();
    h.update(b.as_bytes());
    h.finalize().into_bytes().to_vec()
}
pub async fn request(
    cfg: &Config,
    method: &str,
    path: &str,
    query: &[(&str, String)],
    body: Vec<u8>,
    condition: bool,
) -> Result<reqwest::Response> {
    let endpoint = reqwest::Url::parse(cfg.get("endpoint"))?;
    ensure!(
        endpoint.username().is_empty() && endpoint.password().is_none(),
        "endpoint userinfo forbidden"
    );
    let host = endpoint
        .host_str()
        .ok_or_else(|| anyhow::anyhow!("endpoint host"))?;
    let host = match endpoint.port() {
        Some(p) => format!("{host}:{p}"),
        None => host.to_owned(),
    };
    let key = crate::remote_path(&cfg.root, path);
    let uri = format!(
        "/{}/{}",
        encoded(cfg.get("bucket")),
        key.split('/').map(encoded).collect::<Vec<_>>().join("/")
    );
    let mut pairs = query
        .iter()
        .map(|(k, v)| (encoded(k), encoded(v)))
        .collect::<Vec<_>>();
    pairs.sort();
    let qs = pairs
        .into_iter()
        .map(|(k, v)| format!("{k}={v}"))
        .collect::<Vec<_>>()
        .join("&");
    let ts = jiff::Timestamp::now()
        .strftime("%Y%m%dT%H%M%SZ")
        .to_string();
    let date = &ts[..8];
    let ph = hash(&body);
    let signed = "host;x-amz-content-sha256;x-amz-date";
    let canonical = format!(
        "{method}\n{uri}\n{qs}\nhost:{host}\nx-amz-content-sha256:{ph}\nx-amz-date:{ts}\n\n{signed}\n{ph}"
    );
    let region = cfg.get("region");
    let scope = format!("{date}/{region}/s3/aws4_request");
    let tosign = format!(
        "AWS4-HMAC-SHA256\n{ts}\n{scope}\n{}",
        hash(canonical.as_bytes())
    );
    let kd = hm(
        format!("AWS4{}", cfg.get("secret_access_key")).as_bytes(),
        date,
    );
    let kr = hm(&kd, region);
    let ks = hm(&kr, "s3");
    let key = hm(&ks, "aws4_request");
    let sig = hex::encode(hm(&key, &tosign));
    let auth = format!(
        "AWS4-HMAC-SHA256 Credential={}/{scope}, SignedHeaders={signed}, Signature={sig}",
        cfg.get("access_key_id")
    );
    let url = format!(
        "{}{}{}",
        cfg.get("endpoint").trim_end_matches('/'),
        uri,
        if qs.is_empty() {
            String::new()
        } else {
            format!("?{qs}")
        }
    );
    let client = reqwest::Client::builder()
        .redirect(reqwest::redirect::Policy::none())
        .timeout(std::time::Duration::from_secs(90))
        .build()?;
    let mut req = client
        .request(reqwest::Method::from_bytes(method.as_bytes())?, url)
        .header("Authorization", auth)
        .header("x-amz-date", ts)
        .header("x-amz-content-sha256", ph);
    if condition {
        req = req.header("If-None-Match", "*")
    }
    req.body(body)
        .send()
        .await
        .map_err(|_| anyhow::Error::new(crate::provider_http::Unavailable))
}
#[derive(Serialize, Deserialize, Clone)]
struct Part {
    number: usize,
    etag: String,
    bytes: u64,
    sha256: String,
}
#[derive(Serialize, Deserialize)]
struct State {
    scope: String,
    source_sha256: String,
    size: u64,
    upload_id: String,
    parts: Vec<Part>,
    completed: bool,
}
#[derive(Deserialize)]
struct Init {
    #[serde(rename = "UploadId")]
    id: String,
}
#[derive(Deserialize)]
struct Listing {
    #[serde(rename = "Part", default)]
    parts: Vec<ListPart>,
}
#[derive(Deserialize)]
struct ListPart {
    #[serde(rename = "PartNumber")]
    n: usize,
    #[serde(rename = "ETag")]
    etag: String,
    #[serde(rename = "Size")]
    size: u64,
}
pub async fn upload(cfg: &Config) -> Result<serde_json::Value> {
    if cfg.provider == "drive" || cfg.provider == "onedrive" {
        return crate::cloud::upload(cfg).await;
    }
    ensure!(
        cfg.provider == "s3",
        "resumable streaming upload requires S3, Google Drive or OneDrive"
    );
    fs::create_dir_all(&cfg.work)?;
    let source = std::path::Path::new(cfg.get("source"));
    let size = source.metadata()?.len();
    let sha = file_hash(source)?;
    let name = cfg.get("path");
    let scope = hash(
        serde_json::to_vec(&(
            cfg.root.clone(),
            cfg.get("endpoint"),
            cfg.get("bucket"),
            name,
        ))?
        .as_slice(),
    );
    let checkpoint = cfg.work.join("upload.json");
    let mut s = if checkpoint.exists() {
        let s: State = serde_json::from_slice(&fs::read(&checkpoint)?)?;
        ensure!(
            s.scope == scope && s.size == size && s.source_sha256 == sha,
            "upload scope/source changed; local source retained"
        );
        s
    } else {
        let r = request(
            cfg,
            "POST",
            name,
            &[("uploads", String::new())],
            vec![],
            false,
        )
        .await?;
        ensure!(
            r.status().is_success(),
            "multipart init HTTP {}",
            r.status().as_u16()
        );
        let t = r.text().await.map_err(|_| anyhow::anyhow!("init body"))?;
        let i: Init =
            quick_xml::de::from_str(&t).map_err(|_| anyhow::anyhow!("invalid init XML"))?;
        let s = State {
            scope,
            source_sha256: sha.clone(),
            size,
            upload_id: i.id,
            parts: vec![],
            completed: false,
        };
        atomic(&checkpoint, &serde_json::to_vec(&s)?)?;
        s
    };
    if s.completed {
        return Ok(
            serde_json::json!({"completed":true,"received_bytes":0,"reused_bytes":size,"sha256":sha}),
        );
    }
    if !s.parts.is_empty() {
        let r = request(
            cfg,
            "GET",
            name,
            &[("uploadId", s.upload_id.clone())],
            vec![],
            false,
        )
        .await?;
        ensure!(
            r.status().is_success(),
            "multipart list HTTP {}",
            r.status().as_u16()
        );
        let t = r.text().await.map_err(|_| anyhow::anyhow!("list body"))?;
        let list: Listing =
            quick_xml::de::from_str(&t).map_err(|_| anyhow::anyhow!("invalid parts XML"))?;
        for p in &s.parts {
            ensure!(
                list.parts
                    .iter()
                    .any(|a| a.n == p.number && a.etag == p.etag && a.size == p.bytes),
                "server checkpoint differs; held"
            );
        }
    }
    let reused = s.parts.iter().map(|p| p.bytes).sum::<u64>();
    let mut offset = reused;
    let mut f = File::open(source)?;
    f.seek(SeekFrom::Start(offset))?;
    let chunk = 8 * 1024 * 1024u64;
    let stop = cfg.get("stop_after_parts").parse::<usize>().unwrap_or(0);
    while offset < size {
        let mut b = vec![0; (size - offset).min(chunk) as usize];
        f.read_exact(&mut b)?;
        let digest = hash(&b);
        let n = s.parts.len() + 1;
        let count = b.len() as u64;
        let r = request(
            cfg,
            "PUT",
            name,
            &[
                ("partNumber", n.to_string()),
                ("uploadId", s.upload_id.clone()),
            ],
            b,
            false,
        )
        .await?;
        ensure!(
            r.status().is_success(),
            "upload part HTTP {}",
            r.status().as_u16()
        );
        let etag = r
            .headers()
            .get("etag")
            .ok_or_else(|| anyhow::anyhow!("no part ETag"))?
            .to_str()?
            .to_owned();
        s.parts.push(Part {
            number: n,
            etag,
            bytes: count,
            sha256: digest,
        });
        atomic(&checkpoint, &serde_json::to_vec(&s)?)?;
        offset += count;
        let delay = cfg.get("delay_ms").parse::<u64>().unwrap_or(0);
        if delay > 0 {
            tokio::time::sleep(std::time::Duration::from_millis(delay)).await
        }
        if stop > 0 && s.parts.len() >= stop {
            break;
        }
    }
    if offset == size {
        let mut xml = String::from("<CompleteMultipartUpload>");
        for p in &s.parts {
            xml.push_str(&format!(
                "<Part><PartNumber>{}</PartNumber><ETag>{}</ETag></Part>",
                p.number, p.etag
            ));
        }
        xml.push_str("</CompleteMultipartUpload>");
        let r = request(
            cfg,
            "POST",
            name,
            &[("uploadId", s.upload_id.clone())],
            xml.into_bytes(),
            true,
        )
        .await?;
        ensure!(
            r.status().is_success(),
            "complete HTTP {}; source retained",
            r.status().as_u16()
        );
        let response = r
            .text()
            .await
            .map_err(|_| anyhow::anyhow!("complete body"))?;
        ensure!(
            !response.contains("<Error>"),
            "complete returned an error; source retained"
        );
        s.completed = true;
        atomic(&checkpoint, &serde_json::to_vec(&s)?)?;
    }
    Ok(
        serde_json::json!({"completed":s.completed,"received_bytes":offset-reused,"reused_bytes":reused,"total_bytes":size,"sha256":sha,"parts":s.parts.len(),"buffer_bytes":chunk,"protocol":"Rust S3 multipart checkpoint extension"}),
    )
}
