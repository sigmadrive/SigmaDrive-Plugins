//! S3 protocol/signature parsing stays in s3s; filesystem access stays under a
//! handle-relative capability root. No anonymous or cross-recipient credentials.
use crate::share_fs::Root;
use futures_util::StreamExt;
use s3s::{S3, S3Error, S3Request, S3Response, S3Result, dto::*, s3_error};
use serde_json::json;
use sha2::{Digest, Sha256};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
use tokio::io::{AsyncReadExt, AsyncSeekExt};
#[derive(Clone)]
pub struct Store {
    pub root: Arc<Root>,
    pub pin: String,
    pub access: String,
    pub writable: bool,
    pub stopped: Arc<AtomicBool>,
    pub lease_owner: Arc<std::sync::Mutex<Vec<crate::leases::Guard>>>,
}
fn error(e: anyhow::Error) -> S3Error {
    let message = e.to_string();
    if message.contains("precondition") || message.contains("conflict") {
        s3_error!(PreconditionFailed)
    } else if e
        .downcast_ref::<std::io::Error>()
        .is_some_and(|e| e.kind() == std::io::ErrorKind::NotFound)
    {
        s3_error!(NoSuchKey)
    } else {
        s3_error!(InvalidRequest)
    }
}
fn expected(value: Option<&ETagCondition>) -> Option<String> {
    value
        .and_then(ETagCondition::as_etag)
        .map(|e| format!("\"{}\"", e.value()))
}
fn tag(value: &str) -> ETag {
    ETag::Strong(value.trim_matches('"').into())
}
impl Store {
    fn check<T>(&self, request: &S3Request<T>, bucket: &str, write: bool) -> S3Result<()> {
        if bucket != self.root.bucket
            || self.stopped.load(Ordering::Acquire)
            || write && !self.writable
            || request
                .credentials
                .as_ref()
                .is_none_or(|c| c.access_key != self.access)
        {
            return Err(s3_error!(AccessDenied));
        }
        Ok(())
    }
    fn upload(&self, id: &str, key: &str) -> S3Result<serde_json::Value> {
        let m = self.root.manifest(id).map_err(error)?;
        if m["pin"] != self.pin || m["key"] != key || m["aborted"] == true {
            return Err(s3_error!(NoSuchUpload));
        }
        Ok(m)
    }
}
async fn body(
    mut body: Option<StreamingBlob>,
    size: Option<i64>,
    stop: &AtomicBool,
) -> S3Result<Vec<u8>> {
    let size = size
        .filter(|n| *n >= 0 && *n <= 8 * 1024 * 1024)
        .ok_or_else(|| s3_error!(MissingContentLength))? as usize;
    let mut bytes = Vec::with_capacity(size);
    if let Some(body) = body.as_mut() {
        while let Some(chunk) = body.next().await {
            if stop.load(Ordering::Acquire) {
                return Err(s3_error!(AccessDenied));
            }
            let chunk = chunk.map_err(|_| s3_error!(IncompleteBody))?;
            if bytes.len() + chunk.len() > size {
                return Err(s3_error!(EntityTooLarge));
            }
            bytes.extend_from_slice(&chunk);
        }
    }
    if bytes.len() != size {
        return Err(s3_error!(IncompleteBody));
    }
    Ok(bytes)
}
#[async_trait::async_trait]
impl S3 for Store {
    async fn list_buckets(
        &self,
        r: S3Request<ListBucketsInput>,
    ) -> S3Result<S3Response<ListBucketsOutput>> {
        self.check(&r, &self.root.bucket, false)?;
        Ok(S3Response::new(ListBucketsOutput {
            buckets: Some(vec![Bucket {
                name: Some(self.root.bucket.clone()),
                ..Default::default()
            }]),
            ..Default::default()
        }))
    }
    async fn head_bucket(
        &self,
        r: S3Request<HeadBucketInput>,
    ) -> S3Result<S3Response<HeadBucketOutput>> {
        self.check(&r, &r.input.bucket, false)?;
        Ok(S3Response::new(HeadBucketOutput::default()))
    }
    async fn get_bucket_location(
        &self,
        r: S3Request<GetBucketLocationInput>,
    ) -> S3Result<S3Response<GetBucketLocationOutput>> {
        self.check(&r, &r.input.bucket, false)?;
        Ok(S3Response::new(GetBucketLocationOutput::default()))
    }
    async fn list_objects_v2(
        &self,
        r: S3Request<ListObjectsV2Input>,
    ) -> S3Result<S3Response<ListObjectsV2Output>> {
        self.check(&r, &r.input.bucket, false)?;
        let i = r.input;
        let prefix = i.prefix.unwrap_or_default();
        let after = i.continuation_token.or(i.start_after).unwrap_or_default();
        let limit = i.max_keys.unwrap_or(1000).clamp(1, 1000) as usize;
        let (items, more) = self.root.list(&prefix, &after, limit).map_err(error)?;
        let next = items.last().map(|e| e.key.clone());
        let mut contents = Vec::new();
        let mut common = std::collections::BTreeSet::new();
        for e in items {
            if i.delimiter.as_deref() == Some("/")
                && let Some(end) = e.key[prefix.len()..].find('/')
            {
                common.insert(e.key[..prefix.len() + end + 1].to_owned());
                continue;
            }
            contents.push(Object {
                key: Some(e.key),
                size: Some(e.size as i64),
                e_tag: Some(tag(&e.etag)),
                ..Default::default()
            });
        }
        Ok(S3Response::new(ListObjectsV2Output {
            name: Some(self.root.bucket.clone()),
            prefix: Some(prefix),
            max_keys: Some(limit as i32),
            key_count: Some((contents.len() + common.len()) as i32),
            is_truncated: Some(more),
            next_continuation_token: if more { next } else { None },
            contents: Some(contents),
            common_prefixes: Some(
                common
                    .into_iter()
                    .map(|p| CommonPrefix { prefix: Some(p) })
                    .collect(),
            ),
            delimiter: i.delimiter,
            ..Default::default()
        }))
    }
    async fn head_object(
        &self,
        r: S3Request<HeadObjectInput>,
    ) -> S3Result<S3Response<HeadObjectOutput>> {
        self.check(&r, &r.input.bucket, false)?;
        let f = self.root.read(&r.input.key).map_err(error)?;
        if expected(r.input.if_match.as_ref()).is_some_and(|e| e != f.etag) {
            return Err(s3_error!(PreconditionFailed));
        }
        let root = self.root.clone();
        let key = r.input.key.clone();
        let stop = self.stopped.clone();
        let owner = self.lease_owner.clone();
        let hash = tokio::task::spawn_blocking(move || {
            let _owner = owner;
            root.content_hash(&key, &stop)
        })
        .await
        .map_err(|_| s3_error!(InternalError))?
        .map_err(error)?;
        Ok(S3Response::new(HeadObjectOutput {
            content_length: Some(f.size as i64),
            e_tag: Some(tag(&f.etag)),
            accept_ranges: Some("bytes".into()),
            metadata: Some(std::collections::HashMap::from([(
                "sigma-sha256".into(),
                hash,
            )])),
            ..Default::default()
        }))
    }
    async fn get_object(
        &self,
        r: S3Request<GetObjectInput>,
    ) -> S3Result<S3Response<GetObjectOutput>> {
        self.check(&r, &r.input.bucket, false)?;
        let f = self.root.read(&r.input.key).map_err(error)?;
        if expected(r.input.if_match.as_ref()).is_some_and(|e| e != f.etag) {
            return Err(s3_error!(PreconditionFailed));
        }
        let partial = r.input.range.is_some();
        let range = if let Some(range) = r.input.range {
            range.check(f.size)?
        } else {
            0..f.size
        };
        let length = range.end - range.start;
        let mut file = tokio::fs::File::from_std(f.file);
        file.seek(std::io::SeekFrom::Start(range.start))
            .await
            .map_err(|_| s3_error!(InternalError))?;
        let stop = self.stopped.clone();
        let stream =
            futures_util::stream::try_unfold((file, length), move |(mut file, remaining)| {
                let stop = stop.clone();
                async move {
                    if stop.load(Ordering::Acquire) {
                        return Err(std::io::Error::new(
                            std::io::ErrorKind::PermissionDenied,
                            "authorization revoked",
                        ));
                    }
                    if remaining == 0 {
                        return Ok(None);
                    }
                    let mut bytes = vec![0u8; remaining.min(1024 * 1024) as usize];
                    file.read_exact(&mut bytes).await?;
                    let n = bytes.len() as u64;
                    Ok(Some((bytes::Bytes::from(bytes), (file, remaining - n))))
                }
            });
        Ok(S3Response::with_status(
            GetObjectOutput {
                body: Some(StreamingBlob::wrap(stream)),
                content_length: Some(length as i64),
                e_tag: Some(tag(&f.etag)),
                accept_ranges: Some("bytes".into()),
                content_range: if partial {
                    Some(format!(
                        "bytes {}-{}/{}",
                        range.start,
                        range.end - 1,
                        f.size
                    ))
                } else {
                    None
                },
                ..Default::default()
            },
            if partial {
                http::StatusCode::PARTIAL_CONTENT
            } else {
                http::StatusCode::OK
            },
        ))
    }
    async fn put_object(
        &self,
        r: S3Request<PutObjectInput>,
    ) -> S3Result<S3Response<PutObjectOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        let i = r.input;
        let bytes = body(i.body, i.content_length, &self.stopped).await?;
        let _write = self.root.writes.lock().await;
        let (f, name) = self.root.stage(&bytes).map_err(error)?;
        drop(f);
        if self.stopped.load(Ordering::Acquire) {
            return Err(s3_error!(AccessDenied));
        }
        let e = expected(i.if_match.as_ref());
        let etag = self
            .root
            .commit(
                &i.key,
                &name,
                e.as_deref(),
                i.if_none_match.as_ref().is_some_and(ETagCondition::is_any),
            )
            .map_err(error)?;
        Ok(S3Response::new(PutObjectOutput {
            e_tag: Some(tag(&etag)),
            ..Default::default()
        }))
    }
    async fn delete_object(
        &self,
        r: S3Request<DeleteObjectInput>,
    ) -> S3Result<S3Response<DeleteObjectOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        let _write = self.root.writes.lock().await;
        let e = expected(r.input.if_match.as_ref());
        self.root
            .delete(&r.input.key, e.as_deref())
            .map_err(error)?;
        Ok(S3Response::new(DeleteObjectOutput::default()))
    }
    async fn create_multipart_upload(
        &self,
        r: S3Request<CreateMultipartUploadInput>,
    ) -> S3Result<S3Response<CreateMultipartUploadOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        crate::share_fs::key(&r.input.key).map_err(error)?;
        let _write = self.root.writes.lock().await;
        let id=self.root.create_upload(&json!({"pin":self.pin,"key":r.input.key,"parts":{},"at":crate::state::now(),"aborted":false})).map_err(error)?;
        Ok(S3Response::new(CreateMultipartUploadOutput {
            upload_id: Some(id),
            bucket: Some(self.root.bucket.clone()),
            key: Some(r.input.key),
            ..Default::default()
        }))
    }
    async fn upload_part(
        &self,
        r: S3Request<UploadPartInput>,
    ) -> S3Result<S3Response<UploadPartOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        let i = r.input;
        let bytes = body(i.body, i.content_length, &self.stopped).await?;
        let _write = self.root.writes.lock().await;
        let mut m = self.upload(&i.upload_id, &i.key)?;
        if m["complete"] == true {
            return Err(s3_error!(NoSuchUpload));
        }
        let etag = self
            .root
            .write_part(&i.upload_id, i.part_number, &bytes)
            .map_err(error)?;
        m["parts"][i.part_number.to_string()] = json!({"etag":etag,"bytes":bytes.len()});
        self.root.save_manifest(&i.upload_id, &m).map_err(error)?;
        Ok(S3Response::new(UploadPartOutput {
            e_tag: Some(tag(&etag)),
            ..Default::default()
        }))
    }
    async fn complete_multipart_upload(
        &self,
        r: S3Request<CompleteMultipartUploadInput>,
    ) -> S3Result<S3Response<CompleteMultipartUploadOutput>> {
        let this = self.clone();
        tokio::task::spawn_blocking(move || crate::runtime().block_on(this.complete_impl(r)))
            .await
            .map_err(|_| s3_error!(InternalError))?
    }
    async fn abort_multipart_upload(
        &self,
        r: S3Request<AbortMultipartUploadInput>,
    ) -> S3Result<S3Response<AbortMultipartUploadOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        let _write = self.root.writes.lock().await;
        let mut m = self.upload(&r.input.upload_id, &r.input.key)?;
        m["aborted"] = json!(true);
        self.root
            .save_manifest(&r.input.upload_id, &m)
            .map_err(error)?;
        Ok(S3Response::new(AbortMultipartUploadOutput::default()))
    }
    async fn list_parts(
        &self,
        r: S3Request<ListPartsInput>,
    ) -> S3Result<S3Response<ListPartsOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        let m = self.upload(&r.input.upload_id, &r.input.key)?;
        let mut parts = Vec::new();
        for (n, p) in m["parts"]
            .as_object()
            .ok_or_else(|| s3_error!(InvalidRequest))?
        {
            parts.push(Part {
                part_number: Some(n.parse().map_err(|_| s3_error!(InvalidPart))?),
                e_tag: Some(tag(p["etag"]
                    .as_str()
                    .ok_or_else(|| s3_error!(InvalidPart))?)),
                size: p["bytes"].as_i64(),
                ..Default::default()
            });
        }
        parts.sort_by_key(|p| p.part_number);
        let marker = r.input.part_number_marker.unwrap_or(0);
        let max = r.input.max_parts.unwrap_or(1000).clamp(1, 1000) as usize;
        parts.retain(|p| p.part_number.is_some_and(|n| n > marker));
        let more = parts.len() > max;
        parts.truncate(max);
        let next = if more {
            parts.last().and_then(|p| p.part_number)
        } else {
            None
        };
        Ok(S3Response::new(ListPartsOutput {
            bucket: Some(self.root.bucket.clone()),
            key: Some(r.input.key),
            upload_id: Some(r.input.upload_id),
            parts: Some(parts),
            is_truncated: Some(more),
            next_part_number_marker: next,
            part_number_marker: Some(marker),
            max_parts: Some(max as i32),
            ..Default::default()
        }))
    }
}

impl Store {
    async fn complete_impl(
        &self,
        r: S3Request<CompleteMultipartUploadInput>,
    ) -> S3Result<S3Response<CompleteMultipartUploadOutput>> {
        self.check(&r, &r.input.bucket, true)?;
        let i = r.input;
        let _write = self.root.writes.lock().await;
        let mut m = self.upload(&i.upload_id, &i.key)?;
        let mut parts = Vec::new();
        for p in i
            .multipart_upload
            .and_then(|u| u.parts)
            .ok_or_else(|| s3_error!(InvalidPart))?
        {
            let number = p.part_number.ok_or_else(|| s3_error!(InvalidPart))?;
            let etag = p.e_tag.ok_or_else(|| s3_error!(InvalidPart))?;
            let e = format!("\"{}\"", etag.value());
            if m["parts"][number.to_string()]["etag"] != e {
                return Err(s3_error!(InvalidPart));
            }
            parts.push((number, e));
        }
        let parts_fingerprint = hex::encode(Sha256::digest(
            serde_json::to_vec(&parts).map_err(|_| s3_error!(InvalidPart))?,
        ));
        if m["commit_parts"]
            .as_str()
            .is_some_and(|v| v != parts_fingerprint)
        {
            return Err(s3_error!(InvalidPart));
        }
        if m["complete"] == true {
            let f = self.root.read(&i.key).map_err(error)?;
            if m["etag"] != f.etag {
                return Err(s3_error!(PreconditionFailed));
            }
            return Ok(S3Response::new(CompleteMultipartUploadOutput {
                bucket: Some(self.root.bucket.clone()),
                key: Some(i.key),
                e_tag: Some(tag(&f.etag)),
                ..Default::default()
            }));
        }
        let (f, name) = if let Some(stage) = m["commit_stage"].as_str() {
            if let Some(etag) = self
                .root
                .committed_stage(
                    &i.key,
                    stage,
                    m["commit_hash"].as_str().unwrap_or(""),
                    &self.stopped,
                )
                .map_err(error)?
            {
                m["complete"] = json!(true);
                m["etag"] = json!(etag);
                self.root.save_manifest(&i.upload_id, &m).map_err(error)?;
                return Ok(S3Response::new(CompleteMultipartUploadOutput {
                    bucket: Some(self.root.bucket.clone()),
                    key: Some(i.key),
                    e_tag: Some(tag(&etag)),
                    ..Default::default()
                }));
            }
            self.root
                .assemble(&i.upload_id, &parts, &self.stopped)
                .map_err(error)?
        } else {
            self.root
                .assemble(&i.upload_id, &parts, &self.stopped)
                .map_err(error)?
        };
        let mut file = f.into_std();
        use std::io::{Read, Seek};
        file.rewind().map_err(|_| s3_error!(InternalError))?;
        let mut digest = Sha256::new();
        let mut buffer = vec![0u8; 1024 * 1024];
        loop {
            if self.stopped.load(Ordering::Acquire) {
                return Err(s3_error!(AccessDenied));
            }
            let n = file
                .read(&mut buffer)
                .map_err(|_| s3_error!(InternalError))?;
            if n == 0 {
                break;
            }
            digest.update(&buffer[..n]);
        }
        drop(file);
        let hash = hex::encode(digest.finalize());
        m["commit_stage"] = json!(name);
        m["commit_parts"] = json!(parts_fingerprint);
        m["commit_hash"] = json!(hash);
        self.root.save_manifest(&i.upload_id, &m).map_err(error)?;
        let e = expected(i.if_match.as_ref());
        let etag = self
            .root
            .commit(
                &i.key,
                &name,
                e.as_deref(),
                i.if_none_match.as_ref().is_some_and(ETagCondition::is_any),
            )
            .map_err(error)?;
        m["complete"] = json!(true);
        m["etag"] = json!(etag);
        m["sha256"] = json!(hash);
        self.root.remember_hash(&etag, &hash);
        self.root.save_manifest(&i.upload_id, &m).map_err(error)?;
        Ok(S3Response::new(CompleteMultipartUploadOutput {
            bucket: Some(self.root.bucket.clone()),
            key: Some(i.key),
            e_tag: Some(tag(&etag)),
            ..Default::default()
        }))
    }
}
