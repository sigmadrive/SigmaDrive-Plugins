//! Only immutable, fully hashed component assets are shared. No engine process,
//! session, password, profile, registration or permission is retained here.
use super::*;
use std::{collections::{BTreeSet, HashSet}, os::windows::io::AsRawHandle,
    sync::{Arc, Mutex, Condvar, atomic::{AtomicU64, AtomicUsize, Ordering}},
    time::Duration};
use windows_sys::Win32::Storage::FileSystem::*;

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct AssetContext {
    sid: String,
    desktop: String,
    node: String,
    member: String,
    device_pin: String,
    profile: String,
    state_root: PathBuf,
    auth_epoch: u64,
    pub(super) manifest: String,
}
impl AssetContext {
    pub(crate) fn current(local: &Value, desktop: String, profile: String,
        state_root: PathBuf, auth_epoch: u64) -> Result<Self> {
        fn field(local: &Value, name: &str) -> Result<String> {
            let value=local[name].as_str().unwrap_or("");
            ensure!(!value.is_empty() && value.len()<=512 && !value.chars().any(char::is_control),
                "SigmaDesk asset identity unavailable");
            Ok(value.to_owned())
        }
        ensure!(!profile.is_empty() && profile.len()<=512, "SigmaDesk asset profile unavailable");
        Ok(Self { sid:crate::identity::current_sid()?, desktop,
            node:field(local,"node")?,member:field(local,"member")?,device_pin:field(local,"pin")?,
            profile,state_root,auth_epoch,
            manifest:hex::encode(Sha256::digest(crate::desk_assets::MANIFEST.as_bytes())) })
    }
    pub(super) fn matches(&self, local: &Value, desktop: &str) -> bool {
        self.desktop==desktop && local["node"]==self.node && local["member"]==self.member
            && local["pin"]==self.device_pin
    }
}

struct PinnedObject {
    file: File,
    path: PathBuf,
    directory: bool,
    protected: bool,
    inherited: bool,
    identity: (u32,u64,u64),
    security: String,
}
impl PinnedObject {
    fn observe(&self, sid: &str) -> Result<((u32,u64,u64),String)> {
        let mut info: BY_HANDLE_FILE_INFORMATION=unsafe {std::mem::zeroed()};
        ensure!(unsafe {GetFileInformationByHandle(self.file.as_raw_handle() as HANDLE,&mut info)}!=0,
            "SigmaDesk pinned asset identity unavailable");
        ensure!(info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT==0
            && (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY!=0)==self.directory
            && (self.directory || info.nNumberOfLinks==1), "SigmaDesk pinned asset type changed");
        let identity=(info.dwVolumeSerialNumber,((info.nFileIndexHigh as u64)<<32)|info.nFileIndexLow as u64,
            if self.directory {0}else{((info.nFileSizeHigh as u64)<<32)|info.nFileSizeLow as u64});
        let mut owner=null_mut();let mut acl=null_mut();let mut sd=null_mut();
        let flags=OWNER_SECURITY_INFORMATION|GROUP_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION;
        let code=unsafe {GetSecurityInfo(self.file.as_raw_handle() as HANDLE,SE_FILE_OBJECT,flags,
            &mut owner,null_mut(),&mut acl,null_mut(),&mut sd)};
        struct Memory(*mut std::ffi::c_void);
        impl Drop for Memory {fn drop(&mut self){if !self.0.is_null(){unsafe{LocalFree(self.0);}}}}
        let _memory=Memory(sd);
        ensure!(code==0 && !sd.is_null() && !owner.is_null() && !acl.is_null(),
            "SigmaDesk pinned asset security unavailable");
        let mut actual_sid=null_mut();
        ensure!(unsafe{ConvertSidToStringSidW(owner,&mut actual_sid)}!=0,
            "SigmaDesk pinned asset owner unavailable");
        let _sid_memory=Memory(actual_sid.cast());
        let len=(0..).take_while(|i|unsafe{*actual_sid.add(*i)}!=0).count();
        ensure!(String::from_utf16(unsafe{std::slice::from_raw_parts(actual_sid,len)})?==sid,
            "SigmaDesk pinned asset owner changed");
        let mut control=0;let mut revision=0;
        ensure!(unsafe{GetSecurityDescriptorControl(sd,&mut control,&mut revision)}!=0
            && (!self.protected || control & SE_DACL_PROTECTED!=0),
            "SigmaDesk pinned asset ACL changed");
        let mut acl_info: ACL_SIZE_INFORMATION=unsafe{std::mem::zeroed()};
        ensure!(unsafe{GetAclInformation(acl,(&mut acl_info as *mut ACL_SIZE_INFORMATION).cast(),
            std::mem::size_of::<ACL_SIZE_INFORMATION>() as u32,AclSizeInformation)}!=0
            && acl_info.AceCount==1,"SigmaDesk pinned asset ACL changed");
        let mut raw=null_mut();
        ensure!(unsafe{GetAce(acl,0,&mut raw)}!=0 && !raw.is_null(),"SigmaDesk pinned asset ACL changed");
        let header=unsafe{&*(raw as *const ACE_HEADER)};
        let offset=std::mem::offset_of!(ACCESS_ALLOWED_ACE,SidStart);
        ensure!(header.AceType==0 && header.AceSize as usize>=offset+8,"SigmaDesk pinned asset ACL changed");
        let ace_sid=unsafe{(raw as *mut u8).add(offset)} as PSID;
        ensure!(unsafe{IsValidSid(ace_sid)}!=0
            && (unsafe{GetLengthSid(ace_sid)} as usize)<=header.AceSize as usize-offset,
            "SigmaDesk pinned asset ACL changed");
        let ace=unsafe{&*(raw as *const ACCESS_ALLOWED_ACE)};
        let wanted=if self.directory {OBJECT_INHERIT_ACE|CONTAINER_INHERIT_ACE}else{0};
        let allowed=wanted|if self.inherited {INHERITED_ACE}else{0};
        ensure!(ace.Mask==FILE_ALL_ACCESS && (ace.Header.AceFlags as u32)&!allowed==0
            && (ace.Header.AceFlags as u32)&wanted==wanted
            && unsafe{EqualSid(owner,ace_sid)}!=0,"SigmaDesk pinned asset ACL changed");
        let mut text=null_mut();
        ensure!(unsafe{ConvertSecurityDescriptorToStringSecurityDescriptorW(sd,1,flags,&mut text,null_mut())}!=0,
            "SigmaDesk pinned asset security unavailable");
        let _text_memory=Memory(text.cast());
        let len=(0..).take_while(|i|unsafe{*text.add(*i)}!=0).count();
        let security=hex::encode(Sha256::digest(unsafe{std::slice::from_raw_parts(text,len)}.iter()
            .flat_map(|c|c.to_le_bytes()).collect::<Vec<_>>()));
        Ok((identity,security))
    }
    fn pin(file: File,path: PathBuf,directory: bool,protected: bool,inherited: bool,sid: &str) -> Result<Self> {
        let mut object=Self{file,path,directory,protected,inherited,identity:(0,0,0),security:String::new()};
        (object.identity,object.security)=object.observe(sid)?;
        Ok(object)
    }
    fn validate(&self,sid: &str) -> Result<()> {
        sigmadrive_distribution::download::safe(&self.path).map_err(anyhow::Error::msg)?;
        ensure!(self.observe(sid)?==(self.identity,self.security.clone()),"SigmaDesk pinned asset changed");
        Ok(())
    }
}
pub(super) struct PreparedAssets {
    pub(super) context: AssetContext,
    pub(super) root: PathBuf,
    objects: Vec<PinnedObject>,
    names: Vec<String>,
}
impl PreparedAssets {
    pub(super) fn pinned(&self) -> bool {!self.objects.is_empty()}
    pub(super) fn prepare(context: AssetContext,current: &(impl Fn()->Result<()> + ?Sized)) -> Result<Self> {
        current()?;
        ensure!(context.manifest==hex::encode(Sha256::digest(crate::desk_assets::MANIFEST.as_bytes())),
            "SigmaDesk asset manifest changed");
        let component=runtime_engine_root()?;
        let manifest=crate::desk_assets::manifest()?;
        let value=Self::at(context,component.root,&manifest,current)?;
        // Original installer guards are replaced only after stricter read-only,
        // deny-write/delete guards and complete SHA checks have been acquired.
        drop(component.guards);
        Ok(value)
    }
    fn at(context: AssetContext,root: PathBuf,manifest: &crate::desk_assets::Manifest,
        current: &(impl Fn()->Result<()> + ?Sized)) -> Result<Self> {
        let anchor=root.parent().and_then(Path::parent).and_then(Path::parent)
            .ok_or_else(||anyhow::anyhow!("SigmaDesk asset root denied"))?;
        let mut directories=BTreeSet::new();
        for path in root.ancestors().take(4) {directories.insert(path.to_owned());}
        for asset in &manifest.files {
            let mut path=root.join(&asset.path);
            while let Some(parent)=path.parent().filter(|p|p.starts_with(&root)) {
                directories.insert(parent.to_owned());path=parent.to_owned();
            }
        }
        let mut objects=vec![];
        for path in directories {
            current()?;
            sigmadrive_distribution::download::safe(&path).map_err(anyhow::Error::msg)?;
            let ancestor=path!=root && !path.starts_with(&root);
            // Keep ancestor identity pinned against delete/rename, but permit
            // sibling updater metadata replacement in the private install root.
            // Immutable engine directories/files retain their read-only guards.
            let file=OpenOptions::new().access_mode(READ_CONTROL|FILE_READ_ATTRIBUTES|FILE_LIST_DIRECTORY)
                .share_mode(FILE_SHARE_READ | if ancestor {FILE_SHARE_WRITE}else{0})
                .custom_flags(FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT)
                .open(&path)?;
            objects.push(PinnedObject::pin(file,path.clone(),true,!ancestor || path==anchor,ancestor,&context.sid)?);
        }
        let files=verify_engine_files_until(&root,manifest,current)?;
        for (asset,file) in manifest.files.iter().zip(files) {
            objects.push(PinnedObject::pin(file,root.join(&asset.path),false,true,false,&context.sid)?);
        }
        let value=Self{context,root,objects,names:manifest.files.iter().map(|a|a.path.clone()).collect()};
        value.validate(current)?;
        Ok(value)
    }
    fn validate(&self,current: &(impl Fn()->Result<()> + ?Sized)) -> Result<()> {
        for object in &self.objects {current()?;object.validate(&self.context.sid)?;}
        let names=self.names.iter().map(String::as_str).collect::<HashSet<_>>();
        engine_inventory(&self.root,&self.root,&names)?;
        current()
    }
}

#[derive(Default)]
struct CacheState {context:Option<AssetContext>,assets:Option<Arc<PreparedAssets>>,preparing:Option<u64>,failed:bool}
#[derive(Default)]
pub(crate) struct AssetCache {
    state:Mutex<CacheState>, changed:Condvar, generation:AtomicU64, working:AtomicUsize,
}
impl AssetCache {
    pub(crate) fn clear(&self) {
        if let Ok(mut state)=self.state.lock(){
            self.generation.fetch_add(1,Ordering::AcqRel);state.context=None;state.assets=None;state.failed=false;
        } else {self.generation.fetch_add(1,Ordering::AcqRel);}
        self.changed.notify_all();
    }
    pub(crate) fn busy(&self)->bool {self.working.load(Ordering::Acquire)!=0}
    pub(crate) fn select(&self,context:AssetContext)->Result<bool> {
        let mut state=self.state.lock().map_err(|_|anyhow::anyhow!("SigmaDesk asset state unavailable"))?;
        if state.context.as_ref()!=Some(&context) {
            self.generation.fetch_add(1,Ordering::AcqRel);state.assets=None;state.failed=false;state.context=Some(context);
            self.changed.notify_all();
        }
        Ok(state.assets.is_some())
    }
    pub(crate) fn needs_preparation(&self,context:&AssetContext)->bool {
        self.state.lock().is_ok_and(|s|s.context.as_ref()==Some(context)
            && !s.failed && s.assets.is_none() && s.preparing.is_none())
    }
    pub(crate) fn failed(&self)->bool {self.state.lock().map_or(true,|s|s.failed)}
    fn reject(&self,context:&AssetContext,generation:u64) {
        if let Ok(mut state)=self.state.lock()
            && state.context.as_ref()==Some(context) && self.generation.load(Ordering::Acquire)==generation {
            self.generation.fetch_add(1,Ordering::AcqRel);state.assets=None;state.failed=true;
        }
        self.changed.notify_all();
    }
    pub(crate) fn prepare(&self,context:&AssetContext,current:&impl Fn()->Result<()>) -> Result<()> {
        self.acquire(context,current).map(|_|())
    }
    pub(super) fn acquire(&self,context:&AssetContext,current:&impl Fn()->Result<()>) -> Result<Arc<PreparedAssets>> {
        self.acquire_with(context,current,|valid|PreparedAssets::prepare(context.clone(),valid))
    }
    fn acquire_with(&self,context:&AssetContext,current:&impl Fn()->Result<()>,
        prepare:impl FnOnce(&dyn Fn()->Result<()>) -> Result<PreparedAssets>) -> Result<Arc<PreparedAssets>> {
        struct Work<'a>(&'a AtomicUsize);
        impl Drop for Work<'_>{fn drop(&mut self){self.0.fetch_sub(1,Ordering::AcqRel);}}
        self.working.fetch_add(1,Ordering::AcqRel);
        let _work=Work(&self.working);
        let generation=self.generation.load(Ordering::Acquire);
        let valid=|| {current()?;ensure!(self.generation.load(Ordering::Acquire)==generation,
            "SigmaDesk asset preparation canceled");Ok(())};
        let mut state=self.state.lock().map_err(|_|anyhow::anyhow!("SigmaDesk asset state unavailable"))?;
        loop {
            valid()?;
            ensure!(state.context.as_ref()==Some(context),"SigmaDesk asset context changed");
            ensure!(!state.failed,"SigmaDesk asset preparation failed; explicitly verify the plugin to retry");
            if let Some(assets)=state.assets.clone() {
                drop(state);
                if let Err(error)=assets.validate(&valid){
                    if current().is_ok(){self.reject(context,generation);}
                    return Err(error);
                }
                valid()?;return Ok(assets);
            }
            if state.preparing.is_none(){break;}
            state=self.changed.wait_timeout(state,Duration::from_millis(50))
                .map_err(|_|anyhow::anyhow!("SigmaDesk asset state unavailable"))?.0;
        }
        state.preparing=Some(generation);
        drop(state);
        let result=prepare(&valid).map(Arc::new);
        let still_current=valid().is_ok();
        let mut state=self.state.lock().map_err(|_|anyhow::anyhow!("SigmaDesk asset state unavailable"))?;
        state.preparing=None;
        self.changed.notify_all();
        let value=match result {Ok(value)=>value,Err(error)=>{
            if still_current && self.generation.load(Ordering::Acquire)==generation && state.context.as_ref()==Some(context) {
                state.failed=true;
            }
            return Err(error);
        }};
        valid()?;
        ensure!(state.context.as_ref()==Some(context),"SigmaDesk asset context changed");
        state.assets=Some(value.clone());Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;
    struct Fixture {parent:PathBuf,root:PathBuf,manifest:crate::desk_assets::Manifest,context:AssetContext}
    impl Fixture {
        fn new()->Self {
            let parent=std::env::temp_dir().join(format!("sigmadesk-prepared-test-{}",uuid::Uuid::new_v4()));
            let anchor=parent.join("install");
            let root=anchor.join("components/sigmadesk").join("a".repeat(64));
            std::fs::create_dir_all(root.join("data/sub")).unwrap();
            let bytes=b"synthetic prepared engine only";
            let names=["rustdesk.exe","librustdesk.dll","flutter_windows.dll","data/sub/fixture.bin"];
            let manifest=crate::desk_assets::Manifest {schema:1,entry:"rustdesk.exe".into(),
                files:names.iter().map(|name|crate::desk_assets::Asset{path:(*name).into(),
                    bytes:bytes.len() as u64,sha256:hex::encode(Sha256::digest(bytes))}).collect()};
            for name in names {std::fs::write(root.join(name),bytes).unwrap();}
            let sid=crate::identity::current_sid().unwrap();
            let mut paths=vec![anchor.clone(),anchor.join("components"),anchor.join("components/sigmadesk"),
                root.clone(),root.join("data"),root.join("data/sub")];
            paths.extend(names.iter().map(|name|root.join(name)));
            for path in &paths {descriptor(path,&sid,false);}
            let context=AssetContext::current(&serde_json::json!({"node":"fixture-node","member":"fixture-member",
                "pin":"fixture-pin"}),"fixture-desktop".into(),"fixture-profile".into(),anchor,7).unwrap();
            Self{parent,root,manifest,context}
        }
        fn prepare(&self,current:&dyn Fn()->Result<()>) -> Result<PreparedAssets> {
            PreparedAssets::at(self.context.clone(),self.root.clone(),&self.manifest,current)
        }
        fn acquire(&self,cache:&AssetCache)->Result<Arc<PreparedAssets>> {
            cache.select(self.context.clone())?;
            cache.acquire_with(&self.context,&||Ok(()),|valid|self.prepare(valid))
        }
    }
    fn descriptor(path:&Path,sid:&str,public:bool) {
        let flags=if path.is_dir(){"OICI"}else{""};
        let extra=if public{format!("(A;{flags};FR;;;WD)")}else{String::new()};
        let text=wide(std::ffi::OsStr::new(&format!("O:{sid}D:P(A;{flags};FA;;;{sid}){extra}")));
        let mut sd=null_mut();
        assert_ne!(unsafe{ConvertStringSecurityDescriptorToSecurityDescriptorW(text.as_ptr(),1,&mut sd,null_mut())},0);
        let mut owner=null_mut();let mut acl=null_mut();let mut present=0;let mut defaulted=0;
        assert_ne!(unsafe{GetSecurityDescriptorOwner(sd,&mut owner,&mut defaulted)},0);
        assert_ne!(unsafe{GetSecurityDescriptorDacl(sd,&mut present,&mut acl,&mut defaulted)},0);
        let name=wide(path.as_os_str());
        let result=unsafe{SetNamedSecurityInfoW(name.as_ptr(),SE_FILE_OBJECT,
            OWNER_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION|PROTECTED_DACL_SECURITY_INFORMATION,
            owner,null_mut(),acl,null_mut())};
        unsafe{LocalFree(sd);}
        assert_eq!(result,0,"synthetic fixture security setup failed");
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            let Ok(temp)=std::env::temp_dir().canonicalize() else{return};
            let Ok(path)=self.parent.canonicalize() else{return};
            let Some(name)=path.file_name().and_then(|s|s.to_str()) else{return};
            let Some(id)=name.strip_prefix("sigmadesk-prepared-test-") else{return};
            if path.parent()==Some(temp.as_path()) && uuid::Uuid::parse_str(id).is_ok() {
                let _=std::fs::remove_dir_all(path);
            }
        }
    }
    #[test]
    fn prepared_engine_keeps_sibling_update_metadata_replaceable() {
        let fixture=Fixture::new();
        let ledger=fixture.context.state_root.join("catalog-sequence.json");
        sigmadrive_distribution::install::atomic(&ledger,b"{\"sequence\":23}").unwrap();
        let cache=AssetCache::default();let assets=fixture.acquire(&cache).unwrap();
        // Prewarming an immutable component must not block the updater's
        // atomic replacement of sibling metadata in the private install root.
        sigmadrive_distribution::install::atomic(&ledger,b"{\"sequence\":24}").unwrap();
        assert_eq!(std::fs::read(&ledger).unwrap(),b"{\"sequence\":24}");
        assets.validate(&||Ok(())).unwrap();
        assert!(OpenOptions::new().write(true).open(fixture.root.join("rustdesk.exe")).is_err());
        assert!(std::fs::rename(&fixture.context.state_root,fixture.parent.join("swapped-install")).is_err());
        drop(assets);cache.clear();
    }
    #[test]
    fn repeated_connections_reuse_only_pinned_assets_and_release_after_last_owner() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        let assets=fixture.acquire(&cache).unwrap();
        let reused=cache.acquire_with(&fixture.context,&||Ok(()),|_|panic!("rehashed prepared assets")).unwrap();
        assert!(Arc::ptr_eq(&assets,&reused));
        let file=fixture.root.join("librustdesk.dll");
        assert!(OpenOptions::new().write(true).open(&file).is_err());
        assert!(std::fs::remove_file(&file).is_err());
        assert!(std::fs::rename(&fixture.root,fixture.root.with_file_name("swapped")).is_err());
        assert!(std::fs::rename(fixture.root.parent().unwrap(),fixture.parent.join("swapped-parent")).is_err());
        cache.clear();
        assert!(cache.state.lock().unwrap().assets.is_none());
        assert!(OpenOptions::new().write(true).open(&file).is_err(),"live session lost pinned assets");
        drop(assets);drop(reused);
        assert!(OpenOptions::new().write(true).open(&file).is_ok());
        std::fs::write(&file,b"synthetic tampering").unwrap();
        assert!(fixture.acquire(&cache).is_err(),"cleared cache skipped the fresh size/hash check");
    }
    #[test]
    fn same_size_hash_tampering_is_rejected_before_preparation() {
        let fixture=Fixture::new();
        let path=fixture.root.join("rustdesk.exe");
        let mut bytes=std::fs::read(&path).unwrap();bytes[0]^=1;std::fs::write(path,bytes).unwrap();
        let cache=AssetCache::default();
        assert!(fixture.acquire(&cache).err().unwrap().to_string().contains("hash mismatch"));
        assert!(!cache.busy());assert!(cache.state.lock().unwrap().assets.is_none());
    }
    #[test]
    fn acl_changes_cannot_hide_behind_unchanged_bytes_or_open_handles() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        let assets=fixture.acquire(&cache).unwrap();
        // WRITE_DAC is not denied by ordinary sharing flags. Reuse must inspect
        // descriptor security rather than treating a read handle as an ACL lock.
        descriptor(&fixture.root.join("librustdesk.dll"),&fixture.context.sid,true);
        let result=cache.acquire_with(&fixture.context,&||Ok(()),|_|panic!("unexpected prepare"));
        assert!(result.err().unwrap().to_string().contains("ACL changed"));
        assert!(cache.state.lock().unwrap().assets.is_none());drop(assets);
    }
    #[test]
    fn new_inventory_and_hardlink_aliases_are_rejected_if_namespace_writes_are_available() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        let assets=fixture.acquire(&cache).unwrap();
        if std::fs::create_dir(fixture.root.join("unlisted-empty")).is_ok() {
            eprintln!("prepared fixture: namespace mutation available; inventory rejection exercised");
            assert!(cache.acquire_with(&fixture.context,&||Ok(()),|_|panic!("unexpected prepare"))
                .err().unwrap().to_string().contains("unlisted"));
            std::fs::remove_dir(fixture.root.join("unlisted-empty")).unwrap();
        } else {eprintln!("prepared fixture: directory creation denied by pinned scope");}
        drop(assets);cache.clear();
        let assets=fixture.acquire(&cache).unwrap();
        if std::fs::hard_link(fixture.root.join("librustdesk.dll"),fixture.parent.join("alias.dll")).is_ok() {
            eprintln!("prepared fixture: hardlink creation available; alias rejection exercised");
            assert!(cache.acquire_with(&fixture.context,&||Ok(()),|_|panic!("unexpected prepare"))
                .err().unwrap().to_string().contains("type changed"));
        } else {eprintln!("prepared fixture: hardlink creation denied by pinned scope");}
        drop(assets);cache.clear();
    }
    #[test]
    fn user_desktop_profile_device_and_pin_changes_never_reuse_old_arc() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        let assets=fixture.acquire(&cache).unwrap();
        let mutations:Vec<Box<dyn Fn(&mut AssetContext)>>=vec![
            Box::new(|c|c.sid.push('x')),Box::new(|c|c.desktop.push('x')),
            Box::new(|c|c.node.push('x')),Box::new(|c|c.member.push('x')),
            Box::new(|c|c.device_pin.push('x')),Box::new(|c|c.profile.push('x')),
            Box::new(|c|c.manifest.push('x')),Box::new(|c|c.state_root.push("other")),
            Box::new(|c|c.auth_epoch+=1)];
        for mutate in mutations {
            cache.select(fixture.context.clone()).unwrap();
            cache.state.lock().unwrap().assets=Some(assets.clone());
            let mut changed=fixture.context.clone();mutate(&mut changed);
            assert!(!cache.select(changed).unwrap());
            assert!(cache.state.lock().unwrap().assets.is_none());
            assert!(cache.acquire_with(&fixture.context,&||Ok(()),|_|panic!("wrong context prepared")).is_err());
        }
        cache.clear();drop(assets);
    }
    #[test]
    fn disabled_or_draining_startup_cannot_publish_late_preparation_and_idle_waits() {
        let fixture=Arc::new(Fixture::new());let runtime=Arc::new(crate::desk::Runtime::default());
        runtime.assets.select(fixture.context.clone()).unwrap();
        let (begun,wait_begun)=mpsc::channel();let (resume,wait_resume)=mpsc::channel();
        let work_runtime=runtime.clone();let work_fixture=fixture.clone();
        let worker=std::thread::spawn(move ||work_runtime.assets.acquire_with(&work_fixture.context,&||Ok(()),|valid| {
            let value=work_fixture.prepare(valid)?;begun.send(()).unwrap();
            wait_resume.recv().unwrap();valid()?;Ok(value)
        }).map(|_|()));
        wait_begun.recv_timeout(Duration::from_secs(10)).unwrap();
        assert!(!runtime.idle(),"update drain ignored in-flight preparation");
        runtime.stop_all();
        assert!(!runtime.idle(),"update drain released before stale worker dropped guards");
        resume.send(()).unwrap();assert!(worker.join().unwrap().is_err());
        assert!(runtime.idle());assert!(runtime.assets.state.lock().unwrap().assets.is_none());
        assert!(OpenOptions::new().write(true).open(fixture.root.join("rustdesk.exe")).is_ok());
    }
    #[test]
    fn wrong_embedded_manifest_pin_is_rejected_without_loading_engine() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        let mut wrong=fixture.context.clone();wrong.manifest="f".repeat(64);
        cache.select(wrong.clone()).unwrap();
        assert!(cache.acquire(&wrong,&||Ok(())).err().unwrap().to_string().contains("manifest changed"));
        assert!(!cache.busy());
    }
    #[test]
    fn context_change_during_preparation_cancels_partial_handles_before_publication() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        cache.select(fixture.context.clone()).unwrap();
        let mut changed=fixture.context.clone();changed.desktop.push_str("-new");
        let calls=AtomicUsize::new(0);
        let result=cache.acquire_with(&fixture.context,&|| {
            if calls.fetch_add(1,Ordering::AcqRel)==2 {cache.select(changed.clone())?;}
            Ok(())
        },|valid|fixture.prepare(valid));
        assert!(result.err().unwrap().to_string().contains("canceled"));
        assert!(!cache.busy());assert!(cache.state.lock().unwrap().assets.is_none());
        assert!(OpenOptions::new().write(true).open(fixture.root.join("rustdesk.exe")).is_ok());
    }
    #[test]
    fn existing_writer_prevents_hash_verification_and_prepared_publication() {
        let fixture=Fixture::new();
        let writer=OpenOptions::new().write(true).share_mode(FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE)
            .open(fixture.root.join("rustdesk.exe")).unwrap();
        let cache=AssetCache::default();assert!(fixture.acquire(&cache).is_err());
        assert!(cache.state.lock().unwrap().assets.is_none());drop(writer);
        cache.clear(); // Explicit verification, not an automatic failed retry.
        assert!(fixture.acquire(&cache).is_ok());cache.clear();
    }
    #[test]
    fn failed_preparation_does_not_repeat_hashes_until_explicit_retry_or_new_context() {
        let fixture=Fixture::new();let cache=AssetCache::default();
        let path=fixture.root.join("rustdesk.exe");let original=std::fs::read(&path).unwrap();
        let mut wrong=original.clone();wrong[0]^=1;std::fs::write(&path,wrong).unwrap();
        assert!(fixture.acquire(&cache).is_err());assert!(cache.failed());
        for _ in 0..4 {
            assert!(!cache.select(fixture.context.clone()).unwrap());
            assert!(!cache.needs_preparation(&fixture.context));
            assert!(cache.acquire_with(&fixture.context,&||Ok(()),|_|panic!("failed preparation retried hashes"))
                .err().unwrap().to_string().contains("explicitly verify"));
        }
        std::fs::write(&path,original).unwrap();cache.clear();
        assert!(fixture.acquire(&cache).is_ok());assert!(!cache.failed());
        let mut changed=fixture.context.clone();changed.profile.push_str("-new");
        cache.select(changed.clone()).unwrap();assert!(cache.needs_preparation(&changed));cache.clear();
    }
}
