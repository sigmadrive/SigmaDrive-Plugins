//! Conditional small-document commits. Provider limitations fail closed.
use crate::{
    Config,
    engine::{checked, hash},
    metadata::{Meta, fresh},
};
use anyhow::{Result, bail, ensure};
use opendal::Operator;
use serde_json::json;
pub fn transient(p: &str) -> bool {
    let n = p.rsplit('/').next().unwrap_or(p).to_ascii_lowercase();
    n.starts_with('~')
        || n.ends_with(".tmp")
        || n.ends_with(".asd")
        || (n.len() == 8 && n.bytes().all(|b| b.is_ascii_hexdigit()))
}
pub fn encoded(p: &str) -> String {
    p.split('/')
        .map(|s| {
            s.bytes()
                .map(|b| {
                    if b.is_ascii_alphanumeric() || b"-._~".contains(&b) {
                        (b as char).to_string()
                    } else {
                        format!("%{b:02X}")
                    }
                })
                .collect::<String>()
        })
        .collect::<Vec<_>>()
        .join("/")
}
pub async fn put(
    cfg: &Config,
    op: &Operator,
    p: &str,
    base: Option<&Meta>,
    bytes: Vec<u8>,
) -> Result<()> {
    checked(p)?;
    ensure!(
        bytes.len() <= 32 * 1024 * 1024,
        "small safe document limit exceeded; recovery copy retained"
    );
    match cfg.provider.as_str() {
        "s3" => {
            let out = if let Some(b) = base {
                ensure!(!b.etag.is_empty(), "missing commit ETag");
                op.write_with(p, bytes).if_match(&b.etag).await
            } else {
                op.write_with(p, bytes).if_not_exists(true).await
            };
            out.map_err(|e| anyhow::anyhow!("conditional {:?}", e.kind()))?;
        }
        "onedrive" => {
            let all = crate::remote_path(&cfg.root, p);
            let drive = cfg.get("drive_id");
            ensure!(!drive.is_empty(), "explicit OneDrive required");
            let behavior = if base.is_some() { "replace" } else { "fail" };
            let url = format!(
                "https://graph.microsoft.com/v1.0/drives/{}/root:/{}:/content?@microsoft.graph.conflictBehavior={}",
                encoded(drive),
                encoded(&all),
                behavior
            );
            let client = reqwest::Client::builder()
                .redirect(reqwest::redirect::Policy::none())
                .timeout(std::time::Duration::from_secs(60))
                .build()?;
            let mut req = client
                .put(url)
                .bearer_auth(cfg.get("access_token"))
                .header("X-Sigma-Local-Connection", cfg.get("connection_id"))
                .header("Content-Type", "application/octet-stream")
                .header("Content-Length", bytes.len());
            if let Some(b) = base {
                ensure!(!b.etag.is_empty(), "missing commit ETag");
                req = req.header("If-Match", &b.etag)
            } else {
                req = req.header("If-None-Match", "*")
            };
            let r = crate::cloud::send(req.body(bytes)).await?;
            ensure!(
                r.status().is_success(),
                "conditional HTTP {}",
                r.status().as_u16()
            );
        }
        "fs" => {
            // Single-process fixture only, never represented as remote CAS.
            let now = fresh(op, p).await?;
            ensure!(now.as_ref() == base, "conditional fixture changed");
            op.write(p, bytes).await?;
        }
        _ => bail!("atomic conditional replacement unsupported; local bytes retained"),
    }
    Ok(())
}
pub async fn probe(cfg: &Config, op: &Operator) -> Result<serde_json::Value> {
    let name = format!("conditional-probe-{}.txt", crate::v2::nonce());
    let p = name.as_str();
    let a = b"base".to_vec();
    put(cfg, op, p, None, a.clone()).await?;
    let base = fresh(op, p).await?.unwrap();
    ensure!(
        put(cfg, op, p, None, b"must not overwrite".to_vec())
            .await
            .is_err(),
        "If-None-Match ignored"
    );
    let mut wrong = base.clone();
    wrong.etag = "\"stale-sigma-poc-tag\"".into();
    ensure!(
        put(cfg, op, p, Some(&wrong), b"stale".to_vec())
            .await
            .is_err(),
        "stale If-Match ignored"
    );
    ensure!(
        op.read(p).await?.to_vec() == a,
        "failed condition changed original"
    );
    put(cfg, op, p, Some(&base), b"new version".to_vec()).await?;
    ensure!(
        op.read(p).await?.to_vec() == b"new version",
        "accepted condition stored wrong content"
    );
    Ok(
        json!({"pass":true,"if_none_match":true,"stale_if_match":true,"current_if_match":true,"original_preserved":true,"sha256":hash(b"new version")}),
    )
}
