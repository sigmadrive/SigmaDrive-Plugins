//! One control-plane HTTP client per exact live Windows/authentication context.
//! No file, mtime, profile shadow, credential string or process-global client cache.
//! Dropping an entry closes its idle pool; already-dispatched requests retain the
//! original caller's lease/epoch checks and are not silently retried.
use anyhow::{Result, ensure};
use sha2::{Digest, Sha256};
use std::{sync::Mutex, time::Duration};

pub(crate) struct TlsIdentity<'a> {
    pub certificate: &'a str,
    pub key: &'a str,
    pub ca: Option<&'a str>,
}

// Deliberately no Debug/Serialize. All input strings are borrowed just while
// deriving a domain-separated, length-delimited digest/building a client.
pub(crate) struct Context<'a> {
    pub sid: &'a str,
    pub desktop: &'a str,
    pub member: &'a str,
    pub node: &'a str,
    pub pin: &'a str,
    pub tls: TlsIdentity<'a>,
    pub credential: &'a str,
    pub control_url: &'a str,
    pub authority_url: &'a str,
    pub auth_epoch: u64,
}
impl Context<'_> {
    fn fingerprint(&self) -> [u8; 32] {
        fn field(hash: &mut Sha256, tag: &[u8], value: &[u8]) {
            hash.update((tag.len() as u64).to_le_bytes());
            hash.update(tag);
            hash.update((value.len() as u64).to_le_bytes());
            hash.update(value);
        }
        let mut hash = Sha256::new();
        hash.update(b"sigmadesk/control-client-context/v1\0");
        for (tag, value) in [
            (b"sid".as_slice(), self.sid),
            (b"desktop", self.desktop),
            (b"member", self.member),
            (b"node", self.node),
            (b"pin", self.pin),
            (b"certificate", self.tls.certificate),
            (b"key", self.tls.key),
            (b"credential", self.credential),
            (b"control_url", self.control_url),
            (b"authority_url", self.authority_url),
        ] {
            field(&mut hash, tag, value.as_bytes());
        }
        // Absent CA and a present empty CA are different exact contexts even
        // though both retain the pre-existing default trust-store behavior.
        field(&mut hash, b"ca_present", &[u8::from(self.tls.ca.is_some())]);
        field(&mut hash, b"ca", self.tls.ca.unwrap_or("").as_bytes());
        field(&mut hash, b"auth_epoch", &self.auth_epoch.to_le_bytes());
        hash.finalize().into()
    }
    fn valid(&self) -> bool {
        [self.sid, self.desktop, self.member, self.node, self.pin,
            self.credential, self.control_url, self.authority_url]
            .into_iter().all(|s| !s.is_empty())
    }
}

// Same TLS/redirect/deadline policy as the pre-pool control client. Errors are
// fixed strings so a parser/third-party error cannot copy PEM or credentials.
pub(crate) fn build_client(identity: &TlsIdentity<'_>) -> Result<reqwest::Client> {
    client_builder(identity)?.build().map_err(|_| anyhow::anyhow!("SigmaDesk HTTP client unavailable"))
}
fn client_builder(identity: &TlsIdentity<'_>) -> Result<reqwest::ClientBuilder> {
    let pem = zeroize::Zeroizing::new(format!("{}\n{}", identity.certificate, identity.key));
    let tls = reqwest::Identity::from_pem(pem.as_bytes())
        .map_err(|_| anyhow::anyhow!("SigmaDesk HTTP identity denied"))?;
    let mut builder = reqwest::Client::builder()
        .identity(tls)
        .redirect(reqwest::redirect::Policy::none())
        .tls_version_min(reqwest::tls::Version::TLS_1_3)
        .connect_timeout(Duration::from_secs(5))
        .timeout(Duration::from_secs(8));
    if let Some(ca) = identity.ca.filter(|s| !s.is_empty()) {
        ensure!(ca.len() <= 65536 && !ca.contains("PRIVATE KEY"), "SigmaDesk CA denied");
        for cert in reqwest::Certificate::from_pem_bundle(ca.as_bytes())
            .map_err(|_| anyhow::anyhow!("SigmaDesk HTTP CA denied"))? {
            builder = builder.add_root_certificate(cert);
        }
    }
    Ok(builder)
}

#[derive(Clone, Copy)]
pub(crate) struct Ticket { generation: u64, revision: u64 }
pub(crate) struct ClientLease {
    pub client: reqwest::Client,
    pub ticket: Ticket,
    fingerprint: [u8;32],
}
struct Entry {
    fingerprint: [u8; 32],
    client: reqwest::Client,
    created_from_revision: u64,
}
impl Drop for Entry {
    fn drop(&mut self) {
        use zeroize::Zeroize;
        self.fingerprint.zeroize();
    }
}
#[derive(Default)]
struct State {
    generation: u64,
    revision: u64,
    exhausted: bool,
    entry: Option<Entry>,
    #[cfg(test)]
    builds: usize,
}
#[derive(Default)]
pub(crate) struct Pool(Mutex<State>);
impl Pool {
    // Acquire before async OS/auth context resolution. An invalidation during
    // that work makes this ticket stale instead of repopulating an old client.
    pub(crate) fn ticket(&self) -> Result<Ticket> {
        let state = self.0.lock().map_err(|_| anyhow::anyhow!("SigmaDesk HTTP pool unavailable"))?;
        ensure!(!state.exhausted, "SigmaDesk HTTP pool exhausted");
        Ok(Ticket {generation: state.generation, revision: state.revision})
    }
    pub(crate) fn is_current(&self, ticket: Ticket) -> bool {
        self.0.lock().is_ok_and(|state| Self::current(&state,ticket))
    }
    fn current(state:&State,ticket:Ticket)->bool {
        !state.exhausted && state.generation==ticket.generation && state.revision==ticket.revision
    }
    fn retire(state:&mut State) {
        state.entry=None;state.revision=0;
        if let Some(next)=state.generation.checked_add(1){state.generation=next}else{state.exhausted=true}
    }
    pub(crate) fn clear(&self) {
        if let Ok(mut state) = self.0.lock() {
            Self::retire(&mut state);
        }
    }
    pub(crate) fn clear_if_current(&self,ticket:Ticket)->bool {
        let Ok(mut state)=self.0.lock() else{return false};
        if !Self::current(&state,ticket){return false}
        Self::retire(&mut state);true
    }
    pub(crate) fn uncached_client(&self,ticket:Ticket,context:&Context<'_>)->Result<ClientLease> {
        ensure!(context.valid() && self.is_current(ticket),"SigmaDesk HTTP context changed");
        let client=build_client(&context.tls)?;
        ensure!(self.is_current(ticket),"SigmaDesk HTTP context changed");
        Ok(ClientLease {client,ticket,fingerprint:context.fingerprint()})
    }
    // Called with freshly resolved OS/live identity after headers and again
    // after body parsing. Status invalidation and the exact binding check use
    // the same lock: a late old401/403 cannot clear a new authentication pool.
    pub(crate) fn accept_response(&self,lease:&ClientLease,current:&Context<'_>,status:u16)->Result<()> {
        let mut state=self.0.lock().map_err(|_|anyhow::anyhow!("SigmaDesk HTTP pool unavailable"))?;
        ensure!(Self::current(&state,lease.ticket) && current.valid()
            && lease.fingerprint==current.fingerprint(),"SigmaDesk HTTP context changed");
        if matches!(status,401|403){Self::retire(&mut state);}
        Ok(())
    }
    pub(crate) fn client(&self, ticket: Ticket, context: &Context<'_>) -> Result<ClientLease> {
        self.client_with(ticket, context, build_client)
    }
    fn client_with(&self, ticket: Ticket, context: &Context<'_>,
        build: impl FnOnce(&TlsIdentity<'_>) -> Result<reqwest::Client>) -> Result<ClientLease> {
        let fingerprint = context.fingerprint();
        let mut state = self.0.lock().map_err(|_| anyhow::anyhow!("SigmaDesk HTTP pool unavailable"))?;
        ensure!(!state.exhausted && state.generation == ticket.generation, "SigmaDesk HTTP context changed");
        if let Some(entry) = &state.entry
            && entry.fingerprint == fingerprint {
            // Coalesce callers that resolved the SAME exact context from the
            // initial ticket. A different context cannot claim that ticket.
            ensure!(ticket.revision==state.revision || ticket.revision==entry.created_from_revision,
                "SigmaDesk HTTP context changed");
            return Ok(ClientLease { client: entry.client.clone(),
                ticket: Ticket {generation:state.generation,revision:state.revision},fingerprint });
        }
        ensure!(ticket.revision==state.revision,"SigmaDesk HTTP context changed");
        // Retire before validation/build: failure must not fall back to the old
        // certificate or bearer context. The cache is bounded to one entry.
        state.entry=None;
        // Claim a revision even for the first entry. A late differently-bound
        // caller with the same formerly-empty ticket must not replace it.
        if let Some(next)=state.revision.checked_add(1){state.revision=next}
        else {state.exhausted=true;anyhow::bail!("SigmaDesk HTTP pool exhausted")}
        ensure!(context.valid(), "SigmaDesk HTTP context unavailable");
        let client = build(&context.tls)?;
        #[cfg(test)] { state.builds += 1; }
        state.entry = Some(Entry { fingerprint, client: client.clone(),created_from_revision:ticket.revision });
        Ok(ClientLease { client, ticket: Ticket {generation:state.generation,revision:state.revision},fingerprint })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    #[derive(Clone)]
    struct Fixture {
        certificate: String,
        key: String,
        sid: String,
        desktop: String,
        member: String,
        node: String,
        pin: String,
        credential: String,
        control_url: String,
        authority_url: String,
        ca: Option<String>,
        auth_epoch: u64,
    }
    impl Fixture {
        fn new() -> Self {
            let certified = rcgen::generate_simple_self_signed(vec!["localhost".into()]).unwrap();
            Self {
                certificate: certified.cert.pem(), key: certified.key_pair.serialize_pem(),
                sid: "S-1-5-21-synthetic-user-a".into(), desktop: "synthetic-desktop-a".into(),
                member: "synthetic-member-a".into(), node: "synthetic-node-a".into(),
                pin: "synthetic-pin-a".into(), credential: "synthetic-credential-a".into(),
                control_url: "https://team.sigmadrive.net".into(),
                authority_url: "https://rd-auth.relay.sigmadrive.net".into(), ca: None, auth_epoch: 0,
            }
        }
        fn context(&self) -> Context<'_> {
            Context {sid: &self.sid, desktop: &self.desktop, member: &self.member,
                node: &self.node, pin: &self.pin,
                tls: TlsIdentity {certificate: &self.certificate, key: &self.key, ca: self.ca.as_deref()},
                credential: &self.credential, control_url: &self.control_url,
                authority_url: &self.authority_url, auth_epoch: self.auth_epoch}
        }
    }
    fn builds(pool: &Pool) -> usize {pool.0.lock().unwrap().builds}
    fn request(pool: &Pool, fixture: &Fixture) {pool.client(pool.ticket().unwrap(), &fixture.context()).unwrap();}

    #[test]
    fn same_exact_context_builds_one_client_for_many_control_requests() {
        let fixture=Fixture::new();let pool=Pool::default();
        for _ in 0..64 {request(&pool,&fixture);}
        assert_eq!(builds(&pool),1);
        assert!(pool.0.lock().unwrap().entry.is_some());
    }
    #[test]
    fn each_auth_and_windows_context_field_invalidates_without_old_fallback() {
        let original=Fixture::new();let other=Fixture::new();
        let mut alternatives=Vec::new();
        macro_rules! changed {($field:ident,$value:expr)=>{{let mut f=original.clone();f.$field=$value;alternatives.push(f);}};}
        changed!(sid,"S-1-5-21-synthetic-user-b".into());
        changed!(desktop,"synthetic-desktop-b".into());
        changed!(member,"synthetic-member-b".into());
        changed!(node,"synthetic-node-b".into());
        changed!(pin,"synthetic-pin-b".into());
        // Valid keypair replacement and exact certificate byte replacement.
        let mut replaced=original.clone();replaced.certificate=other.certificate.clone();replaced.key=other.key.clone();alternatives.push(replaced);
        changed!(certificate,format!("{}\n",original.certificate));
        changed!(key,format!("{}\n",original.key));
        changed!(ca,Some(original.certificate.clone()));
        changed!(ca,Some(String::new()));
        changed!(credential,"synthetic-credential-b".into());
        changed!(control_url,"https://synthetic-control.example".into());
        changed!(authority_url,"https://synthetic-authority.example".into());
        changed!(auth_epoch,1);
        for alternative in alternatives {
            let pool=Pool::default();request(&pool,&original);request(&pool,&alternative);
            assert_eq!(builds(&pool),2);
            let state=pool.0.lock().unwrap();
            assert_eq!(state.entry.as_ref().unwrap().fingerprint,alternative.context().fingerprint());
        }
    }
    #[test]
    fn length_delimited_fields_do_not_alias_and_option_presence_is_exact() {
        let mut first=Fixture::new();let mut second=first.clone();
        first.member="a".into();first.node="bc".into();second.member="ab".into();second.node="c".into();
        assert_ne!(first.context().fingerprint(),second.context().fingerprint());
        second=first.clone();second.ca=Some(String::new());
        assert_ne!(first.context().fingerprint(),second.context().fingerprint());
    }
    #[test]
    fn clear_rejects_pre_invalidation_ticket_and_new_ticket_rebuilds() {
        let fixture=Fixture::new();let pool=Pool::default();let before=pool.ticket().unwrap();
        let dispatched=pool.client(before,&fixture.context()).unwrap();
        pool.clear();
        assert!(!pool.is_current(before));
        assert!(pool.client(before,&fixture.context()).is_err());
        assert!(pool.0.lock().unwrap().entry.is_none());
        request(&pool,&fixture);assert_eq!(builds(&pool),2);
        // Caller-owned already-dispatched handles may outlive invalidation, but
        // cannot repopulate this cache or earn a new request ticket.
        drop(dispatched);
    }
    #[test]
    fn invalid_tls_or_context_clears_old_entry_instead_of_reusing_it() {
        let fixture=Fixture::new();let pool=Pool::default();request(&pool,&fixture);
        let mut invalid=fixture.clone();invalid.key="synthetic-not-a-key".into();
        assert!(pool.client(pool.ticket().unwrap(),&invalid.context()).is_err());
        assert!(pool.0.lock().unwrap().entry.is_none());assert_eq!(builds(&pool),1);
        request(&pool,&fixture);assert_eq!(builds(&pool),2);
        invalid=fixture.clone();invalid.member.clear();
        assert!(pool.client(pool.ticket().unwrap(),&invalid.context()).is_err());
        assert!(pool.0.lock().unwrap().entry.is_none());
    }
    #[test]
    fn ca_private_key_limit_and_parse_errors_are_fixed_and_secret_free() {
        let fixture=Fixture::new();
        for ca in [format!("{}PRIVATE KEY synthetic",fixture.certificate),"x".repeat(65537),
            "-----BEGIN CERTIFICATE-----\n! invalid base64\n-----END CERTIFICATE-----".into()] {
            let pool=Pool::default();request(&pool,&fixture);
            let mut invalid=fixture.clone();invalid.ca=Some(ca.clone());
            let error=match pool.client(pool.ticket().unwrap(),&invalid.context()) {Ok(_)=>panic!("invalid CA accepted"),Err(e)=>e};
            let message=error.to_string();assert!(!message.contains(&ca));
            assert!(!message.contains(&fixture.key));assert!(pool.0.lock().unwrap().entry.is_none());
        }
    }
    #[test]
    fn concurrent_same_context_is_single_flight_and_pools_are_runtime_local() {
        let fixture=Arc::new(Fixture::new());let pool=Arc::new(Pool::default());
        let barrier=Arc::new(std::sync::Barrier::new(8));
        let tasks=(0..8).map(|_|{let f=fixture.clone();let p=pool.clone();let b=barrier.clone();std::thread::spawn(move||{b.wait();request(&p,&f);})}).collect::<Vec<_>>();
        for task in tasks {task.join().unwrap();}
        assert_eq!(builds(&pool),1);
        let another=Pool::default();request(&another,&fixture);assert_eq!(builds(&another),1);
        another.clear();assert!(pool.0.lock().unwrap().entry.is_some());
    }
    #[test]
    fn clear_during_async_context_resolution_cannot_repopulate_old_auth() {
        let fixture=Fixture::new();let pool=Pool::default();let resolving=pool.ticket().unwrap();
        pool.clear();
        assert!(pool.client(resolving,&fixture.context()).is_err());assert_eq!(builds(&pool),0);
        request(&pool,&fixture);assert_eq!(builds(&pool),1);
        assert!(pool.client(resolving,&fixture.context()).is_err());assert_eq!(builds(&pool),1);
        assert!(pool.0.lock().unwrap().entry.is_some());
    }
    #[test]
    fn exact_context_switch_invalidates_previously_issued_client_tickets() {
        let fixture=Fixture::new();let pool=Pool::default();
        let old=pool.client(pool.ticket().unwrap(),&fixture.context()).unwrap();
        let resolving=pool.ticket().unwrap();let mut next=fixture.clone();next.credential="synthetic-rotated-credential".into();
        let new=pool.client(resolving,&next.context()).unwrap();
        assert!(!pool.is_current(old.ticket));assert!(!pool.is_current(resolving));
        assert!(pool.is_current(new.ticket));
        assert!(pool.client(old.ticket,&fixture.context()).is_err());
        assert_eq!(builds(&pool),2);
        drop(old.client);drop(new.client);
    }
    #[test]
    fn generation_exhaustion_never_reactivates_old_context() {
        let fixture=Fixture::new();let pool=Pool::default();request(&pool,&fixture);
        pool.0.lock().unwrap().generation=u64::MAX;let final_ticket=pool.ticket().unwrap();pool.clear();
        assert!(pool.ticket().is_err());assert!(!pool.is_current(final_ticket));
        assert!(pool.client(final_ticket,&fixture.context()).is_err());assert!(pool.0.lock().unwrap().entry.is_none());
    }
    #[test]
    fn first_empty_pool_claim_rejects_a_late_different_context_but_coalesces_the_same_context() {
        let old=Fixture::new();let mut current=old.clone();current.credential="synthetic-first-selected-context".into();
        let pool=Pool::default();let delayed=pool.ticket().unwrap();let selected=pool.ticket().unwrap();
        let active=pool.client(selected,&current.context()).unwrap();
        assert!(!pool.is_current(delayed));
        assert!(pool.client(delayed,&old.context()).is_err());
        let same=pool.client(delayed,&current.context()).unwrap();
        assert!(pool.is_current(same.ticket));assert!(pool.is_current(active.ticket));assert_eq!(builds(&pool),1);
    }
    #[test]
    fn response_checks_reject_live_identity_changes_even_without_auth_epoch_change() {
        let original=Fixture::new();let pool=Pool::default();let old=pool.client(pool.ticket().unwrap(),&original.context()).unwrap();
        assert!(pool.accept_response(&old,&original.context(),200).is_ok());
        let mut current=original.clone();current.credential="synthetic-current-identity-rotated".into();
        assert_eq!(original.auth_epoch,current.auth_epoch);
        assert!(pool.accept_response(&old,&current.context(),200).is_err());
        let new=pool.client(pool.ticket().unwrap(),&current.context()).unwrap();
        for status in [200,401,403] {
            assert!(pool.accept_response(&old,&current.context(),status).is_err());
            assert!(!pool.clear_if_current(old.ticket));assert!(pool.is_current(new.ticket));
        }
    }
    #[test]
    fn only_a_current_exactly_bound_unauthorized_response_retires_its_pool() {
        let fixture=Fixture::new();let pool=Pool::default();let current=pool.client(pool.ticket().unwrap(),&fixture.context()).unwrap();
        assert!(pool.accept_response(&current,&fixture.context(),401).is_ok());
        assert!(!pool.is_current(current.ticket));assert!(pool.0.lock().unwrap().entry.is_none());
        request(&pool,&fixture);let new=pool.ticket().unwrap();
        assert!(pool.accept_response(&current,&fixture.context(),403).is_err());assert!(pool.is_current(new));
    }

    #[tokio::test]
    async fn loopback_tls13_mtls_reuses_one_connection_then_rotates_the_actual_client_certificate() {
        use std::{net::{IpAddr, Ipv4Addr}, sync::atomic::{AtomicBool,AtomicU16,AtomicUsize, Ordering}};
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        use rustls::pki_types::{PrivateKeyDer, PrivatePkcs8KeyDer};
        use rcgen::{BasicConstraints, CertificateParams, ExtendedKeyUsagePurpose, IsCa, KeyPair, KeyUsagePurpose, SanType};

        // Fresh fixture CA/certificates exist only in memory. The one listener
        // binds an OS-assigned IPv4 loopback port, never fixed21117. Test-only
        // no_proxy() below prevents environment/system proxy traffic entirely.
        let mut params=CertificateParams::new(Vec::<String>::new()).unwrap();
        params.distinguished_name.push(rcgen::DnType::CommonName,"SigmaDesk synthetic fixture CA");
        params.is_ca=IsCa::Ca(BasicConstraints::Unconstrained);
        params.key_usages=vec![KeyUsagePurpose::KeyCertSign,KeyUsagePurpose::DigitalSignature,KeyUsagePurpose::CrlSign];
        let ca_key=KeyPair::generate().unwrap();let ca=params.self_signed(&ca_key).unwrap();
        let issue=|client:bool| {
            let mut params=CertificateParams::new(Vec::<String>::new()).unwrap();
            params.distinguished_name.push(rcgen::DnType::CommonName,
                if client {"SigmaDesk synthetic fixture client"} else {"SigmaDesk synthetic fixture server"});
            params.subject_alt_names=vec![SanType::IpAddress(IpAddr::V4(Ipv4Addr::LOCALHOST))];
            params.extended_key_usages=vec![if client {ExtendedKeyUsagePurpose::ClientAuth} else {ExtendedKeyUsagePurpose::ServerAuth}];
            params.key_usages=vec![KeyUsagePurpose::DigitalSignature];
            let key=KeyPair::generate().unwrap();let cert=params.signed_by(&key,&ca,&ca_key).unwrap();(cert,key)
        };
        let (server_cert,server_key)=issue(false);let (client_a,key_a)=issue(true);let (client_b,key_b)=issue(true);
        let mut trusted_clients=rustls::RootCertStore::empty();trusted_clients.add(ca.der().clone()).unwrap();
        let provider=Arc::new(rustls::crypto::ring::default_provider());
        let verifier=rustls::server::WebPkiClientVerifier::builder_with_provider(Arc::new(trusted_clients),provider.clone()).build().unwrap();
        let mut config=rustls::ServerConfig::builder_with_provider(provider)
            .with_protocol_versions(&[&rustls::version::TLS13]).unwrap()
            .with_client_cert_verifier(verifier)
            .with_single_cert(vec![server_cert.der().clone()],
                PrivateKeyDer::Pkcs8(PrivatePkcs8KeyDer::from(server_key.serialize_der()))).unwrap();
        config.alpn_protocols=vec![b"http/1.1".to_vec()];
        let acceptor=tokio_rustls::TlsAcceptor::from(Arc::new(config));
        let listener=tokio::net::TcpListener::bind((Ipv4Addr::LOCALHOST,0)).await.unwrap();
        let endpoint=format!("https://127.0.0.1:{}/",listener.local_addr().unwrap().port());
        #[derive(Default)]
        struct Counts {tcp:AtomicUsize,handshakes:AtomicUsize,requests:AtomicUsize,rejected:AtomicUsize,
            bad_protocol:AtomicUsize,peers:Mutex<Vec<[u8;32]>>,delay:AtomicBool,next_status:AtomicU16,
            entered:tokio::sync::Notify,resume:tokio::sync::Notify}
        struct ServerTask(tokio::task::JoinHandle<()>);
        impl Drop for ServerTask {fn drop(&mut self){self.0.abort();}}
        let counts=Arc::new(Counts::default());let observed=counts.clone();
        let server=ServerTask(tokio::spawn(async move {
            let mut connections=tokio::task::JoinSet::new();
            loop {tokio::select! {
                accepted=listener.accept()=>{
                    let Ok((socket,peer))=accepted else{break};
                    if peer.ip()!=IpAddr::V4(Ipv4Addr::LOCALHOST){continue}
                    observed.tcp.fetch_add(1,Ordering::AcqRel);
                    let acceptor=acceptor.clone();let c=observed.clone();
                    connections.spawn(async move {
                        let mut tls=match tokio::time::timeout(Duration::from_secs(3),acceptor.accept(socket)).await {
                            Ok(Ok(tls))=>tls,_=>{c.rejected.fetch_add(1,Ordering::AcqRel);return}
                        };
                        if tls.get_ref().1.protocol_version()!=Some(rustls::ProtocolVersion::TLSv1_3){c.bad_protocol.fetch_add(1,Ordering::AcqRel);return}
                        let Some(peer)=tls.get_ref().1.peer_certificates().and_then(|certs|certs.first()) else {c.rejected.fetch_add(1,Ordering::AcqRel);return};
                        c.peers.lock().unwrap().push(Sha256::digest(peer.as_ref()).into());
                        c.handshakes.fetch_add(1,Ordering::AcqRel);
                        let mut pending=Vec::new();let mut buffer=[0;1024];
                        loop {
                            let size=match tls.read(&mut buffer).await {Ok(0)|Err(_)=>break,Ok(n)=>n};
                            pending.extend_from_slice(&buffer[..size]);
                            if pending.len()>8192 {break}
                            while let Some(end)=pending.windows(4).position(|part|part==b"\r\n\r\n") {
                                let head=pending.drain(..end+4).collect::<Vec<_>>();
                                if !head.starts_with(b"GET / HTTP/1.1\r\n") {return}
                                c.requests.fetch_add(1,Ordering::AcqRel);
                                let status=match c.next_status.swap(0,Ordering::AcqRel){401=>"401 Unauthorized",403=>"403 Forbidden",_=>"200 OK"};
                                if c.delay.swap(false,Ordering::AcqRel){c.entered.notify_one();c.resume.notified().await;}
                                let response=format!("HTTP/1.1 {status}\r\nContent-Length: 2\r\nConnection: keep-alive\r\n\r\nok");
                                if tls.write_all(response.as_bytes()).await.is_err()
                                    || tls.flush().await.is_err(){return}
                            }
                        }
                    });
                },
                Some(_)=connections.join_next(),if !connections.is_empty()=>{},
            }}
        }));
        let pool=Pool::default();let mut fixture=Fixture::new();
        fixture.certificate=client_a.pem();fixture.key=key_a.serialize_pem();fixture.ca=Some(ca.pem());
        fixture.authority_url=endpoint.clone();
        let fixture_client=|pool:&Pool,fixture:&Fixture| pool.client_with(pool.ticket().unwrap(),&fixture.context(),
            |identity|client_builder(identity)?.no_proxy().build().map_err(|_|anyhow::anyhow!("synthetic client build failed"))).unwrap();
        for _ in 0..3 {
            let lease=fixture_client(&pool,&fixture);
            let response=lease.client.get(&endpoint).send().await.unwrap();assert_eq!(response.status(),200);
            assert_eq!(response.bytes().await.unwrap().as_ref(),b"ok");tokio::task::yield_now().await;
        }
        assert_eq!(builds(&pool),1);assert_eq!(counts.tcp.load(Ordering::Acquire),1);
        assert_eq!(counts.handshakes.load(Ordering::Acquire),1);assert_eq!(counts.requests.load(Ordering::Acquire),3);
        let old_ticket=pool.ticket().unwrap();
        fixture.certificate=client_b.pem();fixture.key=key_b.serialize_pem();fixture.credential="synthetic-rotated-client".into();
        let lease=fixture_client(&pool,&fixture);
        assert_eq!(lease.client.get(&endpoint).send().await.unwrap().bytes().await.unwrap().as_ref(),b"ok");
        assert_eq!(builds(&pool),2);assert!(!pool.is_current(old_ticket));
        assert_eq!(counts.tcp.load(Ordering::Acquire),2);assert_eq!(counts.handshakes.load(Ordering::Acquire),2);
        assert_eq!(counts.requests.load(Ordering::Acquire),4);assert_eq!(counts.bad_protocol.load(Ordering::Acquire),0);
        let peers=counts.peers.lock().unwrap().clone();assert_eq!(peers.len(),2);
        assert_eq!(peers[0],<[u8;32]>::from(Sha256::digest(client_a.der().as_ref())));
        assert_eq!(peers[1],<[u8;32]>::from(Sha256::digest(client_b.der().as_ref())));
        assert_ne!(peers[0],peers[1]);
        // Hold actual TLS HTTP responses while the local context is retired and
        // replaced. Late200 may not be committed; late401/403 may not retire the
        // new pool. The production response gate below is the same method.
        let mut committed=0;
        for status in [200u16,401,403] {
            let old=fixture_client(&pool,&fixture);let client=old.client.clone();let address=endpoint.clone();
            counts.delay.store(true,Ordering::Release);counts.next_status.store(status,Ordering::Release);
            let pending=tokio::spawn(async move {
                let response=client.get(address).send().await.unwrap();let status=response.status().as_u16();
                let bytes=response.bytes().await.unwrap();(status,bytes)
            });
            tokio::time::timeout(Duration::from_secs(3),counts.entered.notified()).await.unwrap();
            pool.clear();fixture.credential=format!("synthetic-new-context-after-{status}");
            let current=fixture_client(&pool,&fixture);
            counts.resume.notify_one();
            let (received,body)=tokio::time::timeout(Duration::from_secs(3),pending).await.unwrap().unwrap();
            assert_eq!(received,status);assert_eq!(body.as_ref(),b"ok");
            if pool.accept_response(&old,&fixture.context(),received).is_ok(){committed+=1;}
            assert!(!pool.clear_if_current(old.ticket));assert!(pool.is_current(current.ticket));
        }
        assert_eq!(committed,0);assert_eq!(counts.requests.load(Ordering::Acquire),7);
        // Positive requests above require actual mutual authentication. A TLS
        // client that trusts this CA but presents no certificate cannot send HTTP.
        let anonymous=reqwest::Client::builder().no_proxy()
            .tls_version_min(reqwest::tls::Version::TLS_1_3).timeout(Duration::from_secs(3))
            .add_root_certificate(reqwest::Certificate::from_pem(ca.pem().as_bytes()).unwrap()).build().unwrap();
        assert!(anonymous.get(&endpoint).send().await.is_err());
        assert_eq!(counts.requests.load(Ordering::Acquire),7);
        let until=tokio::time::Instant::now()+Duration::from_secs(3);
        while counts.rejected.load(Ordering::Acquire)==0 {
            assert!(tokio::time::Instant::now()<until);tokio::task::yield_now().await;
        }
        eprintln!("synthetic loopback TLS: initial3 requests=1 TLS1.3+mTLS connection; rotation=second distinct client certificate; late200/401/403 accepted={} current_pool_survives=true; anonymous_rejected={}",committed,counts.rejected.load(Ordering::Acquire));
        pool.clear();drop(lease);drop(anonymous);drop(server);
    }
}
