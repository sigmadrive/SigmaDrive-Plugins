//! Bounded, PC-local observations. These are symptoms, never proof of root cause.
//! No protocol bytes, credentials, endpoint strings or cross-PC identifiers.
use serde_json::{Value, json};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, AtomicU64, Ordering},
};
use std::time::Instant;

const CAP: usize = 64;
#[derive(Clone, Copy, Debug)]
pub(crate) enum Route {
    Id,
    Relay,
}
impl Route {
    fn label(self) -> &'static str {
        match self {
            Self::Id => "id",
            Self::Relay => "relay",
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) enum End {
    LocalSetupError,
    LocalEof,
    LocalReadError,
    RelayWriteError,
    RelayWriteTimeout,
    RemoteEof,
    RemoteCloseNormal,
    RemoteCloseOther,
    RemoteReadError,
    LocalWriteError,
    LocalWriteTimeout,
    UnexpectedFrame,
    DialUnavailable,
    DialTimeout,
    Cancelled,
}
impl End {
    fn label(self) -> &'static str {
        match self {
            Self::LocalSetupError => "local_socket_setup_error",
            Self::LocalEof => "local_eof",
            Self::LocalReadError => "local_read_error",
            Self::RelayWriteError => "relay_write_error",
            Self::RelayWriteTimeout => "relay_write_timeout",
            Self::RemoteEof => "remote_eof",
            Self::RemoteCloseNormal => "remote_close_normal",
            Self::RemoteCloseOther => "remote_close_other",
            Self::RemoteReadError => "remote_read_error",
            Self::LocalWriteError => "local_write_error",
            Self::LocalWriteTimeout => "local_write_timeout",
            Self::UnexpectedFrame => "unexpected_frame",
            Self::DialUnavailable => "dial_unavailable",
            Self::DialTimeout => "dial_timeout",
            Self::Cancelled => "local_task_cancelled",
        }
    }
    fn direction(self) -> &'static str {
        match self {
            Self::LocalSetupError => "local_setup",
            Self::LocalEof
            | Self::LocalReadError
            | Self::RelayWriteError
            | Self::RelayWriteTimeout => "local_to_relay",
            Self::RemoteEof
            | Self::RemoteCloseNormal
            | Self::RemoteCloseOther
            | Self::RemoteReadError
            | Self::LocalWriteError
            | Self::LocalWriteTimeout
            | Self::UnexpectedFrame => "relay_to_local",
            Self::DialUnavailable | Self::DialTimeout => "dial",
            Self::Cancelled => "local_cancellation",
        }
    }
}
struct Row {
    route: Route,
    began_ms: u64,
    connected_ms: Option<u64>,
    local_first_ms: Option<u64>,
    remote_first_ms: Option<u64>,
    end: Option<(u64, End)>,
}
pub(crate) struct Trace {
    pub(crate) tls: Arc<crate::desk_transport_tls::Metrics>,
    origin: Instant,
    rows: Mutex<Vec<Row>>,
    dropped: AtomicU64,
}
impl Default for Trace {
    fn default() -> Self {
        Self::with_tls_diagnostics(false)
    }
}
impl Trace {
    pub(crate) fn with_tls_diagnostics(diagnostics_enabled:bool) -> Self {
        Self {
            tls: Arc::new(crate::desk_transport_tls::Metrics::new(diagnostics_enabled)),
            origin: Instant::now(),
            rows: Mutex::new(Vec::new()),
            dropped: AtomicU64::new(0),
        }
    }
}
impl Trace {
    fn elapsed(&self) -> u64 {
        self.origin.elapsed().as_millis().min(u64::MAX as u128) as u64
    }
    fn lost(&self) {
        let _ = self
            .dropped
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| {
                Some(n.saturating_add(1))
            });
    }
    pub(crate) fn open(self: &Arc<Self>, route: Route) -> Channel {
        // Never wait for diagnostics while handling a connection or media.
        let slot = match self.rows.try_lock() {
            Ok(mut rows) if rows.len() < CAP => {
                let slot = rows.len();
                rows.push(Row {
                    route,
                    began_ms: self.elapsed(),
                    connected_ms: None,
                    local_first_ms: None,
                    remote_first_ms: None,
                    end: None,
                });
                Some(slot)
            }
            _ => {
                self.lost();
                None
            }
        };
        Channel {
            trace: self.clone(),
            slot,
            finished: AtomicBool::new(false),
            local_seen: AtomicBool::new(false),
            remote_seen: AtomicBool::new(false),
        }
    }
    pub(crate) fn snapshot(&self) -> Value {
        let rows = match self.rows.try_lock() {
            Ok(rows) => rows
                .iter()
                .enumerate()
                .map(|(i, r)| {
                    json!({
                        "channel":i+1,"route":r.route.label(),"began_ms":r.began_ms,
                        "connected_ms":r.connected_ms,"first_local_bytes_ms":r.local_first_ms,
                        "first_relay_bytes_ms":r.remote_first_ms,
                        "ended_ms":r.end.map(|e|e.0),"end_observation":r.end.map(|e|e.1.label()),
                        "first_observed_direction":r.end.map(|e|e.1.direction()),
                        "root_cause_confirmed":false
                    })
                })
                .collect::<Vec<_>>(),
            Err(_) => {
                return json!({"schema":1,"coverage":"native_tcp_adapter","available":false,"complete":false,"root_cause_confirmed":false});
            }
        };
        let dropped = self.dropped.load(Ordering::Relaxed);
        json!({"schema":1,"coverage":"native_tcp_adapter","available":true,
            "complete":dropped==0,"dropped_observations":dropped,"capacity":CAP,
            "elapsed_ms":self.elapsed(),"channels":rows,"tls_local":self.tls.snapshot(),"root_cause_confirmed":false})
    }
}
pub(crate) struct Channel {
    trace: Arc<Trace>,
    slot: Option<usize>,
    finished: AtomicBool,
    local_seen: AtomicBool,
    remote_seen: AtomicBool,
}
impl Channel {
    fn update(&self, f: impl FnOnce(&mut Row, u64)) {
        let Some(slot) = self.slot else { return };
        if let Ok(mut rows) = self.trace.rows.try_lock() {
            if let Some(row) = rows.get_mut(slot) {
                f(row, self.trace.elapsed());
            }
        } else {
            self.trace.lost();
        }
    }
    pub(crate) fn connected(&self) {
        self.update(|r, ms| {
            if r.connected_ms.is_none() {
                r.connected_ms = Some(ms)
            }
        });
    }
    pub(crate) fn first_local(&self) {
        if !self.local_seen.swap(true, Ordering::Relaxed) {
            self.update(|r, ms| r.local_first_ms = Some(ms));
        }
    }
    pub(crate) fn first_remote(&self) {
        if !self.remote_seen.swap(true, Ordering::Relaxed) {
            self.update(|r, ms| r.remote_first_ms = Some(ms));
        }
    }
    pub(crate) fn end(&self, reason: End) {
        if !self.finished.swap(true, Ordering::Relaxed) {
            self.update(|r, ms| {
                if r.end.is_none() {
                    r.end = Some((ms, reason))
                }
            });
        }
    }
}
impl Drop for Channel {
    fn drop(&mut self) {
        self.end(End::Cancelled);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn first_end_wins_and_drop_cannot_rewrite_observation() {
        let trace = Arc::new(Trace::default());
        let channel = trace.open(Route::Relay);
        channel.connected();
        channel.first_local();
        channel.first_remote();
        channel.end(End::RemoteReadError);
        channel.end(End::LocalEof);
        drop(channel);
        let s = trace.snapshot();
        assert_eq!(s["channels"][0]["end_observation"], "remote_read_error");
        assert_eq!(
            s["channels"][0]["first_observed_direction"],
            "relay_to_local"
        );
        assert_eq!(s["root_cause_confirmed"], false);
        assert_eq!(s["complete"], true);
    }
    #[test]
    fn cancellation_and_history_overflow_are_explicit() {
        let trace = Arc::new(Trace::default());
        for _ in 0..CAP + 5 {
            drop(trace.open(Route::Id));
        }
        let s = trace.snapshot();
        assert_eq!(s["channels"].as_array().unwrap().len(), CAP);
        assert_eq!(s["dropped_observations"], 5);
        assert_eq!(s["complete"], false);
        assert_eq!(s["channels"][0]["end_observation"], "local_task_cancelled");
    }
    #[test]
    fn local_setup_failure_is_not_misreported_as_inbound_write_failure() {
        let trace = Arc::new(Trace::default());
        let channel = trace.open(Route::Id);
        channel.end(End::LocalSetupError);
        let s = trace.snapshot();
        assert_eq!(
            s["channels"][0]["end_observation"],
            "local_socket_setup_error"
        );
        assert_eq!(s["channels"][0]["first_observed_direction"], "local_setup");
        assert!(s["channels"][0]["connected_ms"].is_null());
    }
    #[test]
    fn contention_never_blocks_and_is_never_reported_complete() {
        let trace = Arc::new(Trace::default());
        let c = trace.open(Route::Relay);
        let lock = trace.rows.lock().unwrap();
        c.connected();
        c.first_local();
        c.end(End::RemoteEof);
        assert_eq!(trace.snapshot()["available"], false);
        drop(lock);
        let s = trace.snapshot();
        assert_eq!(s["dropped_observations"], 3);
        assert_eq!(s["complete"], false);
        assert!(s["channels"][0]["end_observation"].is_null());
    }
    #[test]
    fn memory_does_not_accept_payload_identity_or_network_metadata() {
        let trace = Arc::new(Trace::default());
        let c = trace.open(Route::Id);
        c.end(End::DialTimeout);
        let s = trace.snapshot();
        let row = s["channels"][0].as_object().unwrap();
        assert_eq!(row.len(), 10);
        assert!(!s.to_string().contains("session"));
        assert!(!s.to_string().contains("token"));
        assert!(!s.to_string().contains("address"));
        assert_eq!(row["root_cause_confirmed"], false);
    }
}
