//! Offline data-plane authorization against a separately refreshed authority policy.
//! Receipt clocks are monotonic; neither a timeout nor replay extends authority.
use anyhow::{Result, ensure};
use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use ed25519_dalek::{Signature, VerifyingKey};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::{
    collections::{HashMap, HashSet},
    time::{Duration, Instant},
};

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PublicationPolicy {
    pub verification_key: String,
    pub publisher_pin: String,
    pub version: i64,
    pub server_time: i64,
    pub share: String,
    pub approved_pins: Vec<String>,
    #[serde(default)]
    pub write_pins: Vec<String>,
    pub expires: i64,
}

#[cfg(test)]
mod cryptographic_tests {
    use super::*;
    use ed25519_dalek::{Signer, SigningKey};
    use serde_json::{Value, json};
    fn fixture() -> (PublicationVerifier, SigningKey, PublicationPolicy) {
        let key = SigningKey::from_bytes(&[7; 32]);
        let pin = "a".repeat(64);
        let peer = "b".repeat(64);
        let mut verifier = PublicationVerifier::new(
            "share-a".into(),
            "publisher-a".into(),
            pin.clone(),
            HashSet::from([peer.clone()]),
            HashSet::from([peer.clone()]),
        )
        .unwrap();
        let policy = PublicationPolicy {
            verification_key: URL_SAFE_NO_PAD.encode(key.verifying_key().as_bytes()),
            publisher_pin: pin,
            version: 1,
            server_time: 1_000_000,
            share: "share-a".into(),
            approved_pins: vec![peer.clone()],
            write_pins: vec![peer],
            expires: 1_100_000,
        };
        verifier.update(policy.clone(), Instant::now()).unwrap();
        (verifier, key, policy)
    }
    fn claims(write: bool) -> Value {
        json!({"token":hex::encode(Sha256::digest(b"s3r-test")),"share":"share-a","publisher":"publisher-a","subscriber":"subscriber-a","publisher_pin":"a".repeat(64),"subscriber_pin":"b".repeat(64),"version":1,"issued":1_000_000,"expires":1_090_000,"write":write,"action":"s3-read","relay":true})
    }
    fn sign(key: &SigningKey, claims: &Value) -> String {
        let body = serde_json::to_vec(claims).unwrap();
        let mut signed = b"SigmaDrive/S3/1\0".to_vec();
        signed.extend_from_slice(&body);
        format!(
            "{}.{}",
            URL_SAFE_NO_PAD.encode(&body),
            URL_SAFE_NO_PAD.encode(key.sign(&signed).to_bytes())
        )
    }
    #[test]
    fn valid_signature_cannot_cross_share_peer_or_write_scope() {
        let (mut v, key, _) = fixture();
        let read = sign(&key, &claims(false));
        let pin = "b".repeat(64);
        assert!(
            v.authorize("s3r-test", &read, &pin, "subscriber-a", false)
                .is_ok()
        );
        assert!(
            v.authorize("s3r-test", &read, &pin, "subscriber-a", true)
                .is_err()
        );
        assert!(
            v.authorize("s3r-other", &read, &pin, "subscriber-a", false)
                .is_err()
        );
        assert!(
            v.authorize("s3r-test", &read, &"c".repeat(64), "subscriber-a", false)
                .is_err()
        );
        assert!(
            v.authorize("s3r-test", &read, &pin, "subscriber-b", false)
                .is_err()
        );
        let mut other = claims(true);
        other["share"] = json!("share-b");
        assert!(
            v.authorize("s3r-test", &sign(&key, &other), &pin, "subscriber-a", false)
                .is_err()
        );
        assert!(
            v.authorize(
                "s3r-test",
                &sign(&SigningKey::from_bytes(&[8; 32]), &claims(true)),
                &pin,
                "subscriber-a",
                false
            )
            .is_err()
        );
    }
    #[test]
    fn changed_proof_with_same_expiry_cannot_restart_the_clock() {
        let (mut v, key, mut policy) = fixture();
        let pin = "b".repeat(64);
        let until = v
            .authorize(
                "s3r-test",
                &sign(&key, &claims(true)),
                &pin,
                "subscriber-a",
                true,
            )
            .unwrap();
        policy.server_time += 1000;
        policy.expires += 1000;
        v.update(policy, Instant::now()).unwrap();
        let mut changed = claims(true);
        changed["issued"] = json!(1_000_100);
        let renewed = v
            .authorize(
                "s3r-test",
                &sign(&key, &changed),
                &pin,
                "subscriber-a",
                true,
            )
            .unwrap();
        assert!(renewed <= until);
        v.revoke_local(&pin);
        assert!(
            v.authorize(
                "s3r-test",
                &sign(&key, &changed),
                &pin,
                "subscriber-a",
                true
            )
            .is_err()
        );
    }
    #[test]
    fn authority_key_changes_and_policy_rollbacks_require_explicit_recovery() {
        let (mut v, _, policy) = fixture();
        let mut changed = policy.clone();
        changed.verification_key =
            URL_SAFE_NO_PAD.encode(SigningKey::from_bytes(&[8; 32]).verifying_key().as_bytes());
        assert!(v.update(changed, Instant::now()).is_err());
        let mut newer = policy.clone();
        newer.version = 2;
        newer.server_time += 1000;
        newer.expires += 1000;
        v.update(newer, Instant::now()).unwrap();
        assert!(v.update(policy, Instant::now()).is_err());
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Claims {
    token: String,
    share: String,
    publisher: String,
    subscriber: String,
    subscriber_pin: String,
    publisher_pin: String,
    #[serde(default)]
    endpoint: String,
    #[serde(default)]
    relay: bool,
    version: i64,
    expires: i64,
    issued: i64,
    #[serde(default)]
    write: bool,
    action: String,
    #[serde(default)]
    revision: String,
    #[serde(default)]
    capability: String,
}
struct Accepted {
    expires: i64,
    until: Instant,
    capability_sha: [u8; 32],
    peer_pin: String,
    peer_node: String,
    write: bool,
}
pub struct PublicationVerifier {
    share: String,
    publisher: String,
    pin: String,
    // Local approvals are independent of authority discovery or server grants.
    local_read: HashSet<String>,
    local_write: HashSet<String>,
    pinned_key: Option<[u8; 32]>,
    policy: Option<PublicationPolicy>,
    received: Instant,
    policy_until: Instant,
    leases: HashMap<String, Accepted>,
}
pub fn valid_pin(pin: &str) -> bool {
    pin.len() == 64
        && pin
            .bytes()
            .all(|b| b.is_ascii_digit() || matches!(b, b'a'..=b'f'))
}
impl PublicationVerifier {
    pub fn version(&self) -> Option<i64> {
        self.policy.as_ref().map(|p| p.version)
    }
    pub fn new(
        share: String,
        publisher: String,
        pin: String,
        reads: HashSet<String>,
        writes: HashSet<String>,
    ) -> Result<Self> {
        ensure!(
            !share.is_empty() && !publisher.is_empty() && valid_pin(&pin),
            "invalid publication binding"
        );
        ensure!(
            reads.len() <= 256 && reads.iter().all(|s| valid_pin(s)) && writes.is_subset(&reads),
            "invalid local peer approvals"
        );
        let now = Instant::now();
        Ok(Self {
            share,
            publisher,
            pin,
            local_read: reads,
            local_write: writes,
            pinned_key: None,
            policy: None,
            received: now,
            policy_until: now,
            leases: HashMap::new(),
        })
    }
    /// `sent` is captured BEFORE the verified mTLS control-plane request.
    pub fn update(&mut self, policy: PublicationPolicy, sent: Instant) -> Result<()> {
        let key: [u8; 32] = URL_SAFE_NO_PAD
            .decode(&policy.verification_key)?
            .try_into()
            .map_err(|_| anyhow::anyhow!("invalid publication verification key"))?;
        ensure!(
            self.pinned_key.is_none_or(|k| k == key),
            "authority key changed; explicit rotation is required"
        );
        ensure!(
            policy.share == self.share
                && policy.publisher_pin == self.pin
                && policy.version > 0
                && policy.server_time > 0
                && policy.expires > policy.server_time,
            "publication binding is invalid"
        );
        ensure!(
            policy.approved_pins.len() <= 256
                && policy.approved_pins.iter().all(|p| valid_pin(p))
                && policy
                    .write_pins
                    .iter()
                    .all(|p| policy.approved_pins.contains(p)),
            "invalid publication peer policy"
        );
        if let Some(old) = &self.policy {
            ensure!(
                policy.version >= old.version && policy.server_time >= old.server_time,
                "publication policy rollback denied"
            );
        }
        let millis = policy
            .expires
            .checked_sub(policy.server_time)
            .and_then(|n| n.checked_sub(1000))
            .ok_or_else(|| anyhow::anyhow!("invalid policy expiry"))?;
        ensure!(
            millis > 0 && millis <= 120000,
            "publication lifetime outside protocol bounds"
        );
        let mut until = sent + Duration::from_millis(millis as u64);
        if let Some(old) = &self.policy {
            // Re-delivery of the same server clock cannot restart its budget.
            if policy.server_time == old.server_time {
                ensure!(
                    policy.expires <= old.expires,
                    "policy expiry changed without a new authority clock"
                );
                until = until.min(self.policy_until);
            }
        }
        ensure!(
            until > Instant::now(),
            "publication policy expired in transit"
        );
        if self
            .policy
            .as_ref()
            .is_some_and(|p| p.version != policy.version)
        {
            self.leases.clear();
        }
        self.received = sent;
        self.policy_until = until;
        self.pinned_key = Some(key);
        self.policy = Some(policy);
        Ok(())
    }
    /// For a confirmed revocation/denial. Offline/timeouts retain only the original deadline.
    pub fn invalidate(&mut self) {
        self.policy_until = Instant::now();
        self.leases.clear();
    }
    pub fn revoke_local(&mut self, pin: &str) {
        self.local_read.remove(pin);
        self.local_write.remove(pin);
        self.leases.clear();
    }
    /// The peer fingerprint must come from the completed, proof-of-possession TLS handshake.
    pub fn authorize(
        &mut self,
        token: &str,
        capability: &str,
        peer_pin: &str,
        peer_node: &str,
        write: bool,
    ) -> Result<Instant> {
        let now = Instant::now();
        ensure!(
            now < self.policy_until
                && self.local_read.contains(peer_pin)
                && (!write || self.local_write.contains(peer_pin)),
            "local approval or publication lease denied"
        );
        let policy = self
            .policy
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("publication policy unavailable"))?;
        ensure!(
            policy.approved_pins.iter().any(|p| p == peer_pin)
                && (!write || policy.write_pins.iter().any(|p| p == peer_pin)),
            "peer permission revoked"
        );
        ensure!(
            !token.is_empty() && token.len() <= 8192 && capability.len() <= 8192,
            "invalid session credential bounds"
        );
        let key_id = hex::encode(Sha256::digest(token.as_bytes()));
        let capability_sha: [u8; 32] = Sha256::digest(capability.as_bytes()).into();
        if let Some(lease) = self
            .leases
            .get(&key_id)
            .filter(|l| l.capability_sha == capability_sha)
        {
            ensure!(lease.until > now, "session lease expired");
            ensure!(
                lease.peer_pin == peer_pin
                    && lease.peer_node == peer_node
                    && (!write || lease.write),
                "cached session scope mismatch"
            );
            return Ok(lease.until.min(self.policy_until));
        }
        let (encoded, signature) = capability
            .split_once('.')
            .ok_or_else(|| anyhow::anyhow!("signed session proof required"))?;
        ensure!(!signature.contains('.'), "invalid session proof framing");
        let body = URL_SAFE_NO_PAD.decode(encoded)?;
        let signature = Signature::from_slice(&URL_SAFE_NO_PAD.decode(signature)?)?;
        let mut signed = b"SigmaDrive/S3/1\0".to_vec();
        signed.extend_from_slice(&body);
        VerifyingKey::from_bytes(
            &self
                .pinned_key
                .ok_or_else(|| anyhow::anyhow!("authority key unavailable"))?,
        )?
        .verify_strict(&signed, &signature)?;
        let claims: Claims = serde_json::from_slice(&body)?;
        ensure!(
            claims.token == key_id
                && claims.action == "s3-read"
                && claims.share == self.share
                && claims.publisher == self.publisher
                && claims.subscriber == peer_node
                && claims.publisher_pin == self.pin
                && claims.subscriber_pin == peer_pin
                && claims.version == policy.version
                && (!write || claims.write),
            "signed session scope mismatch"
        );
        ensure!(
            claims.capability.is_empty(),
            "nested capabilities are not permitted"
        );
        // These are signed but never used as an alternate route or permission source.
        let _ = (&claims.endpoint, claims.relay, &claims.revision);
        let lifetime = claims
            .expires
            .checked_sub(claims.issued)
            .ok_or_else(|| anyhow::anyhow!("invalid signed lifetime"))?;
        ensure!(
            claims.issued > 0 && lifetime > 0 && lifetime <= 120000,
            "signed lease lifetime exceeds protocol"
        );
        let remaining = claims
            .expires
            .checked_sub(policy.server_time)
            .and_then(|n| n.checked_sub(1000))
            .ok_or_else(|| anyhow::anyhow!("invalid signed expiry"))?;
        ensure!(remaining > 0, "signed session expired");
        let mut until = (self.received + Duration::from_millis((remaining as u64).min(120000)))
            .min(self.policy_until);
        ensure!(until > now, "signed session expired in transit");
        if let Some(old) = self.leases.get(&key_id) {
            ensure!(claims.expires >= old.expires, "session rollback denied");
            if claims.expires == old.expires {
                until = until.min(old.until);
            }
        }
        self.leases.retain(|_, l| l.until > now);
        ensure!(
            self.leases.contains_key(&key_id) || self.leases.len() < 256,
            "session capacity exceeded"
        );
        self.leases.insert(
            key_id,
            Accepted {
                expires: claims.expires,
                until,
                capability_sha,
                peer_pin: peer_pin.to_owned(),
                peer_node: peer_node.to_owned(),
                write: claims.write,
            },
        );
        Ok(until)
    }
}
