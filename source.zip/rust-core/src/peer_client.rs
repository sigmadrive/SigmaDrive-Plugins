//! Recipient: peer HTTPS/SigV4 runs wholly in Rust. Directory renewals have an
//! independent task and never receive object names, paths or byte counters.
use crate::{
    relay::{Failure, RelayTransport},
    state::Core,
};
use anyhow::{Result, ensure};
use hmac::{Hmac, Mac};
use http_body_util::{BodyExt, Full};
use hyper_util::rt::TokioIo;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    },
    time::{Duration, Instant},
};

struct Proof {
    value: Value,
    until: Instant,
    expires: i64,
}
pub struct Session {
    availability: Arc<crate::availability::Registry>,
    owners: AtomicUsize,
    data: tokio::sync::Mutex<Option<PeerConnection>>,
    drivers: Mutex<Vec<tokio::task::AbortHandle>>,
    route: tokio::sync::OnceCell<String>,
    ending: tokio::sync::watch::Sender<bool>,
    transport: Arc<RelayTransport>,
    share: String,
    raw_token: String,
    pin: String,
    node: String,
    identity: Value,
    proof: Mutex<Proof>,
    stopped: AtomicBool,
    refresh: tokio::sync::Mutex<()>,
    pub credentials: tokio::sync::OnceCell<Value>,
}
struct PeerConnection {
    sender: hyper::client::conn::http1::SendRequest<Full<bytes::Bytes>>,
    driver: tokio::task::JoinHandle<()>,
}
impl Drop for PeerConnection {
    fn drop(&mut self) {
        self.driver.abort();
    }
}
pub struct Handle(Arc<Session>);
impl std::ops::Deref for Handle {
    type Target = Session;
    fn deref(&self) -> &Session {
        &self.0
    }
}
impl Drop for Handle {
    fn drop(&mut self) {
        let mut n = self.0.owners.load(Ordering::Acquire);
        loop {
            if n == usize::MAX {
                return;
            }
            let next = if n == 1 { usize::MAX } else { n - 1 };
            match self
                .0
                .owners
                .compare_exchange(n, next, Ordering::AcqRel, Ordering::Acquire)
            {
                Ok(_) => {
                    if next == usize::MAX {
                        self.0.stop();
                    }
                    return;
                }
                Err(v) => n = v,
            }
        }
    }
}
fn install(
    value: Value,
    sent: Instant,
    clock: i64,
    binding: (&Value, &str, &str, &str),
    old: Option<&Proof>,
) -> Result<Proof> {
    let (identity, share, pin, node) = binding;
    let mut value = value;
    if let Some(old) = old {
        if value["token"].as_str().is_none_or(|s| s.is_empty()) {
            value["token"] = old.value["token"].clone();
        }
        ensure!(
            value["token"] == old.value["token"]
                && value["version"] == old.value["version"]
                && value["expires"].as_i64().unwrap_or(0) >= old.expires,
            "S3 session rollback or scope changed"
        );
    }
    ensure!(
        value["share"] == share
            && value["publisher_pin"] == pin
            && value["publisher"] == node
            && value["subscriber_pin"] == identity["pin"]
            && value["subscriber"] == identity["node"]
            && value["action"] == "s3-read"
            && value["relay"] == true,
        "S3 session identity/scope mismatch"
    );
    ensure!(
        value["token"]
            .as_str()
            .is_some_and(|s| s.starts_with("s3r-") && s.len() <= 8192)
            && value["capability"]
                .as_str()
                .is_some_and(|s| s.len() <= 8192 && !s.is_empty()),
        "S3 authority missing"
    );
    let expires = value["expires"].as_i64().unwrap_or(0);
    let remaining = expires - clock - 1000;
    ensure!(
        clock > 0 && remaining > 0 && remaining <= 120000,
        "S3 authority lifetime invalid"
    );
    let mut until = sent + Duration::from_millis(remaining as u64);
    if let Some(old) = old
        && expires == old.expires
    {
        until = until.min(old.until);
    }
    ensure!(until > Instant::now(), "S3 authority expired in transit");
    Ok(Proof {
        value,
        until,
        expires,
    })
}
impl Session {
    pub fn stop(&self) {
        if self.stopped.swap(true, Ordering::AcqRel) {
            return;
        }
        let transport = self.transport.clone();
        let token = self.raw_token.clone();
        crate::runtime().spawn(async move {
            let _ = tokio::time::timeout(
                Duration::from_secs(3),
                transport.s3_clock_control("close", &json!({"token":token})),
            )
            .await;
        });
        self.ending.send_replace(true);
        if let Ok(drivers) = self.drivers.lock() {
            for d in drivers.iter() {
                d.abort();
            }
        }
    }
    pub fn live(&self) -> bool {
        !self.stopped.load(Ordering::Acquire)
            && self.proof.lock().is_ok_and(|p| p.until > Instant::now())
    }
    fn authority(&self) -> Result<(Value, Instant)> {
        ensure!(
            !self.stopped.load(Ordering::Acquire),
            "S3 authority revoked"
        );
        let p = self
            .proof
            .lock()
            .map_err(|_| anyhow::anyhow!("S3 authority unavailable"))?;
        ensure!(p.until > Instant::now(), "S3 authority expired");
        Ok((p.value.clone(), p.until))
    }
    async fn renew(&self) -> Result<()> {
        let _single = self.refresh.lock().await;
        let (old, _) = self.authority()?;
        let mut ended = self.ending.subscribe();
        let body = json!({"token":old["token"],"peer_pin":""});
        let result = tokio::select! {biased;_=ended.wait_for(|s|*s)=>return Err(anyhow::anyhow!("S3 session ended")),r=self.transport.s3_clock_control("renew",&body)=>r};
        match result {
            Ok((v, s, c)) => {
                let mut p = self
                    .proof
                    .lock()
                    .map_err(|_| anyhow::anyhow!("S3 authority unavailable"))?;
                match install(
                    v,
                    s,
                    c,
                    (&self.identity, &self.share, &self.pin, &self.node),
                    Some(&p),
                ) {
                    Ok(new) => *p = new,
                    Err(e) => {
                        self.stop();
                        return Err(e);
                    }
                }
            }
            Err(e) => {
                if matches!(
                    e.downcast_ref::<Failure>(),
                    Some(Failure::Denied | Failure::InvalidResponse | Failure::UpdateRequired)
                ) {
                    self.stop();
                }
                return Err(e);
            }
        }
        // Refreshes existing publisher request leases, but not from their data path.
        self.raw("HEAD", "/_sigma/s3/authority", &[], Vec::new())
            .await?;
        Ok(())
    }
    async fn connection(&self) -> Result<PeerConnection> {
        let (proof, _) = self.authority()?;
        let origin = self
            .route
            .get_or_try_init(|| self.transport.origin(proof["token"].as_str()))
            .await?;
        let stream = self
            .transport
            .connect_at(proof["token"].as_str().unwrap(), &self.pin, origin)
            .await?;
        let (sender, connection) = hyper::client::conn::http1::handshake(TokioIo::new(stream))
            .await
            .map_err(|_| Failure::Offline)?;
        let driver = tokio::spawn(async move {
            let _ = connection.await;
        });
        if let Ok(mut drivers) = self.drivers.lock() {
            drivers.retain(|d| !d.is_finished());
            drivers.push(driver.abort_handle());
        }
        Ok(PeerConnection { sender, driver })
    }
    async fn exchange(
        &self,
        connection: &mut PeerConnection,
        method: &str,
        path: &str,
        extra: &[(String, String)],
        bytes: Vec<u8>,
    ) -> Result<Reply> {
        let (proof, _) = self.authority()?;
        let mut req = http::Request::builder()
            .method(method)
            .uri(path)
            .header("Host", "localhost")
            .header("Content-Length", bytes.len())
            .header("X-Sigma-S3-Share", &self.share)
            .header("X-Sigma-S3-Permit", proof["token"].as_str().unwrap())
            .header(
                "X-Sigma-S3-Capability",
                proof["capability"].as_str().unwrap(),
            )
            .header("X-Sigma-Protocol-Min", "1")
            .header("X-Sigma-Protocol-Max", "1");
        for (k, v) in extra {
            req = req.header(k, v);
        }
        connection
            .sender
            .ready()
            .await
            .map_err(|_| Failure::Offline)?;
        let mut r = connection
            .sender
            .send_request(req.body(Full::new(bytes::Bytes::from(bytes)))?)
            .await
            .map_err(|_| Failure::Offline)?;
        let status = r.status().as_u16();
        let headers = r.headers().clone();
        let mut body = Vec::new();
        while let Some(frame) = r.body_mut().frame().await {
            ensure!(self.live(), "S3 session authority ended");
            let frame = frame.map_err(|_| Failure::Offline)?;
            if let Some(data) = frame.data_ref() {
                ensure!(
                    body.len() + data.len() <= 16 * 1024 * 1024,
                    "peer response bound"
                );
                body.extend_from_slice(data);
            }
        }
        ensure!(
            headers.get("x-sigma-protocol").is_none_or(|v| v == "1"),
            "peer protocol changed"
        );
        if status == 401 || status == 403 {
            self.stop();
        }
        Ok(Reply {
            status,
            headers,
            body,
        })
    }
    pub async fn raw(
        &self,
        method: &str,
        path: &str,
        extra: &[(String, String)],
        bytes: Vec<u8>,
    ) -> Result<Reply> {
        let operation = async {
            if path.starts_with("/_sigma/") {
                let mut connection = self.connection().await?;
                self.exchange(&mut connection, method, path, extra, bytes)
                    .await
            } else {
                let mut slot = self.data.lock().await;
                if slot.as_ref().is_some_and(|c| c.sender.is_closed()) {
                    *slot = None;
                }
                if slot.is_none() {
                    *slot = Some(self.connection().await?);
                }
                let result = self
                    .exchange(slot.as_mut().unwrap(), method, path, extra, bytes)
                    .await;
                if result.as_ref().map_or(true, |r| {
                    r.headers
                        .get("connection")
                        .is_some_and(|h| h.as_bytes().eq_ignore_ascii_case(b"close"))
                }) {
                    *slot = None;
                }
                result
            }
        };
        tokio::pin!(operation);
        let mut tick = tokio::time::interval(Duration::from_millis(100));
        loop {
            tokio::select! {biased;_=tick.tick()=>{ensure!(self.live(),"S3 authority revoked or expired");},r=&mut operation=>{
                use crate::availability::Contact;
                let contact=match &r {
                    Ok(reply) if (200..300).contains(&reply.status)=>Some(Contact::Verified),
                    Ok(reply) if matches!(reply.status,401|403)=>Some(Contact::Denied),
                    Ok(reply) if matches!(reply.status,408|502|503|504)=>Some(Contact::Unreachable),
                    Err(e) if e.downcast_ref::<Failure>()==Some(&Failure::Offline)=>Some(Contact::Unreachable),
                    Err(e) if e.downcast_ref::<Failure>()==Some(&Failure::Denied)=>Some(Contact::Denied),
                    _=>None,
                };
                if let Some(state)=contact {self.availability.record(&self.share,&self.node,&self.pin,state);}
                return r
            }}
        }
    }
    pub async fn credentials(&self) -> Result<Value> {
        Ok(self
            .credentials
            .get_or_try_init(|| async {
                let r = self
                    .raw("GET", "/_sigma/s3/credentials", &[], vec![])
                    .await?;
                r.success()?;
                let c: Value = serde_json::from_slice(&r.body)?;
                ensure!(
                    c["bucket"]
                        .as_str()
                        .is_some_and(crate::share_fs::bucket_valid)
                        && c["accessKey"]
                            .as_str()
                            .is_some_and(|s| !s.is_empty() && s.len() <= 128)
                        && c["secretKey"]
                            .as_str()
                            .is_some_and(|s| s.len() >= 32 && s.len() <= 128),
                    "invalid peer S3 credential"
                );
                Ok::<_, anyhow::Error>(c)
            })
            .await?
            .clone())
    }
    pub async fn s3(
        &self,
        method: &str,
        key: &str,
        query: &[(&str, String)],
        extra: &[(String, String)],
        body: Vec<u8>,
    ) -> Result<Reply> {
        let creds = self.credentials().await?;
        let uri = format!(
            "/{}/{}",
            crate::safe::encoded(creds["bucket"].as_str().unwrap()),
            key.split('/')
                .map(crate::safe::encoded)
                .collect::<Vec<_>>()
                .join("/")
        );
        let mut query = query
            .iter()
            .map(|(k, v)| (crate::safe::encoded(k), crate::safe::encoded(v)))
            .collect::<Vec<_>>();
        query.sort();
        let qs = query
            .iter()
            .map(|(k, v)| format!("{k}={v}"))
            .collect::<Vec<_>>()
            .join("&");
        let timestamp = jiff::Timestamp::now()
            .strftime("%Y%m%dT%H%M%SZ")
            .to_string();
        let date = &timestamp[..8];
        let hash = hex::encode(Sha256::digest(&body));
        let mut headers = std::collections::BTreeMap::from([
            ("host".to_owned(), "localhost".to_owned()),
            ("x-amz-date".into(), timestamp.clone()),
            ("x-amz-content-sha256".into(), hash.clone()),
        ]);
        for (k, v) in extra {
            headers.insert(k.to_ascii_lowercase(), v.trim().into());
        }
        let signed = headers.keys().cloned().collect::<Vec<_>>().join(";");
        let canonical_headers = headers
            .iter()
            .map(|(k, v)| format!("{k}:{v}\n"))
            .collect::<String>();
        let canonical = format!("{method}\n{uri}\n{qs}\n{canonical_headers}\n{signed}\n{hash}");
        let scope = format!("{date}/us-east-1/s3/aws4_request");
        let string = format!(
            "AWS4-HMAC-SHA256\n{timestamp}\n{scope}\n{}",
            hex::encode(Sha256::digest(canonical.as_bytes()))
        );
        fn h(key: &[u8], v: &str) -> Vec<u8> {
            let mut h = Hmac::<Sha256>::new_from_slice(key).unwrap();
            h.update(v.as_bytes());
            h.finalize().into_bytes().to_vec()
        }
        let k = h(
            format!("AWS4{}", creds["secretKey"].as_str().unwrap()).as_bytes(),
            date,
        );
        let k = h(&h(&h(&k, "us-east-1"), "s3"), "aws4_request");
        let auth = format!(
            "AWS4-HMAC-SHA256 Credential={}/{scope}, SignedHeaders={signed}, Signature={}",
            creds["accessKey"].as_str().unwrap(),
            hex::encode(h(&k, &string))
        );
        let mut signed_headers = headers
            .into_iter()
            .filter(|(k, _)| k != "host")
            .collect::<Vec<_>>();
        signed_headers.push(("authorization".into(), auth));
        self.raw(
            method,
            &format!(
                "{uri}{}",
                if qs.is_empty() {
                    String::new()
                } else {
                    format!("?{qs}")
                }
            ),
            &signed_headers,
            body,
        )
        .await
    }
}
impl Drop for Session {
    fn drop(&mut self) {
        self.stop();
    }
}
pub struct Reply {
    pub status: u16,
    pub headers: http::HeaderMap,
    pub body: Vec<u8>,
}
impl Reply {
    pub fn success(&self) -> Result<()> {
        if matches!(self.status, 408 | 502 | 503 | 504) {
            return Err(Failure::Offline.into());
        }
        if self.status == 429 {
            return Err(Failure::Capacity.into());
        }
        ensure!(
            (200..300).contains(&self.status),
            "peer S3 HTTP {}",
            self.status
        );
        Ok(())
    }
}
pub async fn open(core: &Core, share: &str, pin: &str) -> Result<Handle> {
    let (identity, trust) = {
        let d = core.data.read().await;
        (
            d.share_identity.clone(),
            d.peer_approvals.get(&format!("receiver:{share}")).cloned(),
        )
    };
    let identity = identity.ok_or_else(|| anyhow::anyhow!("enrolled node required"))?;
    {
        let data = core.data.read().await;
        ensure!(
            data.member
                .as_ref()
                .is_some_and(|m| m["memberId"] == identity["bound_member"]
                    && m["expiresAt"].as_u64().unwrap_or(0) > crate::state::now())
                && data.online.as_ref().is_some_and(|p| p.enabled),
            "member or personal profile is not active"
        );
    }
    let trust =
        trust.ok_or_else(|| anyhow::anyhow!("confirm publisher certificate locally first"))?;
    ensure!(
        trust["active"] == true && trust["peer_pin"] == pin,
        "publisher approval revoked or pin mismatch"
    );
    if let Some(old) = core
        .peer_sessions
        .lock()
        .map_err(|_| anyhow::anyhow!("session lock failed"))?
        .get(share)
        .and_then(std::sync::Weak::upgrade)
    {
        ensure!(old.pin == pin, "peer session identity conflict");
        if old.live()
            && old
                .owners
                .fetch_update(Ordering::AcqRel, Ordering::Acquire, |n| {
                    if n > 0 && n < 4096 { Some(n + 1) } else { None }
                })
                .is_ok()
        {
            return Ok(Handle(old));
        }
    }
    let transport = Arc::new(RelayTransport::from_identity(&identity)?);
    let node = trust["peer_node"]
        .as_str()
        .ok_or_else(|| anyhow::anyhow!("publisher node missing"))?
        .to_owned();
    let (value, sent, clock) = transport
        .s3_clock_control("session", &json!({"share":share}))
        .await?;
    let proof = install(value, sent, clock, (&identity, share, pin, &node), None)?;
    let session = Arc::new(Session {
        availability: core.availability.clone(),
        owners: AtomicUsize::new(1),
        data: tokio::sync::Mutex::new(None),
        drivers: Mutex::new(Vec::new()),
        route: tokio::sync::OnceCell::new(),
        ending: tokio::sync::watch::channel(false).0,
        transport,
        share: share.into(),
        raw_token: proof.value["token"].as_str().unwrap_or("").to_owned(),
        pin: pin.into(),
        node,
        identity,
        proof: Mutex::new(proof),
        stopped: AtomicBool::new(false),
        refresh: tokio::sync::Mutex::new(()),
        credentials: tokio::sync::OnceCell::new(),
    });
    core.peer_sessions
        .lock()
        .map_err(|_| anyhow::anyhow!("session lock failed"))?
        .insert(share.into(), Arc::downgrade(&session));
    let weak = Arc::downgrade(&session);
    tokio::spawn(async move {
        loop {
            tokio::time::sleep(Duration::from_secs(10)).await;
            let Some(s) = weak.upgrade() else { break };
            if !s.live() {
                break;
            }
            let _ = s.renew().await;
        }
    });
    Ok(Handle(session))
}
