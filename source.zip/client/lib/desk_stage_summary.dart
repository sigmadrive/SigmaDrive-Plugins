import 'package:flutter/material.dart';

import 'api/api.dart';
import 'desk_readiness_summary.dart';

const _stageNames = [
  'engine_stage_desktop',
  'engine_stage_root',
  'engine_stage_verify',
  'engine_stage_profile_dirs',
  'engine_stage_profile_owner',
  'engine_stage_profile_main',
  'engine_stage_profile_options',
  'engine_stage_profile_peer',
];
const _milestones = {
  'engine_start',
  'engine_start_result',
  'engine_assets_verified',
  'engine_proxy_bound',
  'engine_profile_ready',
  'engine_spawned',
};

class DeskStageDuration {
  final String event, code;
  final int elapsedMs;
  const DeskStageDuration(this.event, this.code, this.elapsedMs);
}

List<DeskStageDuration> recentDeskStages(
  List<Json> diagnostics, {
  List<Json> sessions = const [],
}) {
  final rows = diagnostics.length > 64
      ? diagnostics.sublist(diagnostics.length - 64)
      : diagnostics;
  bool scoped(Json row) =>
      (row['role'] == 'host' || row['role'] == 'viewer') &&
      RegExp(r'^[a-f0-9]{32}$').hasMatch(text(row, 'session'));
  // Session/role are used only for grouping. Returned rows cannot carry them.
  var anchor = -1;
  if (sessions.isNotEmpty) {
    final active = sessions.where((row) {
      final scope = row['session'];
      return (row['role'] == 'host' || row['role'] == 'viewer') &&
          const {'active', 'starting', 'reconnecting'}.contains(row['phase']) &&
          scope is Map &&
          scope['session_id'] is String &&
          RegExp(r'^[a-f0-9]{32}$').hasMatch(scope['session_id'] as String);
    }).toList();
    if (active.length != 1) return const [];
    final id = (active.single['session'] as Map)['session_id'];
    final role = active.single['role'];
    anchor = rows.lastIndexWhere(
      (row) =>
          row['session'] == id &&
          row['role'] == role &&
          (_stageNames.contains(row['event']) ||
              _milestones.contains(row['event'])),
    );
  } else {
    // A late older worker stage cannot replace the newest start's identity.
    anchor = rows.lastIndexWhere(
      (row) =>
          scoped(row) &&
          row['event'] == 'engine_start' &&
          row['code'] == 'begin',
    );
    // A bounded ring can evict its start marker. Without an active runtime, keep
    // the existing historical-stage fallback, never combining different groups.
    if (anchor < 0) {
      anchor = rows.lastIndexWhere(
        (row) =>
            scoped(row) &&
            (_stageNames.contains(row['event']) ||
                _milestones.contains(row['event'])),
      );
    }
  }
  if (anchor < 0) return const [];
  final identity = rows[anchor];
  bool same(Json r) =>
      r['session'] == identity['session'] && r['role'] == identity['role'];
  final start = rows.lastIndexWhere(
    (r) => same(r) && r['event'] == 'engine_start' && r['code'] == 'begin',
  );
  final completed = <String, DeskStageDuration>{};
  for (final row in rows.skip(start < 0 ? 0 : start)) {
    final event = text(row, 'event'), code = text(row, 'code');
    final elapsed = row['elapsed_ms'];
    if (same(row) &&
        _stageNames.contains(event) &&
        (code == 'ok' || code == 'failed') &&
        elapsed is int &&
        elapsed >= 0) {
      completed[event] = DeskStageDuration(event, code, elapsed);
    }
  }
  return [
    for (final name in _stageNames)
      if (completed[name] != null) completed[name]!,
  ];
}

class DeskStageSummary extends StatelessWidget {
  final List<Json> diagnostics;
  final List<Json> sessions;
  const DeskStageSummary({
    super.key,
    required this.diagnostics,
    this.sessions = const [],
  });
  @override
  Widget build(BuildContext context) {
    final stages = recentDeskStages(diagnostics, sessions: sessions);
    return Card(
      child: ExpansionTile(
        title: const Text('최근 엔진 시작 단계별 시간'),
        subtitle: const Text('완료된 단계 · 이 PC에만 보관'),
        children: [
          if (stages.isEmpty) const ListTile(title: Text('완료된 단계 기록이 없습니다.')),
          for (final s in stages)
            ListTile(
              dense: true,
              title: Text('${s.event} · ${s.code} · ${s.elapsedMs} ms'),
            ),
          DeskReadinessSummary(diagnostics: diagnostics, sessions: sessions),
        ],
      ),
    );
  }
}
