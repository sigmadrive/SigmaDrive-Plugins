import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';

import 'api/api.dart';
import 'forms.dart';
import 'oauth_flow.dart';
import 'drive_browser.dart';
import 'profile_setup.dart';
import 's3_browser.dart';
import 'transfers.dart';
import 'share_permissions.dart';
import 'share_connectivity.dart';
import 'desk_access.dart';
import 'update_progress.dart';
import 'desk_stage_summary.dart';
import 'desk_end_summary.dart';
import 'desk_local_diagnostics.dart';

enum Area {
  overview,
  connections,
  drives,
  shares,
  transfers,
  desk,
  plugins,
  updates,
  account,
  settings,
}

class SigmaShell extends StatefulWidget {
  final CoreTransport api;
  const SigmaShell({super.key, required this.api});
  @override
  State<SigmaShell> createState() => _SigmaShellState();
}

class _SigmaShellState extends State<SigmaShell> with WidgetsBindingObserver {
  Area area = Area.overview;
  Json data = {};
  Json portal = {};
  String? error;
  bool loading = false, busy = false, foreground = true, oauthActive = false;
  int generation = 0;
  Timer? timer;
  DateTime? refreshed;
  CoreTransport get api => widget.api;
  static const titles = [
    '개요',
    '클라우드 연결',
    '내 디스크',
    '폴더 공유',
    '전송',
    'SigmaDesk',
    '플러그인',
    '업데이트',
    '회원·프로필',
    '설정',
  ];
  static const icons = [
    Icons.dashboard_outlined,
    Icons.cloud_outlined,
    Icons.storage_outlined,
    Icons.folder_shared_outlined,
    Icons.swap_horiz,
    Icons.desktop_windows_outlined,
    Icons.extension_outlined,
    Icons.system_update_outlined,
    Icons.person_outline,
    Icons.settings_outlined,
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(load());
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await api.call('AcknowledgeStartup');
      } catch (_) {
        /* Launcher retains the previous version if readiness is not confirmed. */
      }
    });
    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (area != Area.transfers &&
          area != Area.updates &&
          refreshed != null &&
          DateTime.now().difference(refreshed!) < const Duration(seconds: 30)) {
        return;
      }
      if (foreground && !loading && !busy && !oauthActive) unawaited(load());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    foreground = state == AppLifecycleState.resumed;
    if (foreground && !loading && !busy && !oauthActive) unawaited(load());
  }

  @override
  void dispose() {
    timer?.cancel();
    ++generation;
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> load() async {
    final token = ++generation;
    final selected = area;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final output = <String, dynamic>{};
      Future<void> read(String key, String rpc, [Json body = const {}]) async {
        output[key] = await api.call(rpc, body);
      }

      switch (selected) {
        case Area.overview:
          await Future.wait([
            read('status', 'GetStatus'),
            read('settings', 'GetSettings'),
            read('drives', 'ListDrives'),
            read('connections', 'ListConnections'),
          ]);
        case Area.connections:
          await Future.wait([
            read('connections', 'ListConnections'),
            read('providers', 'ListProviders'),
            read('registrations', 'GetCloudRegistrations'),
          ]);
        case Area.drives:
          await Future.wait([
            read('drives', 'ListDrives'),
            read('connections', 'ListConnections'),
            read('letters', 'ListDriveLetters'),
          ]);
        case Area.shares:
          await read('shares', 'ManageTeamShare', {'action': 'status'});
        case Area.transfers:
          await Future.wait([
            read('transfers', 'ManageTransfers', {'action': 'status'}),
            read('s3', 'ManageS3Browser', {'action': 'status'}),
          ]);
        case Area.desk:
          await read('shares', 'ManageTeamShare', {'action': 'desk-status'});
        case Area.plugins:
          await read('shares', 'ManageTeamShare', {
            'action': 'component-status',
          });
        case Area.updates:
          await read('downloads', 'ManageDownloads', {'action': 'status'});
        case Area.account:
          await Future.wait([
            read('member', 'ManageProfile', {'action': 'member_status'}),
            read('profiles', 'ManageProfile', {'action': 'status'}),
            read('cloud_profile', 'ManageProfile', {'action': 'cloud_status'}),
            read('connections', 'ListConnections'),
          ]);
        case Area.settings:
          await read('settings', 'GetSettings');
          await read('driver', 'GetDriverStatus');
          try {
            await read('startup', 'GetLoginStartup');
          } catch (_) {
            output['startup'] = {'supported': false};
          }
      }
      if (!mounted || token != generation) return;
      setState(() {
        data = output;
        refreshed = DateTime.now();
      });
    } catch (e) {
      if (mounted && token == generation) {
        setState(() {
          error = cleanError(e);
        });
      }
    } finally {
      if (mounted && token == generation) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  void select(Area next) {
    if (busy || area == next) return;
    setState(() {
      area = next;
      data = {};
      refreshed = null;
    });
    unawaited(load());
  }

  Future<Json?> act(String rpc, Json body, {String? confirmation}) async {
    if (busy) return null;
    if (confirmation != null && !await confirm(context, confirmation)) {
      return null;
    }
    if (!mounted) return null;
    ++generation;
    setState(() {
      busy = true;
      error = null;
      loading = false;
    });
    try {
      final result = await api.call(rpc, body);
      if (mounted) await load();
      return result;
    } catch (e) {
      if (mounted) {
        setState(() {
          error = cleanError(e);
        });
      }
      return null;
    } finally {
      if (mounted) {
        setState(() {
          busy = false;
        });
      }
    }
  }

  Json value(String key) => Map<String, dynamic>.from(data[key] as Map? ?? {});
  Widget tile(
    String title,
    String description, {
    List<Widget> actions = const [],
    IconData? icon,
  }) => Card(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SelectableText(description),
          if (actions.isNotEmpty) ...[
            const SizedBox(height: 14),
            Wrap(spacing: 10, runSpacing: 8, children: actions),
          ],
        ],
      ),
    ),
  );
  Widget button(String label, VoidCallback action, {bool enabled = true}) =>
      OutlinedButton(
        onPressed: !busy && !loading && enabled ? action : null,
        child: Text(label),
      );
  Widget empty(String message) => tile('아직 항목이 없습니다', message);

  Widget navigation() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(22, 28, 20, 8),
        child: Text(
          'SigmaDrive',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
        ),
      ),
      const Padding(
        padding: EdgeInsets.fromLTRB(22, 0, 20, 20),
        child: Text('Flutter Preview · 별도 개발 프로필'),
      ),
      Expanded(
        child: ListView(
          children: [
            nav(Area.overview),
            group('파일과 공유', [
              Area.connections,
              Area.drives,
              Area.shares,
              Area.transfers,
            ]),
            group('원격 작업', [Area.desk]),
            group('앱 관리', [
              Area.plugins,
              Area.updates,
              Area.account,
              Area.settings,
            ]),
          ],
        ),
      ),
    ],
  );
  Widget group(String title, List<Area> items) => ExpansionTile(
    title: Text(title),
    initiallyExpanded: true,
    children: items.map(nav).toList(),
  );
  Widget nav(Area item) => Builder(
    builder: (navigationContext) => ListTile(
      selected: area == item,
      leading: Icon(icons[item.index]),
      title: Text(titles[item.index]),
      onTap: busy
          ? null
          : () {
              select(item);
              if (Scaffold.maybeOf(navigationContext)?.isDrawerOpen ?? false) {
                Navigator.of(navigationContext).pop();
              }
            },
    ),
  );

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final wide = constraints.maxWidth >= 900;
      return Scaffold(
        appBar: wide ? null : AppBar(title: Text(titles[area.index])),
        drawer: wide ? null : Drawer(child: navigation()),
        body: Row(
          children: [
            if (wide)
              SizedBox(
                width: 260,
                child: Material(color: Colors.white, child: navigation()),
              ),
            Expanded(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(28, 24, 28, 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                titles[area.index],
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium,
                              ),
                              const SizedBox(height: 5),
                              Text(
                                refreshed == null
                                    ? '연결 상태를 확인합니다.'
                                    : '마지막 확인 ${refreshed!.hour.toString().padLeft(2, '0')}:${refreshed!.minute.toString().padLeft(2, '0')}',
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          tooltip: '새로고침',
                          onPressed: loading || busy ? null : load,
                          icon: const Icon(Icons.refresh),
                        ),
                      ],
                    ),
                  ),
                  if (loading || busy)
                    const LinearProgressIndicator(minHeight: 2),
                  if (error != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 28,
                        vertical: 8,
                      ),
                      child: MaterialBanner(
                        content: SelectableText(error!),
                        leading: const Icon(Icons.error_outline),
                        actions: [
                          TextButton(
                            onPressed: busy ? null : load,
                            child: const Text('다시 확인'),
                          ),
                        ],
                      ),
                    ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(28, 12, 28, 28),
                      children: content(),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    },
  );

  List<Widget> content() => switch (area) {
    Area.overview => overview(),
    Area.connections => connections(),
    Area.drives => drives(),
    Area.shares => shares(),
    Area.transfers => transfers(),
    Area.desk => desk(),
    Area.plugins => plugins(),
    Area.updates => updates(),
    Area.account => account(),
    Area.settings => settings(),
  };

  List<Widget> overview() {
    final status = value('status'), settings = value('settings');
    if (status.isEmpty) return [empty('전용 개발 코어를 시작하면 실제 상태가 표시됩니다.')];
    return [
      tile(
        text(settings, 'device_name', '이 컴퓨터'),
        '코어 ${text(status, 'version')} · ${text(status, 'profile_name', '로컬 프로필')}',
        icon: Icons.computer,
      ),
      tile(
        '내 디스크',
        '저장 ${rows(value('drives'), 'drives').length}개 · 연결 ${status['mounted_drives'] ?? 0}개',
        actions: [button('디스크 열기', () => select(Area.drives))],
      ),
      tile(
        '클라우드 연결',
        '${rows(value('connections'), 'connections').length}개의 저장소 연결',
        actions: [button('클라우드 연결하기', () => select(Area.connections))],
      ),
      tile(
        '공유와 원격 작업',
        '파일 공유와 원격 접속 권한을 각각 관리합니다.',
        actions: [
          button('폴더 공유', () => select(Area.shares)),
          button('SigmaDesk', () => select(Area.desk)),
        ],
      ),
    ];
  }

  List<Widget> connections() {
    final list = rows(value('connections'), 'connections');
    return [
      tile(
        '내 클라우드와 저장소',
        '연결만으로는 다른 사용자에게 공개되지 않습니다. 공유 메뉴에서 공개할 폴더와 권한을 직접 지정하세요.',
        actions: [
          button(
            'Google Drive 연결',
            () => addConnection(initialProvider: 'drive'),
          ),
          button(
            'OneDrive 연결',
            () => addConnection(initialProvider: 'onedrive'),
          ),
          button('다른 저장소 연결', addConnection),
        ],
      ),
      if (list.isEmpty) empty('Google Drive·OneDrive·S3 또는 다른 저장소를 연결하세요.'),
      for (final item in list)
        tile(
          text(item, 'name'),
          '${text(item, 'provider')} · ${isFileConnection(item) ? '파일 디스크용' : '회원 프로필 보관용'}${item['needs_auth'] == true ? ' · 로그인 필요' : ''}',
          actions: [
            if (item['provider'] == 'drive' || item['provider'] == 'onedrive')
              button(
                '다시 로그인',
                () => item['preset'] == 'profile'
                    ? memberSignIn(
                        item['provider'] == 'drive' ? 'google' : 'microsoft',
                      )
                    : startSignIn(
                        item['preset'] == 'profile'
                            ? (item['provider'] == 'drive'
                                  ? 'profile-google'
                                  : 'profile-onedrive')
                            : text(item, 'provider'),
                        {},
                        text(item, 'name'),
                        connectionId: text(item, 'id'),
                      ),
              ),
            button('연결 검사', () async {
              final result = await act('TestConnection', {
                'id': item['id'],
                'remote_path': '',
              });
              if (result != null && mounted) {
                await showConnectionTest(context, result);
              }
            }),
            button(
              '연결 제거',
              () => act(
                'RemoveConnection',
                {'id': item['id']},
                confirmation:
                    '이 저장소 연결을 제거할까요? 연결된 디스크가 있으면 코어가 제거를 거부할 수 있습니다.',
              ),
            ),
          ],
        ),
    ];
  }

  Future<void> addConnection({String? initialProvider}) async {
    final providers = rows(
      value('providers'),
      'providers',
    ).where((p) => !text(p, 'id').startsWith('profile-')).toList();
    final selection = await showDialog<Json>(
      context: context,
      builder: (_) => ConnectionForm(
        providers: providers,
        initialProvider: initialProvider,
        registrations: rows(value('registrations'), 'registrations')
            .where((r) => r['configured'] == true)
            .map((r) => text(r, 'catalog_id'))
            .toSet(),
        connections: rows(value('connections'), 'connections'),
      ),
    );
    if (selection == null || !mounted) return;
    if (selection.remove('_oauth') == true) {
      await startSignIn(
        text(selection, 'catalog_id'),
        Map<String, dynamic>.from(selection['values'] as Map),
        text(selection, 'name'),
      );
    } else {
      final name = selection.remove('name');
      await act('AddConnection', {
        ...selection,
        'connection': {'name': name},
      });
    }
  }

  Future<void> startSignIn(
    String catalog,
    Json values,
    String name, {
    String? connectionId,
    bool memberProfile = false,
  }) async {
    if (oauthActive) return;
    final flow = await act('StartSignIn', {
      'catalog_id': catalog,
      'values': values,
      'connection': {'name': name, 'id': ?connectionId},
    });
    if (flow == null || !mounted) return;
    setState(() => oauthActive = true);
    Json? completed;
    try {
      completed = await showDialog<Json>(
        context: context,
        barrierDismissible: false,
        builder: (_) =>
            OAuthFlowDialog(api: api, flow: flow, memberProfile: memberProfile),
      );
    } finally {
      if (mounted) setState(() => oauthActive = false);
    }
    if (!mounted) return;
    if (completed?['create_drive'] == true) {
      setState(() {
        area = Area.drives;
        data = {};
      });
      await load();
      if (mounted) {
        await addDrive(
          initialConnectionId: completed!['connection']['id'] as String,
        );
      }
    } else {
      await load();
    }
  }

  List<Widget> drives() {
    final list = rows(value('drives'), 'drives');
    return [
      tile(
        '단일·통합 디스크',
        '클라우드 연결을 선택해 디스크를 만듭니다. 통합 디스크에서는 저장소마다 다른 최상위 폴더를 지정합니다.',
        actions: [button('디스크 만들기', addDrive)],
      ),
      if (list.isEmpty) empty('클라우드 연결 후 디스크를 추가하세요.'),
      for (final item in list)
        tile(
          '${text(item, 'name')} · ${text(item, 'target')}',
          '${item['mode'] == 2 ? '통합 디스크' : '단일 디스크'} · ${item['mounted'] == true ? '연결됨' : '연결 안 됨'} · 미완료 업로드 ${item['pending_uploads'] ?? 0}개\n'
              '${rows(item, 'members').map((m) => '${text(m, 'folder')} ${text(m, 'remote_path')}').join(' / ')}',
          actions: [
            button(
              '파일 열기',
              () => showDialog<void>(
                context: context,
                builder: (_) => DriveBrowser(api: api, drive: item),
              ),
              enabled: item['mounted'] == true,
            ),
            button(
              item['mounted'] == true ? '안전하게 연결 해제' : '디스크 연결',
              () => act(
                item['mounted'] == true ? 'UnmountDrive' : 'MountDrive',
                {'id': item['id']},
              ),
            ),
            button(
              '삭제',
              () => act('DeleteDrive', {
                'id': item['id'],
              }, confirmation: '디스크 구성을 삭제할까요? 원격 저장소 파일은 삭제하지 않습니다.'),
              enabled: item['mounted'] != true,
            ),
          ],
        ),
    ];
  }

  Future<void> addDrive({String? initialConnectionId}) async {
    final draft = await showDialog<Json>(
      context: context,
      builder: (_) => DriveForm(
        initialConnectionId: initialConnectionId,
        connections: rows(value('connections'), 'connections'),
        letters: (value('letters')['free'] as List? ?? []).cast<String>(),
      ),
    );
    if (draft != null) await act('SaveDrive', draft);
  }

  List<Widget> shares() {
    final state = value('shares'),
        names = Map<String, dynamic>.from(state['device_names'] as Map? ?? {});
    final published = rows(state, 'published'),
        available = rows(state, 'available');
    return [
      tile(
        '폴더와 프로토콜',
        '프로토콜 설치와 공유 폴더 지정을 분리합니다. 여러 폴더·버킷을 만들 수 있습니다.\n상태: ${text(state, 'readiness', text(state, 'state', '확인 필요'))}',
        actions: [
          button('공유 추가', addShare, enabled: state['registered'] == true),
          button('플러그인 관리', () => select(Area.plugins)),
          button('회원·개인 프로필 준비', () => select(Area.account)),
          if (state['registered'] == true)
            button('다른 회원의 공유 초대 수락', () async {
              final token = await askText(
                context,
                '공유 초대 수락',
                '공유 제공자가 별도로 전달한 일회용 초대 코드를 입력하세요. 수락 후 회원 권한과 장치 승인이 각각 필요합니다.',
              );
              if (token != null && token.trim().isNotEmpty) {
                await act('ManageTeamShare', {
                  'action': 'accept-member-invite',
                  'share_invite': token.trim(),
                });
              }
            }),
          if (state['registered'] != true)
            button(
              '공유 장치 등록',
              () => act('ManageTeamShare', {'action': 'prepare-member'}),
            ),
        ],
      ),
      if (text(state, 'local_pin').isNotEmpty)
        tile('이 장치의 인증서 지문', text(state, 'local_pin')),
      for (final item in published)
        tile(
          '${text(item, 'name')} · ${text(state, 'device_name', '이 컴퓨터')}',
          '${text(item, 'folder')}\n${text(item, 'protocol')} · ${text(item, 's3_bucket')} · ${text(item, 'state')}\n읽기 ${((item['grants'] as List?) ?? []).length}개 회원 · 쓰기 ${((item['write_grants'] as List?) ?? []).length}개 회원',
          actions: [
            button(
              '다른 회원 초대',
              () async {
                final reply = await act('ManageTeamShare', {
                  'action': 'invite-member',
                  'id': item['id'],
                });
                if (reply != null &&
                    mounted &&
                    text(reply, 'member_invite').isNotEmpty) {
                  await showDialog<void>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('일회용 공유 초대'),
                      content: SizedBox(
                        width: 560,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text(
                              '접속을 허용할 회원에게만 별도로 전달하세요. 수락해도 장치 확인·승인이 끝나야 파일에 접근할 수 있습니다.',
                            ),
                            const SizedBox(height: 12),
                            SelectableText(text(reply, 'member_invite')),
                          ],
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('닫기'),
                        ),
                      ],
                    ),
                  );
                }
              },
              enabled:
                  item['enabled'] == true &&
                  (item['protocol'] != 's3' || item['s3_relay'] == true),
            ),
            button('회원 읽기·쓰기 권한', () async {
              final draft = await showDialog<Json>(
                context: context,
                builder: (_) => SharePermissions(share: item, state: state),
              );
              if (draft != null) await act('ManageTeamShare', draft);
            }, enabled: item['enabled'] == true),
            button(
              item['enabled'] == true ? '공유 중지' : '공유 시작',
              () => act('ManageTeamShare', {
                'action': item['enabled'] == true ? 'stop' : 'start',
                'id': item['id'],
              }),
            ),
          ],
        ),
      tile('받을 수 있는 공유', '공유명과 제공 장치를 함께 표시합니다. 표시 이름은 권한 식별자로 사용하지 않습니다.'),
      for (final item in available)
        tile(
          shareLabel(item, names),
          '${text(item, 'protocol')} · ${shareConnectivityLabel(item)}\n공유 ID ${text(item, 'id')}\n제공 장치 ${text(item, 'publisher')}',
          actions: [
            button(
              '이 장치의 접속 요청',
              () => act('ManageTeamShare', {
                'action': 'request-access',
                'id': item['id'],
              }),
            ),
            button(
              'S3 파일 조회',
              () => browseS3(item),
              enabled: item['protocol'] == 's3',
            ),
          ],
        ),
      if (published.isEmpty && available.isEmpty)
        empty('회원 로그인·개인 프로필·장치 등록이 완료되면 공유를 관리할 수 있습니다.'),
      ...accessRequests(state, names),
    ];
  }

  Future<void> addShare() async {
    final state = value('shares');
    final request = await showDialog<Json>(
      context: context,
      builder: (_) => ShareForm(
        protocols: (state['supported_protocols'] as List? ?? ['sigma-api'])
            .cast<String>(),
        owner: text(state, 'owner_member'),
      ),
    );
    if (request != null) await act('ManageTeamShare', request);
  }

  Future<void> browseS3(Json share) async {
    final identity = await receiverIdentity(
      api,
      share,
      () => showDialog<String>(
        context: context,
        builder: (_) => VerifyDevice(
          device: text(share, 'publisher_name', text(share, 'publisher')),
          receiving: true,
        ),
      ),
    );
    if (identity == null) return;
    final pin = identity.pin;
    if (!mounted) return;
    Json display = share;
    try {
      final resolved = await api.call('ManageTeamShare', {
        'action': 'resolve-name',
        'id': share['id'],
        'peer_pin': pin.trim().toLowerCase(),
        'peer_verified': identity.confirmed,
      });
      display =
          rows(resolved, 'available')
              .where(
                (s) =>
                    s['id'] == share['id'] &&
                    s['publisher'] == share['publisher'],
              )
              .firstOrNull ??
          share;
    } catch (_) {
      /* Optional, encrypted peer display metadata cannot block file access. */
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (_) => S3Browser(
        api: api,
        share: display,
        pin: pin.trim().toLowerCase(),
        device: text(display, 'publisher_name', text(display, 'publisher')),
      ),
    );
    if (mounted) await load();
  }

  List<Widget> accessRequests(Json state, Json names) => [
    tile('장치별 접속 승인', '회원 권한과 별도로 각 요청 PC의 인증서 지문을 확인합니다.'),
    for (final r in rows(state, 'access_requests'))
      tile(
        '${names[r['subscriber']] ?? r['subscriber']} → ${text(r, 'share')}',
        text(r, 'status'),
        actions: [
          if (r['publisher'] == state['node'] && r['status'] == 'pending') ...[
            button('장치 확인·승인', () async {
              final pin = await showDialog<String>(
                context: context,
                builder: (_) => VerifyDevice(
                  device:
                      names[r['subscriber']]?.toString() ??
                      text(r, 'subscriber'),
                ),
              );
              if (pin != null) {
                await act('ManageTeamShare', {
                  'action': 'approve-access',
                  'access_request_id': r['id'],
                  'peer_pin': pin,
                  'peer_node': r['subscriber'],
                  'peer_verified': true,
                  'write_approved': true,
                });
              }
            }),
            button(
              '거부',
              () => act('ManageTeamShare', {
                'action': 'reject-access',
                'access_request_id': r['id'],
              }),
            ),
          ],
          if (r['publisher'] == state['node'] &&
              ['approved', 'local_revoked'].contains(r['status']))
            button(
              '이 장치의 권한 철회',
              () => act('ManageTeamShare', {
                'action': 'revoke-access',
                'access_request_id': r['id'],
              }, confirmation: '이 시험 대상 장치의 해당 공유 접속을 철회할까요? 다른 공유는 유지합니다.'),
            ),
          if (r['subscriber'] == state['node'] && r['status'] == 'pending')
            button(
              '요청 취소',
              () => act('ManageTeamShare', {
                'action': 'cancel-access',
                'access_request_id': r['id'],
              }),
            ),
        ],
      ),
    for (final r in rows(state, 's3_recipients'))
      tile(
        '${names[r['device']] ?? text(r, 'device', text(r, 'member'))} · ${text(r, 'share')}',
        switch (text(r, 'access_state')) {
          'read_write' => '읽기·쓰기',
          'read' => '읽기 전용',
          'revoked' => '철회됨',
          _ => '장치 확인 필요',
        },
      ),
  ];

  List<Widget> transfers() {
    return [
      tile('전송 상태', '상세 전송 정보는 이 PC의 코어에서 조회합니다. 회원·권한 확인과 파일 전송은 별도로 처리합니다.'),
      if (rows(value('transfers'), 'jobs').isEmpty &&
          rows(value('s3'), 'downloads').isEmpty)
        empty('진행 중이거나 보관된 전송이 없습니다.'),
      for (final job in rows(value('s3'), 'downloads').reversed)
        TransferCard(
          job: job,
          rpc: 'ManageS3Browser',
          busy: busy,
          onAction: (rpc, body) async {
            await act(rpc, body);
          },
        ),
      for (final job in rows(value('transfers'), 'jobs').reversed)
        TransferCard(
          job: job,
          rpc: 'ManageTransfers',
          busy: busy,
          onAction: (rpc, body) async {
            await act(rpc, body);
          },
        ),
    ];
  }

  List<Widget> desk() {
    final share = value('shares');
    Json state = {};
    try {
      state = Map<String, dynamic>.from(
        jsonDecode(text(share, 'desk_json', '{}')) as Map,
      );
    } catch (_) {
      /* Explicit empty state below. */
    }
    final names = Map<String, dynamic>.from(
      share['device_names'] as Map? ?? {},
    );
    final devices = rows(
      state,
      'devices',
    ).where((d) => d['node'] != state['node']).toList();
    return [
      tile(
        '내 컴퓨터',
        '등록 장치의 접속 권한과 온라인 상태를 확인합니다. 화면 보기와 입력 제어는 별도 권한입니다.',
        actions: [button('플러그인 설치·상태', () => select(Area.plugins))],
      ),
      tile(
        '접속 허용',
        '이 Windows 사용자로 로그인된 화면만 대상으로 합니다. 파일 공유 권한과는 별개이며 기본값은 허용 안 함입니다.',
      ),
      DeskLocalDiagnosticsCard(
        status:Map<String,dynamic>.from(state['local_diagnostics'] as Map? ?? {}),
        busy:busy||loading,
        sessionActive:['active','starting','stopping'].contains((state['runtime'] as Map?)?['phase']),
        onAction:(body) async {await act('ManageTeamShare',body);},
      ),
      CheckboxListTile(
        value: state['enabled'] == true,
        title: const Text('원격 접속 요청 허용'),
        onChanged: busy
            ? null
            : (v) => act('ManageTeamShare', {
                'action': v == true ? 'desk-enable' : 'desk-disable',
              }),
      ),
      CheckboxListTile(
        value: state['allow_owned'] == true,
        title: const Text('같은 계정의 장치·개인 웹페이지에서 바로 접속 허용'),
        subtitle: const Text(
          '브라우저 접속은 아래의 브라우저 허용도 켜야 합니다. 다른 계정은 접속 요청과 승인이 필요합니다.',
        ),
        onChanged: busy
            ? null
            : (v) => act('ManageTeamShare', {
                'action': v == true ? 'desk-own-enable' : 'desk-own-disable',
              }),
      ),
      CheckboxListTile(
        value: state['browser_enabled'] == true,
        title: const Text('개인 웹페이지에서 브라우저 접속 허용'),
        subtitle: Text(
          state['allow_owned'] == true
              ? '같은 계정으로 웹 로그인하면 매번 승인 없이 브라우저 안에서 접속합니다. 접속하는 PC에 앱을 설치할 필요가 없습니다.'
              : '같은 계정도 접속할 때마다 승인이 필요합니다. 위의 바로 접속 허용을 켜면 반복 승인을 생략합니다.',
        ),
        onChanged: busy
            ? null
            : (v) => act('ManageTeamShare', {
                'action': v == true
                    ? 'desk-browser-enable'
                    : 'desk-browser-disable',
              }),
      ),
      if (text(state, 'error').isNotEmpty)
        tile('SigmaDesk 연결 상태', text(state, 'error')),
      if (text(state, 'message').isNotEmpty) tile('안내', text(state, 'message')),
      if (rows(state, 'diagnostics').isNotEmpty)
        DeskEndSummary(
          diagnostics: rows(state, 'diagnostics'),
          sessions: rows(state, 'sessions'),
        ),
      if (rows(state, 'diagnostics').isNotEmpty)
        DeskStageSummary(
          diagnostics: rows(state, 'diagnostics'),
          sessions: rows(state, 'sessions'),
        ),
      if ((state['runtime'] as Map?)?['resources_released'] == true)
        tile('원격 작업 종료됨', '실행 프로세스 0 · 전송 자원 해제됨'),
      if (rows(state, 'sessions').isNotEmpty)
        tile(
          '원격 연결 ${rows(state, 'sessions').where((s) => ['active', 'starting'].contains(s['phase'])).length}개',
          '각 연결의 승인과 종료는 독립적으로 처리됩니다. 다른 Windows 사용자의 개인 연결과 구성은 표시하지 않습니다.',
        ),
      for (final runtime in rows(state, 'sessions'))
        tile(
          '연결 ${text(Map<String, dynamic>.from(runtime['session'] as Map? ?? {}), 'session_id')}',
          '${text(runtime, 'phase')} · ${runtime['processes'] ?? 0}개 실행 프로세스 · ${runtime['connections'] ?? 0}개 전송 연결',
        ),
      if (devices.isEmpty)
        empty('같은 계정의 다른 등록 장치가 없습니다. 회원·프로필을 연결하고 SigmaDesk를 설치하세요.'),
      for (final d in devices)
        tile(
          names[d['node']]?.toString() ?? text(d, 'name', text(d, 'node')),
          '${deskOwnsDevice(state, d) ? '내 계정의 장치' : '다른 사용자의 장치'} · ${d['online'] == true ? '온라인' : '상태 확인 필요'} · ${deskDirectAccess(state, d) ? '바로 접속 허용' : '접속 승인 필요'}',
          actions: [
            for (final scope in ['view', 'control'])
              button(
                deskDirectAccess(state, d)
                    ? (scope == 'view' ? '화면 바로 보기' : '바로 원격 제어')
                    : (scope == 'view' ? '화면 보기 요청' : '입력 제어 요청'),
                () => act('ManageTeamShare', {
                  'action': deskDirectAccess(state, d)
                      ? 'desk-connect'
                      : 'desk-request',
                  'id': d['node'],
                  'name': scope,
                }),
                enabled: d['enabled'] == true && d['online'] == true,
              ),
          ],
        ),
      tile(
        '다른 사용자의 장치',
        '상대가 알려준 장치 ID로 접속을 요청합니다. 상대의 승인이 있어야 시작하며 다른 회원의 장치를 임의로 검색하지 않습니다.',
        actions: [
          button('장치 ID로 접속 요청', () async {
            final id = TextEditingController();
            final target = await showDialog<String>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('접속할 장치 ID'),
                content: TextField(
                  controller: id,
                  decoration: const InputDecoration(
                    labelText: 'pc-로 시작하는 장치 ID',
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('취소'),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.pop(ctx, id.text.trim()),
                    child: const Text('화면 보기 요청'),
                  ),
                ],
              ),
            );
            id.dispose();
            if (target != null &&
                RegExp(r'^pc-[a-f0-9]{32}$').hasMatch(target)) {
              await act('ManageTeamShare', {
                'action': 'desk-request',
                'id': target,
                'name': 'view',
              });
            }
          }),
        ],
      ),
      for (final r in rows(state, 'requests'))
        tile(
          '${names[r['peer']] ?? text(r, 'peer_name', text(r, 'peer'))} → ${names[r['host']] ?? text(r, 'host_name', text(r, 'host'))}',
          '${r['scope'] == 'control' ? '화면 보기 + 입력 제어' : '화면 보기 전용'} · ${text(r, 'status')}',
          actions: [
            if (r['status'] == 'pending' && r['host'] == state['node']) ...[
              button(
                '이 권한으로 접속 승인',
                () => act('ManageTeamShare', {
                  'action': 'desk-approve',
                  'id': r['id'],
                }),
              ),
              button(
                '거부',
                () => act('ManageTeamShare', {
                  'action': 'desk-reject',
                  'id': r['id'],
                }),
              ),
            ],
            if (['approved', 'active'].contains(r['status']))
              button(
                '권한 철회·연결 종료',
                () => act('ManageTeamShare', {
                  'action': 'desk-revoke',
                  'id': r['id'],
                }, confirmation: '이 원격 세션의 권한을 철회하고 연결을 종료할까요? 파일 공유는 유지합니다.'),
              ),
            if (r['status'] == 'pending' && r['peer'] == state['node'])
              button(
                '요청 취소',
                () => act('ManageTeamShare', {
                  'action': 'desk-cancel',
                  'id': r['id'],
                }),
              ),
          ],
        ),
    ];
  }

  List<Widget> plugins() => [
    tile('프로토콜·부가 기능', '필요한 기능만 앱이 관리하는 위치에 설치합니다. 공유 폴더는 설치 후 별도로 지정합니다.'),
    for (final component in rows(value('shares'), 'components'))
      tile(
        component['id'] == 'remote-rustdesk'
            ? 'SigmaDesk'
            : text(component, 'id'),
        '${text(component, 'state')} · ${text(component, 'version')} · ${bytes(component['bytes'] as num?)}${component['running'] == true ? ' · 사용 중' : ''}${component['progress'] is Map ? '\n${text(Map<String, dynamic>.from(component['progress'] as Map), 'message')}' : ''}',
        actions: [
          button(
            '검증·설치',
            () => act('ManageTeamShare', {
              'action': 'component-install',
              'id': component['id'],
            }),
            enabled:
                component['repository_configured'] == true &&
                component['running'] != true,
          ),
        ],
      ),
  ];
  List<Widget> updates() => [
    tile(
      '앱 업데이트',
      '실행 중에는 서명을 확인한 변경 조각을 백그라운드로 준비하며, 다음 실행 때 적용합니다. 수동 적용 시에는 전송 체크포인트와 저장 완료를 확인한 뒤 재시작합니다.',
      actions: [
        button(
          '업데이트 확인·적용',
          () => act(
            'ManageUpdate',
            {'action': 'check_apply'},
            confirmation: '새 버전이 있으면 다운로드하고 안전한 체크포인트를 확인한 뒤 앱을 재시작합니다. 이 앱의 공유는 재시작 동안 잠시 중단되며 다시 연결됩니다. 계속할까요?',
          ),
        ),
        button('다운로드만 준비', () => act('ManageUpdate', {'action': 'check'})),
      ],
    ),
    for (final p in rows(value('downloads'), 'packages'))
      tile(
        '${text(p, 'name')} · ${text(p, 'version')}',
        updateProgressSummary(p),
        actions: [
          if (p['id'] == 'client' && p['state'] == 'ready')
            button(
              '안전하게 재시작·적용',
              () => act(
                'ManageUpdate',
                {'action': 'apply'},
                confirmation: '진행 중인 전송은 체크포인트에 보관하고 수신 요청과 디스크 저장이 끝난 뒤 업데이트합니다. 재시작 중 이 앱의 공유는 일시 중단되었다가 복구됩니다. 계속할까요?',
              ),
            ),
          if (p['id'] != 'client')
            button(
              '업데이트 확인',
              () => act('ManageDownloads', {'action': 'start', 'id': p['id']}),
              enabled: p['configured'] == true,
            ),
        ],
      ),
  ];

  List<Widget> account() {
    if (loading && data.isEmpty) {
      return [tile('회원·프로필 확인 중', '저장된 로그인과 프로필 연결을 확인하고 있습니다.')];
    }
    Json member = {};
    try {
      member = Map<String, dynamic>.from(
        jsonDecode(text(value('member'), 'export_data', '{}')) as Map,
      );
    } catch (_) {
      /* Not authenticated. */
    }
    return [
      tile(
        'SigmaDrive 회원',
        member['memberId'] == null
            ? '로그인 후 공유와 장치를 등록할 수 있습니다.'
            : '${text(member, 'email').isNotEmpty ? text(member, 'email') : '${text(member, 'provider') == 'microsoft'
                        ? 'Microsoft'
                        : text(member, 'provider') == 'google'
                        ? 'Google'
                        : '회원'} 로그인됨'} · 세션은 코어에서 갱신합니다.',
        actions: [
          if (member['memberId'] == null) ...[
            button('Google 로그인', () => memberSignIn('google')),
            button('Microsoft 로그인', () => memberSignIn('microsoft')),
          ] else
            button(
              '회원 로그아웃',
              () => act(
                'ManageProfile',
                {'action': 'member_logout'},
                confirmation: '이 Rust 앱의 회원 세션과 공유 연결을 종료할까요? 이 Windows 사용자의 클라우드 디스크 연결과 파일은 보관합니다.',
              ),
            ),
        ],
      ),
      tile(
        '로컬 프로필',
        '현재 프로필 ${text(value('profiles'), 'current_id')}\n${rows(value('profiles'), 'profiles').map((p) => text(p, 'name')).join(', ')}',
      ),
      ProfileSetup(
        api: api,
        connections: rows(value('connections'), 'connections'),
        state: value('cloud_profile'),
        onChanged: load,
      ),
      tile(
        '개인 웹페이지',
        '웹에서 내 장치와 원격 접속을 관리할 수 있습니다. 새 주소는 메일 ID와 8자리 임의 문자열로 구성되며, 발급 후 고정됩니다. 기존 주소도 계속 사용할 수 있습니다.'
            '${portal['memberId'] == member['memberId'] && portal['portalUrl'] is String ? '\n${text(portal, 'displayName')}\n${text(portal, portal['canonicalPortalUrl'] is String ? 'canonicalPortalUrl' : 'portalUrl')}' : ''}'
            '${portal['memberId'] == member['memberId'] && portal['addressState'] == 'unassigned' ? '\n처음 열 때 개인 주소가 발급됩니다.' : ''}',
        actions: [
          if (member['memberId'] != null) ...[
            button('주소 확인', () => personalPortal(open: false)),
            button('내 개인 웹페이지 열기', () => personalPortal(open: true)),
          ] else
            button(
              'SigmaDrive 웹 열기',
              () => api.openUrl('https://www.sigmadrive.net/'),
            ),
        ],
      ),
    ];
  }

  Future<void> personalPortal({required bool open}) async {
    final result = await act('ManageProfile', {
      'action': open ? 'member_portal_open' : 'member_portal_status',
    });
    if (result != null && mounted) setState(() => portal = result);
  }

  Future<void> memberSignIn(String provider) async {
    final config = await act('ManageProfile', {'action': 'member_config'});
    if (config == null || !mounted) return;
    final cfg = Map<String, dynamic>.from(
      jsonDecode(text(config, 'export_data', '{}')) as Map,
    );
    final clients = (cfg['providers'] as Map? ?? {})[provider] as List? ?? [];
    if (clients.isEmpty) {
      setState(() => error = '이 로그인 제공자의 앱 등록 정보가 준비되지 않았습니다.');
      return;
    }
    final registrations = await api.call('GetCloudRegistrations');
    final matching = rows(registrations, 'registrations')
        .where(
          (r) =>
              r['catalog_id'] ==
                  (provider == 'google' ? 'drive' : 'onedrive') &&
              r['configured'] == true &&
              clients.contains(r['client_id']),
        )
        .toList();
    if (!mounted) return;
    if (matching.isEmpty) {
      setState(
        () => error =
            '서버에 승인된 Desktop 앱 등록 설정을 설치 패키지에서 확인하지 못했습니다. 앱 등록 정보를 점검해 주세요.',
      );
      return;
    }
    final nativeClient = text(matching.first, 'client_id');
    final terms = text(cfg, 'termsVersion');
    if (terms.isEmpty) {
      setState(() => error = '이용 약관 버전을 확인하지 못했습니다.');
      return;
    }
    final accepted = await confirm(
      context,
      '회원 약관과 개인정보 안내를 확인하고 동의한 경우 계속하세요.\n적용 버전: $terms',
      onDetails: () => api.openUrl('${text(cfg, 'membershipEndpoint')}/legal'),
    );
    if (!accepted) return;
    await startSignIn(
      provider == 'google' ? 'profile-google' : 'profile-onedrive',
      {
        'client_id': nativeClient,
        'member_server': cfg['membershipEndpoint'],
        'member_terms': terms,
      },
      'SigmaDrive 회원·프로필',
      memberProfile: true,
    );
  }

  List<Widget> settings() {
    final settings = value('settings');
    final startup = value('startup');
    return [
      tile(
        'Windows 드라이브 구성요소',
        value('driver')['installed'] == true ? 'Dokany 드라이버가 준비되어 있습니다.' : '클라우드 디스크 마운트에는 Dokany 드라이버가 필요합니다. 설치 시 Windows 관리자 승인이 표시될 수 있습니다.',
        actions: [
          button(
            '드라이브 구성요소 설치',
            () => act(
              'InstallDriveDriver',
              {},
              confirmation: '서명이 검증된 Dokany 드라이버 설치를 시작할까요? 기존 Z: 설정은 변경하지 않습니다. Windows가 승인을 요청할 수 있으며 재부팅이 필요할 수 있습니다.',
            ),
            enabled: value('driver')['installed'] != true,
          ),
        ],
      ),
      tile(
        '지원용 진단',
        '인증 정보와 파일 이름을 제외한 현재 상태를 이 PC에만 저장합니다.',
        actions: [
          button('진단 파일 저장', () async {
            final result = await api.call('ExportDiagnostics');
            if (!mounted) return;
            await showDialog<void>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('진단 파일 저장됨'),
                content: SelectableText(text(result, 'path')),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('닫기'),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
      if (startup['supported'] == true)
        SwitchListTile(
          title: const Text('Windows 로그인 시 자동 시작'),
          subtitle: const Text(
            '이 Windows 사용자로 로그인하면 앱과 승인된 공유를 다시 연결합니다. 다른 사용자의 앱과 공유는 변경하지 않습니다.',
          ),
          value: startup['enabled'] == true,
          onChanged: busy
              ? null
              : (enabled) => act('SetLoginStartup', {'enabled': enabled}),
        ),
      tile(
        '이 장치',
        '컴퓨터 이름: ${text(settings, 'computer_name')}\n표시 이름: ${text(settings, 'device_name')}',
        actions: [
          button('장치 별명 변경', () async {
            final name = await askText(
              context,
              '장치 별명',
              '비워 두면 운영체제의 컴퓨터 이름을 사용합니다.',
              initial: text(settings, 'device_alias'),
            );
            if (name != null) {
              await act('SaveSettings', {
                'language': text(settings, 'language', 'ko'),
                'device_alias': name.trim(),
              });
            }
          }),
        ],
      ),
      tile(
        '언어',
        '코어 안내 언어: ${text(settings, 'language')}',
        actions: [
          button('한국어', () => act('SaveSettings', {'language': 'ko'})),
          button('English', () => act('SaveSettings', {'language': 'en'})),
        ],
      ),
      tile(
        '개발 프로필',
        '이 앱은 Rust 코어에 직접 연결합니다. 창을 닫아도 진행 중인 공유·전송은 백그라운드에서 유지됩니다. 기존 앱의 계정·설정·Z:는 변경하지 않습니다.',
      ),
    ];
  }
}

String cleanError(Object e) => e.toString().replaceFirst(
  RegExp(r'^(Bad state|StateError|Exception):\s*'),
  '',
);
