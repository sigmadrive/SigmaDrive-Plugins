import 'package:flutter/material.dart';

import 'api/api.dart';

const _endLabels = {
  'lease_expired': '접속 권한의 유효 시간이 끝났습니다.',
  'identity_changed': '로그인 또는 장치 정보가 변경되어 연결을 종료했습니다.',
  'engine_exited': '원격 화면 엔진이 종료되었습니다.',
  'transport_timeout': '중계 연결이 복구되지 않아 연결을 종료했습니다.',
  'no_decision': '서버에서 해당 연결의 사용 종료를 확인했습니다.',
};

class DeskEnd {
  final String code;
  final int? exitCode;
  const DeskEnd(this.code, this.exitCode);
  String get label => _endLabels[code] ?? '원격 연결이 종료되었습니다.';
}

/// PC-local, fixed-code diagnostics only. Never render raw errors or identities.
DeskEnd? recentDeskEnd(
  List<Json> diagnostics, {
  List<Json> sessions = const [],
}) {
  if (sessions.isNotEmpty) return null;
  final bounded = diagnostics.length > 64
      ? diagnostics.sublist(diagnostics.length - 64)
      : diagnostics;
  bool scoped(Json row) =>
      const {'host', 'viewer'}.contains(row['role']) &&
      RegExp(r'^[a-f0-9]{32}$').hasMatch(text(row, 'session'));
  final start = bounded.lastIndexWhere(
    (row) =>
        scoped(row) && row['event'] == 'engine_start' && row['code'] == 'begin',
  );
  for (var i = bounded.length - 1; i >= (start < 0 ? 0 : start); i--) {
    final row = bounded[i];
    if (!scoped(row) ||
        !const {'watchdog_stop', 'authority_stop'}.contains(row['event'])) {
      continue;
    }
    if (start >= 0 &&
        (row['session'] != bounded[start]['session'] ||
            row['role'] != bounded[start]['role'])) {
      continue;
    }
    final code = text(row, 'code');
    if (!_endLabels.containsKey(code)) return const DeskEnd('unknown', null);
    final exit = row['exit_code'];
    return DeskEnd(
      code,
      code == 'engine_exited' && exit is int && exit >= 0 && exit <= 0xffffffff
          ? exit
          : null,
    );
  }
  return null;
}

class DeskEndSummary extends StatelessWidget {
  final List<Json> diagnostics, sessions;
  const DeskEndSummary({
    super.key,
    required this.diagnostics,
    this.sessions = const [],
  });
  @override
  Widget build(BuildContext context) {
    final end = recentDeskEnd(diagnostics, sessions: sessions);
    if (end == null) return const SizedBox.shrink();
    return Card(
      child: ExpansionTile(
        title: const Text('최근 원격 연결 종료'),
        subtitle: Text(end.label),
        children: [
          ListTile(
            dense: true,
            title: Text('진단 코드: ${end.code}'),
            subtitle: Text(
              end.exitCode == null
                  ? '이 PC에만 보관하는 연결 상태입니다.'
                  : '화면 엔진 종료 코드: ${end.exitCode} · 이 PC에만 보관',
            ),
          ),
        ],
      ),
    );
  }
}
