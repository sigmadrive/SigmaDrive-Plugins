import 'dart:convert';

import 'package:flutter/material.dart';

import 'api/api.dart';
import 'forms.dart';

class ProfileSetup extends StatefulWidget {
  final CoreTransport api;
  final List<Json> connections;
  final Json state;
  final Future<void> Function() onChanged;
  const ProfileSetup({
    super.key,
    required this.api,
    required this.connections,
    required this.state,
    required this.onChanged,
  });
  @override
  State<ProfileSetup> createState() => _ProfileSetupState();
}

class _ProfileSetupState extends State<ProfileSetup> {
  bool busy = false;
  String? error;
  Json get online {
    try {
      return jsonDecode(text(widget.state, 'export_data', '{}')) as Json;
    } catch (_) {
      return {};
    }
  }

  Future<void> create(String id) async {
    if (!await confirm(
      context,
      '현재 설정을 선택한 회원 계정의 앱 전용 저장소에 암호화해 새 개인 프로필로 저장합니다. 기존 프로필과 Z: 설정은 가져오거나 바꾸지 않습니다.',
    )) {
      return;
    }
    if (!mounted) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.api.call('ManageProfile', {
        'action': 'cloud_create',
        'id': id,
      });
      final data = jsonDecode(text(result, 'export_data', '{}')) as Json;
      if (mounted && text(data, 'recovery').isNotEmpty) {
        // The recovery key stays in this dialog, never status, logs or the parent state.
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (_) => _Recovery(code: text(data, 'recovery')),
        );
      }
      await widget.onChanged();
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> operation(String action, {String? id, String? recovery}) async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await widget.api.call('ManageProfile', {
        'action': action,
        'id': ?id,
        'recovery': ?recovery,
      });
      await widget.onChanged();
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> restore(String id) async {
    final key = await askText(
      context,
      '개인 프로필 복원',
      '본인 계정의 복구 키를 입력하세요. 연결 정보만 복원하며, 이 PC의 로그인·디스크 문자·로컬 폴더·공유 권한은 별도로 지정합니다.',
      obscure: true,
    );
    if (key == null || key.trim().isEmpty || !mounted) return;
    await operation('cloud_restore', id: id, recovery: key.trim());
  }

  @override
  Widget build(BuildContext context) {
    final candidates = widget.connections
        .where((c) => !isFileConnection(c) && c['needs_auth'] != true)
        .toList();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('공유용 개인 프로필', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(
              online['enabled'] == true
                  ? '개인 프로필 연결됨'
                  : '회원 로그인 후 이 PC의 암호화된 개인 프로필을 연결해야 공유를 제공할 수 있습니다.',
            ),
            if (busy) const LinearProgressIndicator(),
            if (error != null)
              SelectableText(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            if (text(online, 'profile').isEmpty)
              for (final c in candidates)
                Wrap(
                  children: [
                    OutlinedButton(
                      onPressed: busy ? null : () => create(text(c, 'id')),
                      child: Text('${text(c, 'name')} · 이 설정으로 온라인 프로필 생성'),
                    ),
                    OutlinedButton(
                      onPressed: busy ? null : () => restore(text(c, 'id')),
                      child: const Text('복구 키로 기존 설정 복원'),
                    ),
                  ],
                ),
            if (text(online, 'profile').isNotEmpty)
              Wrap(
                children: [
                  OutlinedButton(
                    onPressed: busy ? null : () => operation('cloud_sync'),
                    child: const Text('암호화된 설정 동기화'),
                  ),
                  OutlinedButton(
                    onPressed: busy
                        ? null
                        : () async {
                            if (online['enabled'] == true &&
                                !await confirm(
                                  context,
                                  '개인 프로필을 사용 중지하고 이 Rust 앱의 공유 작업을 멈출까요? 설정과 재개 기록은 보관합니다.',
                                )) {
                              return;
                            }
                            await operation(
                              online['enabled'] == true
                                  ? 'cloud_pause'
                                  : 'cloud_resume',
                            );
                          },
                    child: Text(
                      online['enabled'] == true
                          ? '개인 프로필 사용 중지'
                          : '개인 프로필 다시 사용',
                    ),
                  ),
                ],
              ),
            if (online['enabled'] == true)
              OutlinedButton(
                onPressed: busy
                    ? null
                    : () async {
                        setState(() {
                          busy = true;
                          error = null;
                        });
                        try {
                          final result = await widget.api.call(
                            'ManageProfile',
                            {'action': 'cloud_key'},
                          );
                          final data = jsonDecode(
                            text(result, 'export_data', '{}'),
                          ) as Json;
                          if (context.mounted &&
                              text(data, 'recovery').isNotEmpty) {
                            await showDialog<void>(
                              context: context,
                              barrierDismissible: false,
                              builder: (_) =>
                                  _Recovery(code: text(data, 'recovery')),
                            );
                          }
                        } catch (e) {
                          if (mounted) setState(() => error = e.toString());
                        } finally {
                          if (mounted) setState(() => busy = false);
                        }
                      },
                child: const Text('개인 프로필 복구 키 확인'),
              ),
            if (online['enabled'] == true)
              OutlinedButton(
                onPressed: busy
                    ? null
                    : () async {
                        setState(() {
                          busy = true;
                          error = null;
                        });
                        try {
                          await widget.api.call('ManageTeamShare', {
                            'action': 'prepare-member',
                          });
                          await widget.onChanged();
                        } catch (e) {
                          if (mounted) setState(() => error = e.toString());
                        } finally {
                          if (mounted) setState(() => busy = false);
                        }
                      },
                child: const Text('공유 장치 등록·연결 확인'),
              ),
          ],
        ),
      ),
    );
  }
}

class _Recovery extends StatefulWidget {
  final String code;
  const _Recovery({required this.code});
  @override
  State<_Recovery> createState() => _RecoveryState();
}

class _RecoveryState extends State<_Recovery> {
  bool saved = false;
  @override
  Widget build(BuildContext context) => PopScope(
    canPop: saved,
    child: AlertDialog(
      title: const Text('개인 프로필 복구 키 보관'),
      content: SizedBox(
        width: 580,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '이 키로 다른 PC에서 개인 프로필을 복원할 수 있습니다. 안전한 곳에 보관하고 채팅에는 보내지 마세요.',
            ),
            const SizedBox(height: 16),
            SelectableText(widget.code),
            CheckboxListTile(
              title: const Text('복구 키를 안전하게 보관했습니다'),
              value: saved,
              onChanged: (v) => setState(() => saved = v == true),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: saved ? () => Navigator.pop(context) : null,
          child: const Text('완료'),
        ),
      ],
    ),
  );
}
