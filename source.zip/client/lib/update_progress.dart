import 'api/api.dart';

String updateProgressSummary(Json p) {
  final state = text(p, 'state');
  final stage = switch (text(p, 'stage', state)) {
    'checking' => '업데이트 정보 확인',
    'reuse_scan' => '재사용 조각 확인',
    'chunks' => '조각 수신·검증',
    'package_verify' => '설치 파일 구성·검증',
    'extract' => '파일 풀기·검증',
    'candidate_verify' => '새 버전 재검증',
    'stage_publish' => '다음 실행용 저장',
    'seed_save' => '재사용 파일 저장',
    'ready' => '업데이트 준비 완료',
    'up_to_date' => '최신 버전',
    'waiting_for_checkpoint' => '안전한 재시작 준비',
    'restart_ready' => '재시작 준비 완료',
    final value => value,
  };
  final latest = text(p, 'latest_version');
  final target = latest.isNotEmpty
      ? latest
      : state == 'checking' || state == 'downloading'
      ? '확인 중'
      : '미확인';
  String count(String key) => p[key] is num ? '${p[key]}' : '—';
  final received = p['received_bytes'] is num
      ? bytes(p['received_bytes'] as num)
      : '—';
  final source = text(p, 'catalog_source');
  final error = text(p, 'error');
  return '${state == 'failed' ? '실패 · ' : ''}$stage · 새 버전 $target\n'
      '${text(p, 'message')}\n'
      '수신 $received · 재사용 조각 ${count('reused_chunks')} · 새 다운로드 조각 ${count('downloaded_chunks')}'
      '${source.isEmpty ? '' : '\n업데이트 정보: ${source == 'raw.githubusercontent.com' ? 'GitHub 보조 경로' : 'jsDelivr'} · 서명 순번 ${p['catalog_sequence']}'}'
      '${error.isEmpty ? '' : '\n$error'}';
}
