// The old HTTP -> forwarding bridge -> Go web preview is retired.
// A future browser build needs its own Rust/WASM adapter; never fall back to IPC.
import 'api.dart';

class WebTransport implements CoreTransport {
  Never _unavailable() =>
      throw UnsupportedError('현재 웹 미리보기는 사용할 수 없습니다. 설치형 앱을 사용해 주세요.');

  @override
  Future<Json> call(String rpc, [Json body = const {}]) async => _unavailable();

  @override
  Future<void> openUrl(String url) async => _unavailable();
}

CoreTransport createTransport() => WebTransport();
