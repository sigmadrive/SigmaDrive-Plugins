import 'transport_stub.dart'
    if (dart.library.io) 'transport_native.dart'
    if (dart.library.js_interop) 'transport_web.dart'
    as platform;

typedef Json = Map<String, dynamic>;

abstract interface class CoreTransport {
  Future<Json> call(String rpc, [Json body = const {}]);
  Future<void> openUrl(String url);
}

CoreTransport createTransport() => platform.createTransport();
List<Json> rows(Json value, String key) => (value[key] as List? ?? [])
    .map((e) => Map<String, dynamic>.from(e as Map))
    .toList();
String text(Json value, String key, [String fallback = '']) =>
    value[key]?.toString() ?? fallback;

bool validShareBucket(String name) =>
    RegExp(r'^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$').hasMatch(name);
String shareName(Json share) => text(share, 'name').trim().isNotEmpty
    ? text(share, 'name')
    : '공유 ${text(share, 'id')}';

bool memberSessionReady(Json member, {DateTime? now}) =>
    member['signedIn'] != false &&
    text(member, 'memberId').isNotEmpty &&
    text(member, 'connection').isNotEmpty &&
    (member['expiresAt'] as num? ?? 0) >
        (now ?? DateTime.now()).millisecondsSinceEpoch;

bool isFileConnection(Json connection, {bool composite = false}) =>
    connection['preset'] != 'profile' &&
    (connection['options'] as Map? ?? {})['sigma_profile_only'] != 'true' &&
    (!composite || connection['provider'] != 'sigma-share');

String shareLabel(Json share, Json names) {
  final node = text(share, 'publisher');
  final device = names[node]?.toString() ?? text(share, 'publisher_name', node);
  return '${shareName(share)} · $device';
}

String bytes(num? count) {
  final n = (count ?? 0).toDouble();
  if (n >= 1073741824) return '${(n / 1073741824).toStringAsFixed(1)} GiB';
  if (n >= 1048576) return '${(n / 1048576).toStringAsFixed(1)} MiB';
  if (n >= 1024) return '${(n / 1024).toStringAsFixed(1)} KiB';
  return '${n.toInt()} B';
}
