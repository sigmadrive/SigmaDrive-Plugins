import 'api.dart';

CoreTransport createTransport() => throw UnsupportedError('지원하지 않는 플랫폼입니다.');
