import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:isolate';

import 'package:ffi/ffi.dart';

import 'api.dart';

typedef _CallNative = Pointer<Utf8> Function(Pointer<Uint8>, UintPtr);
typedef _CallDart = Pointer<Utf8> Function(Pointer<Uint8>, int);
typedef _FreeNative = Void Function(Pointer<Utf8>);
typedef _FreeDart = void Function(Pointer<Utf8>);
typedef _AbiNative = Uint32 Function();

class NativeTransport implements CoreTransport {
  final String library;
  NativeTransport({
    String? library,
    @Deprecated('Legacy Go IPC is retired') String? pipe,
  }) : library =
           library ?? _libraryPath() {
    if (pipe != null) {
      throw UnsupportedError(
        '기존 Go 파이프를 사용하는 시험 도구는 종료되었습니다. 새 Rust 코어 검증 도구가 필요합니다.',
      );
    }
  }

  static String _libraryPath() {
    final name = Platform.isWindows
        ? 'sigmadrive_core.dll'
        : Platform.isMacOS
        ? 'libsigmadrive_core.dylib'
        : 'libsigmadrive_core.so';
    return '${File(Platform.resolvedExecutable).parent.path}${Platform.pathSeparator}$name';
  }

  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    final request = jsonEncode({'abi': 2, 'rpc': rpc, 'body': body});
    final libraryPath = library;
    // Only immutable strings cross isolates. No FFI pointer or UI object crosses the boundary.
    final output = await Isolate.run(() => invokeNative(libraryPath, request));
    final response = jsonDecode(output) as Json;
    if (response['ok'] != true) throw StateError(response['error'].toString());
    return Map<String, dynamic>.from(response['data'] as Map);
  }

  @override
  Future<void> openUrl(String url) async {
    // Desktop and web use the same Rust HTTPS/provider allowlist.
    await call('OpenExternalUrl', {'url': url});
  }
}

String invokeNative(String libraryPath, String request) {
  final dll = DynamicLibrary.open(libraryPath);
  final abi = dll.lookupFunction<_AbiNative, int Function()>('sigma_core_abi');
  if (abi() != 2) throw StateError('직접 연결할 Rust 코어 버전이 맞지 않습니다.');
  final call = dll.lookupFunction<_CallNative, _CallDart>('sigma_core_call');
  final free = dll.lookupFunction<_FreeNative, _FreeDart>('sigma_core_free');
  final encoded = utf8.encode(request);
  final input = calloc<Uint8>(encoded.length);
  Pointer<Utf8> output = nullptr;
  try {
    input.asTypedList(encoded.length).setAll(0, encoded);
    output = call(input, encoded.length);
    if (output == nullptr) throw StateError('Rust 코어 응답이 없습니다.');
    return output.toDartString();
  } finally {
    if (output != nullptr) free(output);
    calloc.free(input);
  }
}

CoreTransport createTransport() => NativeTransport();
