import 'dart:async';

import 'package:flutter/material.dart';

import 'api/api.dart';
import 'forms.dart';

class DriveBrowser extends StatefulWidget {
  final CoreTransport api;
  final Json drive;
  const DriveBrowser({super.key, required this.api, required this.drive});
  @override
  State<DriveBrowser> createState() => _DriveBrowserState();
}

class _DriveBrowserState extends State<DriveBrowser> {
  String path = '';
  List<Json> entries = [];
  String? error, message;
  bool busy = false, truncated = false;
  int generation = 0;
  Json body([Json extra = const {}]) => {
    'drive_id': widget.drive['id'],
    'path': path,
    ...extra,
  };
  String child(String name) => path.isEmpty ? name : '$path/$name';
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  @override
  void dispose() {
    ++generation;
    super.dispose();
  }

  Future<void> load() async {
    if (!mounted) return;
    final token = ++generation;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.api.call('ListDriveFiles', body());
      if (mounted && token == generation) {
        setState(() {
          entries = rows(result, 'entries');
          truncated = result['truncated'] == true;
        });
      }
    } catch (e) {
      if (mounted && token == generation) setState(() => error = e.toString());
    } finally {
      if (mounted && token == generation) setState(() => busy = false);
    }
  }

  Future<void> folder() async {
    final name = await askText(context, '새 폴더', '현재 폴더 안에 새 폴더를 만듭니다.');
    if (!mounted || name == null || name.trim().isEmpty) return;
    await run('CreateDriveFolder', {'path': child(name.trim())});
  }

  Future<void> newText() async {
    final draft = await showDialog<Json>(
      context: context,
      builder: (_) => const _NewTextFile(),
    );
    if (!mounted || draft == null) return;
    final result = await run('WriteDriveText', {
      'path': child(text(draft, 'name')),
      'text': draft['text'],
    });
    if (result != null && mounted) {
      setState(
        () => message =
            '새 파일을 PC에 저장했습니다. 클라우드 반영은 디스크의 미완료 업로드 상태에서 확인할 수 있습니다.',
      );
    }
  }

  Future<Json?> run(String method, Json extra) async {
    if (!mounted) return null;
    setState(() {
      busy = true;
      error = null;
      message = null;
    });
    try {
      final result = await widget.api.call(method, body(extra));
      await load();
      return result;
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
      return null;
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> open(Json entry) async {
    if (entry['link'] == true) return;
    if (entry['directory'] == true) {
      setState(() => path = child(text(entry, 'name')));
      await load();
      return;
    }
    if ((entry['bytes'] as num? ?? 0) > 65536) {
      setState(() => error = '텍스트 미리보기는 64 KiB까지 지원합니다.');
      return;
    }
    setState(() => busy = true);
    try {
      final result = await widget.api.call(
        'ReadDriveText',
        body({'path': child(text(entry, 'name'))}),
      );
      if (mounted) {
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text(text(entry, 'name')),
            content: SizedBox(
              width: 680,
              child: SingleChildScrollView(
                child: SelectableText(text(result, 'text')),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('닫기'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text('${text(widget.drive, 'name')} · 파일'),
    content: SizedBox(
      width: 760,
      height: 520,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(path.isEmpty ? '/' : path),
          const Text('일반 파일·폴더를 표시합니다. OneDrive의 공유 바로 가기·OneNote 등 특수 항목은 아직 지원하지 않습니다.'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              OutlinedButton(
                onPressed: busy || path.isEmpty
                    ? null
                    : () {
                        setState(
                          () => path = path.contains('/')
                              ? path.substring(0, path.lastIndexOf('/'))
                              : '',
                        );
                        unawaited(load());
                      },
                child: const Text('상위 폴더'),
              ),
              OutlinedButton(
                onPressed: busy ? null : folder,
                child: const Text('새 폴더'),
              ),
              OutlinedButton(
                onPressed: busy ? null : newText,
                child: const Text('새 텍스트 파일'),
              ),
              IconButton(
                onPressed: busy ? null : load,
                icon: const Icon(Icons.refresh),
                tooltip: '목록 새로고침',
              ),
            ],
          ),
          if (busy) const LinearProgressIndicator(),
          if (error != null)
            SelectableText(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          if (message != null) Text(message!),
          if (truncated) const Text('처음 500개 항목을 표시합니다.'),
          Expanded(
            child: ListView(
              children: [
                for (final entry in entries)
                  ListTile(
                    leading: Icon(
                      entry['directory'] == true
                          ? Icons.folder_outlined
                          : Icons.description_outlined,
                    ),
                    title: Text(text(entry, 'name')),
                    subtitle: Text(
                      entry['directory'] == true
                          ? '폴더'
                          : bytes(entry['bytes'] as num?),
                    ),
                    onTap: busy || entry['link'] == true
                        ? null
                        : () => open(entry),
                  ),
                if (entries.isEmpty && !busy)
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('이 폴더는 비어 있습니다.'),
                  ),
              ],
            ),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('닫기'),
      ),
    ],
  );
}

class _NewTextFile extends StatefulWidget {
  const _NewTextFile();
  @override
  State<_NewTextFile> createState() => _NewTextFileState();
}

class _NewTextFileState extends State<_NewTextFile> {
  final form = GlobalKey<FormState>();
  final name = TextEditingController(text: '새 문서.txt'),
      content = TextEditingController();
  @override
  void dispose() {
    name.dispose();
    content.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('새 텍스트 파일'),
    content: SizedBox(
      width: 600,
      child: Form(
        key: form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: name,
              decoration: const InputDecoration(labelText: '파일 이름'),
              validator: (v) =>
                  v == null || v.trim().isEmpty || RegExp(r'[/\\:]').hasMatch(v)
                  ? '경로 구분자가 없는 파일 이름을 입력하세요.'
                  : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: content,
              minLines: 5,
              maxLines: 12,
              decoration: const InputDecoration(labelText: '내용'),
            ),
            const SizedBox(height: 12),
            const Text('같은 이름의 기존 파일은 덮어쓰지 않습니다.'),
          ],
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: () {
          if (form.currentState!.validate()) {
            Navigator.pop(context, {
              'name': name.text.trim(),
              'text': content.text,
            });
          }
        },
        child: const Text('새 파일로 저장'),
      ),
    ],
  );
}
