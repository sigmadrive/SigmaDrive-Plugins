import 'package:flutter/material.dart';

const _stages = {1: 'OS 신뢰 저장소 준비', 2: 'DNS·TCP 연결', 3: 'TLS·WebSocket 준비', 4: '연결 준비 전체'};
const _routes = {0: '공통', 1: '장치 등록', 2: 'ID 협상', 3: 'Relay'};

class DeskTransportTiming {
  final String label;
  final int outcome, elapsedUs;
  const DeskTransportTiming(this.label, this.outcome, this.elapsedUs);
}

List<DeskTransportTiming> localTransportTimings(Object? raw) {
  if (raw is! Map || raw['schema'] != 1 || raw['storage'] != 'pc_memory_only' || raw['identity_exported'] != false) return const [];
  final active = raw['active'], recent = raw['recent'];
  Object? observation;
  if (active is List && active.isNotEmpty) {
    if (active.length != 1) return const [];
    observation = active.single;
  } else if (recent is List && recent.isNotEmpty && recent.last is Map) {
    observation = (recent.last as Map)['observations'];
  }
  if (observation is! Map || observation['schema'] != 1 || observation['available'] != true) return const [];
  final tls = observation['tls_local'];
  if (tls is! Map || tls['schema'] != 1 || tls['enabled'] != 1 || tls['dropped'] != 0 || tls['unavailable'] == 1) return const [];
  final rows = tls['rows'];
  if (rows is! List || rows.length > 64) return const [];
  final result = <DeskTransportTiming>[];
  for (final row in rows) {
    if (row is! List || row.length != 4 || row.any((v) => v is! int)) return const [];
    final stage = row[0] as int, outcome = row[1] as int, us = row[2] as int, route = row[3] as int;
    if (!_stages.containsKey(stage) || !_routes.containsKey(route) || outcome < 1 || outcome > 4 || us < 0 || us > 60000000 || (stage == 1 && route != 0)) return const [];
    result.add(DeskTransportTiming('${_routes[route]} · ${_stages[stage]}', outcome, us));
  }
  return result;
}

class DeskTransportSummary extends StatelessWidget {
  final Object? observations;
  const DeskTransportSummary({super.key, required this.observations});
  @override
  Widget build(BuildContext context) {
    final timings = localTransportTimings(observations);
    if (timings.isEmpty) return const SizedBox.shrink();
    const outcomes = {1: '완료', 2: '오류', 3: '취소', 4: '시간 초과'};
    return Card(child: ExpansionTile(
      title: const Text('PC 전용 통신 준비 시간'),
      subtitle: const Text('직접 동의한 진단의 숫자만 표시 · 서버 전송 없음'),
      children: [
        const ListTile(title: Text('연결 준비 전체에는 DNS·TCP와 TLS 시간이 포함됩니다. 각 값을 합산하지 않습니다. 전송 속도·화면 반응 시간과는 다릅니다.')),
        for (final row in timings) ListTile(dense: true, title: Text('${row.label} · ${outcomes[row.outcome]} · ${(row.elapsedUs / 1000).toStringAsFixed(1)} ms')),
      ],
    ));
  }
}
