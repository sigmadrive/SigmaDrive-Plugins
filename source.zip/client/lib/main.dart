import 'package:flutter/material.dart';

import 'api/api.dart';
import 'shell.dart';

void main() => runApp(SigmaDriveApp(api: createTransport()));

class SigmaDriveApp extends StatelessWidget {
  final CoreTransport api;
  const SigmaDriveApp({super.key, required this.api});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'SigmaDrive · Rust Preview',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff4263d5)),
      scaffoldBackgroundColor: const Color(0xfff7f8fb),
      textTheme: const TextTheme(
        bodyMedium: TextStyle(color: Color(0xff263247)),
        bodySmall: TextStyle(color: Color(0xff49576d)),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
      ),
      cardTheme: const CardThemeData(
        color: Colors.white,
        elevation: 0,
        margin: EdgeInsets.only(bottom: 12),
      ),
    ),
    home: SigmaShell(api: api),
  );
}
