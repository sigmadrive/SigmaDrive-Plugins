import 'api/api.dart';

// Display and route selection only. The authority verifies ownership and host
// consent again; a device name or an absent member ID never establishes trust.
bool deskOwnsDevice(Json self, Json device) {
  final member = self['member'];
  final node = device['node'];
  return member is String &&
      member.isNotEmpty &&
      device['member'] == member &&
      node is String &&
      node.isNotEmpty &&
      node != self['node'];
}

bool deskDirectAccess(Json self, Json device) =>
    deskOwnsDevice(self, device) && device['allow_owned'] == true;
