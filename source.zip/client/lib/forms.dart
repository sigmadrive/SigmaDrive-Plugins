import 'dart:convert';

import 'package:flutter/material.dart';

import 'api/api.dart';

Future<void> showConnectionTest(
  BuildContext context,
  Json result,
) => showDialog<void>(
  context: context,
  builder: (ctx) => AlertDialog(
    title: Text(result['ok'] == true ? '클라우드 연결 확인' : '연결 확인 필요'),
    content: SizedBox(
      width: 560,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(result['ok'] == true ? '파일 목록 접근 확인됨' : '파일 목록에 접근하지 못했습니다.'),
            const SizedBox(height: 8),
            Text(
              result['can_write'] == true ? '파일 쓰기 확인됨' : '파일 쓰기를 확인하지 못했습니다.',
            ),
            if ((result['free_bytes'] as num? ?? -1) >= 0) ...[
              const SizedBox(height: 8),
              Text('사용 가능한 공간: ${bytes(result['free_bytes'] as num)}'),
            ],
            if (text(result, 'protection_text').isNotEmpty) ...[
              const SizedBox(height: 16),
              Text(text(result, 'protection_text')),
            ],
            if (text(result, 'error').isNotEmpty) ...[
              const SizedBox(height: 16),
              SelectableText(
                text(result, 'error'),
                style: TextStyle(color: Theme.of(ctx).colorScheme.error),
              ),
            ],
          ],
        ),
      ),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('닫기')),
    ],
  ),
);

Future<bool> confirm(
  BuildContext context,
  String message, {
  Future<void> Function()? onDetails,
}) async =>
    await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('내용 확인'),
        content: SelectableText(message),
        actions: [
          if (onDetails != null)
            TextButton(
              onPressed: onDetails,
              child: const Text('약관·개인정보 안내 열기'),
            ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(onDetails == null ? '계속' : '확인하고 동의'),
          ),
        ],
      ),
    ) ??
    false;

Future<String?> askText(
  BuildContext context,
  String title,
  String description, {
  String initial = '',
  bool obscure = false,
}) => showDialog<String>(
  context: context,
  builder: (_) => _TextPrompt(
    title: title,
    description: description,
    initial: initial,
    obscure: obscure,
  ),
);

class _TextPrompt extends StatefulWidget {
  final String title, description, initial;
  final bool obscure;
  const _TextPrompt({
    required this.title,
    required this.description,
    required this.initial,
    this.obscure = false,
  });
  @override
  State<_TextPrompt> createState() => _TextPromptState();
}

class _TextPromptState extends State<_TextPrompt> {
  late final TextEditingController controller;
  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.initial);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.title),
    content: SizedBox(
      width: 480,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.description),
          const SizedBox(height: 16),
          TextField(
            controller: controller,
            autofocus: true,
            maxLength: 512,
            obscureText: widget.obscure,
            enableSuggestions: !widget.obscure,
            autocorrect: !widget.obscure,
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: () => Navigator.pop(context, controller.text),
        child: const Text('저장'),
      ),
    ],
  );
}

Future<void> showResult(BuildContext context, String title, Json result) =>
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: SizedBox(
          width: 640,
          child: SingleChildScrollView(
            child: SelectableText(
              const JsonEncoder.withIndent('  ').convert(
                Map.fromEntries(
                  result.entries.where(
                    (e) => !RegExp(
                      'secret|token|passphrase',
                      caseSensitive: false,
                    ).hasMatch(e.key),
                  ),
                ),
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('닫기'),
          ),
        ],
      ),
    );

class ConnectionForm extends StatefulWidget {
  final List<Json> providers;
  final List<Json> connections;
  final Set<String> registrations;
  final String? initialProvider;
  const ConnectionForm({
    super.key,
    required this.providers,
    this.connections = const [],
    this.registrations = const {},
    this.initialProvider,
  });
  @override
  State<ConnectionForm> createState() => _ConnectionFormState();
}

class _ConnectionFormState extends State<ConnectionForm> {
  final key = GlobalKey<FormState>();
  final name = TextEditingController();
  final controllers = <String, TextEditingController>{};
  Json? selected;
  bool customRegistration = false;
  bool get configured =>
      selected != null && widget.registrations.contains(selected!['id']);
  Json? get registrationSource => selected == null
      ? null
      : widget.connections
            .where(
              (c) =>
                  !isFileConnection(c) &&
                  c['provider'] == selected!['backend'] &&
                  c['needs_auth'] != true,
            )
            .firstOrNull;
  bool get reuseRegistration =>
      !customRegistration && (configured || registrationSource != null);
  @override
  void initState() {
    super.initState();
    final id = widget.initialProvider;
    if (id != null) {
      selected = widget.providers.where((p) => p['id'] == id).firstOrNull;
      if (selected != null) name.text = text(selected!, 'name');
    }
  }

  @override
  void dispose() {
    name.dispose();
    for (final c in controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  void pick(Json provider) {
    // Keep old controllers alive until the dialog is disposed; old TextFields may
    // still detach during this frame. New fields are keyed by provider + key.
    setState(() {
      selected = provider;
      name.text = text(provider, 'name');
    });
  }

  TextEditingController controller(Json field) => controllers.putIfAbsent(
    '${selected!['id']}:${field['key']}',
    () => TextEditingController(text: text(field, 'default_value')),
  );
  void submit() {
    if (selected == null || !key.currentState!.validate()) return;
    final values = <String, String>{};
    for (final field in rows(selected!, 'fields')) {
      if (!reuseRegistration ||
          !['client_id', 'client_secret'].contains(field['key'])) {
        values[text(field, 'key')] = controller(field).text;
      }
    }
    if (reuseRegistration && registrationSource != null) {
      values['source_connection'] = text(registrationSource!, 'id');
    }
    Navigator.pop(context, <String, dynamic>{
      'name': name.text.trim(),
      'catalog_id': selected!['id'],
      'values': values,
      '_oauth': selected!['auth'] == 'oauth',
    });
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('클라우드 연결'),
    content: SizedBox(
      width: 580,
      child: SingleChildScrollView(
        child: Form(
          key: key,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: '저장소'),
                initialValue: selected?['id'] as String?,
                isExpanded: true,
                items: widget.providers
                    .map(
                      (p) => DropdownMenuItem(
                        value: text(p, 'id'),
                        child: Text(text(p, 'name')),
                      ),
                    )
                    .toList(),
                onChanged: (id) =>
                    pick(widget.providers.firstWhere((p) => p['id'] == id)),
              ),
              if (selected != null) ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: name,
                  decoration: const InputDecoration(labelText: '연결 이름'),
                  validator: (v) => v!.trim().isEmpty ? '이름을 입력하세요.' : null,
                ),
                if (text(selected!, 'unavailable').isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(text(selected!, 'unavailable')),
                  ),
                if (selected!['auth'] == 'oauth')
                  CheckboxListTile(
                    title: const Text('직접 등록한 앱 사용 · 고급'),
                    value: customRegistration,
                    onChanged: (v) =>
                        setState(() => customRegistration = v ?? false),
                  ),
                if (reuseRegistration)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      '준비된 앱 등록 설정으로 로그인합니다. 파일 접근 권한은 브라우저에서 별도로 확인합니다.',
                    ),
                  ),
                for (final field in rows(selected!, 'fields').where(
                  (f) =>
                      !reuseRegistration ||
                      !['client_id', 'client_secret'].contains(f['key']),
                ))
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: fieldWidget(field),
                  ),
                if (selected!['auth'] == 'oauth')
                  const Padding(
                    padding: EdgeInsets.only(top: 16),
                    child: Text('브라우저에서 로그인한 뒤 파일 접근 검사가 자동으로 진행됩니다.'),
                  ),
              ],
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: selected != null && text(selected!, 'unavailable').isEmpty
            ? submit
            : null,
        child: const Text('계속'),
      ),
    ],
  );
  Widget fieldWidget(Json field) {
    final c = controller(field);
    final label = text(field, 'label', text(field, 'key'));
    String? validate(String? v) =>
        field['required'] == true && (v ?? '').trim().isEmpty
        ? '필수 항목입니다.'
        : null;
    if (field['kind'] == 'choice') {
      final choices = (field['choices'] as List? ?? []).cast<String>();
      return DropdownButtonFormField<String>(
        key: ValueKey('${selected!['id']}:${field['key']}'),
        initialValue: choices.contains(c.text) ? c.text : null,
        decoration: InputDecoration(
          labelText: label,
          helperText: text(field, 'help').isEmpty ? null : text(field, 'help'),
        ),
        items: choices
            .map((s) => DropdownMenuItem(value: s, child: Text(s)))
            .toList(),
        onChanged: (v) => c.text = v ?? '',
        validator: validate,
      );
    }
    if (field['kind'] == 'bool') {
      return CheckboxListTile(
        title: Text(label),
        value: c.text == 'true',
        onChanged: (v) => setState(() => c.text = v == true ? 'true' : 'false'),
      );
    }
    return TextFormField(
      key: ValueKey('${selected!['id']}:${field['key']}'),
      controller: c,
      obscureText: field['secret'] == true || field['kind'] == 'password',
      enableSuggestions: field['secret'] != true,
      autocorrect: false,
      decoration: InputDecoration(
        labelText: label,
        helperText: text(field, 'help').isEmpty ? null : text(field, 'help'),
        helperMaxLines: 4,
      ),
      validator: validate,
    );
  }
}

class DriveForm extends StatefulWidget {
  final List<Json> connections;
  final List<String> letters;
  final String? initialConnectionId;
  const DriveForm({
    super.key,
    required this.connections,
    required this.letters,
    this.initialConnectionId,
  });
  @override
  State<DriveForm> createState() => _DriveFormState();
}

class _DriveFormState extends State<DriveForm> {
  bool selectedProvidersContainOneDrive()=>members.any((m)=>available.any((c)=>c['id']==m['connection_id']&&c['provider']=='onedrive'));
  final form = GlobalKey<FormState>();
  final name = TextEditingController();
  final members = <Json>[];
  bool composite = false, auto = false, readOnly = false, identitySwap = false;
  String target = '';
  String? issue;
  List<Json> get available => widget.connections
      .where((c) => isFileConnection(c, composite: composite))
      .toList();
  @override
  void initState() {
    super.initState();
    addMember();
  }

  void addMember() {
    members.add({
      'folder': 'Cloud${members.length + 1}',
      'connection_id': available.isEmpty
          ? ''
          : (members.isEmpty &&
                    available.any((c) => c['id'] == widget.initialConnectionId)
                ? widget.initialConnectionId
                : available.first['id']),
      'remote_path': '',
    });
  }

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  void submit() {
    if (!form.currentState!.validate()) return;
    final selected = composite ? members : members.take(1).toList();
    if (selected.isEmpty ||
        selected.any(
          (m) => !available.any((c) => c['id'] == m['connection_id']),
        )) {
      setState(() => issue = '파일 저장소 연결을 먼저 추가하세요.');
      return;
    }
    final folders = selected
        .map((m) => text(m, 'folder').trim().toLowerCase())
        .toList();
    if (composite &&
        (folders.any(
              (s) =>
                  s.isEmpty ||
                  s.contains('/') ||
                  s.contains('\\') ||
                  s == '.' ||
                  s == '..',
            ) ||
            folders.toSet().length != folders.length)) {
      setState(
        () => issue = '통합 디스크의 최상위 폴더 이름은 서로 달라야 하며 경로 구분자를 포함할 수 없습니다.',
      );
      return;
    }
    Navigator.pop(context, <String, dynamic>{
      'name': name.text.trim(),
      'mode': composite ? 2 : 1,
      'members': selected
          .map(
            (m) => {...m, 'folder': composite ? text(m, 'folder').trim() : ''},
          )
          .toList(),
      'target': target,
      'disk_type': 1,
      'access_mode': readOnly ? 2 : 1,
      'allow_identity_swap': !readOnly && identitySwap,
      'auto_mount': auto,
    });
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('디스크 만들기'),
    content: SizedBox(
      width: 620,
      child: SingleChildScrollView(
        child: Form(
          key: form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: name,
                decoration: const InputDecoration(labelText: '디스크 이름'),
                validator: (v) =>
                    (v ?? '').trim().isEmpty ? '이름을 입력하세요.' : null,
              ),
              SwitchListTile(
                title: const Text('여러 저장소를 통합 디스크로 구성'),
                value: composite,
                onChanged: (v) => setState(() {
                  composite = v;
                  for (final m in members) {
                    if (!available.any((c) => c['id'] == m['connection_id'])) {
                      m['connection_id'] = available.isEmpty
                          ? ''
                          : available.first['id'];
                    }
                  }
                }),
              ),
              if (available.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    '파일 디스크용 저장소 연결이 없습니다. 회원 프로필 보관용 연결은 선택할 수 없습니다.',
                  ),
                ),
              for (var i = 0; i < (composite ? members.length : 1); i++)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    children: [
                      DropdownButtonFormField<String>(
                        key: ValueKey(
                          '$composite-$i-${members[i]['connection_id']}',
                        ),
                        initialValue:
                            available.any(
                              (c) => c['id'] == members[i]['connection_id'],
                            )
                            ? members[i]['connection_id'] as String
                            : null,
                        decoration: const InputDecoration(labelText: '저장소 연결'),
                        items: available
                            .map(
                              (c) => DropdownMenuItem(
                                value: text(c, 'id'),
                                child: Text(text(c, 'name')),
                              ),
                            )
                            .toList(),
                        onChanged: (v) =>
                            setState(() => members[i]['connection_id'] = v),
                      ),
                      if (composite)
                        Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: TextFormField(
                            initialValue: text(members[i], 'folder'),
                            decoration: const InputDecoration(
                              labelText: '디스크 안의 폴더 이름',
                            ),
                            onChanged: (v) => members[i]['folder'] = v,
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: TextFormField(
                          initialValue: text(members[i], 'remote_path'),
                          decoration: const InputDecoration(
                            labelText: '저장소 경로 · 비우면 루트',
                          ),
                          onChanged: (v) =>
                              members[i]['remote_path'] = v.trim(),
                        ),
                      ),
                    ],
                  ),
                ),
              if (composite)
                TextButton.icon(
                  onPressed: () => setState(addMember),
                  icon: const Icon(Icons.add),
                  label: const Text('저장소 추가'),
                ),
              const SizedBox(height: 12),
              SwitchListTile(title:const Text('읽기 전용 디스크'),value:readOnly,onChanged:(v)=>setState(()=>readOnly=v)),
              if(!readOnly && selectedProvidersContainOneDrive())
                CheckboxListTile(title:const Text('OneDrive 대용량 교체 허용'),subtitle:const Text('32 MiB를 넘는 기존 파일은 새 파일로 교체하고 원본을 백업 이름으로 보관합니다. 파일 ID가 바뀌므로 기존 공유 링크와 개별 파일 권한은 이어지지 않을 수 있습니다.'),value:identitySwap,onChanged:(v)=>setState(()=>identitySwap=v??false)),
              DropdownButtonFormField<String>(
                initialValue: target,
                decoration: const InputDecoration(labelText: '드라이브 위치'),
                items: [
                  const DropdownMenuItem(
                    value: '',
                    child: Text('사용 가능한 위치 자동 선택'),
                  ),
                  for (final letter in widget.letters.where(
                    (l) => l.toUpperCase() != 'Z:',
                  ))
                    DropdownMenuItem(value: letter, child: Text(letter)),
                ],
                onChanged: (v) => target = v ?? '',
              ),
              CheckboxListTile(
                title: const Text('코어 시작 시 자동 연결'),
                value: auto,
                onChanged: (v) => setState(() => auto = v ?? false),
              ),
              if (issue != null)
                Text(
                  issue!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: available.isEmpty ? null : submit,
        child: const Text('저장'),
      ),
    ],
  );
}

class ShareForm extends StatefulWidget {
  final List<String> protocols;
  final String owner;
  const ShareForm({super.key, required this.protocols, this.owner = ''});
  @override
  State<ShareForm> createState() => _ShareFormState();
}

class _ShareFormState extends State<ShareForm> {
  final form = GlobalKey<FormState>();
  final name = TextEditingController(),
      folder = TextEditingController(),
      bucket = TextEditingController();
  String protocol = 'sigma-api';
  @override
  void dispose() {
    name.dispose();
    folder.dispose();
    bucket.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('폴더 공유 추가'),
    content: SizedBox(
      width: 560,
      child: SingleChildScrollView(
        child: Form(
          key: form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: name,
                decoration: const InputDecoration(labelText: '공유 이름'),
                validator: (v) => v!.trim().isEmpty ? '이름을 입력하세요.' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: folder,
                decoration: const InputDecoration(
                  labelText: '공유할 로컬 폴더의 전체 경로',
                ),
                validator: (v) => v!.trim().isEmpty ? '폴더를 지정하세요.' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: protocol,
                decoration: const InputDecoration(labelText: '공유 프로토콜'),
                items: widget.protocols
                    .where((p) => ['sigma-api', 's3'].contains(p))
                    .map(
                      (p) => DropdownMenuItem(
                        value: p,
                        child: Text(p == 's3' ? 'S3 호환 공유' : 'SigmaDrive 공유'),
                      ),
                    )
                    .toList(),
                onChanged: (v) => setState(() => protocol = v ?? 'sigma-api'),
              ),
              if (protocol == 's3') ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: bucket,
                  decoration: const InputDecoration(labelText: '버킷 이름'),
                  validator: (v) => !validShareBucket(v ?? '')
                      ? '소문자·숫자로 3~63자 버킷 이름을 입력하세요.'
                      : null,
                ),
              ],
              const SizedBox(height: 16),
              const Text(
                '새 공유에는 장치별 권한을 별도로 부여해야 합니다. 프로토콜 설치만으로 폴더 접근을 허용하지 않습니다.',
              ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: () {
          if (form.currentState!.validate()) {
            Navigator.pop(context, <String, dynamic>{
              'action': 'save',
              'name': name.text.trim(),
              'folder': folder.text.trim(),
              'protocol': protocol,
              's3_bucket': bucket.text.trim(),
              's3_relay': protocol == 's3',
              'grants': <String>[if (widget.owner.isNotEmpty) widget.owner],
              'write_grants': <String>[],
              'team_wide': false,
            });
          }
        },
        child: const Text('공유 구성 저장'),
      ),
    ],
  );
}
