import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';

import 'api/api.dart';

/// A single owner for an OAuth wait. Cancellation also closes the core's loopback listener.
class OAuthFlowDialog extends StatefulWidget {
  final CoreTransport api;
  final Json flow;
  final bool memberProfile;
  const OAuthFlowDialog({
    super.key,
    required this.api,
    required this.flow,
    this.memberProfile = false,
  });
  @override
  State<OAuthFlowDialog> createState() => _OAuthFlowDialogState();
}

class _OAuthFlowDialogState extends State<OAuthFlowDialog> {
  String phase = 'waiting';
  String? error;
  Json? connection, test;
  bool closing = false, opening = false;
  int generation = 0;
  @override
  void initState() {
    super.initState();
    unawaited(waitForConnection());
  }

  Future<void> waitForConnection() async {
    final token = ++generation;
    try {
      final result = await widget.api.call('FinishSignIn', {
        'id': widget.flow['id'],
      });
      if (!mounted || closing || token != generation) return;
      setState(() {
        connection = result;
        phase = 'verifying';
      });
      await verify();
    } catch (e) {
      if (mounted && !closing && token == generation) {
        setState(() {
          phase = 'failed';
          error = oauthError(e);
        });
      }
    }
  }

  Future<void> verify() async {
    if (connection == null || closing) return;
    setState(() {
      phase = 'verifying';
      error = null;
    });
    try {
      if (widget.memberProfile) {
        final result = await widget.api.call('ManageProfile', {
          'action': 'member_status',
        });
        if (!mounted || closing) return;
        final member = jsonDecode(text(result, 'export_data', '{}')) as Json;
        final signedIn =
            memberSessionReady(member) &&
            member['connection'] == connection!['id'];
        setState(() {
          test = {'ok': signedIn};
          phase = 'ready';
          if (!signedIn) error = '회원 로그인을 확인하지 못했습니다. 다시 시도해 주세요.';
        });
        return;
      }
      final result = await widget.api.call('TestConnection', {
        'id': connection!['id'],
        'remote_path': '',
      });
      if (!mounted || closing) return;
      setState(() {
        test = result;
        phase = 'ready';
        if (result['ok'] != true) {
          error = text(result, 'error', '저장소 접근을 확인하지 못했습니다.');
        }
      });
    } catch (e) {
      if (mounted && !closing) {
        setState(() {
          phase = 'ready';
          error = oauthError(e);
        });
      }
    }
  }

  Future<void> cancel() async {
    if (closing) return;
    setState(() {
      closing = true;
    });
    ++generation;
    try {
      await widget.api.call('CancelSignIn', {'id': widget.flow['id']});
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() {
          closing = false;
          error = '로그인 취소를 확인하지 못했습니다. 연결을 확인한 뒤 다시 취소하세요.';
        });
      }
    }
  }

  Future<void> openBrowser() async {
    if (opening || closing) return;
    setState(() {
      opening = true;
      error = null;
    });
    try {
      await widget.api.openUrl(accountSelectionUrl(text(widget.flow, 'url')));
    } catch (e) {
      if (mounted) setState(() => error = oauthError(e));
    } finally {
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  void dispose() {
    ++generation;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: phase == 'ready' || phase == 'failed',
    child: AlertDialog(
      title: Text(switch (phase) {
        'waiting' => '브라우저에서 로그인',
        'verifying' => widget.memberProfile ? '회원 로그인 확인' : '저장소 접근 확인',
        'ready' => widget.memberProfile ? '회원 로그인 확인' : '클라우드 연결 확인',
        _ => '로그인을 완료하지 못했습니다',
      }),
      content: SizedBox(
        width: 520,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (['waiting', 'verifying'].contains(phase)) ...[
              const LinearProgressIndicator(),
              const SizedBox(height: 16),
              Text(
                phase == 'waiting'
                    ? '로그인 페이지를 열고 사용할 계정과 파일 접근 권한을 직접 확인해 주세요. 인증이 끝나면 자동으로 연결을 검사합니다.'
                    : widget.memberProfile
                    ? '회원 세션을 확인하고 있습니다.'
                    : '인증은 완료됐습니다. 실제 파일 목록과 읽기·쓰기 접근을 확인하고 있습니다.',
              ),
            ],
            if (connection != null) ...[
              const SizedBox(height: 12),
              Text(text(connection!, 'name')),
            ],
            if (test != null && widget.memberProfile)
              Text(
                test!['ok'] == true
                    ? '회원 로그인 확인됨 · 닫은 뒤 개인 프로필을 연결해 주세요.'
                    : '회원 로그인 확인 필요',
              ),
            if (test != null && !widget.memberProfile) ...[
              const SizedBox(height: 12),
              Text(test!['ok'] == true ? '파일 목록 접근 확인됨' : '파일 목록 접근 확인 필요'),
              Text(
                test!['can_write'] == true
                    ? '파일 쓰기 확인됨'
                    : '파일 쓰기는 아직 확인되지 않았습니다.',
              ),
              if (text(test!, 'protection_text').isNotEmpty)
                Text(text(test!, 'protection_text')),
            ],
            if (error != null) ...[
              const SizedBox(height: 16),
              SelectableText(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ],
          ],
        ),
      ),
      actions: [
        if (['waiting', 'failed'].contains(phase))
          TextButton(
            onPressed: closing ? null : cancel,
            child: Text(closing ? '취소 중…' : '로그인 취소'),
          ),
        if (phase == 'waiting')
          FilledButton(
            onPressed: opening || closing ? null : openBrowser,
            child: const Text('로그인 페이지 열기'),
          ),
        if (phase == 'failed')
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('닫기'),
          ),
        if (phase == 'ready') ...[
          TextButton(onPressed: verify, child: const Text('연결 다시 검사')),
          TextButton(
            onPressed: () => Navigator.pop(context, {
              'connection': connection,
              'create_drive': false,
            }),
            child: const Text('닫기'),
          ),
          if (!widget.memberProfile)
            FilledButton(
              onPressed: test?['ok'] == true
                  ? () => Navigator.pop(context, {
                      'connection': connection,
                      'create_drive': true,
                    })
                  : null,
              child: const Text('디스크 만들기'),
            ),
        ],
      ],
    ),
  );
}

String oauthError(Object error) {
  final message = error.toString().replaceFirst(
    RegExp(r'^(Bad state|StateError|Exception):\s*'),
    '',
  );
  if (message.contains('unmount and finish pending uploads')) {
    return '연결 중인 디스크와 미완료 파일을 보호하기 위해 기존 저장소의 재로그인을 보류했습니다. 공유용 회원 로그인은 회원·프로필 메뉴에서 별도로 진행하세요.';
  }
  if (message.contains('oauth_scope_insufficient')) {
    return '파일 디스크 접근 권한이 부족합니다. Google Drive의 파일 접근 권한을 확인해 다시 로그인하세요.';
  }
  if (message.contains('oauth_account_mismatch')) {
    return '이 연결을 처음 만든 계정으로 로그인해 주세요. 기존 디스크와 미완료 파일은 유지됩니다.';
  }
  if (message.contains('google_drive_access_unverified')) {
    return '인증 응답은 받았지만 Google Drive 접근을 확인하지 못했습니다. 연결을 다시 확인해 주세요.';
  }
  if (message.contains('not finished') || message.contains('canceled')) {
    return '로그인이 취소됐거나 제한 시간이 지났습니다. 다시 연결해 주세요.';
  }
  if (message.contains('declined')) {
    return '계정 제공자에서 접근을 허용하지 않았습니다. 필요한 권한을 확인해 주세요.';
  }
  return message;
}

String accountSelectionUrl(String url) {
  final uri = Uri.parse(url);
  if (uri.scheme != 'https') return url;
  final query = Map<String, String>.from(uri.queryParameters);
  if (uri.host == 'login.microsoftonline.com') {
    query['prompt'] = 'select_account';
  } else if (uri.host == 'accounts.google.com') {
    final prompts =
        (query['prompt'] ?? '').split(' ').where((s) => s.isNotEmpty).toSet()
          ..add('select_account');
    prompts.remove('none');
    query['prompt'] = prompts.join(' ');
  } else {
    return url;
  }
  return uri.replace(queryParameters: query).toString();
}
