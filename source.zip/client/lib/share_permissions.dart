import 'package:flutter/material.dart';

import 'api/api.dart';

/// Reuse only the Rust core's local, share-and-device-bound trust record.
/// Directory fields must never supply a certificate pin.
Future<({String pin, bool confirmed})?> receiverIdentity(
  CoreTransport api,
  Json share,
  Future<String?> Function() confirm,
) async {
  final local = await api.call('ManageTeamShare', {
    'action': 'receiver-trust',
    'id': share['id'],
    'publisher': share['publisher'],
  });
  final pin = local['peer_pin'];
  if (local['trusted'] == true &&
      local['share'] == share['id'] &&
      local['publisher'] == share['publisher'] &&
      pin is String &&
      RegExp(r'^[a-f0-9]{64}$').hasMatch(pin)) {
    return (pin: pin, confirmed: false);
  }
  final entered = await confirm();
  if (entered == null ||
      !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(entered.trim())) {
    return null;
  }
  return (pin: entered.trim().toLowerCase(), confirmed: true);
}

Json shareSaveRequest(
  Json share,
  Iterable<String> reads,
  Iterable<String> writes,
) {
  final r = reads.toSet();
  final w = writes.toSet().intersection(r);
  return {
    'action': 'save',
    'id': share['id'],
    'name': share['name'],
    'folder': share['folder'],
    'protocol': share['protocol'],
    's3_bucket': share['s3_bucket'] ?? '',
    's3_port': share['s3_port'] ?? 0,
    's3_relay': share['s3_relay'] == true,
    'team_wide': share['team_wide'] == true,
    'grants': r.toList(),
    'write_grants': w.toList(),
  };
}

class SharePermissions extends StatefulWidget {
  final Json share, state;
  const SharePermissions({super.key, required this.share, required this.state});
  @override
  State<SharePermissions> createState() => _SharePermissionsState();
}

class _SharePermissionsState extends State<SharePermissions> {
  late final reads = (widget.share['grants'] as List? ?? [])
      .cast<String>()
      .toSet();
  late final writes = (widget.share['write_grants'] as List? ?? [])
      .cast<String>()
      .toSet();
  @override
  Widget build(BuildContext context) {
    // These are member IDs, not node names. Device approvals are managed separately.
    final members = <String>{
      ...reads,
      ...writes,
      if (text(widget.state, 'owner_member').isNotEmpty)
        text(widget.state, 'owner_member'),
      for (final invite in rows(widget.state, 'member_invites'))
        if (invite['share'] == widget.share['id'] &&
            invite['status'] == 'accepted')
          text(invite, 'member'),
    }..remove('');
    return AlertDialog(
      title: Text('${text(widget.share, 'name')} · 회원 권한'),
      content: SizedBox(
        width: 680,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '회원의 읽기·쓰기 허용과 각 장치의 인증서 승인은 별도입니다. 이름이 같아도 공유 ID와 장치 키로 구분합니다.',
              ),
              if (members.isEmpty) const Text('공유 초대를 수락한 회원이 없습니다.'),
              for (final member in members)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Divider(),
                    SelectableText(
                      member == widget.state['owner_member']
                          ? '내 회원 계정 · $member'
                          : member,
                    ),
                    CheckboxListTile(
                      title: const Text('읽기 허용'),
                      value: reads.contains(member),
                      onChanged: (v) => setState(() {
                        if (v == true) {
                          reads.add(member);
                        } else {
                          reads.remove(member);
                          writes.remove(member);
                        }
                      }),
                    ),
                    CheckboxListTile(
                      title: const Text('쓰기·삭제 허용'),
                      value: writes.contains(member),
                      onChanged:
                          !reads.contains(member) ||
                              widget.share['protocol'] != 's3' ||
                              widget.share['s3_relay'] != true
                          ? null
                          : (v) => setState(() {
                              if (v == true) {
                                writes.add(member);
                              } else {
                                writes.remove(member);
                              }
                            }),
                    ),
                  ],
                ),
              const Text(
                '읽기 철회 시 쓰기 권한도 함께 제거합니다. 진행 중인 해당 공유의 연결은 코어에서 차단하며 다른 공유는 유지합니다.',
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('취소'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            shareSaveRequest(widget.share, reads, writes),
          ),
          child: const Text('권한 변경 적용'),
        ),
      ],
    );
  }
}

class VerifyDevice extends StatefulWidget {
  final String device;
  final bool receiving;
  const VerifyDevice({super.key, required this.device, this.receiving = false});
  @override
  State<VerifyDevice> createState() => _VerifyDeviceState();
}

class _VerifyDeviceState extends State<VerifyDevice> {
  final pin = TextEditingController();
  bool verified = false;
  @override
  void dispose() {
    pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.receiving ? '공유 제공 장치 확인' : '요청 장치 확인·승인'),
    content: SizedBox(
      width: 600,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.device),
          if (!widget.receiving)
            const Text(
              '이 장치가 공유에 설정된 회원 읽기·쓰기 권한 범위 안에서 접속하도록 승인합니다. 실제 쓰기는 해당 회원의 쓰기 권한도 있어야 가능합니다.',
            ),
          Text(
            widget.receiving
                ? '공유 제공 PC의 공유 화면에 표시된 장치 인증서 지문을 별도 경로로 확인해 입력하세요.'
                : '요청한 PC의 공유 화면에 표시된 장치 인증서 지문을 별도 경로로 확인해 입력하세요. 서버가 알려준 지문을 자동으로 신뢰하지 않습니다.',
          ),
          const SizedBox(height: 12),
          TextField(
            controller: pin,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              labelText: '장치 SHA-256 지문 · 64자리 16진수',
            ),
          ),
          CheckboxListTile(
            value: verified,
            onChanged: (v) => setState(() => verified = v == true),
            title: const Text('요청한 장치와 지문을 직접 확인했습니다'),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed:
            verified && RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(pin.text.trim())
            ? () => Navigator.pop(context, pin.text.trim().toLowerCase())
            : null,
        child: Text(widget.receiving ? '확인한 장치의 S3 열기' : '확인한 장치의 접속 승인'),
      ),
    ],
  );
}
