import 'api/api.dart';

String shareConnectivityLabel(Json share) {
  final contact = share['connectivity'] as Map? ?? const {};
  return switch (contact['state']) {
    'verified' => '접속 확인됨 · 최근 1분 이내',
    'unreachable' => '최근 연결 실패 · 다시 확인 가능',
    'access_denied' => '접속 권한 확인 필요',
    'approval_required' => '장치 승인 필요',
    _ => share['online'] == true ? '서버에서 온라인 보고 · 실제 접속 확인 전' : '실제 접속 확인 전',
  };
}
