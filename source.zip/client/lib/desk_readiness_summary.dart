import 'package:flutter/material.dart';

import 'api/api.dart';

const _modeCodes = {'mode_ack', 'mode_legacy'};
const _timingCodes = {'registration_observed', 'proof_accepted'};
const _maximumExactMs = 9007199254740991;

class DeskReadinessTiming {
  final String code;
  final int elapsedMs;
  const DeskReadinessTiming(this.code, this.elapsedMs);
}

String? _session(Json row) {
  final value = row['session'];
  return value is String && RegExp(r'^[a-f0-9]{32}$').hasMatch(value)
      ? value
      : null;
}

int? _elapsed(Json row) {
  final value = row['elapsed_ms'];
  return value is int && value >= 0 && value <= _maximumExactMs ? value : null;
}

/// Identifiers are used only to select the current host attempt in memory.
/// Returned objects contain only four fixed codes and bounded integer timings.
List<DeskReadinessTiming> recentHostReadiness(
  List<Json> diagnostics, {
  List<Json> sessions = const [],
}) {
  final rows = diagnostics.length > 64
      ? diagnostics.sublist(diagnostics.length - 64)
      : diagnostics;
  String? selected;
  var start = -1;
  if (sessions.isNotEmpty) {
    final hosts = sessions.where((row) {
      final scope = row['session'];
      return row['role'] == 'host' &&
          const {'active', 'starting', 'reconnecting'}.contains(row['phase']) &&
          scope is Map &&
          _session({'session': scope['session_id']}) != null;
    }).toList();
    // Ambiguous/malformed or viewer-only state must not select an older host.
    if (hosts.length != 1) return const [];
    selected = (hosts.single['session'] as Map)['session_id'] as String;
    start = rows.lastIndexWhere(
      (row) =>
          _session(row) == selected &&
          row['role'] == 'host' &&
          row['event'] == 'engine_start' &&
          row['code'] == 'begin',
    );
  } else {
    // A late readiness row cannot become a new attempt's selection anchor.
    start = rows.lastIndexWhere(
      (row) =>
          _session(row) != null &&
          const {'host', 'viewer'}.contains(row['role']) &&
          row['event'] == 'engine_start' &&
          row['code'] == 'begin',
    );
    if (start < 0 || rows[start]['role'] != 'host') return const [];
    selected = _session(rows[start]);
  }
  final readings = rows
      .skip(start < 0 ? 0 : start)
      .where(
        (row) =>
            row['role'] == 'host' &&
            _session(row) == selected &&
            row['event'] == 'registration_readiness' &&
            (_modeCodes.contains(row['code']) ||
                _timingCodes.contains(row['code'])) &&
            _elapsed(row) != null,
      )
      .toList();
  final modes = readings
      .where((row) => _modeCodes.contains(row['code']) && _elapsed(row) == 0)
      .toList();
  if (modes.isEmpty || modes.map((row) => row['code']).toSet().length != 1) {
    return const [];
  }
  final mode = modes.first['code'] as String;
  final output = [DeskReadinessTiming(mode, 0)];
  if (mode == 'mode_legacy') return output;
  int? observed;
  int? accepted;
  for (final row in readings.skip(readings.indexOf(modes.first) + 1)) {
    if (row['code'] == 'registration_observed') observed ??= _elapsed(row);
    if (row['code'] == 'proof_accepted' && observed != null) {
      accepted ??= _elapsed(row);
    }
  }
  if (observed != null) {
    output.add(DeskReadinessTiming('registration_observed', observed));
    if (accepted != null && accepted >= observed) {
      output.add(DeskReadinessTiming('proof_accepted', accepted));
    }
  }
  return output;
}

class DeskReadinessSummary extends StatelessWidget {
  final List<Json> diagnostics;
  final List<Json> sessions;
  const DeskReadinessSummary({
    super.key,
    required this.diagnostics,
    this.sessions = const [],
  });

  @override
  Widget build(BuildContext context) {
    final timings = recentHostReadiness(diagnostics, sessions: sessions);
    const labels = {
      'mode_ack': '실제 등록 응답 확인 방식',
      'mode_legacy': '기존 대기 방식',
      'registration_observed': '등록 응답 관측',
      'proof_accepted': '서버 준비 확인',
    };
    return ExpansionTile(
      title: const Text('최근 호스트 등록 준비'),
      subtitle: const Text('전문 진단 · 이 PC에만 보관'),
      children: [
        if (timings.isEmpty)
          const ListTile(title: Text('선택한 호스트의 등록 준비 기록이 없습니다.')),
        for (final timing in timings)
          ListTile(
            dense: true,
            title: Text(labels[timing.code]!),
            subtitle: Text('${timing.code} · ${timing.elapsedMs} ms'),
          ),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 4, 16, 16),
          child: Text(
            '방식 선택의 0 ms는 등록 완료 시간이 아닙니다. 다른 값은 진단 시작부터의 경과 시간이며, '
            '등록 응답 관측에는 상태 확인 대기가 포함될 수 있습니다. 화면 표시 시간이나 입력 지연과는 다릅니다.',
          ),
        ),
      ],
    );
  }
}
