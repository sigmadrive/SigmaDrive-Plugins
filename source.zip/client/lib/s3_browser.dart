import 'dart:async';

import 'package:flutter/material.dart';

import 'api/api.dart';
import 'forms.dart';
import 'transfers.dart';

// S3 keys remain exact opaque identifiers. Folder rows are a presentation of prefixes only.
List<Json> s3Children(List<Json> objects, String prefix) {
  final dirs = <String>{};
  final files = <Json>[];
  for (final o in objects) {
    final key = text(o, 'key');
    if (!key.startsWith(prefix)) continue;
    final tail = key.substring(prefix.length);
    if (tail.isEmpty) continue;
    final slash = tail.indexOf('/');
    if (slash >= 0) {
      dirs.add(tail.substring(0, slash + 1));
    } else {
      files.add({...o, 'label': tail, 'directory': false});
    }
  }
  final result = <Json>[
    for (final d in dirs)
      {
        'label': d.substring(0, d.length - 1),
        'key': '$prefix$d',
        'directory': true,
      },
    ...files,
  ];
  result.sort(
    (a, b) => a['directory'] == b['directory']
        ? text(a, 'label').compareTo(text(b, 'label'))
        : a['directory'] == true
        ? -1
        : 1,
  );
  return result;
}

class S3Browser extends StatefulWidget {
  final CoreTransport api;
  final Json share;
  final String pin, device;
  const S3Browser({
    super.key,
    required this.api,
    required this.share,
    required this.pin,
    required this.device,
  });
  @override
  State<S3Browser> createState() => _S3BrowserState();
}

class _S3BrowserState extends State<S3Browser> {
  List<Json> objects = [], jobs = [];
  String prefix = '', continuation = '', bucket = '', endpoint = '';
  String? error, message;
  bool busy = false, writable = false, checking = false;
  Timer? timer;
  Json request(String action, [Json extra = const {}]) => {
    'action': action,
    'share': widget.share['id'],
    'peer_pin': widget.pin,
    ...extra,
  };
  @override
  void initState() {
    super.initState();
    unawaited(load());
    timer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => unawaited(poll()),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> poll() async {
    if (busy || checking || !mounted) return;
    checking = true;
    try {
      final result = await widget.api.call('ManageS3Browser', {
        'action': 'status',
      });
      if (mounted) {
        setState(
          () => jobs = rows(
            result,
            'downloads',
          ).where((j) => j['share'] == widget.share['id']).toList(),
        );
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      checking = false;
    }
  }

  Future<void> load({bool more = false}) async {
    if (busy || !mounted) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.api.call(
        'ManageS3Browser',
        request('list', {'continuation': more ? continuation : ''}),
      );
      if (!mounted) return;
      setState(() {
        final merged = <String, Json>{
          if (more)
            for (final o in objects) text(o, 'key'): o,
          for (final o in rows(result, 'objects')) text(o, 'key'): o,
        };
        objects = merged.values.toList();
        continuation = text(result, 'continuation');
        bucket = text(result, 'bucket');
        endpoint = text(result, 'endpoint');
        writable = result['writable'] == true;
        jobs = rows(
          result,
          'downloads',
        ).where((j) => j['share'] == widget.share['id']).toList();
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          error = e.toString();
          writable = false;
          objects = [];
        });
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> action(String rpc, Json body) async {
    if (busy || !mounted) return;
    setState(() {
      busy = true;
      error = null;
      message = null;
    });
    try {
      final result = await widget.api.call(rpc, body);
      if (mounted) {
        setState(() {
          jobs = rows(
            result,
            'downloads',
          ).where((j) => j['share'] == widget.share['id']).toList();
          message = '요청을 처리했습니다. 완료 여부와 자원 해제 상태는 아래 전송 목록에서 확인하세요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> transfer({Json? object}) async {
    final draft = await showDialog<Json>(
      context: context,
      builder: (_) => S3TransferForm(
        upload: object == null,
        objectKey: object == null ? prefix : text(object, 'key'),
      ),
    );
    if (draft == null || !mounted) return;
    await action(
      'ManageS3Browser',
      request(object == null ? 'upload' : 'download', draft),
    );
  }

  Future<void> remove(Json object) async {
    if (!await confirm(
      context,
      '버킷 $bucket에서 ${text(object, 'key')} 파일을 삭제할까요? 이 작업은 되돌리지 못할 수 있습니다. 목록에서 확인한 파일 버전이 바뀌면 삭제를 거부합니다.',
    )) {
      return;
    }
    await action(
      'ManageS3Browser',
      request('delete', {'key': object['key'], 'etag': object['etag']}),
    );
    if (mounted) await load();
  }

  @override
  Widget build(BuildContext context) => Dialog(
    child: SizedBox(
      width: 1000,
      height: 760,
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${shareName(widget.share)} · ${widget.device}',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            Text(
              '버킷 ${bucket.isEmpty ? '확인 중' : bucket} · ${writable ? '읽기·쓰기' : '읽기 전용'}',
            ),
            if (endpoint.isNotEmpty) SelectableText(endpoint),
            Text(prefix.isEmpty ? '/' : prefix),
            Wrap(
              spacing: 8,
              children: [
                OutlinedButton(
                  onPressed: busy || prefix.isEmpty
                      ? null
                      : () => setState(() {
                          final parts = prefix.split('/')
                            ..removeLast()
                            ..removeLast();
                          prefix = parts.isEmpty ? '' : '${parts.join('/')}/';
                        }),
                  child: const Text('상위 폴더'),
                ),
                OutlinedButton(
                  onPressed: busy ? null : () => load(),
                  child: const Text('목록 새로고침'),
                ),
                OutlinedButton(
                  onPressed: busy || !writable ? null : () => transfer(),
                  child: const Text('파일 업로드'),
                ),
                if (continuation.isNotEmpty)
                  OutlinedButton(
                    onPressed: busy ? null : () => load(more: true),
                    child: const Text('추가 목록 불러오기'),
                  ),
              ],
            ),
            if (busy) const LinearProgressIndicator(),
            if (error != null)
              SelectableText(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            if (message != null) Text(message!),
            const Text(
              '전송 상세 정보는 이 PC에만 보관합니다. 창을 닫아도 전송은 계속되며 전송 메뉴에서 중단·재개할 수 있습니다.',
            ),
            Expanded(
              child: ListView(
                children: [
                  for (final o in s3Children(objects, prefix))
                    ListTile(
                      leading: Icon(
                        o['directory'] == true
                            ? Icons.folder_outlined
                            : Icons.description_outlined,
                      ),
                      title: Text(text(o, 'label')),
                      subtitle: o['directory'] == true
                          ? const Text('폴더')
                          : Text(bytes((o['bytes'] ?? o['size']) as num?)),
                      onTap: busy
                          ? null
                          : o['directory'] == true
                          ? () => setState(() => prefix = text(o, 'key'))
                          : null,
                      trailing: o['directory'] == true
                          ? null
                          : Wrap(
                              children: [
                                IconButton(
                                  tooltip: '다운로드',
                                  onPressed: busy
                                      ? null
                                      : () => transfer(object: o),
                                  icon: const Icon(Icons.download_outlined),
                                ),
                                IconButton(
                                  tooltip: '이 버전의 파일 삭제',
                                  onPressed:
                                      busy ||
                                          !writable ||
                                          text(o, 'etag').isEmpty
                                      ? null
                                      : () => remove(o),
                                  icon: const Icon(Icons.delete_outline),
                                ),
                              ],
                            ),
                    ),
                  if (objects.isEmpty && !busy && error == null)
                    const ListTile(title: Text('표시할 파일이 없습니다.')),
                  for (final job in jobs.reversed)
                    TransferCard(
                      job: job,
                      shareName:
                          '${shareName(widget.share)} · ${widget.device} · $bucket',
                      rpc: 'ManageS3Browser',
                      onAction: action,
                      busy: busy,
                    ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('닫기'),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class S3TransferForm extends StatefulWidget {
  final bool upload;
  final String objectKey;
  const S3TransferForm({
    super.key,
    required this.upload,
    required this.objectKey,
  });
  @override
  State<S3TransferForm> createState() => _S3TransferFormState();
}

class _S3TransferFormState extends State<S3TransferForm> {
  final form = GlobalKey<FormState>();
  final local = TextEditingController(),
      rate = TextEditingController(text: '0');
  late final keyName = TextEditingController(text: widget.objectKey);
  @override
  void dispose() {
    local.dispose();
    rate.dispose();
    keyName.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.upload ? '새 파일 업로드' : '파일 다운로드'),
    content: SizedBox(
      width: 580,
      child: SingleChildScrollView(
        child: Form(
          key: form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: local,
                decoration: InputDecoration(
                  labelText: widget.upload
                      ? '이 PC의 원본 파일 전체 경로'
                      : '이 PC에 저장할 파일의 전체 경로',
                ),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? '경로를 입력하세요.' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: keyName,
                readOnly: !widget.upload,
                decoration: const InputDecoration(labelText: '버킷 안의 파일 경로'),
                validator: (v) =>
                    v == null || v.trim().isEmpty || v.endsWith('/')
                    ? '파일 이름까지 입력하세요.'
                    : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: rate,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: '속도 제한 MiB/s · 0은 제한 없음',
                ),
                validator: (v) {
                  final n = double.tryParse(v ?? '');
                  return n == null || !n.isFinite || n < 0 || n > 1048576
                      ? '0 이상의 속도를 입력하세요.'
                      : null;
                },
              ),
              const SizedBox(height: 12),
              if (widget.upload) const Text('업로드할 폴더는 제공 PC에 미리 있어야 합니다.'),
              const Text(
                '기존 파일은 덮어쓰지 않습니다. 중단 시 원본과 부분 파일을 보존하며 재개할 때 권한을 다시 검사합니다.',
              ),
            ],
          ),
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: () {
          if (form.currentState!.validate()) {
            Navigator.pop(context, <String, dynamic>{
              widget.upload ? 'source' : 'destination': local.text.trim(),
              'key': keyName.text.trim(),
              'bytes_per_second': (double.parse(rate.text) * 1048576).round(),
            });
          }
        },
        child: Text(widget.upload ? '업로드 시작' : '다운로드 시작'),
      ),
    ],
  );
}
