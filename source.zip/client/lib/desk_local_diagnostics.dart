import 'package:flutter/material.dart';

import 'api/api.dart';

/// UI for one explicit, local-only gesture. It never changes remote access or
/// receiving preferences, opens a URL, starts a timer or writes a setting.
class DeskLocalDiagnosticsCard extends StatelessWidget {
  final Json status;
  final bool busy;
  final bool sessionActive;
  final Future<void> Function(Json body) onAction;
  const DeskLocalDiagnosticsCard({
    super.key,
    required this.status,
    required this.busy,
    required this.sessionActive,
    required this.onAction,
  });

  static const notice =
      '다음 원격 접속 1회에서 캡처·인코딩·로컬 전송의 시간과 횟수 같은 숫자만 이 PC에 남깁니다. 화면·입력 내용·파일·URL·계정 정보는 수집하지 않으며 서버로 보내지 않습니다. 접속이 끝나면 진단도 자동 종료됩니다. 60분 안에 접속하지 않으면 대기 동의가 만료됩니다. 원격 접속 허용과 공유 권한은 바뀌지 않습니다.';

  @override
  Widget build(BuildContext context) {
    final code = status['state_code'];
    final remaining = status['remaining_ms'];
    final valid =
        status['schema'] == 1 &&
        code is int &&
        code >= 0 &&
        code <= 4 &&
        remaining is int &&
        remaining >= 0 &&
        remaining <= 3600000 &&
        [0, 1].contains(status['pin_ready']);
    final state = valid ? code : 4;
    final pinReady = valid && status['pin_ready'] == 1;
    final description = switch (state) {
      1 => '다음 접속 1회 진단 대기 · 남은 ${((remaining as int) + 59999) ~/ 60000}분',
      2 => '1회 진단 선택이 사용됐습니다. 해당 접속이 끝나면 진단도 자동 종료됩니다.',
      3 => '대기 동의가 만료됐습니다. 기본값은 진단 꺼짐입니다.',
      4 => '로컬 진단 상태를 확인할 수 없습니다. 진단은 켜지지 않습니다.',
      _ => '기본값은 진단 꺼짐입니다.',
    };
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('PC 전용 성능 진단', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(description),
            if (!pinReady)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('검토된 새 진단 엔진이 준비되기 전에는 사용할 수 없습니다.'),
              ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: busy || sessionActive || !pinReady || state == 1
                  ? null
                  : () async {
                      final accepted = await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('다음 접속 1회 성능 진단'),
                          content: const Text(notice),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(ctx, false),
                              child: const Text('취소'),
                            ),
                            FilledButton(
                              onPressed: () => Navigator.pop(ctx, true),
                              child: const Text('이 PC에서 1회 진단'),
                            ),
                          ],
                        ),
                      );
                      if (accepted == true) {
                        await onAction({
                          'action': 'desk-diagnostics-arm',
                          'name': 'local_numeric_once',
                        });
                      }
                    },
              child: const Text('다음 접속 1회 성능 진단'),
            ),
            if (state == 1)
              TextButton(
                onPressed: busy
                    ? null
                    : () => onAction({'action': 'desk-diagnostics-cancel'}),
                child: const Text('대기 진단 취소'),
              ),
          ],
        ),
      ),
    );
  }
}
