import 'package:flutter/material.dart';

import 'api/api.dart';

/// UI for one explicit, local-only gesture. It never changes remote access or
/// receiving preferences, opens a URL, starts a timer or writes a setting.
class DeskLocalDiagnosticsCard extends StatelessWidget {
  final Json status;
  final bool busy;
  final bool sessionActive;
  final Future<void> Function(Json body) onAction;
  const DeskLocalDiagnosticsCard({
    super.key,
    required this.status,
    required this.busy,
    required this.sessionActive,
    required this.onAction,
  });

  static const notice =
      '다음 원격 접속 1회에서 캡처·인코딩·로컬 전송의 시간과 횟수 같은 숫자만 이 PC에 남깁니다. 화면·입력 내용·파일·URL·계정 정보는 수집하지 않으며 서버로 보내지 않습니다. 접속이 끝나면 진단도 자동 종료됩니다. 60분 안에 접속하지 않으면 대기 동의가 만료됩니다. 원격 접속 허용과 공유 권한은 바뀌지 않습니다.';

  @override
  Widget build(BuildContext context) {
    final code = status['state_code'];
    final remaining = status['remaining_ms'];
    final pin = status['pin_ready'];
    // The original schema has four numeric fields. Absence alone keeps its
    // default reason; an explicitly malformed or unknown new reason fails shut.
    final legacyReason = !status.containsKey('reason_code');
    final reason = legacyReason ? 0 : status['reason_code'];
    final valid =
        status['schema'] is int &&
        status['schema'] == 1 &&
        code is int &&
        code >= 0 &&
        code <= 4 &&
        remaining is int &&
        remaining >= 0 &&
        remaining <= 3600000 &&
        pin is int &&
        (pin == 0 || pin == 1) &&
        reason is int &&
        reason >= 0 &&
        reason <= 4 &&
        (code == 1 || remaining == 0) &&
        switch (code) {
          0 => [0, 1, 3, 4].contains(reason),
          1 || 2 || 4 => reason == 0,
          3 => reason == 2 || (legacyReason && reason == 0),
          _ => false,
        };
    final state = valid ? code : 4;
    final pinReady = valid && pin == 1;
    final description = valid && (reason == 3 || reason == 4)
        ? '환경 변경으로 1회 진단 동의가 취소되었습니다. 다시 진단하려면 현재 환경에서 새로 동의하세요.'
        : switch (state) {
            1 =>
              '다음 접속 1회 진단 대기 · 남은 ${((remaining as int) + 59999) ~/ 60000}분',
            2 =>
              '1회 진단 선택이 접속 준비에 사용됐습니다. 실제 기록 여부는 접속 결과와 이 PC의 진단 기록에서 확인하세요.',
            3 => '대기 동의가 만료됐습니다. 새 진단을 시작하려면 다시 동의하세요.',
            4 => '로컬 진단 상태를 확인할 수 없습니다. 이 상태에서는 새 진단을 켤 수 없습니다.',
            _ =>
              reason == 1
                  ? '대기 중인 1회 진단 동의를 취소했습니다. 진단은 기본적으로 꺼져 있습니다.'
                  : '기본값은 진단 꺼짐입니다.',
          };
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('PC 전용 성능 진단', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(description),
            if (valid && !pinReady)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('검토된 새 진단 엔진이 준비되기 전에는 사용할 수 없습니다.'),
              ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed:
                  busy || sessionActive || !pinReady || state == 1 || state == 4
                  ? null
                  : () async {
                      final accepted = await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('다음 접속 1회 성능 진단'),
                          content: const Text(notice),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(ctx, false),
                              child: const Text('취소'),
                            ),
                            FilledButton(
                              onPressed: () => Navigator.pop(ctx, true),
                              child: const Text('이 PC에서 1회 진단'),
                            ),
                          ],
                        ),
                      );
                      if (accepted == true) {
                        await onAction({
                          'action': 'desk-diagnostics-arm',
                          'name': 'local_numeric_once',
                        });
                      }
                    },
              child: const Text('다음 접속 1회 성능 진단'),
            ),
            if (state == 1)
              TextButton(
                onPressed: busy
                    ? null
                    : () => onAction({'action': 'desk-diagnostics-cancel'}),
                child: const Text('대기 진단 취소'),
              ),
          ],
        ),
      ),
    );
  }
}
