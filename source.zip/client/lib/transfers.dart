import 'package:flutter/material.dart';

import 'api/api.dart';

String transferState(String state) => switch (state) {
  'downloading' || 'receiving' => '다운로드 중',
  'uploading' || 'publishing' => '업로드 중',
  'pausing' => '중단·자원 정리 중',
  'paused' => '일시 중단',
  'complete' => '완료',
  'update_required' => '업데이트 필요',
  _ => state,
};
bool canPauseTransfer(Json job) =>
    job['resources_released'] != true &&
    [
      'downloading',
      'uploading',
      'receiving',
      'publishing',
    ].contains(job['state']);
bool canResumeTransfer(Json job) =>
    job['resources_released'] == true && job['state'] == 'paused';

class TransferCard extends StatelessWidget {
  final Json job;
  final String rpc;
  final bool busy;
  final Future<void> Function(String, Json) onAction;
  final String? shareName;
  const TransferCard({
    super.key,
    required this.job,
    required this.rpc,
    required this.onAction,
    this.busy = false,
    this.shareName,
  });
  @override
  Widget build(BuildContext context) {
    final done =
        (job['completed_bytes'] as num? ?? job['verified_bytes'] as num? ?? 0)
            .toDouble();
    final total = (job['total_bytes'] as num? ?? 0).toDouble();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${job['direction'] == 'upload' ? '↑ 업로드' : '↓ 다운로드'} · ${text(job, 'key', text(job, 'id'))}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            if (shareName != null || text(job, 'share').isNotEmpty)
              Text(shareName ?? '공유 ${text(job, 'share')}'),
            Text(
              '${transferState(text(job, 'state'))} · ${bytes(done)}/${bytes(total)}',
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: total > 0
                  ? (done / total).clamp(0, 1)
                  : (job['state'] == 'complete' ? 1 : null),
            ),
            const SizedBox(height: 8),
            Text(
              job['resources_released'] == true
                  ? (job['state'] == 'complete'
                        ? '작업 자원 해제됨'
                        : '작업 자원 해제됨 · 재개 기록은 이 PC에 보관됩니다.')
                  : '작업 자원 사용 중',
            ),
            if (text(job, 'destination').isNotEmpty)
              SelectableText('PC 파일: ${text(job, 'destination')}'),
            if (text(job, 'error').isNotEmpty)
              SelectableText(
                text(job, 'error'),
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            if (job['state'] == 'complete' && text(job, 'sha256').isNotEmpty)
              SelectableText('파일 검증 SHA-256: ${text(job, 'sha256')}'),
            Wrap(
              spacing: 8,
              children: [
                OutlinedButton(
                  onPressed: !busy && canPauseTransfer(job)
                      ? () =>
                            onAction(rpc, {'action': 'pause', 'id': job['id']})
                      : null,
                  child: const Text('일시 중단'),
                ),
                OutlinedButton(
                  onPressed: !busy && canResumeTransfer(job)
                      ? () =>
                            onAction(rpc, {'action': 'resume', 'id': job['id']})
                      : null,
                  child: const Text('중단 지점부터 재개'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
