#include <flutter/dart_project.h>
#include <flutter/flutter_view_controller.h>
#include <windows.h>

#include "flutter_window.h"
#include "utils.h"

int APIENTRY wWinMain(_In_ HINSTANCE instance, _In_opt_ HINSTANCE prev,
                      _In_ wchar_t *command_line, _In_ int show_command) {
  // Attach to console when present (e.g., 'flutter run') or create a
  // new console when running with a debugger.
  if (!::AttachConsole(ATTACH_PARENT_PROCESS) && ::IsDebuggerPresent()) {
    CreateAndAttachConsole();
  }

  // Initialize COM, so that it is available for use in the library and/or
  // plugins.
  ::CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

  const auto arguments = GetCommandLineArguments();
  if (!arguments.empty() && arguments[0] == "--sigma-update-worker") {
    // Thin OS entry point only; Rust owns validation, handoff and activation.
    wchar_t executable[32768];
    const auto count = GetModuleFileNameW(nullptr, executable, 32768);
    if (count == 0 || count >= 32768) return EXIT_FAILURE;
    std::wstring library(executable, count);
    library = library.substr(0, library.find_last_of(L"\\/") + 1) + L"sigmadrive_core.dll";
    const auto core = LoadLibraryExW(library.c_str(), nullptr,
        LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if (!core) return EXIT_FAILURE;
    using Worker = unsigned int (*)();
    const auto worker = reinterpret_cast<Worker>(GetProcAddress(core, "sigma_core_update_worker"));
    const auto result = worker ? worker() : EXIT_FAILURE;
    FreeLibrary(core);
    ::CoUninitialize();
    return static_cast<int>(result);
  }

  flutter::DartProject project(L"data");

  std::vector<std::string> command_line_arguments =
      GetCommandLineArguments();

  project.set_dart_entrypoint_arguments(std::move(command_line_arguments));

  FlutterWindow window(project);
  Win32Window::Point origin(10, 10);
  Win32Window::Size size(1280, 720);
  if (!window.Create(L"SigmaDrive Rust Preview", origin, size)) {
    return EXIT_FAILURE;
  }
  window.SetQuitOnClose(true);

  ::MSG msg;
  while (::GetMessage(&msg, nullptr, 0, 0)) {
    ::TranslateMessage(&msg);
    ::DispatchMessage(&msg);
  }

  ::CoUninitialize();
  return EXIT_SUCCESS;
}
