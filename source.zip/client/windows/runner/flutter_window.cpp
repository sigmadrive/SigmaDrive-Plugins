#include "flutter_window.h"

#include <optional>

#include "flutter/generated_plugin_registrant.h"

namespace {
constexpr UINT_PTR kRustUpdateTimer = 0x5344;
}

FlutterWindow::FlutterWindow(const flutter::DartProject& project)
    : project_(project) {}

FlutterWindow::~FlutterWindow() {}

bool FlutterWindow::OnCreate() {
  if (!Win32Window::OnCreate()) {
    return false;
  }

  RECT frame = GetClientArea();

  // The size here must match the window dimensions to avoid unnecessary surface
  // creation / destruction in the startup path.
  flutter_controller_ = std::make_unique<flutter::FlutterViewController>(
      frame.right - frame.left, frame.bottom - frame.top, project_);
  // Ensure that basic setup of the controller was successful.
  if (!flutter_controller_->engine() || !flutter_controller_->view()) {
    return false;
  }
  RegisterPlugins(flutter_controller_->engine());
  SetChildContent(flutter_controller_->view()->GetNativeWindow());

  flutter_controller_->engine()->SetNextFrameCallback([&]() {
    this->Show();
  });

  // Flutter can complete the first frame before the "show window" callback is
  // registered. The following call ensures a frame is pending to ensure the
  // window is shown. It is a no-op if the first frame hasn't completed yet.
  flutter_controller_->ForceRedraw();

  // Windows lifecycle glue only. Flutter's SystemNavigator.pop does not
  // guarantee closing a Windows process. Rust alone authorizes update exit
  // after draining handles, jobs, leases and publication. Retry if a status
  // call is still in flight; never terminate a process or bypass WM_CLOSE.
  if (!SetTimer(GetHandle(), kRustUpdateTimer, 500, nullptr)) {
    return false;
  }

  return true;
}

void FlutterWindow::OnDestroy() {
  KillTimer(GetHandle(), kRustUpdateTimer);
  if (flutter_controller_) {
    flutter_controller_ = nullptr;
  }

  Win32Window::OnDestroy();
}

LRESULT
FlutterWindow::MessageHandler(HWND hwnd, UINT const message,
                              WPARAM const wparam,
                              LPARAM const lparam) noexcept {
  if (message == WM_TIMER && wparam == kRustUpdateTimer) {
    const auto core = GetModuleHandleW(L"sigmadrive_core.dll");
    if (core) {
      using Ready = unsigned int (*)();
      const auto ready = reinterpret_cast<Ready>(
          GetProcAddress(core, "sigma_core_update_exit_ready"));
      if (ready && ready() == 1) {
        PostMessageW(hwnd, WM_CLOSE, 0, 0);
      }
    }
    return 0;
  }
  if (message == WM_CLOSE) {
    // Thin OS glue only. Rust owns the lifecycle decision; no extra daemon.
    const auto core = GetModuleHandleW(L"sigmadrive_core.dll");
    if (core) {
      using CanExit = unsigned int (*)();
      const auto can_exit = reinterpret_cast<CanExit>(
          GetProcAddress(core, "sigma_core_can_exit"));
      if (!can_exit || can_exit() == 0) {
        ShowWindow(hwnd, SW_MINIMIZE);
        return 0;
      }
    }
  }
  // Give Flutter, including plugins, an opportunity to handle window messages.
  if (flutter_controller_) {
    std::optional<LRESULT> result =
        flutter_controller_->HandleTopLevelWindowProc(hwnd, message, wparam,
                                                      lparam);
    if (result) {
      return *result;
    }
  }

  switch (message) {
    case WM_FONTCHANGE:
      flutter_controller_->engine()->ReloadSystemFonts();
      break;
  }

  return Win32Window::MessageHandler(hwnd, message, wparam, lparam);
}
