import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/s3_browser.dart';
import 'package:sigmadrive_flutter/share_permissions.dart';
import 'package:sigmadrive_flutter/share_connectivity.dart';
import 'package:sigmadrive_flutter/transfers.dart';

class S3Fixture implements CoreTransport {
  final calls = <Json>[];
  final List<Json> objects;
  S3Fixture({
    this.objects = const [
      {'key': '자료/한글.txt', 'bytes': 12, 'etag': '"e"'},
    ],
  });
  bool denied = false;
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    calls.add({'rpc': rpc, ...body});
    if (body['action'] == 'list') {
      if (denied) throw StateError('permission revoked');
      return {
        'bucket': 'read-only',
        'endpoint': 'https://qa.invalid',
        'writable': false,
        'objects': objects,
      };
    }
    return {'downloads': <Json>[]};
  }

  @override
  Future<void> openUrl(String url) async {}
}

class TrustFixture extends S3Fixture {
  Json trust;
  TrustFixture(this.trust);
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    if (body['action'] == 'receiver-trust') {
      calls.add({'rpc': rpc, ...body});
      return trust;
    }
    return super.call(rpc, body);
  }
}

void main() {
  test('Relay contact is distinct from directory online and unknown is not offline', () {
    expect(shareConnectivityLabel({'online': false}), '실제 접속 확인 전');
    expect(shareConnectivityLabel({'online': true}), contains('실제 접속 확인 전'));
    expect(
      shareConnectivityLabel({
        'online': false,
        'connectivity': {'state': 'verified'},
      }),
      contains('접속 확인됨'),
    );
    expect(
      shareConnectivityLabel({
        'online': true,
        'connectivity': {'state': 'unreachable'},
      }),
      contains('최근 연결 실패'),
    );
    expect(
      shareConnectivityLabel({
        'online': true,
        'connectivity': {'state': 'access_denied'},
      }),
      '접속 권한 확인 필요',
    );
    expect(
      shareConnectivityLabel({
        'connectivity': {'state': 'approval_required'},
      }),
      '장치 승인 필요',
    );
  });
  test(
    'Reopening a locally trusted share needs no confirmation or new approval',
    () async {
      final pin = List.filled(64, 'a').join();
      final api = TrustFixture({
        'trusted': true,
        'share': 's1',
        'publisher': 'p1',
        'peer_pin': pin,
      });
      var confirms = 0;
      final identity = await receiverIdentity(
        api,
        {'id': 's1', 'publisher': 'p1', 'peer_pin': 'untrusted directory pin'},
        () async {
          confirms++;
          return null;
        },
      );
      expect(identity, (pin: pin, confirmed: false));
      expect(confirms, 0);
      expect(api.calls.single['action'], 'receiver-trust');
    },
  );
  test(
    'Missing, changed or revoked device trust requires explicit confirmation',
    () async {
      final pin = List.filled(64, 'b').join();
      for (final trust in <Json>[
        {'trusted': false},
        {'trusted': true, 'share': 'other', 'publisher': 'p1', 'peer_pin': pin},
        {'trusted': true, 'share': 's1', 'publisher': 'other', 'peer_pin': pin},
        {'trusted': true, 'share': 's1', 'publisher': 'p1', 'peer_pin': 'bad'},
      ]) {
        var confirms = 0;
        final identity = await receiverIdentity(
          TrustFixture(trust),
          {'id': 's1', 'publisher': 'p1'},
          () async {
            confirms++;
            return null;
          },
        );
        expect(identity, isNull);
        expect(confirms, 1);
      }
      expect(
        await receiverIdentity(TrustFixture({'trusted': false}), {
          'id': 's1',
          'publisher': 'p1',
        }, () async => pin),
        (pin: pin, confirmed: true),
      );
    },
  );
  test(
    'Bucket naming matches the core and unnamed shares remain distinguishable',
    () {
      expect(validShareBucket('documents-qa'), true);
      for (final invalid in [
        'a',
        'ab',
        'UPPER',
        'docs.photos',
        '-bad',
        'bad-',
      ]) {
        expect(validShareBucket(invalid), false);
      }
      expect(
        shareLabel(
          {'id': 'a', 'name': '', 'publisher': 'pc'},
          {'pc': 'Laptop'},
        ),
        '공유 a · Laptop',
      );
    },
  );
  test('S3 prefix presentation preserves exact keys and folder boundaries', () {
    final rows = s3Children([
      {'key': 'a/한글.txt'},
      {'key': 'ab/other.txt'},
      {'key': 'a/deep/x.txt'},
    ], 'a/');
    expect(rows.map((r) => r['key']), ['a/deep/', 'a/한글.txt']);
    expect(rows.last['directory'], false);
  });
  test('Write permissions are a subset of read and preserve immutable share identity', () {
    final body = shareSaveRequest(
      {
        'id': 'share-a',
        'folder': 'D:\\qa',
        'name': 'same',
        'protocol': 's3',
        's3_bucket': 'bucket-a',
        's3_relay': true,
      },
      ['member-a'],
      ['member-a', 'member-b'],
    );
    expect(body['write_grants'], ['member-a']);
    expect(body['id'], 'share-a');
    expect(body['folder'], 'D:\\qa');
    expect(body['s3_relay'], true);
  });
  test('Pause/resume waits for actual release and never resumes completed or revoked work automatically', () {
    expect(
      canPauseTransfer({'state': 'uploading', 'resources_released': false}),
      true,
    );
    expect(
      canResumeTransfer({'state': 'pausing', 'resources_released': false}),
      false,
    );
    expect(
      canResumeTransfer({'state': 'paused', 'resources_released': false}),
      false,
    );
    expect(
      canResumeTransfer({'state': 'paused', 'resources_released': true}),
      true,
    );
    expect(
      canResumeTransfer({'state': 'complete', 'resources_released': true}),
      false,
    );
  });
  testWidgets(
    'Rust S3 size is displayed and download asks for a complete file path',
    (tester) async {
      tester.view.physicalSize = const Size(1300, 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final api = S3Fixture(
        objects: [
          {'key': 'payload.bin', 'size': 4194304, 'etag': '"rust"'},
        ],
      );
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: S3Browser(
              api: api,
              share: {'id': 'share-a'},
              pin: 'verified',
              device: 'Laptop',
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('0 B'), findsNothing);
      expect(find.textContaining('4.0 MiB'), findsOneWidget);
      await tester.tap(find.byTooltip('다운로드'));
      await tester.pumpAndSettle();
      expect(find.text('이 PC에 저장할 파일의 전체 경로'), findsOneWidget);
      expect(find.text('이 PC의 저장 폴더 전체 경로'), findsNothing);
      await tester.enterText(
        find.byType(TextFormField).first,
        r'C:\QA\received-payload.bin',
      );
      await tester.tap(find.text('다운로드 시작'));
      await tester.pumpAndSettle();
      final download = api.calls.singleWhere((c) => c['action'] == 'download');
      expect(download['destination'], r'C:\QA\received-payload.bin');
      expect(download['key'], 'payload.bin');
      await tester.pumpWidget(const SizedBox());
    },
  );
  testWidgets(
    'Read-only S3 disables upload; revocation clears previously listed objects',
    (tester) async {
      tester.view.physicalSize = const Size(1300, 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final api = S3Fixture();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: S3Browser(
              api: api,
              share: {'id': 'share-a', 'name': 'Documents'},
              pin: 'verified',
              device: 'Laptop',
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(
        tester
            .widget<OutlinedButton>(
              find.widgetWithText(OutlinedButton, '파일 업로드'),
            )
            .onPressed,
        isNull,
      );
      expect(find.text('자료'), findsOneWidget);
      api.denied = true;
      await tester.tap(find.text('목록 새로고침'));
      await tester.pumpAndSettle();
      expect(find.text('자료'), findsNothing);
      expect(find.textContaining('permission revoked'), findsOneWidget);
      expect(api.calls.every((c) => c['action'] != 'upload'), true);
      await tester.pumpWidget(const SizedBox());
    },
  );
}
