import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/forms.dart';
import 'package:sigmadrive_flutter/main.dart';

class FixtureTransport implements CoreTransport {
  final requests = <String>[];
  Completer<Json>? delayed;
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    requests.add(rpc);
    if (rpc == 'GetStatus' && delayed != null) return delayed!.future;
    return switch (rpc) {
      'GetStatus' => {
        'version': 'fixture',
        'profile_name': '시험 프로필',
        'mounted_drives': 0,
      },
      'GetSettings' => {'device_name': '한글 장치', 'language': 'ko'},
      'ListConnections' => {'connections': <Json>[]},
      'ListDrives' => {'drives': <Json>[]},
      'ListDriveLetters' => {
        'free': ['Q:'],
      },
      _ => {},
    };
  }

  @override
  Future<void> openUrl(String url) async {}
}

class MultiDeskFixture extends FixtureTransport {
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    if (rpc == 'ManageTeamShare' && body['action'] == 'desk-status') {
      return {
        'desk_json': jsonEncode({
          'node': 'own-node',
          'member': 'own-member',
          'sessions': [
            {
              'phase': 'active',
              'session': {'session_id': 'approval-a'},
              'processes': 1,
              'connections': 1,
            },
            {
              'phase': 'active',
              'session': {'session_id': 'approval-b'},
              'processes': 1,
              'connections': 1,
            },
          ],
          'devices': [],
          'requests': [],
        }),
      };
    }
    return super.call(rpc, body);
  }
}

class OwnedDeskFixture extends FixtureTransport {
  final String? member;
  final String? hostMember;
  final bool allowOwned;
  final calls = <Json>[];
  OwnedDeskFixture({this.member, this.hostMember, this.allowOwned = false});
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    if (rpc == 'ManageTeamShare' &&
        (body['action'] as String? ?? '').startsWith('desk-')) {
      calls.add(Map<String, dynamic>.from(body));
      return {
        'desk_json': jsonEncode({
          'node': 'this-pc',
          'member': member,
          'allow_owned': allowOwned,
          'browser_enabled': true,
          'devices': [
            {
              'node': 'host-pc',
              'name': 'Test host',
              'member': hostMember,
              'allow_owned': allowOwned,
              'enabled': true,
              'online': true,
            },
          ],
        }),
      };
    }
    return super.call(rpc, body);
  }
}

void main() {
  testWidgets('Owned host uses direct connect without a per-session approval', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1400, 1600);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final api = OwnedDeskFixture(
      member: 'member-a',
      hostMember: 'member-a',
      allowOwned: true,
    );
    await tester.pumpWidget(SigmaDriveApp(api: api));
    await tester.pumpAndSettle();
    await tester.tap(find.text('SigmaDesk').first);
    await tester.pumpAndSettle();
    expect(find.textContaining('매번 승인 없이 브라우저 안에서 접속'), findsOneWidget);
    await tester.ensureVisible(find.text('바로 원격 제어'));
    await tester.tap(find.text('바로 원격 제어'));
    await tester.pumpAndSettle();
    expect(api.calls.where((c) => c['action'] == 'desk-connect').single, {
      'action': 'desk-connect',
      'id': 'host-pc',
      'name': 'control',
    });
    expect(api.calls.any((c) => c['action'] == 'desk-approve'), false);
    await tester.pumpWidget(const SizedBox());
  });
  testWidgets(
    'Foreign, absent identity and unconsented hosts retain requests',
    (tester) async {
      tester.view.physicalSize = const Size(1400, 1600);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      for (final api in [
        OwnedDeskFixture(member: 'a', hostMember: 'b', allowOwned: true),
        OwnedDeskFixture(allowOwned: true),
        OwnedDeskFixture(member: 'a', hostMember: 'a'),
      ]) {
        await tester.pumpWidget(SigmaDriveApp(api: api));
        await tester.pumpAndSettle();
        await tester.tap(find.text('SigmaDesk').first);
        await tester.pumpAndSettle();
        expect(find.text('바로 원격 제어'), findsNothing);
        await tester.ensureVisible(find.text('입력 제어 요청'));
        await tester.tap(find.text('입력 제어 요청'));
        await tester.pumpAndSettle();
        expect(api.calls.where((c) => c['action'] == 'desk-request').single, {
          'action': 'desk-request',
          'id': 'host-pc',
          'name': 'control',
        });
        expect(api.calls.any((c) => c['action'] == 'desk-connect'), false);
        await tester.pumpWidget(const SizedBox());
      }
    },
  );
  testWidgets('Concurrent desk approvals have distinct visible session rows', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1400, 1200);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(SigmaDriveApp(api: MultiDeskFixture()));
    await tester.pumpAndSettle();
    await tester.tap(find.text('SigmaDesk').first);
    await tester.pumpAndSettle();
    expect(find.text('원격 연결 2개'), findsOneWidget);
    expect(find.text('연결 approval-a'), findsOneWidget);
    expect(find.text('연결 approval-b'), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
  });
  test('Profile-only storage cannot become a file or composite drive', () {
    expect(isFileConnection({'preset': 'profile'}), false);
    expect(
      isFileConnection({
        'options': {'sigma_profile_only': 'true'},
      }),
      false,
    );
    expect(
      isFileConnection({'provider': 'sigma-share'}, composite: true),
      false,
    );
    expect(isFileConnection({'provider': 'drive'}), true);
  });
  test('Identical share names are labeled by publisher device', () {
    expect(
      shareLabel(
        {'id': 'a', 'name': 'Documents', 'publisher': 'pc-a'},
        {'pc-a': 'Laptop'},
      ),
      'Documents · Laptop',
    );
    expect(
      shareLabel(
        {'id': 'b', 'name': 'Documents', 'publisher': 'pc-b'},
        {'pc-b': 'Server'},
      ),
      'Documents · Server',
    );
  });
  testWidgets('A late overview result cannot replace the selected page', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1400, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final api = FixtureTransport()..delayed = Completer<Json>();
    await tester.pumpWidget(SigmaDriveApp(api: api));
    await tester.pump();
    await tester.tap(find.text('설정').last);
    await tester.pumpAndSettle();
    api.delayed!.complete({
      'version': 'late',
      'profile_name': 'SHOULD_NOT_RENDER',
    });
    await tester.pumpAndSettle();
    expect(find.textContaining('SHOULD_NOT_RENDER'), findsNothing);
    expect(find.textContaining('표시 이름: 한글 장치'), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
  });
  testWidgets(
    'Drive form excludes profile storage and protects existing Z letter',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: DriveForm(
              connections: [
                {
                  'id': 'profile',
                  'name': 'PROFILE_MUST_NOT_APPEAR',
                  'preset': 'profile',
                },
              ],
              letters: ['Z:', 'Q:'],
            ),
          ),
        ),
      );
      expect(find.textContaining('파일 디스크용 저장소 연결이 없습니다.'), findsOneWidget);
      final save = tester.widget<FilledButton>(
        find.widgetWithText(FilledButton, '저장'),
      );
      expect(save.onPressed, isNull);
    },
  );
}
