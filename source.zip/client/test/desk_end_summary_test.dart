import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/desk_end_summary.dart';

const current = '0123456789abcdef0123456789abcdef';
const old = 'ffffffffffffffffffffffffffffffff';
Json row(String event, String code, {String session = current, dynamic exit}) =>
    {
      'event': event,
      'code': code,
      'session': session,
      'role': 'host',
      'exit_code': exit,
    };

void main() {
  test('late old connection stop cannot replace newest attempt', () {
    expect(
      recentDeskEnd([
        row('watchdog_stop', 'lease_expired', session: old),
        row('engine_start', 'begin'),
        row('watchdog_stop', 'engine_exited', session: old, exit: 9),
      ]),
      isNull,
    );
    final end = recentDeskEnd([
      row('engine_start', 'begin'),
      row('watchdog_stop', 'engine_exited', exit: 42),
      row('watchdog_stop', 'lease_expired', session: old),
    ]);
    expect(end?.code, 'engine_exited');
    expect(end?.exitCode, 42);
  });
  test('a current connection never shows an old ended status', () {
    expect(
      recentDeskEnd(
        [row('watchdog_stop', 'lease_expired')],
        sessions: [
          {'phase': 'active'},
        ],
      ),
      isNull,
    );
  });
  test(
    'raw errors, IDs and exit strings are never returned as diagnostics',
    () {
      final end = recentDeskEnd([
        row('watchdog_stop', 'secret token=example', exit: 'private value'),
      ]);
      expect(end?.code, 'unknown');
      expect(end?.exitCode, isNull);
      expect(
        recentDeskEnd([row('watchdog_stop', 'engine_exited', exit: -1)])
            ?.exitCode,
        isNull,
      );
      expect(
        recentDeskEnd([
          row('watchdog_stop', 'engine_exited', exit: 0x100000000),
        ])?.exitCode,
        isNull,
      );
      expect(
        recentDeskEnd([
          row('watchdog_stop', 'engine_exited', session: 'invalid'),
        ]),
        isNull,
      );
      expect(
        recentDeskEnd([row('authority_stop', 'no_decision')])?.label,
        isNot(contains('사용자가')),
      );
    },
  );
}
