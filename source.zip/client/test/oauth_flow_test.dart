import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/forms.dart';
import 'package:sigmadrive_flutter/oauth_flow.dart';

class AuthFixture implements CoreTransport {
  final finished = Completer<Json>();
  final requests = <String>[];
  bool cancelFails = false;
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async {
    requests.add(rpc);
    if (rpc == 'FinishSignIn') return finished.future;
    if (rpc == 'ManageProfile') {
      return {
        'export_data': '{"memberId":"member-fixture","connection":"profile-store","expiresAt":4102444800000}',
      };
    }
    if (rpc == 'TestConnection') {
      if (body.keys.any((key) => !{'id', 'remote_path'}.contains(key))) {
        throw StateError('Invalid TestConnection request');
      }
      return {'ok': true, 'can_write': true};
    }
    if (rpc == 'CancelSignIn') {
      if (cancelFails) throw StateError('network unavailable');
      if (!finished.isCompleted) finished.completeError(StateError('canceled'));
    }
    return {};
  }

  @override
  Future<void> openUrl(String url) async {}
}

void main() {
  test('Actual member session JSON has no signedIn=true field; expiry and binding are required', () {
    final member = <String, dynamic>{
      'memberId': 'm',
      'connection': 'c',
      'expiresAt': 2000,
    };
    expect(
      memberSessionReady(
        member,
        now: DateTime.fromMillisecondsSinceEpoch(1000),
      ),
      true,
    );
    expect(
      memberSessionReady(
        member,
        now: DateTime.fromMillisecondsSinceEpoch(2000),
      ),
      false,
    );
    expect(
      memberSessionReady({
        'signedIn': true,
      }, now: DateTime.fromMillisecondsSinceEpoch(1000)),
      false,
    );
    expect(
      memberSessionReady({
        ...member,
        'signedIn': false,
      }, now: DateTime.fromMillisecondsSinceEpoch(1000)),
      false,
    );
  });
  test('Account chooser preserves OAuth state and PKCE while retaining Google consent', () {
    final ms = Uri.parse(
      accountSelectionUrl(
        'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?state=unchanged&code_challenge=PKCE&nonce=N&prompt=login',
      ),
    );
    expect(ms.queryParameters['prompt'], 'select_account');
    expect(ms.queryParameters['state'], 'unchanged');
    expect(ms.queryParameters['code_challenge'], 'PKCE');
    expect(ms.queryParameters['nonce'], 'N');
    final google = Uri.parse(
      accountSelectionUrl(
        'https://accounts.google.com/o/oauth2/auth?prompt=consent&access_type=offline&state=S',
      ),
    );
    expect(google.queryParameters['prompt'], 'consent select_account');
    expect(google.queryParameters['access_type'], 'offline');
    expect(
      accountSelectionUrl('https://www.sigmadrive.net/'),
      'https://www.sigmadrive.net/',
    );
  });
  testWidgets(
    'Member login opens browser and checks membership without file-disk probe',
    (tester) async {
      final api = AuthFixture();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: OAuthFlowDialog(
              api: api,
              flow: {'id': 'member'},
              memberProfile: true,
            ),
          ),
        ),
      );
      expect(find.text('로그인 페이지 열기'), findsOneWidget);
      api.finished.complete({'id': 'profile-store', 'name': 'Member profile'});
      await tester.pumpAndSettle();
      expect(api.requests, ['FinishSignIn', 'ManageProfile']);
      expect(find.text('디스크 만들기'), findsNothing);
      expect(find.textContaining('회원 로그인 확인됨'), findsOneWidget);
    },
  );
  testWidgets('Prepared registration does not ask user for app secrets', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ConnectionForm(
            initialProvider: 'drive',
            registrations: {'drive'},
            providers: [
              {
                'id': 'drive',
                'name': 'Google Drive',
                'backend': 'drive',
                'auth': 'oauth',
                'fields': [
                  {
                    'key': 'client_id',
                    'label': 'CLIENT_ID_SHOULD_BE_HIDDEN',
                    'required': true,
                  },
                  {
                    'key': 'client_secret',
                    'label': 'SECRET_SHOULD_BE_HIDDEN',
                    'required': true,
                    'secret': true,
                  },
                ],
              },
            ],
          ),
        ),
      ),
    );
    expect(find.text('CLIENT_ID_SHOULD_BE_HIDDEN'), findsNothing);
    expect(find.text('SECRET_SHOULD_BE_HIDDEN'), findsNothing);
    expect(find.textContaining('준비된 앱 등록 설정'), findsOneWidget);
  });
  testWidgets(
    'OAuth wait survives 30 seconds and verifies storage automatically',
    (tester) async {
      final api = AuthFixture();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: OAuthFlowDialog(
              api: api,
              flow: {'id': 'fixture', 'url': 'https://accounts.google.com/'},
            ),
          ),
        ),
      );
      await tester.pump(const Duration(seconds: 45));
      expect(find.text('로그인 페이지 열기'), findsOneWidget);
      expect(api.requests, ['FinishSignIn']);
      api.finished.complete({'id': 'cloud', 'name': 'Cloud fixture'});
      await tester.pumpAndSettle();
      expect(api.requests, ['FinishSignIn', 'TestConnection']);
      expect(find.text('파일 쓰기 확인됨'), findsOneWidget);
      expect(
        tester
            .widget<FilledButton>(find.widgetWithText(FilledButton, '디스크 만들기'))
            .onPressed,
        isNotNull,
      );
    },
  );
  testWidgets('Failed cancellation is visible and can be retried', (
    tester,
  ) async {
    final api = AuthFixture()..cancelFails = true;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Builder(
            builder: (context) => TextButton(
              onPressed: () => showDialog<void>(
                context: context,
                builder: (_) =>
                    OAuthFlowDialog(api: api, flow: {'id': 'fixture'}),
              ),
              child: const Text('OPEN'),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('OPEN'));
    await tester.pump();
    await tester.tap(find.text('로그인 취소'));
    await tester.pump();
    expect(find.textContaining('로그인 취소를 확인하지 못했습니다.'), findsOneWidget);
    api.cancelFails = false;
    await tester.tap(find.text('로그인 취소'));
    await tester.pumpAndSettle();
    expect(find.text('로그인 취소'), findsNothing);
    expect(api.requests.where((r) => r == 'CancelSignIn').length, 2);
  });
}
