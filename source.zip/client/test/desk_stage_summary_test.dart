import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/desk_stage_summary.dart';

const _session = '0123456789abcdef0123456789abcdef';
Json row(String event, String code, int ms, {String session = _session}) => {
  'event': event,
  'code': code,
  'elapsed_ms': ms,
  'session': session,
  'role': 'host',
};
void main() {
  test('late previous worker stages cannot replace a newer start group', () {
    const previous = 'ffffffffffffffffffffffffffffffff';
    final stages = recentDeskStages([
      row('engine_start', 'begin', 0, session: previous),
      row('engine_stage_root', 'ok', 999, session: previous),
      row('engine_start', 'begin', 0),
      row('engine_stage_root', 'ok', 7),
      row('engine_stage_verify', 'ok', 1000, session: previous),
    ]);
    expect(stages.map((stage) => stage.event), ['engine_stage_root']);
    expect(stages.map((stage) => stage.elapsedMs), [7]);
  });
  test(
    'active runtime identity wins over late rows after its marker was evicted',
    () {
      const previous = 'ffffffffffffffffffffffffffffffff';
      final diagnostics = [
        row('engine_stage_root', 'ok', 7),
        row('engine_stage_verify', 'ok', 9),
        row('engine_stage_root', 'ok', 999, session: previous),
      ];
      final sessions = <Json>[
        {
          'role': 'host',
          'phase': 'active',
          'session': {'session_id': _session},
        },
      ];
      expect(
        recentDeskStages(
          diagnostics,
          sessions: sessions,
        ).map((stage) => stage.elapsedMs),
        [7, 9],
      );
      expect(
        recentDeskStages(
          diagnostics,
          sessions: [
            ...sessions,
            {
              'role': 'host',
              'phase': 'active',
              'session': {'session_id': previous},
            },
          ],
        ),
        isEmpty,
      );
      expect(
        recentDeskStages(
          diagnostics,
          sessions: [
            {
              'role': 'host',
              'phase': 'active',
              'session': {'session_id': 'malformed'},
            },
          ],
        ),
        isEmpty,
      );
    },
  );
  test('root and verify completed outside the latest eight remain visible from the bounded ring', () {
    final rows = [
      row('engine_start', 'begin', 0),
      row('engine_stage_root', 'begin', 0),
      row('engine_stage_root', 'ok', 23139),
      row('engine_stage_verify', 'ok', 17),
      for (var i = 0; i < 60; i++) row('startup_heartbeat', 'ok', i),
    ];
    final stages = recentDeskStages(rows);
    expect(stages.map((s) => s.event), [
      'engine_stage_root',
      'engine_stage_verify',
    ]);
    expect(stages.map((s) => s.elapsedMs), [23139, 17]);
  });
  test('latest attempt is isolated and a begin value is never presented as a zero success', () {
    final rows = [
      row('engine_start', 'begin', 0),
      row('engine_stage_root', 'ok', 999),
      row('engine_start', 'begin', 0),
      row('engine_stage_root', 'begin', 0),
      row('engine_stage_profile_main', 'failed', 5),
      row('engine_stage_verify', 'ok', 0),
    ];
    final stages = recentDeskStages(rows);
    expect(stages.map((s) => s.event), [
      'engine_stage_verify',
      'engine_stage_profile_main',
    ]);
    expect(stages.map((s) => s.code), ['ok', 'failed']);
    expect(stages.map((s) => s.elapsedMs), [0, 5]);
    final newer = [
      ...rows,
      row(
        'engine_start',
        'begin',
        0,
        session: 'ffffffffffffffffffffffffffffffff',
      ),
    ];
    expect(recentDeskStages(newer), isEmpty);
  });
  test('evicted marker still groups the latest attempt and rejects unknown or malformed rows', () {
    final stages = recentDeskStages([
      row(
        'engine_stage_root',
        'ok',
        888,
        session: 'ffffffffffffffffffffffffffffffff',
      ),
      row('engine_stage_root', 'failed', 12),
      row('engine_stage_profile_main', 'ok', 5),
      {...row('engine_stage_verify', 'ok', 1), 'elapsed_ms': '999'},
      row('engine_stage_profile_options', 'begin', 0),
      row('engine_stage_fake', 'ok', 77),
      row('engine_start_result', 'operation_failed', 22),
    ]);
    expect(stages.map((s) => s.elapsedMs), [12, 5]);
  });
  testWidgets(
    'collapsed details show only fixed event code duration and never private fields',
    (tester) async {
      final diagnostics = [
        row('engine_start', 'begin', 0),
        {
          ...row('engine_stage_root', 'ok', 23139),
          'readiness_nonce': 'synthetic-nonce',
          'path': 'synthetic-private-path',
          'sid': 'synthetic-sid',
          'key': 'synthetic-key',
        },
      ];
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(body: DeskStageSummary(diagnostics: diagnostics)),
        ),
      );
      expect(find.text('engine_stage_root · ok · 23139 ms'), findsNothing);
      await tester.tap(find.text('최근 엔진 시작 단계별 시간'));
      await tester.pumpAndSettle();
      expect(find.text('engine_stage_root · ok · 23139 ms'), findsOneWidget);
      for (final forbidden in [
        _session,
        'synthetic-nonce',
        'synthetic-private-path',
        'synthetic-sid',
        'synthetic-key',
      ]) {
        expect(find.textContaining(forbidden), findsNothing);
      }
    },
  );
}
