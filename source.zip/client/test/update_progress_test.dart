import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/main.dart';
import 'package:sigmadrive_flutter/update_progress.dart';

class UpdateFixture implements CoreTransport {
  Json package = {
    'id': 'client',
    'name': 'Test client',
    'version': '0.3.16',
    'state': 'checking',
  };
  @override
  Future<Json> call(String rpc, [Json body = const {}]) async => switch (rpc) {
    'GetStatus' => {'version': 'fixture', 'mounted_drives': 0},
    'GetSettings' => {'language': 'ko'},
    'ManageDownloads' => {
      'packages': [package],
    },
    _ => {},
  };
  @override
  Future<void> openUrl(String url) async {}
}

void main() {
  test('unknown target never falls back to the installed version or fake zero counters', () {
    final summary = updateProgressSummary({
      'version': '0.3.16',
      'state': 'downloading',
    });
    expect(summary, contains('새 버전 확인 중'));
    expect(summary, isNot(contains('새 버전 0.3.16')));
    expect(summary, contains('수신 — · 재사용 조각 — · 새 다운로드 조각 —'));
  });
  test('observed zero differs from counters that have not been reported', () {
    final summary = updateProgressSummary({
      'state': 'downloading',
      'stage': 'reuse_scan',
      'latest_version': '0.3.18',
      'received_bytes': 0,
      'reused_chunks': 0,
      'downloaded_chunks': 0,
    });
    expect(summary, contains('재사용 조각 확인 · 새 버전 0.3.18'));
    expect(summary, contains('수신 0 B · 재사용 조각 0 · 새 다운로드 조각 0'));
  });
  test(
    'post-download stages keep measured counters and signed target visible',
    () {
      for (final stage in [
        'package_verify',
        'extract',
        'candidate_verify',
        'stage_publish',
        'seed_save',
        'ready',
      ]) {
        final summary = updateProgressSummary({
          'state': stage == 'ready' ? 'ready' : 'downloading',
          'stage': stage,
          'latest_version': '0.3.18',
          'received_bytes': 13297729,
          'reused_chunks': 92,
          'downloaded_chunks': 80,
          'catalog_source': 'cdn.jsdelivr.net',
          'catalog_sequence': 19,
        });
        expect(summary, contains('새 버전 0.3.18'));
        expect(summary, contains('수신 12.7 MiB · 재사용 조각 92 · 새 다운로드 조각 80'));
        expect(summary, contains('서명 순번 19'));
      }
    },
  );
  test(
    'failed target remains unknown when catalog selection never completed',
    () {
      final summary = updateProgressSummary({
        'state': 'failed',
        'stage': 'checking',
        'version': '0.3.16',
        'error': 'synthetic error',
      });
      expect(summary, contains('실패 · 업데이트 정보 확인 · 새 버전 미확인'));
      expect(summary, contains('synthetic error'));
      expect(summary, isNot(contains('새 버전 0.3.16')));
    },
  );
  testWidgets(
    'real update card refreshes target, stage and counters before ready',
    (tester) async {
      tester.view.physicalSize = const Size(1400, 1600);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final fixture = UpdateFixture();
      await tester.pumpWidget(SigmaDriveApp(api: fixture));
      await tester.pumpAndSettle();
      await tester.tap(find.text('업데이트').first);
      await tester.pumpAndSettle();
      expect(find.text('Test client · 0.3.16'), findsOneWidget);
      expect(find.textContaining('새 버전 확인 중'), findsOneWidget);
      expect(find.textContaining('수신 —'), findsOneWidget);
      fixture.package = {
        ...fixture.package,
        'state': 'downloading',
        'stage': 'extract',
        'latest_version': '0.3.18',
        'received_bytes': 13297729,
        'reused_chunks': 92,
        'downloaded_chunks': 80,
        'catalog_source': 'cdn.jsdelivr.net',
        'catalog_sequence': 19,
      };
      await tester.pump(const Duration(seconds: 3));
      await tester.pumpAndSettle();
      expect(find.textContaining('파일 풀기·검증 · 새 버전 0.3.18'), findsOneWidget);
      expect(
        find.textContaining('수신 12.7 MiB · 재사용 조각 92 · 새 다운로드 조각 80'),
        findsOneWidget,
      );
      expect(find.text('안전하게 재시작·적용'), findsNothing);
      fixture.package = {
        ...fixture.package,
        'state': 'ready',
        'stage': 'ready',
      };
      await tester.pump(const Duration(seconds: 3));
      await tester.pumpAndSettle();
      expect(find.text('안전하게 재시작·적용'), findsOneWidget);
      expect(find.textContaining('업데이트 준비 완료 · 새 버전 0.3.18'), findsOneWidget);
      await tester.pumpWidget(const SizedBox());
    },
  );
}
