import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/desk_readiness_summary.dart';
import 'package:sigmadrive_flutter/desk_stage_summary.dart';

const _old = '0123456789abcdef0123456789abcdef';
const _current = 'fedcba9876543210fedcba9876543210';
Json _row(
  String code,
  Object ms, {
  String session = _current,
  String role = 'host',
}) => {
  'event': 'registration_readiness',
  'code': code,
  'elapsed_ms': ms,
  'session': session,
  'role': role,
};
Json _start({String session = _current, String role = 'host'}) => {
  'event': 'engine_start',
  'code': 'begin',
  'elapsed_ms': 0,
  'session': session,
  'role': role,
};
Json _session(String id, {String role = 'host', String phase = 'active'}) => {
  'role': role,
  'phase': phase,
  'session': {'session_id': id},
};
List<String> _codes(List<DeskReadinessTiming> rows) =>
    rows.map((row) => row.code).toList();

void main() {
  test(
    'latest host start isolates foreign and late previous readiness rows',
    () {
      final result = recentHostReadiness([
        _start(session: _old),
        _row('mode_legacy', 0, session: _old),
        _start(),
        _row('mode_ack', 0),
        _row('registration_observed', 31),
        _row('registration_observed', 999, session: _old),
        _row('proof_accepted', 999, session: _old),
        _row('proof_accepted', 34),
        _row('mode_legacy', 0, session: _old),
      ]);
      expect(_codes(result), [
        'mode_ack',
        'registration_observed',
        'proof_accepted',
      ]);
      expect(result.map((row) => row.elapsedMs), [0, 31, 34]);
    },
  );

  test(
    'current runtime host selects its group when the start marker is evicted',
    () {
      final rows = [
        _row('mode_ack', 0),
        _row('registration_observed', 12),
        _row('proof_accepted', 14),
        for (var i = 0; i < 61; i++)
          {
            'event': 'startup_heartbeat',
            'code': 'ok',
            'elapsed_ms': i,
            'session': _current,
            'role': 'host',
          },
      ];
      expect(rows, hasLength(64));
      expect(recentHostReadiness(rows), isEmpty);
      expect(
        _codes(recentHostReadiness(rows, sessions: [_session(_current)])),
        ['mode_ack', 'registration_observed', 'proof_accepted'],
      );
      expect(recentHostReadiness(rows, sessions: [_session(_old)]), isEmpty);
    },
  );

  test('viewer-only new attempt never falls back to an older host', () {
    final rows = [
      _start(session: _old),
      _row('mode_ack', 0, session: _old),
      _start(role: 'viewer'),
      _row('registration_observed', 23, session: _old),
      _row('proof_accepted', 25, session: _old),
    ];
    expect(recentHostReadiness(rows), isEmpty);
    expect(
      recentHostReadiness(rows, sessions: [_session(_current, role: 'viewer')]),
      isEmpty,
    );
  });

  test('new attempt with the same id resets prior timings rather than filling missing values', () {
    final result = recentHostReadiness([
      _start(),
      _row('mode_ack', 0),
      _row('registration_observed', 999),
      _row('proof_accepted', 1000),
      _start(),
      _row('mode_ack', 0),
      _row('registration_observed', 7),
    ]);
    expect(_codes(result), ['mode_ack', 'registration_observed']);
    expect(result.map((row) => row.elapsedMs), [0, 7]);
  });

  test('only exact fixed codes and bounded integer ms are admitted', () {
    final result = recentHostReadiness([
      _start(),
      _row('mode_ack', 0),
      for (final bad in [
        '123',
        -1,
        1.5,
        double.infinity,
        true,
        9007199254740992,
      ])
        _row('registration_observed', bad),
      _row('registration_observed ', 11),
      _row('MODE_ACK', 0),
      {
        ..._row('registration_observed', 14),
        'event': 'registration_readiness_unknown',
      },
      _row('registration_observed', 17, role: 'viewer'),
      _row('registration_observed', 18, session: 'not-a-session'),
      {
        ..._row('registration_observed', 19),
        'nonce': 'synthetic-private',
        'token': 'synthetic-private',
        'generation': 123,
        'pid': 7,
        'address': 'synthetic-private',
        'node': 'synthetic-private',
      },
      _row('proof_accepted', 21),
    ]);
    expect(_codes(result), [
      'mode_ack',
      'registration_observed',
      'proof_accepted',
    ]);
    expect(result.map((row) => row.elapsedMs), [0, 19, 21]);
  });

  test('legacy and inconsistent data cannot manufacture ACK success', () {
    expect(
      _codes(
        recentHostReadiness([
          _start(),
          _row('mode_legacy', 0),
          _row('registration_observed', 2),
          _row('proof_accepted', 3),
        ]),
      ),
      ['mode_legacy'],
    );
    expect(
      recentHostReadiness([
        _start(),
        _row('mode_ack', 0),
        _row('mode_legacy', 0),
      ]),
      isEmpty,
    );
    expect(
      recentHostReadiness([
        _start(),
        _row('mode_ack', 99),
        _row('registration_observed', 2),
      ]),
      isEmpty,
    );
    expect(
      _codes(
        recentHostReadiness([
          _start(),
          _row('mode_ack', 0),
          _row('proof_accepted', 4),
          _row('registration_observed', 3),
        ]),
      ),
      ['mode_ack', 'registration_observed'],
    );
    expect(
      _codes(
        recentHostReadiness([
          _start(),
          _row('mode_ack', 0),
          _row('registration_observed', 5),
          _row('proof_accepted', 4),
        ]),
      ),
      ['mode_ack', 'registration_observed'],
    );
  });

  test('ambiguous runtime and evicted mode do not select another session', () {
    final rows = [
      _start(),
      _row('mode_ack', 0),
      _row('registration_observed', 5),
    ];
    expect(
      recentHostReadiness(rows, sessions: [_session(_current), _session(_old)]),
      isEmpty,
    );
    expect(
      recentHostReadiness(
        rows,
        sessions: [
          {
            'role': 'host',
            'session': {'session_id': 'bad'},
          },
        ],
      ),
      isEmpty,
    );
    final evicted = [
      ...rows,
      for (var i = 0; i < 64; i++) _row('proof_accepted', 8),
    ];
    expect(
      recentHostReadiness(evicted, sessions: [_session(_current)]),
      isEmpty,
    );
  });

  testWidgets(
    'readiness stays under two collapsed diagnostic sections and omits identifiers',
    (tester) async {
      final diagnostics = [
        _start(),
        {
          ..._row('mode_ack', 0),
          'nonce': 'synthetic-nonce',
          'token': 'synthetic-token',
          'node': 'synthetic-node',
          'address': 'synthetic-address',
          'pid': 123456,
        },
        _row('registration_observed', 31),
        _row('proof_accepted', 34),
      ];
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: DeskStageSummary(
                diagnostics: diagnostics,
                sessions: [_session(_current)],
              ),
            ),
          ),
        ),
      );
      expect(find.text('최근 호스트 등록 준비'), findsNothing);
      expect(find.text('mode_ack · 0 ms'), findsNothing);
      await tester.tap(find.text('최근 엔진 시작 단계별 시간'));
      await tester.pumpAndSettle();
      expect(find.text('최근 호스트 등록 준비'), findsOneWidget);
      expect(find.text('mode_ack · 0 ms'), findsNothing);
      await tester.tap(find.text('최근 호스트 등록 준비'));
      await tester.pumpAndSettle();
      expect(find.text('mode_ack · 0 ms'), findsOneWidget);
      expect(find.text('registration_observed · 31 ms'), findsOneWidget);
      expect(find.text('proof_accepted · 34 ms'), findsOneWidget);
      for (final forbidden in [
        _current,
        _old,
        'synthetic-nonce',
        'synthetic-token',
        'synthetic-node',
        'synthetic-address',
        '123456',
      ]) {
        expect(find.textContaining(forbidden), findsNothing);
      }
      expect(find.byType(SelectableText), findsNothing);
      expect(find.byType(TextField), findsNothing);
    },
  );
}
