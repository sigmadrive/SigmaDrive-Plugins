import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/desk_transport_summary.dart';

Map<String, dynamic> observation(List<Object> rows, {int enabled = 1}) => {'schema': 1, 'available': true, 'tls_local': {'schema': 1, 'enabled': enabled, 'dropped': 0, 'rows': rows}};
Map<String, dynamic> envelope(Object value) => {'schema': 1, 'storage': 'pc_memory_only', 'identity_exported': false, 'active': [value], 'recent': []};
void main() {
  test('Shows only an explicitly enabled current session without mixing history', () {
    final raw = envelope(observation([[1, 1, 32000, 0], [2, 1, 150000, 3], [3, 1, 620000, 3], [4, 1, 770000, 3]]));
    raw['recent'] = [{'observations': observation([[1, 1, 999999, 0]])}];
    final result = localTransportTimings(raw);
    expect(result.length, 4);
    expect(result.map((r) => r.elapsedUs), [32000, 150000, 620000, 770000]);
    expect(localTransportTimings(envelope(observation([[1, 1, 32, 0]], enabled: 0))), isEmpty);
    raw['active'] = [observation([]), observation([])];
    expect(localTransportTimings(raw), isEmpty);
  });
  test('Rejects malformed, dropped or unbounded numbers and handles ended history', () {
    for (final row in [[9, 1, 1, 0], [1, 1, -1, 0], [1, 1, 60000001, 0], [1, 1, 1, 3], [1, 'secret', 1, 0]]) {
      expect(localTransportTimings(envelope(observation([row]))), isEmpty);
    }
    final ended = envelope(observation([]));
    ended['active'] = [];
    ended['recent'] = [{'observations': observation([[2, 1, 150000, 3]])}];
    expect(localTransportTimings(ended).single.elapsedUs, 150000);
    (ended['recent'] as List).last['observations']['tls_local']['dropped'] = 1;
    expect(localTransportTimings(ended), isEmpty);
  });
  testWidgets('Renders fixed labels and numbers, never arbitrary payload text', (tester) async {
    final raw = envelope(observation([[1, 1, 32000, 0]]));
    (raw['active'] as List).single['untrusted'] = 'private screen token';
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: DeskTransportSummary(observations: raw))));
    await tester.tap(find.text('PC 전용 통신 준비 시간'));
    await tester.pumpAndSettle();
    expect(find.text('공통 · OS 신뢰 저장소 준비 · 완료 · 32.0 ms'), findsOneWidget);
    expect(find.textContaining('private screen token'), findsNothing);
  });
}
