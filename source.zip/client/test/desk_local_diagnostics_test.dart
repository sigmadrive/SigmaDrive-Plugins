import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/desk_local_diagnostics.dart';

Json state({int code = 0, int pin = 1}) => {
  'schema': 1,
  'state_code': code,
  'remaining_ms': code == 1 ? 3600000 : 0,
  'pin_ready': pin,
};
Future<void> mount(
  WidgetTester tester,
  List<Json> calls, {
  Json? status,
  bool busy = false,
  bool active = false,
}) async {
  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(
        body: DeskLocalDiagnosticsCard(
          status: status ?? state(),
          busy: busy,
          sessionActive: active,
          onAction: (body) async {
            calls.add(body);
          },
        ),
      ),
    ),
  );
}

void main() {
  testWidgets(
    'default missing or unknown pin is off and cannot invoke consent',
    (tester) async {
      final calls = <Json>[];
      await mount(tester, calls, status: {});
      expect(
        tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
        isNull,
      );
      expect(calls, isEmpty);
      await mount(tester, calls, status: state(pin: 0));
      expect(find.textContaining('새 진단 엔진'), findsOneWidget);
      expect(
        tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
        isNull,
      );
    },
  );
  testWidgets('local notice shown before any RPC and cancel does not arm', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls);
    await tester.tap(find.byType(OutlinedButton));
    await tester.pumpAndSettle();
    expect(find.text(DeskLocalDiagnosticsCard.notice), findsOneWidget);
    expect(calls, isEmpty);
    await tester.tap(find.text('취소'));
    await tester.pumpAndSettle();
    expect(calls, isEmpty);
  });
  testWidgets('explicit local acceptance sends existing FFI action only once', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls);
    await tester.tap(find.byType(OutlinedButton));
    await tester.pumpAndSettle();
    await tester.tap(find.text('이 PC에서 1회 진단'));
    await tester.pumpAndSettle();
    expect(calls, [
      {'action': 'desk-diagnostics-arm', 'name': 'local_numeric_once'},
    ]);
    expect(
      calls.any(
        (c) => c['action'] == 'desk-enable' || c['action'] == 'desk-connect',
      ),
      false,
    );
  });
  testWidgets('pending cancel only clears local pending consent', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls, status: state(code: 1));
    expect(
      tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
      isNull,
    );
    await tester.tap(find.text('대기 진단 취소'));
    await tester.pumpAndSettle();
    expect(calls, [
      {'action': 'desk-diagnostics-cancel'},
    ]);
  });
  testWidgets('active session and busy state never arm a second grant', (
    tester,
  ) async {
    for (final busy in [false, true]) {
      final calls = <Json>[];
      await mount(tester, calls, busy: busy, active: !busy);
      expect(
        tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
        isNull,
      );
      expect(calls, isEmpty);
    }
  });
  testWidgets('expired status stays off and UI never displays private fields', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(
      tester,
      calls,
      status: {
        ...state(code: 3),
        'session': 'private-identity',
        'url': 'private-url',
      },
    );
    expect(find.textContaining('만료'), findsOneWidget);
    expect(find.textContaining('private-identity'), findsNothing);
    expect(find.textContaining('private-url'), findsNothing);
  });
}
