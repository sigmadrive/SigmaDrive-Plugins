import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sigmadrive_flutter/api/api.dart';
import 'package:sigmadrive_flutter/desk_local_diagnostics.dart';

Json state({int code = 0, int pin = 1, int? reason}) => {
  'schema': 1,
  'state_code': code,
  'remaining_ms': code == 1 ? 3600000 : 0,
  'pin_ready': pin,
  'reason_code': ?reason,
};
Future<void> mount(
  WidgetTester tester,
  List<Json> calls, {
  Json? status,
  bool busy = false,
  bool active = false,
}) async {
  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(
        body: DeskLocalDiagnosticsCard(
          status: status ?? state(),
          busy: busy,
          sessionActive: active,
          onAction: (body) async {
            calls.add(body);
          },
        ),
      ),
    ),
  );
}

void main() {
  testWidgets(
    'default missing or unknown pin is off and cannot invoke consent',
    (tester) async {
      final calls = <Json>[];
      await mount(tester, calls, status: {});
      expect(
        tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
        isNull,
      );
      expect(calls, isEmpty);
      await mount(tester, calls, status: state(pin: 0));
      expect(find.textContaining('새 진단 엔진'), findsOneWidget);
      expect(
        tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
        isNull,
      );
    },
  );
  testWidgets('local notice shown before any RPC and cancel does not arm', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls);
    await tester.tap(find.byType(OutlinedButton));
    await tester.pumpAndSettle();
    expect(find.text(DeskLocalDiagnosticsCard.notice), findsOneWidget);
    expect(calls, isEmpty);
    await tester.tap(find.text('취소'));
    await tester.pumpAndSettle();
    expect(calls, isEmpty);
  });
  testWidgets('explicit local acceptance sends existing FFI action only once', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls);
    await tester.tap(find.byType(OutlinedButton));
    await tester.pumpAndSettle();
    await tester.tap(find.text('이 PC에서 1회 진단'));
    await tester.pumpAndSettle();
    expect(calls, [
      {'action': 'desk-diagnostics-arm', 'name': 'local_numeric_once'},
    ]);
    expect(
      calls.any(
        (c) => c['action'] == 'desk-enable' || c['action'] == 'desk-connect',
      ),
      false,
    );
  });
  testWidgets('pending cancel only clears local pending consent', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls, status: state(code: 1));
    expect(
      tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
      isNull,
    );
    await tester.tap(find.text('대기 진단 취소'));
    await tester.pumpAndSettle();
    expect(calls, [
      {'action': 'desk-diagnostics-cancel'},
    ]);
  });
  testWidgets('active session and busy state never arm a second grant', (
    tester,
  ) async {
    for (final busy in [false, true]) {
      final calls = <Json>[];
      await mount(tester, calls, busy: busy, active: !busy);
      expect(
        tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
        isNull,
      );
      expect(calls, isEmpty);
    }
  });
  testWidgets('expired status stays off and UI never displays private fields', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(
      tester,
      calls,
      status: {
        ...state(code: 3),
        'session': 'private-identity',
        'url': 'private-url',
      },
    );
    expect(find.textContaining('만료'), findsOneWidget);
    expect(find.textContaining('private-identity'), findsNothing);
    expect(find.textContaining('private-url'), findsNothing);
  });
  testWidgets(
    'legacy absent reason and explicit normal reason keep consent local',
    (tester) async {
      final calls = <Json>[];
      for (final status in [state(), state(reason: 0)]) {
        await mount(tester, calls, status: status);
        expect(find.text('기본값은 진단 꺼짐입니다.'), findsOneWidget);
        expect(
          tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
          isNotNull,
        );
        expect(calls, isEmpty);
      }
    },
  );
  testWidgets(
    'context and security boundaries explain cancellation without a recording claim',
    (tester) async {
      final calls = <Json>[];
      for (final reason in [3, 4]) {
        await mount(tester, calls, status: state(reason: reason));
        expect(find.textContaining('환경 변경으로 1회 진단 동의가 취소'), findsOneWidget);
        expect(find.textContaining('현재 환경에서 새로 동의'), findsOneWidget);
        expect(find.textContaining('기록하지 않았'), findsNothing);
        expect(find.text('대기 진단 취소'), findsNothing);
        expect(calls, isEmpty);
        await mount(tester, calls, status: state(reason: reason), active: true);
        expect(
          tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
          isNull,
        );
      }
    },
  );
  testWidgets('consumed selection is not proof that engine records exist', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls, status: state(code: 2, reason: 0));
    expect(find.textContaining('접속 준비에 사용'), findsOneWidget);
    expect(find.textContaining('실제 기록 여부는 접속 결과'), findsOneWidget);
    expect(find.textContaining('기록 완료'), findsNothing);
    expect(find.textContaining('기록했습니다'), findsNothing);
    expect(calls, isEmpty);
  });
  testWidgets(
    'user cancellation and expiry remain separate from boundary cancellation',
    (tester) async {
      final calls = <Json>[];
      await mount(tester, calls, status: state(reason: 1));
      expect(find.textContaining('대기 중인 1회 진단 동의를 취소'), findsOneWidget);
      expect(find.textContaining('환경 변경'), findsNothing);
      await mount(tester, calls, status: state(code: 3, reason: 2));
      expect(find.textContaining('대기 동의가 만료'), findsOneWidget);
      expect(find.textContaining('환경 변경'), findsNothing);
      expect(calls, isEmpty);
    },
  );
  testWidgets(
    'unknown or malformed reasons fail shut without displaying raw values',
    (tester) async {
      final calls = <Json>[];
      for (final reason in [-1, 5, 3.0, null, true, 'private-reason']) {
        await mount(tester, calls, status: {...state(), 'reason_code': reason});
        expect(find.textContaining('상태를 확인할 수 없습니다'), findsOneWidget);
        expect(find.textContaining('private-reason'), findsNothing);
        expect(find.text('대기 진단 취소'), findsNothing);
        expect(
          tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
          isNull,
        );
        expect(calls, isEmpty);
      }
    },
  );
  testWidgets(
    'noninteger schema or pin and invalid remaining never enable diagnostics',
    (tester) async {
      final calls = <Json>[];
      for (final changed in [
        {'schema': 1.0},
        {'pin_ready': 1.0},
        {'remaining_ms': -1},
        {'remaining_ms': 1},
        {'remaining_ms': 3600001},
      ]) {
        await mount(tester, calls, status: {...state(), ...changed});
        expect(
          tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
          isNull,
        );
        expect(calls, isEmpty);
      }
    },
  );
  testWidgets(
    'contradictory state and reason never offer consent or pending cancellation',
    (tester) async {
      final calls = <Json>[];
      for (final status in [
        state(reason: 2),
        state(code: 1, reason: 3),
        state(code: 2, reason: 4),
        state(code: 3, reason: 0),
        state(code: 4, reason: 1),
      ]) {
        await mount(tester, calls, status: status);
        expect(find.textContaining('상태를 확인할 수 없습니다'), findsOneWidget);
        expect(find.text('대기 진단 취소'), findsNothing);
        expect(
          tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
          isNull,
        );
        expect(calls, isEmpty);
      }
    },
  );
  testWidgets('unavailable state stays off even if a pin flag is supplied', (
    tester,
  ) async {
    final calls = <Json>[];
    await mount(tester, calls, status: state(code: 4, reason: 0));
    expect(
      tester.widget<OutlinedButton>(find.byType(OutlinedButton)).onPressed,
      isNull,
    );
    expect(calls, isEmpty);
  });
}
