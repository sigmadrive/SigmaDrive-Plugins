param([Parameter(Mandatory=$true)][string]$Payload)
$ErrorActionPreference='Stop'
$taskSource=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskPayload=[IO.Path]::GetFullPath($Payload)
if(-not $taskPayload.StartsWith($taskSource+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Fresh source-local payload required'}
foreach($taskEntry in (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'license-data-manifest.json') -Raw|ConvertFrom-Json)){
 if($taskEntry.path -match '\.\.|\\|:' -or [IO.Path]::IsPathRooted($taskEntry.path)){throw 'Invalid license path'}
 $taskOriginal=Join-Path (Join-Path $PSScriptRoot 'license-data') $taskEntry.path
 if((Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskEntry.sha256){throw 'License data changed'}
 $taskDestination=Join-Path (Join-Path $taskPayload 'data/licenses') $taskEntry.path
 New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($taskDestination)) -Force|Out-Null
 Copy-Item -LiteralPath $taskOriginal -Destination $taskDestination -Force
}
