@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
set "CARGO_TARGET_DIR=S:\SigmaNode\_qa\desk-wgc-client-20261027\target"
set "SIGMA_CORE_SOURCE=S:\SigmaNode\_qa\desk-empty-frame-client-20261028\source\rust-core"
set "SIGMA_CORE_PREBUILT=1"
cargo test --release --lib --locked --offline --manifest-path S:\SigmaNode\_qa\desk-empty-frame-client-20261028\source\rust-core\Cargo.toml -- --skip desk_transport::tests::stopped_proxy_releases_owned_loopback_tcp_udp_without_network_or_engine > S:\SigmaNode\_qa\desk-empty-frame-client-20261028\combined-rust-tests-final.log 2>&1
if errorlevel 1 exit /b %errorlevel%
cargo build --release --locked --offline --manifest-path S:\SigmaNode\_qa\desk-empty-frame-client-20261028\source\rust-core\Cargo.toml --lib --bin sigma-core > S:\SigmaNode\_qa\desk-empty-frame-client-20261028\rust-build-final.log 2>&1
if errorlevel 1 exit /b %errorlevel%
cargo check --release --locked --offline --manifest-path S:\SigmaNode\_qa\desk-empty-frame-client-20261028\source\installer-rust\Cargo.toml > S:\SigmaNode\_qa\desk-empty-frame-client-20261028\installer-check-final.log 2>&1
if errorlevel 1 exit /b %errorlevel%
cd /d S:\SigmaNode\_qa\desk-empty-frame-client-20261028\source\client
call flutter build windows --release --no-pub > S:\SigmaNode\_qa\desk-empty-frame-client-20261028\windows-build-final.log 2>&1
exit /b %errorlevel%
