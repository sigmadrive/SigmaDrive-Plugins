@echo off
rem Use the recorded Rust/Flutter toolchain in an x64 Native Tools prompt.
set "SIGMA_SOURCE=%~dp0.."
if not defined CARGO_TARGET_DIR set "CARGO_TARGET_DIR=%SIGMA_SOURCE%\.runtime\rebuild-target"
cargo build --release --locked --manifest-path "%SIGMA_SOURCE%\rust-core\Cargo.toml" --lib --bin sigma-core
if errorlevel 1 exit /b %errorlevel%
set "SIGMA_CORE_SOURCE=%SIGMA_SOURCE%\rust-core"
set "SIGMA_CORE_PREBUILT=1"
cd /d "%SIGMA_SOURCE%\client"
call flutter pub get
if errorlevel 1 exit /b %errorlevel%
call flutter build windows --release --no-pub
exit /b %errorlevel%
