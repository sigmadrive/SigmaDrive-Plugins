param([string]$Version='0.3.6')
$ErrorActionPreference='Stop'
$taskRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$vendor=Join-Path $taskRoot 'vendor\dokany-2.3.1'
$provenance=Get-Content -Raw -LiteralPath (Join-Path $vendor 'provenance.json')|ConvertFrom-Json
foreach($item in @($provenance.dll,$provenance.msi)) {
  $file=Join-Path $vendor $item.file
  if((Get-Item -LiteralPath $file).Length -ne $item.bytes -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256){throw 'Pinned Dokany dependency changed'}
  if((Get-AuthenticodeSignature -LiteralPath $file).Status -ne 'Valid'){throw 'Upstream driver signature is not valid'}
}
if((Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'rust-core\Cargo.toml')) -notmatch ('version = "'+[regex]::Escape($Version)+'"')){throw 'Core version mismatch'}
& (Join-Path $PSScriptRoot 'Build.ps1')
if($LASTEXITCODE -ne 0){throw 'Product build failed'}
$env:CARGO_TARGET_DIR=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SigmaDriveRustBuild\target'
$out=Join-Path $taskRoot ('.runtime\rust-'+$Version)
New-Item -ItemType Directory -Path $out -Force|Out-Null
$package=Join-Path $out 'client.package'
if(Test-Path -LiteralPath $package){throw 'Immutable build artifact exists; use a new version or review the existing artifact'}
Push-Location -LiteralPath $taskRoot
try {
  node scripts/collect-rust-notices.mjs (Join-Path $taskRoot '.runtime\rust-build-final\client\build\windows\x64\runner\Release')
  if($LASTEXITCODE -ne 0){throw 'Upstream notice collection failed'}
  & (Join-Path $PSScriptRoot 'Stage-WindowsRuntime.ps1') -Payload (Join-Path $taskRoot '.runtime\rust-build-final\client\build\windows\x64\runner\Release')
  $result=& cargo run --manifest-path distribution/Cargo.toml --bin pack --release --locked -- (Join-Path $taskRoot '.runtime\rust-build-final\client\build\windows\x64\runner\Release') $package $Version
  if($LASTEXITCODE -ne 0){throw 'Package build failed'}
  [IO.File]::WriteAllText((Join-Path $out 'package-build.json'),($result -join "`n"),[Text.UTF8Encoding]::new($false))
  & (Join-Path $PSScriptRoot 'Build-RustBootstrap.ps1')
  if($LASTEXITCODE -ne 0){throw 'Rust bootstrap build failed'}
} finally {Pop-Location}
Write-Output $out
