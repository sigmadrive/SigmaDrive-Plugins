// Build/release tooling only. The delivered installer and updater are Rust.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const canonical=value=>Buffer.from(JSON.stringify(sort(value)));
function sort(v){if(Array.isArray(v))return v.map(sort);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,sort(v[k])]));return v;}
function assert(v,m){if(!v)throw Error(m);}
function writeNew(p,b){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'});}
function dpapi(bytes,protect){
  const action=protect?'Protect':'Unprotect';
  const script=`Add-Type -AssemblyName System.Security; $b=[Convert]::FromBase64String([Console]::In.ReadToEnd()); $o=[Security.Cryptography.ProtectedData]::${action}($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Out.Write([Convert]::ToBase64String($o))`;
  const r=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{input:bytes.toString('base64'),encoding:'utf8',windowsHide:true});
  assert(r.status===0,'Current Windows user key protection failed');
  return Buffer.from(r.stdout.trim(),'base64');
}
function keydir(){const d=path.join(process.env.LOCALAPPDATA,'SigmaDrive-ReleaseSigning','rust-direct-20261021');assert(!d.toLowerCase().startsWith(root.toLowerCase()+path.sep),'keys must be outside repository');fs.mkdirSync(d,{recursive:true});return d;}
const [action,...args]=process.argv.slice(2);
const expiry=days=>new Date(Date.now()+days*86400000).toISOString();
function envelope(signed,keys,ids){const bytes=canonical(signed);return {signatures:ids.map(keyid=>({keyid,sig:crypto.sign(null,bytes,crypto.createPrivateKey({key:Buffer.from(keys[keyid],'base64'),format:'der',type:'pkcs8'})).toString('hex')})),signed};}
if(action==='init'){
  const d=keydir(),store=path.join(d,'keys.dpapi');assert(!fs.existsSync(store),'Signing store already exists; never replace a published trust root');
  const acl=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',`$d=[IO.DirectoryInfo]::new([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${Buffer.from(d).toString('base64')}')));$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User;$a=[Security.AccessControl.DirectorySecurity]::new();$a.SetOwner($sid);$a.SetAccessRuleProtection($true,$false);$r=[Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow');$a.AddAccessRule($r);$d.SetAccessControl($a)`],{encoding:'utf8',windowsHide:true});
  assert(acl.status===0,'Private signing directory ACL could not be set');
  const privateKeys={},keys={},roles={};
  for(const [role,count,threshold] of [['root',3,2],['targets',3,2],['snapshot',1,1],['timestamp',1,1]]){
    const keyids=[];
    for(let i=0;i<count;i++){
      const pair=crypto.generateKeyPairSync('ed25519');
      const publicBytes=pair.publicKey.export({format:'der',type:'spki'}).subarray(-32);
      const key={keytype:'ed25519',keyval:{public:publicBytes.toString('hex')},scheme:'ed25519'};
      const id=hash(canonical(key));keys[id]=key;keyids.push(id);
      privateKeys[id]=pair.privateKey.export({format:'der',type:'pkcs8'}).toString('base64');
    }
    roles[role]={keyids,threshold};
  }
  const signed={_type:'root',version:1,spec_version:'1.0.31',consistent_snapshot:false,expires:expiry(365),keys,roles};
  const publicRoot=canonical(envelope(signed,privateKeys,roles.root.keyids.slice(0,2)));
  writeNew(store,dpapi(canonical(privateKeys),true));
  writeNew(path.join(d,'component-root.json'),publicRoot);
  // This root is for the new, unpublished Rust-only channel. Legacy roots and
  // catalogs are never edited by this tool.
  fs.writeFileSync(path.join(root,'distribution/public/component-root.json'),publicRoot);
  console.log(JSON.stringify({state:'new_rust_root_created',public_root_sha256:hash(publicRoot),private_keys_logged:false}));
}else if(action==='chunks'){
  const [artifact,out]=args;assert(path.isAbsolute(artifact)&&path.isAbsolute(out),'absolute artifact/output required');
  const fd=fs.openSync(artifact,'r'),chunks=[],fileHash=crypto.createHash('sha256');let offset=0;
  // Same Gear CDC boundaries as the native Rust delta reader.
  const mask=(1n<<64n)-1n,table=[];let x=0x7369676d61647276n;
  for(let i=0;i<256;i++){x=(x+0x9e3779b97f4a7c15n)&mask;let z=x;z=((z^(z>>30n))*0xbf58476d1ce4e5b9n)&mask;z=((z^(z>>27n))*0x94d049bb133111ebn)&mask;table.push(z^(z>>31n));}
  try{while(true){const buf=Buffer.alloc(1048576),n=fs.readSync(fd,buf,0,buf.length,offset);if(!n)break;let cut=n,h=0n;for(let i=0;i<n;i++){h=((h<<1n)+table[buf[i]])&mask;const j=i+1;if(j>=1048576||(j>=65536&&(h&((1n<<18n)-1n))===0n)){cut=j;break;}}
    const raw=buf.subarray(0,cut),wire=zlib.gzipSync(raw,{level:6,mtime:0}),wireHash=hash(wire),dest=path.join(out,'chunks/sha256',wireHash.slice(0,2),`${wireHash}.bin`);
    if(fs.existsSync(dest))assert(hash(fs.readFileSync(dest))===wireHash,'existing chunk changed');else writeNew(dest,wire);
    chunks.push({sha256:hash(raw),size:cut,wire_sha256:wireHash,wire_size:wire.length});fileHash.update(raw);offset+=cut;
  }}finally{fs.closeSync(fd);}
  assert(offset>0&&offset<=256*1048576,'package size budget');
  console.log(JSON.stringify({sha256:fileHash.digest('hex'),length:offset,chunks:{schema:'sigmadrive.chunks/v2',chunks}}));
}else if(action==='sign'){
  const [input,out]=args;const release=JSON.parse(fs.readFileSync(input));assert(/^\d+\.\d+\.\d+$/.test(release.version)&&/^[0-9a-f]{40}$/.test(release.commit),'release identity');assert(/^[0-9a-f]{64}$/.test(release.manifest_sha256),'signed manifest identity');
  const d=keydir(); const lock=fs.openSync(path.join(d,'signing.lock'),'wx');
  process.on('exit',()=>{fs.closeSync(lock);fs.unlinkSync(path.join(d,'signing.lock'));});
  const publicRoot=fs.readFileSync(path.join(d,'component-root.json'),'utf8');assert(publicRoot===fs.readFileSync(path.join(root,'distribution/public/component-root.json'),'utf8'),'embedded root mismatch');
  const keys=JSON.parse(dpapi(fs.readFileSync(path.join(d,'keys.dpapi')),false));const roles=JSON.parse(publicRoot).signed.roles;
  const ledger=path.join(d,'ledger.json'),old=fs.existsSync(ledger)?JSON.parse(fs.readFileSync(ledger)):{sequence:0};
  assert(Number.isSafeInteger(release.sequence)&&release.sequence>old.sequence,'catalog sequence must increase');assert(!fs.existsSync(out),'catalog output already exists; inspect instead of signing twice');
  const sign=(name,signed)=>canonical(envelope(signed,keys,roles[name].keyids.slice(0,roles[name].threshold))).toString();
  const custom={schema:3,product_id:'sigmadrive.flutter.rust',core_engine:'rust',ui_runtime:'flutter',version:release.version,os:'windows',arch:'amd64',format:'sigmadrive.package/v1',artifact_commit:release.commit,package_manifest_sha256:release.manifest_sha256,chunks:release.chunks};
  const targets=sign('targets',{_type:'targets',version:release.sequence,expires:expiry(30),targets:{'stable/windows-amd64/package.bin':{length:release.length,hashes:{sha256:release.sha256},custom}}});
  const desc=raw=>({version:release.sequence,length:Buffer.byteLength(raw),hashes:{sha256:hash(raw)}});
  const snapshot=sign('snapshot',{_type:'snapshot',version:release.sequence,expires:expiry(14),meta:{'targets.json':desc(targets)}});
  const timestamp=sign('timestamp',{_type:'timestamp',version:release.sequence,expires:expiry(7),meta:{'snapshot.json':desc(snapshot)}});
  // Reserve the sequence before publication. A failure can skip a sequence,
  // never cause two differing catalogs to reuse it.
  fs.writeFileSync(ledger,canonical({sequence:release.sequence,version:release.version,package_sha256:release.sha256}));
  writeNew(out,canonical({schema:'sigmadrive.catalog-bundle/v1',metadata:{'1.root.json':publicRoot,'timestamp.json':timestamp,'snapshot.json':snapshot,'targets.json':targets}}));
  console.log(JSON.stringify({state:'signed_not_published',sequence:release.sequence,version:release.version,keys_logged:false}));
}else throw Error('rust-release.mjs init | chunks <package> <artifact checkout> | sign <release.json> <catalog output>');
