// Read PE imports without loading or executing any product binary.
import fs from 'node:fs';import path from 'node:path';
const [mode,input]=process.argv.slice(2);
if(!['bootstrap','payload'].includes(mode)||!input)throw Error('bootstrap <exe> | payload <directory>');
const crt=/^(?:msvcp|vcruntime|concrt|vccorlib)\d.*\.dll$/i;
function imports(file){
 const b=fs.readFileSync(file);
 function u16(p){if(p<0||p+2>b.length)throw Error('Truncated PE');return b.readUInt16LE(p);}
 function u32(p){if(p<0||p+4>b.length)throw Error('Truncated PE');return b.readUInt32LE(p);}
 if(u16(0)!==0x5a4d)throw Error('Missing MZ');const pe=u32(0x3c);
 if(u32(pe)!==0x4550||u16(pe+4)!==0x8664)throw Error('Expected Windows amd64 PE');
 const count=u16(pe+6),optional=pe+24,optionalSize=u16(pe+20);
 if(count>96||u16(optional)!==0x20b||optionalSize<128)throw Error('Invalid PE32+ header');
 const sections=optional+optionalSize;
 function offset(rva){if(rva<u32(optional+60))return rva;for(let i=0;i<count;i++){const s=sections+i*40,va=u32(s+12),size=u32(s+16);if(rva>=va&&rva-va<size)return u32(s+20)+rva-va;}throw Error('PE RVA outside raw data');}
 function name(rva){const at=offset(rva);let end=at;while(end<b.length&&end-at<256&&b[end]!==0)end++;if(end===b.length||end-at===256)throw Error('Invalid DLL name');const s=b.subarray(at,end).toString('ascii');if(!/^[a-zA-Z0-9_.-]+\.(?:dll|drv)$/i.test(s))throw Error('Invalid import '+JSON.stringify(s)+' in '+path.basename(file));return s;}
 const result=[];
 for(const [index,stride,nameAt] of [[1,20,12],[13,32,4]]){
  const dir=optional+112+index*8;if(dir+8>optional+optionalSize)continue;
  const rva=u32(dir),size=u32(dir+4);if(!rva)continue;const start=offset(rva);
  for(let p=start;p+stride<=start+size;p+=stride){const n=u32(p+nameAt);if(!n)break;if(index===13&&u32(p)!==1)throw Error('Unsupported delay-import addressing');result.push(name(n));}
 }
 return [...new Set(result)];
}
if(mode==='bootstrap'){
 const deps=imports(input),bad=deps.filter(n=>crt.test(n)||/^api-ms-win-crt-/i.test(n));
 if(bad.length)throw Error('Bootstrap requires an installed runtime: '+bad.join(', '));
 console.log(JSON.stringify({mode,verified:true,imports:deps,externalCrtDependencies:0,payloadExecuted:false}));
}else{
 const files=fs.readdirSync(input),names=new Set(files.map(n=>n.toLowerCase())),checked=[];
 for(const f of files.filter(n=>/\.(exe|dll)$/i.test(n))){
  const deps=imports(path.join(input,f));for(const n of deps.filter(n=>crt.test(n))){if(/\d+d\.dll$/i.test(n)||!names.has(n.toLowerCase()))throw Error('Unresolved app-local runtime '+n+' required by '+f);}
  checked.push({file:f,crtImports:deps.filter(n=>crt.test(n))});
 }
 if(!checked.length)throw Error('No native payload');
 console.log(JSON.stringify({mode,verified:true,checked,payloadExecuted:false}));
}
