// Build evidence only. Never invokes a core, cloud API, installer or updater.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const candidate=process.argv[2];
if(!candidate)throw Error('Absolute candidate bundle directory required');
const folder=path.resolve(candidate);
const runtime=path.join(root,'.runtime')+path.sep;
if(!folder.startsWith(runtime))throw Error('Evidence candidate must stay in this workspace .runtime');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{
  if(e.isSymbolicLink())throw Error('Symlink in candidate/source tree');
  const p=path.join(dir,e.name);return e.isDirectory()?walk(p):[p];
});}
const forbidden=/^(sigmad|sigma-bridge|sigma-update|rclone|sigmadrive_bridge|SigmaDriveFlutter)\.(exe|dll)$/i;
const payload=walk(folder);
for(const p of payload)if(forbidden.test(path.basename(p)))throw Error('Legacy payload entry: '+p);
for(const name of ['sigmadrive_flutter.exe','sigmadrive_core.dll','flutter_windows.dll']){
  if(!fs.statSync(path.join(folder,name)).isFile())throw Error('Candidate missing '+name);
}
const locked=fs.readFileSync(path.join(root,'rust-core/Cargo.lock'),'utf8');
if(/^name = "(?:tonic|prost|prost-build|tonic-build|rclone)"$/m.test(locked))throw Error('Legacy forwarding dependency');
const cmake=fs.readFileSync(path.join(root,'client/windows/CMakeLists.txt'),'utf8');
if(!cmake.includes('sigma_rust_core')||cmake.includes('../../native'))throw Error('Incorrect Flutter build target');
const corePath=path.join(process.env.CARGO_TARGET_DIR||path.join(process.env.LOCALAPPDATA,'SigmaDriveRustBuild/target'),'release/sigmadrive_core.dll');
if(sha(fs.readFileSync(corePath))!==sha(fs.readFileSync(path.join(folder,'sigmadrive_core.dll'))))throw Error('Candidate core DLL is stale');
const sources=[...walk(path.join(root,'rust-core/src')),...walk(path.join(root,'rust-core/public')),...walk(path.join(root,'distribution/src')),...walk(path.join(root,'installer-rust/src')),...walk(path.join(root,'client/lib')),...walk(path.join(root,'client/windows/runner')),...walk(path.join(root,'vendor/opendal-service-onedrive-0.59.5')),...walk(path.join(root,'vendor/microsoft-vc-runtime-14.51.36231')),
  ...['rust-core/Cargo.toml','rust-core/Cargo.lock','distribution/Cargo.toml','distribution/Cargo.lock','distribution/public/component-root.json','installer-rust/Cargo.toml','installer-rust/Cargo.lock','rust-core/public/public-oauth.json','vendor/dokany-2.3.1/provenance.json','client/pubspec.yaml','client/pubspec.lock','client/windows/CMakeLists.txt','scripts/Build-RustBootstrap.ps1','scripts/Stage-WindowsRuntime.ps1','scripts/verify-windows-runtime.mjs','scripts/Prepare-RustPayload.ps1'].map(p=>path.join(root,p))]
  .sort().map(p=>({path:path.relative(root,p).replaceAll('\\','/'),sha256:sha(fs.readFileSync(p))}));
const sourceTime=Math.max(...walk(path.join(root,'rust-core/src')).map(p=>fs.statSync(p).mtimeMs));
if(sourceTime>fs.statSync(corePath).mtimeMs)throw Error('Rust source is newer than the built DLL');
const mirror=process.argv[3]?path.resolve(process.argv[3]):path.resolve(folder,'../../../../..');
for(const file of walk(path.join(root,'client/lib'))){
  const relative=path.relative(path.join(root,'client'),file);
  const copy=path.join(mirror,relative);
  if(!fs.existsSync(copy)||sha(fs.readFileSync(copy))!==sha(fs.readFileSync(file)))throw Error('Candidate Flutter source mirror differs: '+relative);
}
const output={schema:1,at:new Date().toISOString(),state:'BUILD_ONLY_NOT_ACCEPTANCE',architecture:'flutter-direct-rust-ffi',abi:2,
  coreVersion:fs.readFileSync(path.join(root,'rust-core/Cargo.toml'),'utf8').match(/^version = "([^"]+)"/m)[1],candidate:folder,sourceFingerprint:sha(Buffer.from(JSON.stringify(sources))),sources,
  payload:payload.sort().map(p=>({path:path.relative(folder,p).replaceAll('\\','/'),bytes:fs.statSync(p).size,sha256:sha(fs.readFileSync(p))})),
  testsExecuted:0,cloudOperations:0,remoteInstallations:0,productionPublication:false,
  legacyGoPayload:false,legacyBridgePayload:false,completion:JSON.parse(fs.readFileSync(path.join(root,'contracts/rust-core-completion.json'),'utf8'))};
const dest=process.argv[4]?path.resolve(process.argv[4]):path.join(root,'docs/RUST_CORE_BUILD_20261021.json');
if(!dest.startsWith(path.join(root,'docs')+path.sep))throw Error('Build evidence must remain in docs');
fs.writeFileSync(dest,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({state:output.state,sourceFingerprint:output.sourceFingerprint,files:output.payload.length,report:dest,acceptanceAllowed:output.completion.acceptance_allowed}));
