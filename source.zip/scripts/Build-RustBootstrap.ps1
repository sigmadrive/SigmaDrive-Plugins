param()
$ErrorActionPreference='Stop'
$taskRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskTarget=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SigmaDriveRustBuild\target'
$taskPreviousFlags=$env:RUSTFLAGS
try {
  # A downloader must start before any application-local VC runtime exists.
  $env:RUSTFLAGS='-C target-feature=+crt-static'
  cargo build --manifest-path (Join-Path $taskRoot 'installer-rust\Cargo.toml') --release --locked --target x86_64-pc-windows-msvc --target-dir $taskTarget
  if($LASTEXITCODE -ne 0){throw 'Standalone Rust bootstrap build failed'}
} finally {$env:RUSTFLAGS=$taskPreviousFlags}
$taskBuilt=Join-Path $taskTarget 'x86_64-pc-windows-msvc\release\SigmaDriveRustSetup.exe'
node (Join-Path $PSScriptRoot 'verify-windows-runtime.mjs') bootstrap $taskBuilt
if($LASTEXITCODE -ne 0){throw 'Bootstrap unexpectedly requires an installed C runtime'}
Copy-Item -LiteralPath $taskBuilt -Destination (Join-Path $taskTarget 'release\SigmaDriveRustSetup.exe') -Force
