param([Parameter(Mandatory=$true)][string]$Payload)
$ErrorActionPreference='Stop'
$taskRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskPayload=[IO.Path]::GetFullPath($Payload)
if(-not $taskPayload.StartsWith((Join-Path $taskRoot '.runtime\'),[StringComparison]::OrdinalIgnoreCase)){throw 'Fresh workspace payload required'}
$taskVendor=Join-Path $taskRoot 'vendor\microsoft-vc-runtime-14.51.36231'
$taskProvenance=Get-Content -LiteralPath (Join-Path $taskVendor 'provenance.json') -Raw | ConvertFrom-Json
foreach($taskFile in $taskProvenance.files){
  if($taskFile.file -notmatch '^[a-z0-9_]+\.dll$'){throw 'Invalid CRT inventory member'}
  $taskSource=Join-Path (Join-Path $taskVendor 'x64') $taskFile.file
  if((Get-Item -LiteralPath $taskSource).Length -ne $taskFile.bytes -or (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskFile.sha256){throw 'Pinned Microsoft runtime changed'}
  $taskSignature=Get-AuthenticodeSignature -LiteralPath $taskSource
  if($taskSignature.Status -ne 'Valid' -or $taskSignature.SignerCertificate.Subject -notmatch 'Microsoft'){throw 'Microsoft runtime signature invalid'}
  Copy-Item -LiteralPath $taskSource -Destination (Join-Path $taskPayload $taskFile.file) -Force
}
$taskNotices=Join-Path $taskPayload 'data\licenses\microsoft-vc-runtime'
New-Item -ItemType Directory -Path $taskNotices -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $taskVendor 'provenance.json') -Destination $taskNotices -Force
Copy-Item -LiteralPath (Join-Path $taskVendor 'NOTICE.txt') -Destination $taskNotices -Force
node (Join-Path $PSScriptRoot 'verify-windows-runtime.mjs') payload $taskPayload
if($LASTEXITCODE -ne 0){throw 'Application-local runtime dependency check failed'}
