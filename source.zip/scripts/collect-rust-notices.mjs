// Package upstream license/notice files as data, never execute upstream files.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const payload=path.resolve(process.argv[2]??'');
if(!payload.startsWith(path.join(root,'.runtime')+path.sep))throw Error('A fresh workspace payload is required');
const cache=path.join(process.env.USERPROFILE,'.cargo/registry/src');
const registries=fs.readdirSync(cache).map(n=>path.join(cache,n));
const lock=fs.readFileSync(path.join(root,'rust-core/Cargo.lock'),'utf8');
const index=[];
for(const block of lock.split('[[package]]').slice(1)){
 const name=block.match(/^\s*name = "([^"]+)"/m)?.[1],version=block.match(/^\s*version = "([^"]+)"/m)?.[1];
 if(!name||!version)continue;
 const localVendor=name==='opendal-service-onedrive'?path.join(root,'vendor',`${name}-${version}`):null;
 if(!block.includes('registry+')&&!localVendor)continue;
 const source=localVendor??registries.map(p=>path.join(p,`${name}-${version}`)).find(p=>fs.existsSync(p));if(!source)continue;
 const manifest=fs.readFileSync(path.join(source,'Cargo.toml'),'utf8');
 const files=[];
 for(const file of fs.readdirSync(source).filter(n=>/^(?:LICEN[CS]E|NOTICE|COPYRIGHT|SIGMADRIVE-PATCH)(?:$|[.-])/i.test(n))){
  const original=path.join(source,file),stat=fs.lstatSync(original);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>1048576)continue;
  const relative=`data/licenses/rust/${name}-${version}/${file}`,destination=path.join(payload,relative);
  fs.mkdirSync(path.dirname(destination),{recursive:true});fs.copyFileSync(original,destination);files.push(relative);
 }
 index.push({name,version,license:manifest.match(/^license = "([^"]+)"/m)?.[1]??null,repository:manifest.match(/^repository = "([^"]+)"/m)?.[1]??null,files});
}
const dest=path.join(payload,'data/licenses/rust-index.json');fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,JSON.stringify({schema:1,source:'Pinned Cargo.lock and cached upstream crate distributions',packages:index},null,2));
console.log(JSON.stringify({licensePackages:index.length,noticeFiles:index.reduce((n,p)=>n+p.files.length,0)}));
