use crate::download::wide;
use std::{
    ptr::{null, null_mut},
    sync::{
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver, Sender},
        Arc,
    },
};
use windows_sys::Win32::{
    Foundation::*,
    Graphics::Gdi::*,
    System::LibraryLoader::GetModuleHandleW,
    UI::{Controls::*, Input::KeyboardAndMouse::EnableWindow, WindowsAndMessaging::*},
};

enum Event {
    Progress(u32, String),
    Finished(std::result::Result<crate::outcome::InstallOutcome, String>),
}
struct State {
    status: HWND,
    bar: HWND,
    start: HWND,
    stop: HWND,
    font: HFONT,
    heading_font: HFONT,
    cancel: Arc<AtomicBool>,
    tx: Sender<Event>,
    rx: Receiver<Event>,
    running: bool,
    installing: bool,
    done: bool,
}
unsafe fn label(parent: HWND, text: &str, x: i32, y: i32, w: i32, h: i32, font: HFONT) -> HWND {
    let control = CreateWindowExW(
        0,
        wide("STATIC").as_ptr(),
        wide(text).as_ptr(),
        WS_CHILD | WS_VISIBLE,
        x,
        y,
        w,
        h,
        parent,
        null_mut(),
        GetModuleHandleW(null()),
        null(),
    );
    SendMessageW(control, WM_SETFONT, font as usize, 1);
    control
}
unsafe fn button(parent: HWND, text: &str, x: i32, y: i32, w: i32, id: usize, font: HFONT) -> HWND {
    let control = CreateWindowExW(
        0,
        wide("BUTTON").as_ptr(),
        wide(text).as_ptr(),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP,
        x,
        y,
        w,
        36,
        parent,
        id as HMENU,
        GetModuleHandleW(null()),
        null(),
    );
    SendMessageW(control, WM_SETFONT, font as usize, 1);
    control
}
unsafe extern "system" fn proc(window: HWND, msg: u32, wp: usize, lp: isize) -> isize {
    if msg == WM_CREATE {
        let font = CreateFontW(
            -16,
            0,
            0,
            0,
            400,
            0,
            0,
            0,
            1,
            0,
            0,
            5,
            0,
            wide("맑은 고딕").as_ptr(),
        );
        let heading_font = CreateFontW(
            -27,
            0,
            0,
            0,
            600,
            0,
            0,
            0,
            1,
            0,
            0,
            5,
            0,
            wide("맑은 고딕").as_ptr(),
        );
        label(
            window,
            "SigmaDrive Rust + Flutter 설치",
            28,
            24,
            480,
            44,
            heading_font,
        );
        label(window,"필요한 파일을 준비한 뒤 자동으로 설치합니다.\r\n이 Windows 사용자 전용이며, 로그인 시 자동 시작합니다.",30,82,500,54,font);
        let status = label(
            window,
            "준비되었습니다. 설치를 시작해 주세요.",
            30,
            159,
            500,
            72,
            font,
        );
        let bar = CreateWindowExW(
            0,
            wide("msctls_progress32").as_ptr(),
            null(),
            WS_CHILD | WS_VISIBLE,
            30,
            240,
            500,
            18,
            window,
            null_mut(),
            GetModuleHandleW(null()),
            null(),
        );
        SendMessageW(bar, PBM_SETRANGE32, 0, 100);
        let start = button(window, "설치", 314, 286, 104, 1, font);
        let stop = button(window, "닫기", 430, 286, 100, 2, font);
        let (tx, rx) = mpsc::channel();
        let state = Box::new(State {
            status,
            bar,
            start,
            stop,
            font,
            heading_font,
            cancel: Arc::new(AtomicBool::new(false)),
            tx,
            rx,
            running: false,
            installing: false,
            done: false,
        });
        SetWindowLongPtrW(window, GWLP_USERDATA, Box::into_raw(state) as isize);
        SetTimer(window, 1, 80, None);
        return 0;
    }
    let p = GetWindowLongPtrW(window, GWLP_USERDATA) as *mut State;
    if !p.is_null() {
        let s = &mut *p;
        match msg {
            WM_COMMAND => {
                match wp & 0xffff {
                    1 if !s.running => {
                        if s.done {
                            DestroyWindow(window);
                            return 0;
                        }
                        s.running = true;
                        s.cancel.store(false, Ordering::Relaxed);
                        EnableWindow(s.start, 0);
                        SetWindowTextW(s.stop, wide("중지").as_ptr());
                        let tx = s.tx.clone();
                        let cancel = s.cancel.clone();
                        std::thread::spawn(move || {
                            let result =
                                crate::run(crate::cache(), &cancel, false, None, &mut |p, t| {
                                    let _ = tx.send(Event::Progress(p, t.into()));
                                });
                            let _ = tx.send(Event::Finished(result));
                        });
                    }
                    2 => {
                        if s.running {
                            if !s.installing {
                                s.cancel.store(true, Ordering::Relaxed);
                                SetWindowTextW(
                                    s.status,
                                    wide(
                                        "중지하고 있습니다. 받은 파일은 다음 설치에 재사용됩니다.",
                                    )
                                    .as_ptr(),
                                );
                            }
                        } else {
                            DestroyWindow(window);
                        }
                    }
                    _ => {}
                }
                return 0;
            }
            WM_TIMER => {
                while let Ok(event) = s.rx.try_recv() {
                    match event {
                        Event::Progress(p, t) => {
                            SendMessageW(s.bar, PBM_SETPOS, p as usize, 0);
                            if !s.cancel.load(Ordering::Relaxed) {
                                SetWindowTextW(s.status, wide(&t).as_ptr());
                            }
                            s.installing = p >= 95;
                            EnableWindow(s.stop, if s.installing { 0 } else { 1 });
                        }
                        Event::Finished(result) => {
                            s.running = false;
                            s.installing = false;
                            EnableWindow(s.start, 1);
                            EnableWindow(s.stop, 1);
                            SetWindowTextW(s.stop, wide("닫기").as_ptr());
                            match result {
                                Ok(crate::outcome::InstallOutcome::Installed) => {
                                    s.done = true;
                                    SetWindowTextW(s.start, wide("완료").as_ptr());
                                }
                                Ok(crate::outcome::InstallOutcome::Deferred) => {
                                    SetWindowTextW(
                                        s.status,
                                        wide(crate::outcome::DEFERRED_MESSAGE).as_ptr(),
                                    );
                                    SetWindowTextW(s.start, wide("다시 확인").as_ptr());
                                }
                                Err(e) => {
                                    let text = if e.contains("cancelled") {
                                        "중지되었습니다. 설치를 누르면 이어서 진행합니다."
                                            .to_owned()
                                    } else {
                                        format!("설치를 완료하지 못했습니다. 다시 시도해 주세요.\r\n{e}")
                                    };
                                    SetWindowTextW(s.status, wide(&text).as_ptr());
                                    SetWindowTextW(s.start, wide("다시 시도").as_ptr());
                                }
                            }
                        }
                    }
                }
                return 0;
            }
            WM_CLOSE => {
                if s.running {
                    if !s.installing {
                        s.cancel.store(true, Ordering::Relaxed);
                        SetWindowTextW(
                            s.status,
                            wide("중지 중입니다. 잠시 후 닫을 수 있습니다.").as_ptr(),
                        );
                    }
                    return 0;
                }
                DestroyWindow(window);
                return 0;
            }
            WM_DESTROY => {
                KillTimer(window, 1);
                DeleteObject(s.font);
                DeleteObject(s.heading_font);
                drop(Box::from_raw(p));
                SetWindowLongPtrW(window, GWLP_USERDATA, 0);
                PostQuitMessage(0);
                return 0;
            }
            _ => {}
        }
    }
    DefWindowProcW(window, msg, wp, lp)
}
pub fn show() {
    unsafe {
        InitCommonControls();
        let instance = GetModuleHandleW(null());
        let class = wide("SigmaDriveFlutterPilotBootstrap1");
        let wc = WNDCLASSW {
            lpfnWndProc: Some(proc),
            hInstance: instance,
            lpszClassName: class.as_ptr(),
            hCursor: LoadCursorW(null_mut(), IDC_ARROW),
            hbrBackground: (COLOR_WINDOW + 1) as HBRUSH,
            ..std::mem::zeroed()
        };
        RegisterClassW(&wc);
        let w = CreateWindowExW(
            0,
            class.as_ptr(),
            wide("SigmaDrive Rust + Flutter 설치").as_ptr(),
            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            576,
            380,
            null_mut(),
            null_mut(),
            instance,
            null(),
        );
        if w.is_null() {
            return;
        }
        ShowWindow(w, SW_SHOW);
        UpdateWindow(w);
        let mut msg: MSG = std::mem::zeroed();
        while GetMessageW(&mut msg, null_mut(), 0, 0) > 0 {
            if IsDialogMessageW(w, &msg) == 0 {
                TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }
        }
    }
}
