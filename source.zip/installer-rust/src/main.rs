#![cfg_attr(not(test), windows_subsystem = "windows")]
mod outcome;
mod ui;
use sigmadrive_distribution::install;
pub use sigmadrive_distribution::{download, trust};
use std::{path::PathBuf, sync::atomic::AtomicBool};
fn cache() -> PathBuf {
    install::root()
        .expect("private install directory")
        .join("cache-v2")
}
fn run(
    _dir: PathBuf,
    cancel: &AtomicBool,
    download_only: bool,
    _stop_after: Option<usize>,
    notify: &mut dyn FnMut(u32, &str),
) -> trust::Result<outcome::InstallOutcome> {
    let result = (|| -> Result<outcome::InstallOutcome, Box<dyn std::error::Error>> {
        let root = install::root()?;
        notify(0, "서명된 설치 정보를 확인합니다.");
        let catalog = download::catalog(cancel)?;
        let prepared = install::prepare(&root, &catalog, cancel, notify)?;
        if download_only {
            println!("{}", prepared);
            return Ok(outcome::InstallOutcome::Deferred);
        }
        // One stable Rust launcher dispatches immutable version directories.
        let launcher = root.join("SigmaDrive.exe");
        if !launcher.is_file() {
            let current = std::env::current_exe()?;
            let mut input = std::fs::File::open(current)?;
            let mut output = std::fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&launcher)?;
            std::io::copy(&mut input, &mut output)?;
            output.sync_all()?;
        }
        if !install::core_idle()? {
            notify(
                95,
                "업데이트 준비 완료. 실행 중인 앱의 업데이트 메뉴 또는 다음 실행 때 적용합니다.",
            );
            return Ok(outcome::InstallOutcome::Deferred);
        }
        notify(95, "검증된 새 버전을 적용합니다.");
        install::apply_staged(&root)?;
        install::register_startup(&root, true)?;
        install::register_app(&root)?;
        install::launch_checked(&root, false)?;
        notify(100, "설치가 완료되었습니다.");
        Ok(outcome::InstallOutcome::Installed)
    })();
    result.map_err(|e| e.to_string())
}
fn message(error: &str) {
    unsafe {
        use windows_sys::Win32::UI::WindowsAndMessaging::{MessageBoxW, MB_ICONINFORMATION, MB_OK};
        MessageBoxW(
            std::ptr::null_mut(),
            download::wide(error).as_ptr(),
            download::wide("SigmaDrive").as_ptr(),
            MB_OK | MB_ICONINFORMATION,
        );
    }
}
fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    let result = (|| -> Result<bool, Box<dyn std::error::Error>> {
        let root = install::root()?;
        if args.iter().any(|s| s == "--apply-after-exit") {
            let at = args.iter().position(|s| s == "--apply-after-exit").unwrap();
            let pid = args.get(at + 1).ok_or("missing PID")?.parse()?;
            let stamp = args.get(at + 2).ok_or("missing creation stamp")?.parse()?;
            let ready = args.get(at + 3).map(String::as_str);
            install::wait_client_exit_ready(&root, pid, stamp, ready)?;
            if let Err(e) = install::apply_staged(&root) {
                message(&format!(
                    "새 버전을 적용하지 못해 기존 버전을 유지합니다.\n{e}"
                ));
            }
            install::launch_checked(&root, false)?;
            return Ok(true);
        }
        let installed = std::env::current_exe()? == root.join("SigmaDrive.exe");
        if installed && install::current(&root)?.is_some() {
            if root.join("rollback-pending.json").is_file() && root.join("previous.json").is_file()
            {
                install::rollback(&root)?;
                std::fs::remove_file(root.join("rollback-pending.json"))?;
            }
            if let Err(e) = install::apply_staged(&root) {
                message(&format!("업데이트를 보류하고 기존 버전을 유지합니다.\n{e}"));
            }
            install::launch_checked(&root, args.iter().any(|s| s == "--startup"))?;
            return Ok(true);
        }
        if args.iter().any(|s| s == "--download-only") {
            let r = run(cache(), &AtomicBool::new(false), true, None, &mut |_, _| {});
            r.map_err(|e| -> Box<dyn std::error::Error> { e.into() })?;
            return Ok(true);
        }
        Ok(false)
    })();
    match result {
        Ok(true) => {}
        Ok(false) => ui::show(),
        Err(e) => {
            message(&e.to_string());
            std::process::exit(1);
        }
    }
}
