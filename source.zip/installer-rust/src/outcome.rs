#[derive(Debug, PartialEq, Eq)]
pub enum InstallOutcome {
    Installed,
    Deferred,
}

pub const DEFERRED_MESSAGE: &str = "공유나 전송을 사용 중이라 업데이트를 보류했습니다.\r\n받은 파일은 보관됩니다. 작업을 마친 뒤 다시 확인하세요.";
